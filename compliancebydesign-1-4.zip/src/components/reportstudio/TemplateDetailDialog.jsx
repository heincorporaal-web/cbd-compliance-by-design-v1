import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2 } from "lucide-react";
import SectionEditor from "./SectionEditor";
import HelpLabel from "./HelpLabel";
import { useToast } from "@/components/ui/use-toast";
import { CATEGORY_OPTIONS, STATUS_OPTIONS, CLASSIFICATION_OPTIONS, OUTPUT_FORMAT_OPTIONS, SELECT_CLASS } from "@/lib/reportStudioUtils";

const emptyTemplate = () => ({
  template_id: "", name: "", category: "Governance", source_modules: [],
  audience: "", status: "Draft", classification: "Internal", output_formats: [],
  summary: "", scope_parameters: "", import_status: "", brand_policy: null,
});

export default function TemplateDetailDialog({ open, onClose, template, fields, canEdit, onSaved }) {
  const { toast } = useToast();
  const isNew = !template;
  const [form, setForm] = useState(emptyTemplate());
  const [sections, setSections] = useState([]);
  const [loadingSections, setLoadingSections] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (template) {
      setForm({ ...emptyTemplate(), ...template });
      loadSections(template.template_id);
    } else {
      setForm(emptyTemplate());
      setSections([]);
    }
  }, [open, template]);

  const loadSections = async (tid) => {
    if (!tid) { setSections([]); return; }
    setLoadingSections(true);
    try {
      const res = await base44.entities.TemplateSection.filter({ template_id: tid }, { sort: "order", limit: 500 });
      setSections((res.items || []).map((s) => ({ ...s, _state: "existing" })));
    } catch {
      setSections([]);
    } finally {
      setLoadingSections(false);
    }
  };

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const setBrand = (k, v) => setForm((f) => ({ ...f, brand_policy: { ...(f.brand_policy || {}), [k]: v } }));

  const addSection = () => {
    const order = sections.length ? Math.max(...sections.map((s) => s.order || 0)) + 1 : 1;
    setSections((arr) => [...arr, {
      _state: "new", _id: String(Date.now() + Math.random()),
      template_id: form.template_id, order, section_id: "", section_title: "",
      block_type: "narrative", primary_field_id: "", optional: false,
      visibility_rule: "", state: "Draft", source_contract: "", bindings: [],
    }]);
  };
  const updateSection = (id, patch) => setSections((arr) => arr.map((s) => (s._id || s.id) === id ? { ...s, ...patch } : s));
  const removeSection = (id) => setSections((arr) => arr.map((s) => (s._id || s.id) === id ? { ...s, _state: "deleted" } : s));

  const save = async () => {
    if (!form.template_id || !form.name) { toast({ title: "Template ID and Name are required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      let templateId = form.template_id;
      const payload = {
        template_id: form.template_id, name: form.name, category: form.category,
        source_modules: form.source_modules, audience: form.audience, status: form.status,
        classification: form.classification, output_formats: form.output_formats,
        summary: form.summary, scope_parameters: form.scope_parameters,
        import_status: form.import_status, brand_policy: form.brand_policy,
      };
      if (isNew) {
        const created = await base44.entities.ReportTemplate.create(payload);
        templateId = created.template_id;
      } else {
        await base44.entities.ReportTemplate.update(template.id, payload);
      }
      for (const s of sections) {
        const sPayload = {
          template_id: templateId, order: s.order, section_id: s.section_id,
          section_title: s.section_title, block_type: s.block_type,
          primary_field_id: s.primary_field_id, optional: s.optional,
          visibility_rule: s.visibility_rule, state: s.state,
          source_contract: s.source_contract, bindings: s.bindings || [],
        };
        if (s._state === "deleted") {
          if (s.id) await base44.entities.TemplateSection.delete(s.id);
        } else if (s._state === "new") {
          await base44.entities.TemplateSection.create(sPayload);
        } else {
          await base44.entities.TemplateSection.update(s.id, sPayload);
        }
      }
      toast({ title: "Template saved" });
      onSaved?.();
      onClose();
    } catch (e) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const visibleSections = sections.filter((s) => s._state !== "deleted");

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isNew ? "New Report Template" : `Edit ${template.template_id}`}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <div><HelpLabel help="Stable, unique identifier for this template. Used as the upsert key when seeding or importing. Example: RPT-09">Template ID</HelpLabel><Input value={form.template_id} onChange={(e) => set("template_id", e.target.value)} disabled={!isNew || !canEdit} placeholder="RPT-09" /></div>
            <div><HelpLabel help="Display name shown in the template list and on the rendered report. Example: Executive Governance Report">Name</HelpLabel><Input value={form.name} onChange={(e) => set("name", e.target.value)} disabled={!canEdit} /></div>
            <div><HelpLabel help="Report category, used to group and filter templates. Example: Governance, Risk, Compliance">Category</HelpLabel><select className={SELECT_CLASS} value={form.category} onChange={(e) => set("category", e.target.value)} disabled={!canEdit}>{CATEGORY_OPTIONS.map((c) => <option key={c}>{c}</option>)}</select></div>
            <div><HelpLabel help="Who the report is intended for. Example: Executive / Board, Process Owner">Audience</HelpLabel><Input value={form.audience} onChange={(e) => set("audience", e.target.value)} disabled={!canEdit} /></div>
            <div><HelpLabel help="Lifecycle status. Draft = still being authored, Active = ready to use, Retired = no longer used. Example: Active">Status</HelpLabel><select className={SELECT_CLASS} value={form.status} onChange={(e) => set("status", e.target.value)} disabled={!canEdit}>{STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}</select></div>
            <div><HelpLabel help="Information classification controlling who may view the rendered report. Example: Confidential, Internal, Public">Classification</HelpLabel><select className={SELECT_CLASS} value={form.classification} onChange={(e) => set("classification", e.target.value)} disabled={!canEdit}>{CLASSIFICATION_OPTIONS.map((c) => <option key={c}>{c}</option>)}</select></div>
            <div className="sm:col-span-2">
              <HelpLabel help="File formats the template can be rendered to. Example: DOCX, PDF, HTML">Output Formats</HelpLabel>
              <div className="flex gap-4 pt-1">
                {OUTPUT_FORMAT_OPTIONS.map((f) => (
                  <label key={f} className="flex items-center gap-1.5 text-sm">
                    <input type="checkbox" disabled={!canEdit} checked={(form.output_formats || []).includes(f)}
                      onChange={(e) => set("output_formats", e.target.checked ? [...(form.output_formats || []), f] : (form.output_formats || []).filter((x) => x !== f))} />
                    {f}
                  </label>
                ))}
              </div>
            </div>
            <div className="sm:col-span-2"><HelpLabel help="CBD modules the template draws data from, separated by semicolons. Example: Risk Register; Company; Controls">Source Modules (semicolon-separated)</HelpLabel><Input value={(form.source_modules || []).join("; ")} onChange={(e) => set("source_modules", e.target.value.split(";").map((s) => s.trim()).filter(Boolean))} disabled={!canEdit} /></div>
            <div className="sm:col-span-2"><HelpLabel help="Short description of the report contents, shown to help users pick the right template. Example: Quarterly summary of principal risks and mitigation actions.">Summary</HelpLabel><Textarea value={form.summary} onChange={(e) => set("summary", e.target.value)} disabled={!canEdit} rows={2} /></div>
            <div className="sm:col-span-2"><HelpLabel help="Parameters required to run the report, such as company or as-of date. Example: company={{company_id}};as_of={{report_date}}">Scope Parameters</HelpLabel><Input value={form.scope_parameters} onChange={(e) => set("scope_parameters", e.target.value)} disabled={!canEdit} /></div>
            <div className="sm:col-span-2"><HelpLabel help="Seed / schema-mapping status for this template. Example: Mapped, Unmapped - Base44 to resolve">Import Status</HelpLabel><Input value={form.import_status} onChange={(e) => set("import_status", e.target.value)} disabled={!canEdit} /></div>
          </div>

          <Card>
            <CardContent className="p-4 space-y-3">
              <h4 className="font-semibold text-sm">Brand Policy</h4>
              <div className="grid sm:grid-cols-2 gap-3">
                <div><HelpLabel className="text-xs" help="Brand profile to apply by default when rendering this report. Example: BRAND-COMPANY">Default Brand Profile</HelpLabel><Input value={form.brand_policy?.default_brand_profile_id || ""} onChange={(e) => setBrand("default_brand_profile_id", e.target.value)} disabled={!canEdit} /></div>
                <div><HelpLabel className="text-xs" help="Whether to inherit the company's default branding. Example: Yes, No">Use Company Defaults</HelpLabel><Input value={form.brand_policy?.use_company_defaults || ""} onChange={(e) => setBrand("use_company_defaults", e.target.value)} disabled={!canEdit} /></div>
                <div><HelpLabel className="text-xs" help="Where the company brand definition comes from. Example: CompanySetup">Company Brand Source</HelpLabel><Input value={form.brand_policy?.company_brand_source || ""} onChange={(e) => setBrand("company_brand_source", e.target.value)} disabled={!canEdit} /></div>
                <div><HelpLabel className="text-xs" help="What overrides are permitted over the company defaults. Example: Logo only">Allowed Override</HelpLabel><Input value={form.brand_policy?.allowed_override || ""} onChange={(e) => setBrand("allowed_override", e.target.value)} disabled={!canEdit} /></div>
                <div><HelpLabel className="text-xs" help="Brand tokens that cannot be overridden by this template. Example: brand.primary, brand.logo">Protected Tokens</HelpLabel><Input value={form.brand_policy?.protected_tokens || ""} onChange={(e) => setBrand("protected_tokens", e.target.value)} disabled={!canEdit} /></div>
                <div><HelpLabel className="text-xs" help="How branding applies when the report spans multiple companies. Example: Use parent brand">Multi-Company Rule</HelpLabel><Input value={form.brand_policy?.multi_company_rule || ""} onChange={(e) => setBrand("multi_company_rule", e.target.value)} disabled={!canEdit} /></div>
                <div><HelpLabel className="text-xs" help="Status of this brand policy. Example: Active, Draft">Policy Status</HelpLabel><Input value={form.brand_policy?.status || ""} onChange={(e) => setBrand("status", e.target.value)} disabled={!canEdit} /></div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-sm">Sections ({visibleSections.length})</h4>
              {canEdit && <Button size="sm" variant="outline" onClick={addSection}><Plus className="w-4 h-4 mr-1" /> Add Section</Button>}
            </div>
            {loadingSections && <p className="text-xs text-slate-500">Loading sections…</p>}
            <div className="space-y-2">
              {visibleSections.map((s) => (
                <SectionEditor key={s._id || s.id} section={s} fields={fields} canEdit={canEdit}
                  onChange={(patch) => updateSection(s._id || s.id, patch)} onRemove={() => removeSection(s._id || s.id)} />
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          {canEdit && <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save Template"}</Button>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}