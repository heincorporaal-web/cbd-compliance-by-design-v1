import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import HelpLabel, { HelpIcon } from "./HelpLabel";
import { Plus, Pencil, Palette, SwatchBook } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { STATUS_OPTIONS, OBLIGATION_OPTIONS, AUTHORITY_OPTIONS, OBLIGATION_STYLES, SELECT_CLASS } from "@/lib/reportStudioUtils";

export default function BrandingTab({ canEdit, reloadKey }) {
  const [profiles, setProfiles] = useState([]);
  const [tokens, setTokens] = useState([]);
  const [loading, setLoading] = useState(true);
  const [profDialog, setProfDialog] = useState(false);
  const [tokDialog, setTokDialog] = useState(false);
  const [activeProf, setActiveProf] = useState(null);
  const [activeTok, setActiveTok] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [p, t] = await Promise.all([
        base44.entities.BrandingProfile.filter({}, { sort: "brand_id", limit: 500 }),
        base44.entities.BrandToken.filter({}, { sort: "token_id", limit: 500 }),
      ]);
      setProfiles(p.items || []);
      setTokens(t.items || []);
    } catch { setProfiles([]); setTokens([]); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load, reloadKey]);

  return (
    <div className="space-y-5">
      {/* Profiles */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm flex items-center gap-1.5"><Palette className="w-4 h-4 text-slate-500" /> Branding Profiles</h3>
          {canEdit && <Button size="sm" variant="outline" onClick={() => { setActiveProf(null); setProfDialog(true); }}><Plus className="w-4 h-4 mr-1" /> New Profile</Button>}
        </div>
        {loading ? <p className="text-sm text-slate-500">Loading…</p> : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {profiles.map((p) => (
              <Card key={p.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => { setActiveProf(p); setProfDialog(true); }}>
                <CardContent className="p-4 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-mono text-slate-500">{p.brand_id}</p>
                    <Badge variant="outline" className={p.state === "Active" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"}>{p.state}</Badge>
                  </div>
                  <h4 className="font-semibold text-slate-900">{p.brand_name}</h4>
                  <p className="text-xs text-slate-500">Scope: {p.company_scope}</p>
                  <p className="text-xs text-slate-500">Source: {p.brand_source}</p>
                  <p className="text-xs text-slate-500">Inherit defaults: {p.inherit_company_defaults ? "Yes" : "No"}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Tokens */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm flex items-center gap-1.5"><SwatchBook className="w-4 h-4 text-slate-500" /> Brand Tokens</h3>
          {canEdit && <Button size="sm" variant="outline" onClick={() => { setActiveTok(null); setTokDialog(true); }}><Plus className="w-4 h-4 mr-1" /> New Token</Button>}
        </div>
        {loading ? <p className="text-sm text-slate-500">Loading…</p> : (
          <Card>
            <CardContent className="p-0 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                  <tr>
                    <th className="text-left p-2 font-medium">Token ID</th>
                    <th className="text-left p-2 font-medium">Description</th>
                    <th className="text-left p-2 font-medium">Type</th>
                    <th className="text-left p-2 font-medium">Obligation</th>
                    <th className="text-left p-2 font-medium">Authority</th>
                    <th className="p-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {tokens.map((t) => (
                    <tr key={t.id} className="border-t border-slate-100 hover:bg-slate-50">
                      <td className="p-2 font-mono text-xs">{t.token_id}</td>
                      <td className="p-2">{t.description}</td>
                      <td className="p-2 text-slate-600">{t.data_type}</td>
                      <td className="p-2"><Badge variant="outline" className={OBLIGATION_STYLES[t.obligation] || "bg-slate-100 text-slate-600"}>{t.obligation}</Badge></td>
                      <td className="p-2 text-slate-600">{t.authority}</td>
                      <td className="p-2 text-right">{canEdit && <Button size="icon" variant="ghost" onClick={() => { setActiveTok(t); setTokDialog(true); }}><Pencil className="w-4 h-4" /></Button>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        )}
      </div>

      <ProfileEditDialog open={profDialog} onClose={() => setProfDialog(false)} profile={activeProf} canEdit={canEdit} onSaved={load} />
      <TokenEditDialog open={tokDialog} onClose={() => setTokDialog(false)} token={activeTok} canEdit={canEdit} onSaved={load} />
    </div>
  );
}

function ProfileEditDialog({ open, onClose, profile, canEdit, onSaved }) {
  const { toast } = useToast();
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (!open) return;
    setForm(profile ? { ...profile } : { brand_id: "", brand_name: "", company_scope: "", brand_source: "", inherit_company_defaults: true, override_policy: "", presentation_rules: "", state: "Draft", schema_mapping: "" });
  }, [open, profile]);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const save = async () => {
    if (!form.brand_id || !form.brand_name) { toast({ title: "Brand ID and Name are required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (profile) await base44.entities.BrandingProfile.update(profile.id, form);
      else await base44.entities.BrandingProfile.create(form);
      toast({ title: "Profile saved" });
      onSaved?.(); onClose();
    } catch (e) { toast({ title: "Save failed", description: e.message, variant: "destructive" }); } finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{profile ? "Edit Branding Profile" : "New Branding Profile"}</DialogTitle></DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3">
          <div><HelpLabel help="Stable brand profile identifier, unique across profiles. Example: BRAND-COMPANY, BRAND-BOARD">Brand ID</HelpLabel><Input value={form.brand_id} onChange={(e) => set("brand_id", e.target.value)} disabled={!canEdit || !!profile} /></div>
          <div><HelpLabel help="Display name for the brand profile. Example: Company Brand, Board Report Brand">Brand Name</HelpLabel><Input value={form.brand_name} onChange={(e) => set("brand_name", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Applicable company scope. Example: Any, Group/parent reporting entity">Company Scope</HelpLabel><Input value={form.company_scope} onChange={(e) => set("company_scope", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Where the brand definition comes from. Example: CompanySetup">Brand Source</HelpLabel><Input value={form.brand_source} onChange={(e) => set("brand_source", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Profile lifecycle. Draft = still being authored, Active = ready to use, Retired = no longer used.">State</HelpLabel><select className={SELECT_CLASS} value={form.state} onChange={(e) => set("state", e.target.value)} disabled={!canEdit}>{STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}</select></div>
          <div><HelpLabel help="Schema mapping status for this profile.">Schema Mapping</HelpLabel><Input value={form.schema_mapping} onChange={(e) => set("schema_mapping", e.target.value)} disabled={!canEdit} /></div>
          <div className="sm:col-span-2"><HelpLabel help="What overrides are permitted over the company defaults.">Override Policy</HelpLabel><Input value={form.override_policy} onChange={(e) => set("override_policy", e.target.value)} disabled={!canEdit} /></div>
          <div className="sm:col-span-2"><HelpLabel help="Presentation rules: logo, palette, layout.">Presentation Rules</HelpLabel><Input value={form.presentation_rules} onChange={(e) => set("presentation_rules", e.target.value)} disabled={!canEdit} /></div>
          <div className="flex items-center gap-2 text-sm sm:col-span-2">
              <label className="flex items-center gap-2"><input type="checkbox" checked={!!form.inherit_company_defaults} onChange={(e) => set("inherit_company_defaults", e.target.checked)} disabled={!canEdit} /> Inherit company defaults</label>
              <HelpIcon help="Whether to inherit the company's default branding for this profile." />
            </div>
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Cancel</Button>{canEdit && <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>}</DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function TokenEditDialog({ open, onClose, token, canEdit, onSaved }) {
  const { toast } = useToast();
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (!open) return;
    setForm(token ? { ...token } : { token_id: "", description: "", data_type: "", existing_source: "", illustrative_source_alias: "", presentation_mapping: "", obligation: "Required", authority: "Authoritative", missing_value_handling: "", actual_field_mapping: "" });
  }, [open, token]);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const save = async () => {
    if (!form.token_id || !form.description) { toast({ title: "Token ID and Description are required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (token) await base44.entities.BrandToken.update(token.id, form);
      else await base44.entities.BrandToken.create(form);
      toast({ title: "Token saved" });
      onSaved?.(); onClose();
    } catch (e) { toast({ title: "Save failed", description: e.message, variant: "destructive" }); } finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{token ? "Edit Brand Token" : "New Brand Token"}</DialogTitle></DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3">
          <div><HelpLabel help="Stable token identifier. Example: company.name, brand.logo, brand.primary">Token ID</HelpLabel><Input value={form.token_id} onChange={(e) => set("token_id", e.target.value)} disabled={!canEdit || !!token} placeholder="company.name" /></div>
          <div><HelpLabel help="Token data type. Example: Text, HEX #RRGGBB, Image asset">Data Type</HelpLabel><Input value={form.data_type} onChange={(e) => set("data_type", e.target.value)} disabled={!canEdit} /></div>
          <div className="sm:col-span-2"><HelpLabel help="What the token represents. Example: Primary brand colour used on covers and headers">Description</HelpLabel><Input value={form.description} onChange={(e) => set("description", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Where the token value lives today. Example: CompanySetup">Existing Source</HelpLabel><Input value={form.existing_source} onChange={(e) => set("existing_source", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Illustrative source alias. Example: CompanySetup.primaryColor">Illustrative Source Alias</HelpLabel><Input value={form.illustrative_source_alias} onChange={(e) => set("illustrative_source_alias", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Required, Optional, or Policy-defined mandatory.">Obligation</HelpLabel><select className={SELECT_CLASS} value={form.obligation} onChange={(e) => set("obligation", e.target.value)} disabled={!canEdit}>{OBLIGATION_OPTIONS.map((o) => <option key={o}>{o}</option>)}</select></div>
          <div><HelpLabel help="Authoritative (the source of truth) or Derived (computed from another value).">Authority</HelpLabel><select className={SELECT_CLASS} value={form.authority} onChange={(e) => set("authority", e.target.value)} disabled={!canEdit}>{AUTHORITY_OPTIONS.map((o) => <option key={o}>{o}</option>)}</select></div>
          <div className="sm:col-span-2"><HelpLabel help="Where the token is used in the document. Example: cover, headers, charts">Presentation Mapping</HelpLabel><Input value={form.presentation_mapping} onChange={(e) => set("presentation_mapping", e.target.value)} disabled={!canEdit} /></div>
          <div className="sm:col-span-2"><HelpLabel help="Policy when the value is missing. Example: fallback colour, block if required">Missing Value Handling</HelpLabel><Input value={form.missing_value_handling} onChange={(e) => set("missing_value_handling", e.target.value)} disabled={!canEdit} /></div>
          <div className="sm:col-span-2"><HelpLabel help="Resolved CBD field mapping for this token.">Actual Field Mapping</HelpLabel><Input value={form.actual_field_mapping} onChange={(e) => set("actual_field_mapping", e.target.value)} disabled={!canEdit} /></div>
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Cancel</Button>{canEdit && <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>}</DialogFooter>
      </DialogContent>
    </Dialog>
  );
}