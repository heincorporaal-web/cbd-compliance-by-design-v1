import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import HelpLabel from "./HelpLabel";
import { Search, Plus, Pencil } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { CRITICALITY_STYLES, CRITICALITY_OPTIONS, SELECT_CLASS } from "@/lib/reportStudioUtils";

export default function QATestTab({ canEdit, reloadKey }) {
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [active, setActive] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await base44.entities.QATest.filter({}, { sort: "test_id", limit: 500 });
      setTests(res.items || []);
    } catch { setTests([]); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load, reloadKey]);

  const q = search.toLowerCase();
  const filtered = tests.filter((t) => !q || (t.test_id || "").toLowerCase().includes(q) || (t.scenario || "").toLowerCase().includes(q) || (t.category || "").toLowerCase().includes(q));

  return (
    <div className="space-y-3">
      <div className="flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tests…" className="pl-9" />
        </div>
        {canEdit && <Button size="sm" onClick={() => { setActive(null); setDialogOpen(true); }}><Plus className="w-4 h-4 mr-1" />New Test</Button>}
      </div>
      {loading ? <p className="text-sm text-slate-500 py-8 text-center">Loading…</p> : (
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="text-left p-2 font-medium">ID</th>
                  <th className="text-left p-2 font-medium">Category</th>
                  <th className="text-left p-2 font-medium">Scenario</th>
                  <th className="text-left p-2 font-medium">Expected Output</th>
                  <th className="text-left p-2 font-medium">Criticality</th>
                  <th className="p-2"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((t) => (
                  <tr key={t.id} className="border-t border-slate-100 hover:bg-slate-50 align-top">
                    <td className="p-2 font-mono text-xs">{t.test_id}</td>
                    <td className="p-2 text-slate-600">{t.category}</td>
                    <td className="p-2 max-w-[260px]">{t.scenario}</td>
                    <td className="p-2 max-w-[260px] text-slate-600">{t.expected_output}</td>
                    <td className="p-2"><Badge variant="outline" className={CRITICALITY_STYLES[t.criticality] || "bg-slate-100 text-slate-600"}>{t.criticality}</Badge></td>
                    <td className="p-2 text-right">{canEdit && <Button size="icon" variant="ghost" onClick={() => { setActive(t); setDialogOpen(true); }}><Pencil className="w-4 h-4" /></Button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
      <QATestEditDialog open={dialogOpen} onClose={() => setDialogOpen(false)} test={active} canEdit={canEdit} onSaved={load} />
    </div>
  );
}

function QATestEditDialog({ open, onClose, test, canEdit, onSaved }) {
  const { toast } = useToast();
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (!open) return;
    setForm(test ? { ...test } : { test_id: "", category: "", scenario: "", expected_output: "", criticality: "Mandatory" });
  }, [open, test]);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const save = async () => {
    if (!form.test_id || !form.scenario) { toast({ title: "Test ID and Scenario are required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (test) await base44.entities.QATest.update(test.id, form);
      else await base44.entities.QATest.create(form);
      toast({ title: "Test saved" });
      onSaved?.(); onClose();
    } catch (e) { toast({ title: "Save failed", description: e.message, variant: "destructive" }); } finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{test ? "Edit QA Test" : "New QA Test"}</DialogTitle></DialogHeader>
        <div className="grid gap-3">
          <div className="grid sm:grid-cols-2 gap-3">
            <div><HelpLabel help="Stable test identifier, unique across QA tests. Example: T16">Test ID</HelpLabel><Input value={form.test_id} onChange={(e) => set("test_id", e.target.value)} disabled={!canEdit || !!test} placeholder="T16" /></div>
            <div><HelpLabel help="Test importance: Mandatory, Recommended, or Optional.">Criticality</HelpLabel><select className={SELECT_CLASS} value={form.criticality} onChange={(e) => set("criticality", e.target.value)} disabled={!canEdit}>{CRITICALITY_OPTIONS.map((o) => <option key={o}>{o}</option>)}</select></div>
          </div>
          <div><HelpLabel help="Test category. Example: Company isolation, Zero vs unavailable, DOCX import">Category</HelpLabel><Input value={form.category} onChange={(e) => set("category", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Test scenario description: what is being checked. Example: Two companies cannot see each other's templates">Scenario</HelpLabel><Textarea value={form.scenario} onChange={(e) => set("scenario", e.target.value)} disabled={!canEdit} rows={3} /></div>
          <div><HelpLabel help="Expected output or pass condition for the test. Example: Each company sees only its own templates">Expected Output</HelpLabel><Textarea value={form.expected_output} onChange={(e) => set("expected_output", e.target.value)} disabled={!canEdit} rows={3} /></div>
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Cancel</Button>{canEdit && <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>}</DialogFooter>
      </DialogContent>
    </Dialog>
  );
}