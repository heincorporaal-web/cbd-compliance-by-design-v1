import React from "react";
import { HelpCircle } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

/**
 * Label with an inline help (?) tooltip. Renders help text (with examples)
 * in a ported tooltip so it is never clipped by the dialog's scroll area.
 */
export default function HelpLabel({ children, help, className, as = "label" }) {
  return (
    <TooltipProvider delayDuration={150}>
      <Label className={cn("flex items-center gap-1", className)}>
        {children}
        {help && (
          <Tooltip>
            <TooltipTrigger asChild>
              <button type="button" className="text-slate-400 hover:text-slate-600 focus:outline-none" aria-label="Field help">
                <HelpCircle className="w-3.5 h-3.5" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-[260px] leading-snug whitespace-normal text-left font-normal">
              {help}
            </TooltipContent>
          </Tooltip>
        )}
      </Label>
    </TooltipProvider>
  );
}

export function HelpIcon({ help, className }) {
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" className={cn("text-slate-400 hover:text-slate-600 focus:outline-none inline-flex align-middle", className)} aria-label="Field help">
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-[260px] leading-snug whitespace-normal text-left font-normal">
          {help}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}