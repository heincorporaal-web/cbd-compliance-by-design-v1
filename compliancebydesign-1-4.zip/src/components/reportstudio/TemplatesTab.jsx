import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Plus, Search, Layers, Upload } from "lucide-react";
import TemplateDetailDialog from "./TemplateDetailDialog";
import ImportDocxDialog from "./ImportDocxDialog";
import { CATEGORY_STYLES, STATUS_STYLES, CATEGORY_OPTIONS, SELECT_CLASS } from "@/lib/reportStudioUtils";

export default function TemplatesTab({ canEdit, reloadKey }) {
  const [templates, setTemplates] = useState([]);
  const [fields, setFields] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [active, setActive] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [t, f] = await Promise.all([
        base44.entities.ReportTemplate.filter({}, { sort: "template_id", limit: 500 }),
        base44.entities.ReportField.filter({}, { sort: "field_id", limit: 500 }),
      ]);
      setTemplates(t.items || []);
      setFields(f.items || []);
    } catch {
      setTemplates([]);
      setFields([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load, reloadKey]);

  const q = search.toLowerCase();
  const filtered = templates.filter((t) => {
    const matchCat = catFilter === "all" || t.category === catFilter;
    const matchSearch = !q || (t.name || "").toLowerCase().includes(q) || (t.template_id || "").toLowerCase().includes(q);
    return matchCat && matchSearch;
  });

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search templates…" className="pl-9" />
        </div>
        <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className={SELECT_CLASS + " w-auto"}>
          <option value="all">All categories</option>
          {CATEGORY_OPTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        {canEdit && (
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setImportOpen(true)}><Upload className="w-4 h-4 mr-1" /> Import DOCX</Button>
            <Button size="sm" onClick={() => { setActive(null); setDialogOpen(true); }}><Plus className="w-4 h-4 mr-1" /> New Template</Button>
          </div>
        )}
      </div>

      {loading ? (
        <p className="text-sm text-slate-500 py-8 text-center">Loading templates…</p>
      ) : filtered.length === 0 ? (
        <p className="text-sm text-slate-500 py-8 text-center">No templates found.</p>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((t) => (
            <Card key={t.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => { setActive(t); setDialogOpen(true); }}>
              <CardContent className="p-4 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs text-slate-500 font-mono">{t.template_id}</p>
                    <h3 className="font-semibold text-slate-900 truncate">{t.name}</h3>
                  </div>
                  <Badge variant="outline" className={STATUS_STYLES[t.status] || "bg-slate-100 text-slate-600"}>{t.status}</Badge>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Badge variant="outline" className={CATEGORY_STYLES[t.category] || "bg-slate-100 text-slate-700"}>{t.category}</Badge>
                  {(t.output_formats || []).map((f) => <Badge key={f} variant="outline" className="bg-slate-50 text-slate-600">{f}</Badge>)}
                </div>
                {t.audience && <p className="text-xs text-slate-500 truncate">Audience: {t.audience}</p>}
                {(t.source_modules || []).length > 0 && (
                  <div className="flex items-center gap-1 text-xs text-slate-500">
                    <Layers className="w-3 h-3 shrink-0" /> <span className="truncate">{t.source_modules.join(" · ")}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <TemplateDetailDialog open={dialogOpen} onClose={() => setDialogOpen(false)} template={active} fields={fields} canEdit={canEdit} onSaved={load} />
      <ImportDocxDialog open={importOpen} onClose={() => setImportOpen(false)} onImported={load} />
    </div>
  );
}