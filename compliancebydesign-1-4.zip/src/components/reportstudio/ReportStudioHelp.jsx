import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  FileText, Database, Palette, CheckCircle2, ClipboardCheck, Upload,
  Layers, BookOpen, ChevronDown, ChevronRight, ShieldCheck, RefreshCw,
} from "lucide-react";

function Section({ id, icon: Icon, title, children }) {
  return (
    <Card id={id} className="scroll-mt-24">
      <CardContent className="p-4 sm:p-5 space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
            <Icon className="w-4 h-4 text-slate-700" />
          </div>
          <h2 className="text-base font-semibold text-slate-900">{title}</h2>
        </div>
        <div className="space-y-2 text-sm text-slate-600 leading-relaxed pl-10">{children}</div>
      </CardContent>
    </Card>
  );
}

function Sub({ title, children }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-lg border border-slate-200 overflow-hidden">
      <button type="button" onClick={() => setOpen((o) => !o)} className="w-full flex items-center gap-2 px-3 py-2 text-left bg-slate-50 hover:bg-slate-100 transition-colors">
        {open ? <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />}
        <span className="font-medium text-slate-800 text-sm">{title}</span>
      </button>
      {open && <div className="px-3 py-3 space-y-2 text-sm text-slate-600 leading-relaxed bg-white">{children}</div>}
    </div>
  );
}

function Field({ name, desc }) {
  return (
    <div className="grid sm:grid-cols-[180px_1fr] gap-1 sm:gap-3 py-1.5 border-b border-slate-100 last:border-0">
      <div className="font-mono text-xs text-slate-800 font-semibold pt-0.5">{name}</div>
      <div className="text-xs text-slate-600">{desc}</div>
    </div>
  );
}

function Pill({ children }) {
  return <Badge variant="outline" className="bg-slate-50 text-slate-600 font-mono text-[10px]">{children}</Badge>;
}

const TOC = [
  { id: "overview", label: "Overview", icon: BookOpen },
  { id: "templates", label: "Templates", icon: FileText },
  { id: "sections", label: "Sections & blocks", icon: Layers },
  { id: "bindings", label: "Field bindings", icon: Database },
  { id: "registry", label: "Field Registry", icon: Database },
  { id: "branding", label: "Branding", icon: Palette },
  { id: "readiness", label: "Readiness gates", icon: CheckCircle2 },
  { id: "qa", label: "QA tests", icon: ClipboardCheck },
  { id: "import", label: "Import from DOCX", icon: Upload },
  { id: "permissions", label: "Permissions & re-seed", icon: ShieldCheck },
];

export default function ReportStudioHelp() {
  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-slate-800 to-slate-900 text-white border-0">
        <CardContent className="p-5 space-y-2">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            <h1 className="text-lg font-semibold">Report Centre — Help Guide</h1>
          </div>
          <p className="text-sm text-slate-200">
            The Report Centre (Report Template Studio) is where you author and govern reusable report templates,
            the field registry that feeds them, brand profiles, readiness gates and QA tests. This guide explains
            every part of the studio and how the pieces fit together.
          </p>
        </CardContent>
      </Card>

      <div className="flex flex-wrap gap-2">
        {TOC.map((t) => (
          <a key={t.id} href={`#${t.id}`} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-xs font-medium text-slate-700 transition-colors">
            <t.icon className="w-3.5 h-3.5" /> {t.label}
          </a>
        ))}
      </div>

      <Section id="overview" icon={BookOpen} title="Overview">
        <p>The Report Centre turns the data captured across the CBD modules into governed, repeatable documents. Rather than building each report by hand, you define a <strong>template</strong> once, break it into <strong>sections</strong>, and bind each section to one or more <strong>fields</strong> from the Field Registry. Branding, readiness gates and QA tests keep the output consistent and audit-ready.</p>
        <p>The studio is organised into five working tabs plus this help guide:</p>
        <ul className="list-disc pl-5 space-y-1">
          <li><strong>Templates</strong> — author and manage report templates and their sections.</li>
          <li><strong>Field Registry</strong> — the catalogue of fields available to bind into sections.</li>
          <li><strong>Branding</strong> — brand profiles and the brand tokens they expose.</li>
          <li><strong>Readiness</strong> — gates that must pass before a template is considered production-ready.</li>
          <li><strong>QA</strong> — test scenarios used to validate templates and company isolation.</li>
        </ul>
        <p className="text-xs text-slate-500 pt-1">Tip: each field label in the template editor carries a <span className="font-bold">?</span> icon — hover it for guidance and a worked example.</p>
      </Section>

      <Section id="templates" icon={FileText} title="Templates">
        <p>A template is the master definition of a report. Use <span className="font-semibold">+ New Template</span> to create one from scratch, or <span className="font-semibold">Import DOCX</span> to generate one from an existing Word document (see the Import section below).</p>
        <p>Each template card shows its ID, name, category, status, output formats and audience. Click a card to open the editor, where you set the template metadata and manage its sections.</p>
        <Sub title="Template fields">
          <Field name="Template ID" desc="Stable, unique identifier used as the upsert key when seeding or importing. Example: RPT-09. Cannot be changed after creation." />
          <Field name="Name" desc="Display name shown in the list and on the rendered report. Example: Executive Governance Report." />
          <Field name="Category" desc="Groups and filters templates. One of: Governance, Diagnostics, Capability, Process, Technology, Risk, Compliance, Other." />
          <Field name="Audience" desc="Who the report is intended for. Example: Executive / Board, Process Owner." />
          <Field name="Status" desc="Lifecycle: Draft (still being authored), Active (ready to render), Retired (no longer used)." />
          <Field name="Classification" desc="Information classification controlling who may view the rendered report: Public, Internal, Confidential, Restricted." />
          <Field name="Output Formats" desc="Formats the template can render to: DOCX, PDF, HTML. Select all that apply." />
          <Field name="Source Modules" desc="CBD modules the template draws data from, semicolon-separated. Example: Risk Register; Company; Controls." />
          <Field name="Summary" desc="Short description shown to help users pick the right template." />
          <Field name="Scope Parameters" desc="Parameters required to run the report. Example: company={{company_id}};as_of={{report_date}}." />
          <Field name="Import Status" desc="Seed / schema-mapping status. Example: Mapped, or Unmapped - Base44 to resolve." />
        </Sub>
        <Sub title="Brand policy (per template)">
          <p>Each template carries an optional brand policy that controls how branding is applied when the report is rendered.</p>
          <Field name="Default Brand Profile" desc="Brand profile to apply by default. Example: BRAND-COMPANY." />
          <Field name="Use Company Defaults" desc="Whether to inherit the company's default branding. Example: Yes, No." />
          <Field name="Company Brand Source" desc="Where the company brand definition comes from. Example: CompanySetup." />
          <Field name="Allowed Override" desc="What overrides are permitted over the company defaults. Example: Logo only." />
          <Field name="Protected Tokens" desc="Brand tokens that cannot be overridden by this template. Example: brand.primary, brand.logo." />
          <Field name="Multi-Company Rule" desc="How branding applies when the report spans multiple companies. Example: Use parent brand." />
          <Field name="Policy Status" desc="Status of this brand policy. Example: Active, Draft." />
        </Sub>
      </Section>

      <Section id="sections" icon={Layers} title="Sections & blocks">
        <p>A template is built from ordered <strong>sections</strong>. Each section becomes a block in the rendered report. Add sections with <span className="font-semibold">Add Section</span>, then expand a section to edit it.</p>
        <Sub title="Section fields">
          <Field name="Section ID" desc="Stable identifier, unique within the template. Example: RPT-01-S04." />
          <Field name="Order" desc="Render / display order within the template. Lower numbers render first." />
          <Field name="Section Title" desc="Heading shown in the rendered report." />
          <Field name="Block Type" desc="How the section renders — see the block types table below." />
          <Field name="Primary Field" desc="The main bound field for this section (from the Field Registry)." />
          <Field name="State" desc="Section lifecycle: Draft, Active, Retired." />
          <Field name="Visibility Rule" desc="When to show the section. Example: Show when data exists." />
          <Field name="Source Contract" desc="Optional reference to the source contract this section implements." />
          <Field name="Optional" desc="When ticked, the section is omitted if its data is missing rather than rendering an empty block." />
        </Sub>
        <Sub title="Block types">
          <div className="space-y-1.5">
            <div className="flex items-start gap-2"><Pill>narrative</Pill><span className="text-xs">A paragraph or body of text.</span></div>
            <div className="flex items-start gap-2"><Pill>kpi</Pill><span className="text-xs">A single key metric with a value and label.</span></div>
            <div className="flex items-start gap-2"><Pill>table</Pill><span className="text-xs">A rows-and-columns data table.</span></div>
            <div className="flex items-start gap-2"><Pill>chart</Pill><span className="text-xs">A chart visualisation (bar, line, pie, etc.).</span></div>
            <div className="flex items-start gap-2"><Pill>image</Pill><span className="text-xs">A single image or diagram.</span></div>
            <div className="flex items-start gap-2"><Pill>callout</Pill><span className="text-xs">A highlighted note, warning or insight box.</span></div>
            <div className="flex items-start gap-2"><Pill>page_break</Pill><span className="text-xs">Forces the next section onto a new page.</span></div>
            <div className="flex items-start gap-2"><Pill>list</Pill><span className="text-xs">A bulleted or numbered list.</span></div>
          </div>
        </Sub>
      </Section>

      <Section id="bindings" icon={Database} title="Field bindings">
        <p>Inside each section you add one or more <strong>bindings</strong> — the link between a section and a field in the registry, plus the rules for how that field's data is fetched, filtered and formatted.</p>
        <Sub title="Binding fields">
          <Field name="Field" desc="The registry field this binding pulls from (selected from the Field Registry)." />
          <Field name="Context Filter Template" desc="Filter template applied at render time. Example: company={{company_id}};as_of={{report_date}}." />
          <Field name="State Filter" desc="Restricts the records included by lifecycle state. Example: status=approved." />
          <Field name="Aggregate Rule" desc="How values are aggregated when the field holds a collection. Example: sum, count, avg." />
          <Field name="Formatting" desc="Display formatting applied to the value. Example: 0.0%, dd-MMM-yyyy." />
          <Field name="Approved Scope" desc="The scope the binding is approved to run within. Example: company-scoped." />
          <Field name="Validation Rule" desc="Rule the rendered value must satisfy. Example: required, max 100." />
          <Field name="Actual CBD Query" desc="The resolved CBD query or API path that supplies the data at render time." />
        </Sub>
        <p className="text-xs text-slate-500">A section with no bindings renders as static content (e.g. a narrative or page break). Data-driven blocks need at least one binding.</p>
      </Section>

      <Section id="registry" icon={Database} title="Field Registry">
        <p>The Field Registry is the catalogue of every field available to bind into template sections. Each field is defined once here and reused across many templates, so its source, type and null policy stay consistent.</p>
        <Sub title="Registry fields">
          <Field name="Field ID" desc="Stable, unique identifier used as the upsert key. Example: company.name, metric.risk_distinct_count." />
          <Field name="Friendly Name" desc="Human-readable name shown when picking fields." />
          <Field name="Source Module" desc="CBD module the field originates from. Example: Risk Register, Company." />
          <Field name="Data Type" desc="text, date, percentage, integer, number, collection, boolean, image, currency." />
          <Field name="Source Alias" desc="Short alias for the source module. Example: risk, company." />
          <Field name="Allowed Scope" desc="Scoping level: company-scoped, report-scoped, global." />
          <Field name="Requirement" desc="Required, Optional, or Conditional." />
          <Field name="Null Policy" desc="How missing values are handled. Example: N/A, Not assessed, empty table with caption." />
          <Field name="Mapping Status" desc="Whether the field is mapped to a CBD source yet. Example: Mapped, Unmapped - Base44 to resolve." />
          <Field name="Actual CBD Field / API" desc="The resolved CBD field path or API endpoint that supplies the value." />
          <Field name="Role Restriction" desc="Optional role-based access restriction for this field." />
        </Sub>
      </Section>

      <Section id="branding" icon={Palette} title="Branding">
        <p>The Branding tab governs how rendered reports look. It has two parts: <strong>Brand Profiles</strong> (a named set of branding rules, optionally scoped to a company) and <strong>Brand Tokens</strong> (the individual values — colours, logos, fonts — that a profile exposes).</p>
        <Sub title="Brand Profile fields">
          <Field name="Brand ID" desc="Stable profile identifier used as the upsert key. Example: BRAND-COMPANY, BRAND-BOARD." />
          <Field name="Brand Name" desc="Display name for the profile." />
          <Field name="Company Scope" desc="Applicable company scope. Example: Any, Group/parent reporting entity." />
          <Field name="Brand Source" desc="Where the brand definition comes from. Example: CompanySetup." />
          <Field name="Inherit Company Defaults" desc="Whether to inherit the company's default branding." />
          <Field name="Override Policy" desc="What overrides are permitted over the company defaults." />
          <Field name="Presentation Rules" desc="Logo, palette and layout rules." />
          <Field name="State" desc="Draft, Active, Retired." />
        </Sub>
        <Sub title="Brand Token fields">
          <Field name="Token ID" desc="Stable token identifier. Example: company.name, brand.logo, brand.primary." />
          <Field name="Description" desc="What the token represents." />
          <Field name="Data Type" desc="Text, HEX #RRGGBB, Image asset, etc." />
          <Field name="Existing Source" desc="Where the token value lives today. Example: CompanySetup." />
          <Field name="Presentation Mapping" desc="Where the token is used in the document — cover, headers, charts." />
          <Field name="Obligation" desc="Required, Optional, or Policy-defined mandatory." />
          <Field name="Authority" desc="Authoritative (source of truth) or Derived." />
          <Field name="Missing Value Handling" desc="Policy when the value is missing. Example: fallback colour, block if required." />
        </Sub>
      </Section>

      <Section id="readiness" icon={CheckCircle2} title="Readiness gates">
        <p>Readiness gates are the acceptance criteria a template must meet before it is considered production-ready. Each gate has a stage, a criterion, a weight, a type (Mandatory or Recommended) and a status you progress from <em>Not Started</em> through <em>In Progress</em> to <em>Complete</em> (or <em>Blocked</em>).</p>
        <p>Use gates to track work across the readiness stages — Discovery and reuse, Field registry, Template Studio — and to evidence that a template is safe to activate.</p>
        <Sub title="Gate fields">
          <Field name="Gate ID" desc="Stable identifier. Example: RD-01." />
          <Field name="Stage" desc="Readiness stage. Example: Discovery and reuse, Field registry, Template Studio." />
          <Field name="Criterion" desc="The acceptance condition that must be met." />
          <Field name="Weight" desc="Importance weight for the gate." />
          <Field name="Gate Type" desc="Mandatory or Recommended." />
          <Field name="Status" desc="Not Started, In Progress, Complete, Blocked." />
          <Field name="Owner" desc="Accountable owner." />
          <Field name="Due Date" desc="Target completion date." />
          <Field name="Evidence Link" desc="Link to evidence of completion." />
        </Sub>
      </Section>

      <Section id="qa" icon={ClipboardCheck} title="QA tests">
        <p>QA tests define the scenarios used to validate templates and confirm company isolation. Each test records a category, a scenario, the expected output and a criticality (Mandatory, Recommended, Optional).</p>
        <p>Run through the QA list before activating a template. Mandatory tests must pass; Recommended tests should pass; Optional tests are nice-to-have.</p>
        <Sub title="QA Test fields">
          <Field name="Test ID" desc="Stable identifier. Example: T01." />
          <Field name="Category" desc="Test category. Example: Company isolation, Zero vs unavailable, DOCX import." />
          <Field name="Scenario" desc="The test scenario description." />
          <Field name="Expected Output" desc="The pass condition / expected result." />
          <Field name="Criticality" desc="Mandatory, Recommended, or Optional." />
        </Sub>
      </Section>

      <Section id="import" icon={Upload} title="Import from DOCX">
        <p>Use <span className="font-semibold">Import DOCX</span> on the Templates tab to generate a template from an existing Word document. The importer reads the document structure and proposes a template you can review before saving.</p>
        <Sub title="How the import works">
          <ol className="list-decimal pl-5 space-y-1">
            <li>Choose a <Pill>.docx</Pill> file. It is uploaded <span className="italic">stored privately</span> to the app's private storage.</li>
            <li>The importer parses the document and maps its structure to a template and sections.</li>
            <li>You review the proposed template ID, name, category, status and detected sections, and edit any of them.</li>
            <li>On <span className="font-semibold">Create Template</span>, the template and its sections are saved to the registry.</li>
          </ol>
        </Sub>
        <Sub title="How structure is detected">
          <ul className="list-disc pl-5 space-y-1">
            <li><strong>Heading 1</strong> becomes the template name.</li>
            <li><strong>Heading 2 and deeper</strong> each become a section, titled from the heading text.</li>
            <li><strong>Tables</strong> are detected as <Pill>table</Pill> block sections.</li>
            <li><strong>Bullet / numbered lists</strong> are detected as <Pill>list</Pill> block sections.</li>
            <li><strong>Images</strong> are detected as <Pill>image</Pill> block sections.</li>
            <li>Remaining body paragraphs become <Pill>narrative</Pill> sections.</li>
          </ul>
        </Sub>
        <p className="text-xs text-slate-500">Tip: structure your source Word document with clear Heading 1 / Heading 2 styles so the importer can split it cleanly into sections.</p>
      </Section>

      <Section id="permissions" icon={ShieldCheck} title="Permissions & re-seed">
        <p>Editing (creating, updating, deleting) templates, sections, fields, brand profiles, brand tokens, readiness gates and QA tests is restricted to <strong>admins</strong>. Non-admin users can read and browse the studio.</p>
        <p>Admins see a <span className="font-semibold">Re-seed from config pack</span> button at the top of the page. This re-runs the starter-pack seeding, refreshing all studio records from the configuration pack. Use it to reset the studio to the canonical baseline, or to pull in updates after the config pack changes.</p>
        <div className="flex items-start gap-2 rounded-lg bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800">
          <RefreshCw className="w-4 h-4 shrink-0 mt-0.5" />
          <span>Re-seeding is idempotent — it upserts by stable ID, so it updates existing records rather than duplicating them. Records you added that are not in the config pack are left untouched.</span>
        </div>
      </Section>
    </div>
  );
}