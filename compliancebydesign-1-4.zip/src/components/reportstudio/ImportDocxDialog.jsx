import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import HelpLabel from "./HelpLabel";
import { Upload, Loader2, FileText, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { CATEGORY_OPTIONS, STATUS_OPTIONS, BLOCK_TYPE_OPTIONS, BLOCK_TYPE_LABELS, SELECT_CLASS } from "@/lib/reportStudioUtils";

const slug = (s) => "RPT-" + String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 14).replace(/-+$/g, "");

export default function ImportDocxDialog({ open, onClose, onImported }) {
  const { toast } = useToast();
  const fileRef = useRef(null);
  const [stage, setStage] = useState("idle"); // idle | uploading | parsing | preview
  const [file, setFile] = useState(null);
  const [form, setForm] = useState({ template_id: "", name: "", category: "Governance", status: "Draft", classification: "Internal" });
  const [sections, setSections] = useState([]);
  const [saving, setSaving] = useState(false);

  const reset = () => {
    setStage("idle"); setFile(null);
    setForm({ template_id: "", name: "", category: "Governance", status: "Draft", classification: "Internal" });
    setSections([]);
    if (fileRef.current) fileRef.current.value = "";
  };

  const onFile = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    setStage("uploading");
    try {
      const up = await base44.integrations.Core.UploadPrivateFile({ file: f });
      setStage("parsing");
      const res = await base44.functions.invoke("importTemplateFromDocx", { file_uri: up.file_uri, filename: f.name });
      const parsed = res.data?.parsed || res.parsed;
      if (!parsed) throw new Error(res.data?.error || "No parsed structure returned");
      const baseName = parsed.templateName || f.name.replace(/\.docx$/i, "");
      setForm({ template_id: slug(baseName), name: baseName, category: "Governance", status: "Draft", classification: "Internal" });
      setSections((parsed.sections || []).map((s, i) => ({
        order: s.order || i + 1, section_id: "", section_title: s.section_title,
        block_type: s.block_type, primary_field_id: "", optional: false,
        visibility_rule: "", state: "Draft", source_contract: "", bindings: [],
        content_preview: s.content_preview,
      })));
      setStage("preview");
    } catch (err) {
      toast({ title: "Import failed", description: err.message || String(err), variant: "destructive" });
      setStage("idle");
    }
  };

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const setSec = (i, patch) => setSections((arr) => arr.map((s, idx) => idx === i ? { ...s, ...patch } : s));
  const removeSec = (i) => setSections((arr) => arr.filter((_, idx) => idx !== i).map((s, idx) => ({ ...s, order: idx + 1 })));

  const save = async () => {
    if (!form.template_id || !form.name) { toast({ title: "Template ID and Name are required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      await base44.entities.ReportTemplate.create({
        template_id: form.template_id, name: form.name, category: form.category,
        status: form.status, classification: form.classification, source_modules: [],
        output_formats: ["DOCX"], summary: `Imported from ${file?.name || "DOCX"}`,
        scope_parameters: "", import_status: "Imported from DOCX", brand_policy: null,
      });
      const secPayloads = sections.map((s, i) => ({
        template_id: form.template_id, order: s.order || i + 1,
        section_id: s.section_id || `${form.template_id}-S${String(i + 1).padStart(2, "0")}`,
        section_title: s.section_title, block_type: s.block_type,
        primary_field_id: s.primary_field_id || "", optional: s.optional,
        visibility_rule: s.visibility_rule, state: s.state, source_contract: s.source_contract,
        bindings: s.bindings || [],
      }));
      if (secPayloads.length) await base44.entities.TemplateSection.bulkCreate(secPayloads);
      toast({ title: "Template imported", description: `${secPayloads.length} section${secPayloads.length !== 1 ? "s" : ""} created.` });
      onImported?.();
      reset();
      onClose();
    } catch (e) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) { reset(); onClose(); } }}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Import Template from DOCX</DialogTitle></DialogHeader>

        {stage !== "preview" ? (
          <div className="border-2 border-dashed border-slate-200 rounded-lg p-8 text-center">
            {stage === "idle" ? (
              <>
                <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-sm text-slate-500 mb-3">Select a .docx file. Heading 1 becomes the template name; Heading 2+ become sections. Tables, lists and images are detected automatically.</p>
                <Button onClick={() => fileRef.current?.click()}><FileText className="w-4 h-4 mr-2" /> Choose DOCX file</Button>
                <input ref={fileRef} type="file" accept=".docx" className="hidden" onChange={onFile} />
              </>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
                <p className="text-sm text-slate-600">{stage === "uploading" ? "Uploading file (stored privately)…" : "Parsing document structure…"}</p>
                {file && <p className="text-xs text-slate-400">{file.name}</p>}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-3">
              <div><HelpLabel help="Stable template identifier, auto-generated from the document name. Example: RPT-board-report">Template ID</HelpLabel><Input value={form.template_id} onChange={(e) => set("template_id", e.target.value)} /></div>
              <div><HelpLabel help="Display name for the template, detected from Heading 1. Example: Board Risk Report">Name</HelpLabel><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
              <div><HelpLabel help="Report category. Example: Governance, Risk, Compliance, Technology">Category</HelpLabel><select className={SELECT_CLASS} value={form.category} onChange={(e) => set("category", e.target.value)}>{CATEGORY_OPTIONS.map((c) => <option key={c}>{c}</option>)}</select></div>
              <div><HelpLabel help="Template lifecycle status. Draft, Active, or Retired.">Status</HelpLabel><select className={SELECT_CLASS} value={form.status} onChange={(e) => set("status", e.target.value)}>{STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}</select></div>
            </div>
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-sm">Detected Sections ({sections.length})</h4>
              <Badge variant="outline" className="bg-slate-50 text-slate-600 truncate max-w-[200px]">{file?.name}</Badge>
            </div>
            <div className="space-y-2 max-h-[42vh] overflow-y-auto">
              {sections.map((s, i) => (
                <div key={i} className="grid grid-cols-[2rem_1fr_8rem_2rem] gap-2 items-center">
                  <span className="text-xs text-slate-400 text-center">{s.order}</span>
                  <Input value={s.section_title} onChange={(e) => setSec(i, { section_title: e.target.value })} className="h-8" placeholder="Section title" title="Section title detected from the document heading" />
                  <select className={SELECT_CLASS + " h-8"} value={s.block_type} onChange={(e) => setSec(i, { block_type: e.target.value })} title="Render block type: narrative, table, chart, image, KPI, list, callout or page break">{BLOCK_TYPE_OPTIONS.map((b) => <option key={b} value={b}>{BLOCK_TYPE_LABELS[b] || b}</option>)}</select>
                  <Button size="icon" variant="ghost" onClick={() => removeSec(i)}><X className="w-4 h-4 text-rose-500" /></Button>
                </div>
              ))}
              {sections.length === 0 && <p className="text-xs text-slate-400">No sections detected — you can add them later in the editor.</p>}
            </div>
          </div>
        )}

        <DialogFooter>
          {stage === "preview" && (
            <>
              <Button variant="outline" onClick={() => { reset(); onClose(); }}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Create Template"}</Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}