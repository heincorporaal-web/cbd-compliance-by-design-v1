import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import HelpLabel from "./HelpLabel";
import { Search, Plus, Pencil } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { DATA_TYPE_OPTIONS, SCOPE_OPTIONS, REQUIREMENT_OPTIONS, SELECT_CLASS } from "@/lib/reportStudioUtils";

export default function FieldRegistryTab({ canEdit, reloadKey }) {
  const [fields, setFields] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [active, setActive] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await base44.entities.ReportField.filter({}, { sort: "field_id", limit: 500 });
      setFields(res.items || []);
    } catch { setFields([]); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load, reloadKey]);

  const q = search.toLowerCase();
  const filtered = fields.filter((f) => !q || (f.field_id || "").toLowerCase().includes(q) || (f.friendly_name || "").toLowerCase().includes(q) || (f.source_module || "").toLowerCase().includes(q));

  return (
    <div className="space-y-3">
      <div className="flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search fields…" className="pl-9" />
        </div>
        {canEdit && <Button size="sm" onClick={() => { setActive(null); setDialogOpen(true); }}><Plus className="w-4 h-4 mr-1" />New Field</Button>}
      </div>
      {loading ? <p className="text-sm text-slate-500 py-8 text-center">Loading…</p> : (
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="text-left p-2 font-medium">Field ID</th>
                  <th className="text-left p-2 font-medium">Friendly Name</th>
                  <th className="text-left p-2 font-medium">Source</th>
                  <th className="text-left p-2 font-medium">Type</th>
                  <th className="text-left p-2 font-medium">Scope</th>
                  <th className="text-left p-2 font-medium">Req.</th>
                  <th className="text-left p-2 font-medium">Mapping</th>
                  <th className="p-2"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((f) => (
                  <tr key={f.id} className="border-t border-slate-100 hover:bg-slate-50">
                    <td className="p-2 font-mono text-xs">{f.field_id}</td>
                    <td className="p-2">{f.friendly_name}</td>
                    <td className="p-2 text-slate-600">{f.source_module}</td>
                    <td className="p-2"><Badge variant="outline" className="bg-slate-50 text-slate-600">{f.data_type}</Badge></td>
                    <td className="p-2 text-slate-600">{f.allowed_scope}</td>
                    <td className="p-2 text-slate-600">{f.requirement}</td>
                    <td className="p-2 text-xs text-slate-500 truncate max-w-[160px]">{f.current_mapping_status}</td>
                    <td className="p-2 text-right">{canEdit && <Button size="icon" variant="ghost" onClick={() => { setActive(f); setDialogOpen(true); }}><Pencil className="w-4 h-4" /></Button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
      <FieldEditDialog open={dialogOpen} onClose={() => setDialogOpen(false)} field={active} canEdit={canEdit} onSaved={load} />
    </div>
  );
}

function FieldEditDialog({ open, onClose, field, canEdit, onSaved }) {
  const { toast } = useToast();
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (!open) return;
    setForm(field ? { ...field } : { field_id: "", friendly_name: "", source_module: "", data_type: "text", source_alias: "", allowed_scope: "company-scoped", requirement: "Required", null_policy: "", current_mapping_status: "", actual_cbd_field_or_api: "", role_restriction: "" });
  }, [open, field]);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const save = async () => {
    if (!form.field_id || !form.friendly_name) { toast({ title: "Field ID and Friendly Name are required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (field) await base44.entities.ReportField.update(field.id, form);
      else await base44.entities.ReportField.create(form);
      toast({ title: "Field saved" });
      onSaved?.(); onClose();
    } catch (e) { toast({ title: "Save failed", description: e.message, variant: "destructive" }); } finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{field ? "Edit Field" : "New Field"}</DialogTitle></DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3">
          <div><HelpLabel help="Stable field identifier, unique across the registry. Example: company.name, metric.risk_distinct_count">Field ID</HelpLabel><Input value={form.field_id} onChange={(e) => set("field_id", e.target.value)} disabled={!canEdit || !!field} placeholder="company.name" /></div>
          <div><HelpLabel help="Human-readable name shown in editors and bindings. Example: Company Name">Friendly Name</HelpLabel><Input value={form.friendly_name} onChange={(e) => set("friendly_name", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="CBD module the field originates from. Example: Risk Register, Company">Source Module</HelpLabel><Input value={form.source_module} onChange={(e) => set("source_module", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Short alias for the source module, used in bindings. Example: risk, company">Source Alias</HelpLabel><Input value={form.source_alias} onChange={(e) => set("source_alias", e.target.value)} disabled={!canEdit} /></div>
          <div><HelpLabel help="Field data type. Example: text, date, percentage, integer, number, collection, boolean, image, currency">Data Type</HelpLabel><select className={SELECT_CLASS} value={form.data_type} onChange={(e) => set("data_type", e.target.value)} disabled={!canEdit}>{DATA_TYPE_OPTIONS.map((o) => <option key={o}>{o}</option>)}</select></div>
          <div><HelpLabel help="Scoping level for the field. company-scoped, report-scoped, or global">Allowed Scope</HelpLabel><select className={SELECT_CLASS} value={form.allowed_scope} onChange={(e) => set("allowed_scope", e.target.value)} disabled={!canEdit}>{SCOPE_OPTIONS.map((o) => <option key={o}>{o}</option>)}</select></div>
          <div><HelpLabel help="Whether the field is Required, Optional, or Conditional in a binding.">Requirement</HelpLabel><select className={SELECT_CLASS} value={form.requirement} onChange={(e) => set("requirement", e.target.value)} disabled={!canEdit}>{REQUIREMENT_OPTIONS.map((o) => <option key={o}>{o}</option>)}</select></div>
          <div><HelpLabel help="Optional role-based access restriction for this field. Example: admin, risk_manager">Role Restriction</HelpLabel><Input value={form.role_restriction} onChange={(e) => set("role_restriction", e.target.value)} disabled={!canEdit} /></div>
          <div className="sm:col-span-2"><HelpLabel help="How to handle missing values. Example: N/A, Not assessed, empty table with caption">Null Policy</HelpLabel><Input value={form.null_policy} onChange={(e) => set("null_policy", e.target.value)} disabled={!canEdit} /></div>
          <div className="sm:col-span-2"><HelpLabel help="Mapping status. Example: Unmapped - Base44 to resolve, Mapped">Current Mapping Status</HelpLabel><Input value={form.current_mapping_status} onChange={(e) => set("current_mapping_status", e.target.value)} disabled={!canEdit} /></div>
          <div className="sm:col-span-2"><HelpLabel help="Resolved CBD field path or API endpoint that supplies the value at render time.">Actual CBD Field / API</HelpLabel><Input value={form.actual_cbd_field_or_api} onChange={(e) => set("actual_cbd_field_or_api", e.target.value)} disabled={!canEdit} /></div>
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Cancel</Button>{canEdit && <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>}</DialogFooter>
      </DialogContent>
    </Dialog>
  );
}