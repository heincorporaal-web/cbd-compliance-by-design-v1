import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import HelpLabel, { HelpIcon } from "./HelpLabel";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, Trash2, Plus } from "lucide-react";
import { BLOCK_TYPE_OPTIONS, STATUS_OPTIONS, BLOCK_TYPE_LABELS, SELECT_CLASS } from "@/lib/reportStudioUtils";

export default function SectionEditor({ section, fields, canEdit, onChange, onRemove }) {
  const [open, setOpen] = useState(false);
  const set = (k, v) => onChange({ [k]: v });
  const bindings = section.bindings || [];

  const addBinding = () => onChange({ bindings: [...bindings, { field_id: "", context_filter_template: "", state_filter: "", aggregate_rule: "", formatting: "", approved_scope: "", validation_rule: "", actual_cbd_query: "" }] });
  const updateBinding = (i, patch) => onChange({ bindings: bindings.map((b, idx) => idx === i ? { ...b, ...patch } : b) });
  const removeBinding = (i) => onChange({ bindings: bindings.filter((_, idx) => idx !== i) });

  return (
    <Card>
      <CardContent className="p-3 space-y-2">
        <div className="flex items-center gap-2">
          <button onClick={() => setOpen((o) => !o)} className="p-1 text-slate-400 hover:text-slate-700">
            {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
          <Badge variant="outline" className="bg-slate-50 text-slate-600 font-mono">{section.order ?? "—"}</Badge>
          <span className="font-medium text-sm flex-1 truncate">{section.section_title || section.section_id || "Untitled section"}</span>
          <Badge variant="outline" className="bg-slate-50 text-slate-600">{BLOCK_TYPE_LABELS[section.block_type] || section.block_type}</Badge>
          {bindings.length > 0 && <Badge variant="outline" className="bg-indigo-50 text-indigo-700">{bindings.length} binding{bindings.length > 1 ? "s" : ""}</Badge>}
          {canEdit && <Button size="icon" variant="ghost" onClick={onRemove}><Trash2 className="w-4 h-4 text-rose-500" /></Button>}
        </div>
        {open && (
          <div className="space-y-3 pl-7 border-l border-slate-100 ml-1">
            <div className="grid sm:grid-cols-2 gap-2">
              <div><HelpLabel className="text-xs" help="Stable identifier, unique within the template. Example: RPT-01-S04">Section ID</HelpLabel><Input value={section.section_id} onChange={(e) => set("section_id", e.target.value)} disabled={!canEdit} placeholder="RPT-01-S04" /></div>
              <div><HelpLabel className="text-xs" help="Render/display order within the template; lower numbers render first. Example: 4">Order</HelpLabel><Input type="number" value={section.order ?? ""} onChange={(e) => set("order", e.target.value === "" ? null : Number(e.target.value))} disabled={!canEdit} /></div>
            </div>
            <div><HelpLabel className="text-xs" help="Heading shown in the rendered report. Example: Principal Risk Summary">Section Title</HelpLabel><Input value={section.section_title} onChange={(e) => set("section_title", e.target.value)} disabled={!canEdit} /></div>
            <div className="grid sm:grid-cols-3 gap-2">
              <div><HelpLabel className="text-xs" help="How this section renders. Example: narrative, table, kpi, chart, callout">Block Type</HelpLabel><select className={SELECT_CLASS} value={section.block_type} onChange={(e) => set("block_type", e.target.value)} disabled={!canEdit}>{BLOCK_TYPE_OPTIONS.map((b) => <option key={b} value={b}>{BLOCK_TYPE_LABELS[b] || b}</option>)}</select></div>
              <div><HelpLabel className="text-xs" help="The main bound field for this section, from the Field Registry. Example: metric.risk_distinct_count">Primary Field</HelpLabel><select className={SELECT_CLASS} value={section.primary_field_id || ""} onChange={(e) => set("primary_field_id", e.target.value)} disabled={!canEdit}><option value="">—</option>{fields.map((f) => <option key={f.field_id} value={f.field_id}>{f.field_id}</option>)}</select></div>
              <div><HelpLabel className="text-xs" help="Section lifecycle. Draft = still being authored, Active = ready to use, Retired = no longer used.">State</HelpLabel><select className={SELECT_CLASS} value={section.state} onChange={(e) => set("state", e.target.value)} disabled={!canEdit}>{STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}</select></div>
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              <div><HelpLabel className="text-xs" help="When to show this section. Example: Show when data exists">Visibility Rule</HelpLabel><Input value={section.visibility_rule} onChange={(e) => set("visibility_rule", e.target.value)} disabled={!canEdit} /></div>
              <div><HelpLabel className="text-xs" help="Optional reference to the source contract this section implements.">Source Contract</HelpLabel><Input value={section.source_contract} onChange={(e) => set("source_contract", e.target.value)} disabled={!canEdit} /></div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <label className="flex items-center gap-2"><input type="checkbox" checked={!!section.optional} onChange={(e) => set("optional", e.target.checked)} disabled={!canEdit} /> Optional (omit when data missing)</label>
              <HelpIcon help="When ticked, the section is omitted if its data is missing, rather than rendering an empty block." />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <HelpLabel className="text-xs font-semibold" help="Links between this section and Field Registry fields, with rules for how data is fetched, filtered and formatted.">Bindings</HelpLabel>
                {canEdit && <Button size="sm" variant="ghost" onClick={addBinding}><Plus className="w-3.5 h-3.5 mr-1" />Add binding</Button>}
              </div>
              {bindings.length === 0 && <p className="text-xs text-slate-400">No field bindings.</p>}
              {bindings.map((b, i) => (
                <div key={i} className="rounded-md border border-slate-200 p-2 space-y-2 bg-slate-50/50">
                  <div className="space-y-1">
                    <HelpLabel className="text-xs" help="The registry field this binding pulls its data from.">Field</HelpLabel>
                    <div className="flex items-center gap-2">
                      <select className={SELECT_CLASS + " flex-1"} value={b.field_id} onChange={(e) => updateBinding(i, { field_id: e.target.value })} disabled={!canEdit}><option value="">Field…</option>{fields.map((f) => <option key={f.field_id} value={f.field_id}>{f.field_id}</option>)}</select>
                      {canEdit && <Button size="icon" variant="ghost" onClick={() => removeBinding(i)}><Trash2 className="w-3.5 h-3.5 text-rose-500" /></Button>}
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    <div><HelpLabel className="text-xs" help="Filter applied at render time. Example: company={{company_id}};as_of={{report_date}}">Context Filter Template</HelpLabel><Input value={b.context_filter_template} onChange={(e) => updateBinding(i, { context_filter_template: e.target.value })} disabled={!canEdit} placeholder="company={{company_id}};as_of={{report_date}}" /></div>
                    <div><HelpLabel className="text-xs" help="Restricts the records included by lifecycle state. Example: status=approved">State Filter</HelpLabel><Input value={b.state_filter} onChange={(e) => updateBinding(i, { state_filter: e.target.value })} disabled={!canEdit} placeholder="status=approved" /></div>
                    <div><HelpLabel className="text-xs" help="How values are aggregated when the field holds a collection. Example: sum, count, avg">Aggregate Rule</HelpLabel><Input value={b.aggregate_rule} onChange={(e) => updateBinding(i, { aggregate_rule: e.target.value })} disabled={!canEdit} placeholder="sum, count, avg" /></div>
                    <div><HelpLabel className="text-xs" help="Display formatting applied to the value. Example: 0.0%, dd-MMM-yyyy">Formatting</HelpLabel><Input value={b.formatting} onChange={(e) => updateBinding(i, { formatting: e.target.value })} disabled={!canEdit} placeholder="0.0%, dd-MMM-yyyy" /></div>
                    <div><HelpLabel className="text-xs" help="The scope the binding is approved to run within. Example: company-scoped">Approved Scope</HelpLabel><Input value={b.approved_scope} onChange={(e) => updateBinding(i, { approved_scope: e.target.value })} disabled={!canEdit} placeholder="company-scoped" /></div>
                    <div><HelpLabel className="text-xs" help="Rule the rendered value must satisfy. Example: required, max 100">Validation Rule</HelpLabel><Input value={b.validation_rule} onChange={(e) => updateBinding(i, { validation_rule: e.target.value })} disabled={!canEdit} placeholder="required, max 100" /></div>
                    <div><HelpLabel className="text-xs" help="Resolved CBD query or API path that supplies the data at render time.">Actual CBD Query</HelpLabel><Input value={b.actual_cbd_query} onChange={(e) => updateBinding(i, { actual_cbd_query: e.target.value })} disabled={!canEdit} placeholder="risk.distinct_count?company=…" /></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}