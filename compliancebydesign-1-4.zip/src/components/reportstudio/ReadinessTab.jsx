import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import HelpLabel from "./HelpLabel";
import { GATE_STATUS_STYLES, GATE_TYPE_OPTIONS, GATE_STATUS_OPTIONS, SELECT_CLASS } from "@/lib/reportStudioUtils";

export default function ReadinessTab({ canEdit, reloadKey }) {
  const { toast } = useToast();
  const [gates, setGates] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await base44.entities.ReadinessGate.filter({}, { sort: "gate_id", limit: 500 });
      setGates(res.items || []);
    } catch { setGates([]); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load, reloadKey]);

  const updateStatus = async (gate, status) => {
    setGates((arr) => arr.map((g) => g.id === gate.id ? { ...g, status } : g));
    try {
      await base44.entities.ReadinessGate.update(gate.id, { status });
    } catch (e) {
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
      load();
    }
  };

  const updateField = async (gate, field, value) => {
    setGates((arr) => arr.map((g) => g.id === gate.id ? { ...g, [field]: value } : g));
    try {
      await base44.entities.ReadinessGate.update(gate.id, { [field]: value });
    } catch (e) {
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
      load();
    }
  };

  const stages = [];
  const byStage = {};
  gates.forEach((g) => {
    const st = g.stage || "Unstaged";
    if (!byStage[st]) { byStage[st] = []; stages.push(st); }
    byStage[st].push(g);
  });

  const completed = gates.filter((g) => g.status === "Complete").length;
  const pct = gates.length ? Math.round((completed / gates.length) * 100) : 0;

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 flex items-center gap-4">
          <div className="flex-1">
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 transition-all" style={{ width: `${pct}%` }} />
            </div>
          </div>
          <Badge variant="outline" className="bg-emerald-50 text-emerald-700">{completed}/{gates.length} gates complete ({pct}%)</Badge>
        </CardContent>
      </Card>

      {loading ? <p className="text-sm text-slate-500">Loading…</p> : stages.map((st) => (
        <div key={st} className="space-y-2">
          <h3 className="font-semibold text-sm text-slate-700">{st}</h3>
          <div className="space-y-2">
            {byStage[st].map((g) => (
              <Card key={g.id}>
                <CardContent className="p-3">
                  <div className="flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="bg-slate-50 text-slate-600 font-mono">{g.gate_id}</Badge>
                        <Badge variant="outline" className={g.gate_type === "Mandatory" ? "bg-rose-50 text-rose-700" : "bg-amber-50 text-amber-700"}>{g.gate_type}</Badge>
                        {g.weight != null && <span className="text-xs text-slate-400">weight {g.weight}</span>}
                      </div>
                      <p className="text-sm text-slate-800 mt-1">{g.criterion}</p>
                      <div className="grid sm:grid-cols-2 gap-2 mt-2">
                        <div>
                          <HelpLabel className="text-xs" help="Accountable owner for this gate. Example: Report Owner, Compliance Lead">Owner</HelpLabel>
                          <Input value={g.owner || ""} onChange={(e) => updateField(g, "owner", e.target.value)} disabled={!canEdit} className="h-8 text-sm" />
                        </div>
                        <div>
                          <HelpLabel className="text-xs" help="Target date by which this gate should be complete.">Due date</HelpLabel>
                          <Input type="date" value={g.due_date || ""} onChange={(e) => updateField(g, "due_date", e.target.value)} disabled={!canEdit} className="h-8 text-sm" />
                        </div>
                      </div>
                    </div>
                    <div className="space-y-1 shrink-0">
                      <HelpLabel className="text-xs" help="Gate progress: Not Started, In Progress, Complete, or Blocked.">Status</HelpLabel>
                      <select className={SELECT_CLASS + " w-40"} value={g.status} onChange={(e) => updateStatus(g, e.target.value)} disabled={!canEdit}>
                        {GATE_STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}
                      </select>
                    </div>
                    <Badge variant="outline" className={GATE_STATUS_STYLES[g.status] || "bg-slate-100 text-slate-600"}>{g.status}</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}