import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Filter, X } from "lucide-react";

const RISK_CATEGORIES = [
  { value: "operational", label: "Operational" },
  { value: "financial", label: "Financial" },
  { value: "strategic", label: "Strategic" },
  { value: "compliance", label: "Compliance" },
  { value: "cyber_security", label: "Cyber Security" },
  { value: "third_party", label: "Third Party" },
  { value: "reputational", label: "Reputational" },
  { value: "technology", label: "Technology" },
];

const DEFAULT_PARAMS = {
  source: "all",
  frameworkId: "all",
  valueChain: "all",
  searchTerm: "",
  category: "all",
  targetCompany: "all",
};

export default function GenerationParametersPanel({ params, setParams, frameworks, valueChains, companies }) {
  const update = (key, value) => setParams((prev) => ({ ...prev, [key]: value }));

  const reset = () => setParams({ ...DEFAULT_PARAMS });

  const hasActiveFilters = Object.entries(params).some(
    ([k, v]) => (k === "searchTerm" ? v !== "" : v !== "all")
  );

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <Filter className="w-4 h-4 text-indigo-600" />
              Generation Parameters
            </CardTitle>
            <p className="text-sm text-slate-500 mt-1">
              Scope the proposed risk generation by library source, framework, value chain, and more.
            </p>
          </div>
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={reset} className="text-slate-500">
              <X className="w-3.5 h-3.5 mr-1" /> Reset
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Library Source */}
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-500">Library Source</Label>
            <Select value={params.source} onValueChange={(v) => update("source", v)}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Library Risks</SelectItem>
                <SelectItem value="universal">Main Library (universal)</SelectItem>
                <SelectItem value="framework_specific">External Library (framework-specific)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Framework */}
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-500">Framework</Label>
            <Select value={params.frameworkId} onValueChange={(v) => update("frameworkId", v)}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Frameworks</SelectItem>
                {frameworks.map((f) => (
                  <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Value Chain */}
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-500">Value Chain</Label>
            <Select value={params.valueChain} onValueChange={(v) => update("valueChain", v)}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Value Chains</SelectItem>
                {valueChains.map((vc) => (
                  <SelectItem key={vc.id} value={vc.id}>{vc.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Risk Category */}
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-500">Risk Category</Label>
            <Select value={params.category} onValueChange={(v) => update("category", v)}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {RISK_CATEGORIES.map((c) => (
                  <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Target Company */}
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-500">Target Company</Label>
            <Select value={params.targetCompany} onValueChange={(v) => update("targetCompany", v)}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Companies</SelectItem>
                {companies.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Search Term */}
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-500">Search Term</Label>
            <Input
              value={params.searchTerm}
              onChange={(e) => update("searchTerm", e.target.value)}
              placeholder="Search title / description..."
              className="h-9"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}