import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import SearchableSelect from "@/components/ui/SearchableSelect";
import { Button } from "@/components/ui/button";
import { Plus, Trash2 } from "lucide-react";

const ENTITY_TYPE_CONFIG = {
  OrgProcess: { label: "Process", nameField: "name", codeField: "process_code" },
  Assessment: { label: "Assessment", nameField: "name", codeField: null },
  PrincipalRisk: { label: "Principal Risk", nameField: "risk_title", codeField: "risk_reference" },
  GRCGoal: { label: "Goals", nameField: "title", codeField: null },
  GovernanceDocument: { label: "Governance & Policies", nameField: "document_name", codeField: "document_code" },
};

const MAX_MAPPINGS = 5;

function getRecordName(record, config) {
  if (!record || !config) return "";
  return record[config.nameField] || "";
}

function getRecordLabel(record, config) {
  if (!record || !config) return "";
  const code = config.codeField ? record[config.codeField] : "";
  const name = getRecordName(record, config);
  return code ? `${code} — ${name}` : name;
}

export default function ObjectiveMappingMatrix({ mappings = [], onChange, disabled }) {
  const processQuery = useQuery({
    queryKey: ["obj-mapping-OrgProcess"],
    queryFn: () => base44.entities.OrgProcess.list("-name", 500),
  });
  const assessmentQuery = useQuery({
    queryKey: ["obj-mapping-Assessment"],
    queryFn: () => base44.entities.Assessment.list("-name", 500),
  });
  const principalRiskQuery = useQuery({
    queryKey: ["obj-mapping-PrincipalRisk"],
    queryFn: () => base44.entities.PrincipalRisk.list("-risk_reference", 500),
  });
  const grcGoalQuery = useQuery({
    queryKey: ["obj-mapping-GRCGoal"],
    queryFn: () => base44.entities.GRCGoal.list("-title", 500),
  });
  const governanceDocQuery = useQuery({
    queryKey: ["obj-mapping-GovernanceDocument"],
    queryFn: () => base44.entities.GovernanceDocument.list("-document_name", 500),
  });

  const dataMap = {
    OrgProcess: processQuery.data || [],
    Assessment: assessmentQuery.data || [],
    PrincipalRisk: principalRiskQuery.data || [],
    GRCGoal: grcGoalQuery.data || [],
    GovernanceDocument: governanceDocQuery.data || [],
  };

  const loadingMap = {
    OrgProcess: processQuery.isLoading,
    Assessment: assessmentQuery.isLoading,
    PrincipalRisk: principalRiskQuery.isLoading,
    GRCGoal: grcGoalQuery.isLoading,
    GovernanceDocument: governanceDocQuery.isLoading,
  };

  const updateRow = (index, field, value) => {
    const newMappings = [...mappings];
    if (field === "entity_type") {
      newMappings[index] = { entity_type: value, entity_id: "", entity_name: "" };
    } else if (field === "entity_id") {
      const type = newMappings[index].entity_type;
      const config = ENTITY_TYPE_CONFIG[type];
      const record = (dataMap[type] || []).find(r => r.id === value);
      newMappings[index] = {
        entity_type: type,
        entity_id: value,
        entity_name: getRecordName(record, config),
      };
    }
    onChange(newMappings);
  };

  const addRow = () => {
    if (mappings.length >= MAX_MAPPINGS) return;
    onChange([...mappings, { entity_type: "", entity_id: "", entity_name: "" }]);
  };

  const removeRow = (index) => {
    onChange(mappings.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-3">
      <p className="text-sm text-slate-500">
        Link this control objective to up to {MAX_MAPPINGS} items across processes, assessments, principal risks, goals, and governance documents.
      </p>
      <div className="rounded-lg border border-slate-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="text-left px-3 py-2 font-semibold text-slate-700 w-1/5">Link Type</th>
              <th className="text-left px-3 py-2 font-semibold text-slate-700 w-2/5">Item</th>
              <th className="text-left px-3 py-2 font-semibold text-slate-700 w-1/5">Name</th>
              <th className="w-10"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {mappings.length === 0 && (
              <tr>
                <td colSpan={4} className="text-center py-6 text-slate-400">
                  No mappings yet. Click "Add Mapping" to link this objective.
                </td>
              </tr>
            )}
            {mappings.map((mapping, index) => {
              const config = ENTITY_TYPE_CONFIG[mapping.entity_type];
              const records = mapping.entity_type ? (dataMap[mapping.entity_type] || []) : [];
              const isLoading = mapping.entity_type ? loadingMap[mapping.entity_type] : false;
              return (
                <tr key={index}>
                  <td className="px-3 py-2">
                    <Select
                      value={mapping.entity_type || "none"}
                      onValueChange={v => updateRow(index, "entity_type", v === "none" ? "" : v)}
                      disabled={disabled}
                    >
                      <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">— Select —</SelectItem>
                        {Object.entries(ENTITY_TYPE_CONFIG).map(([key, cfg]) => (
                          <SelectItem key={key} value={key}>{cfg.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-3 py-2">
                    <SearchableSelect
                      value={mapping.entity_id}
                      onValueChange={v => updateRow(index, "entity_id", v)}
                      options={records.map(r => ({ id: r.id, label: getRecordLabel(r, config) }))}
                      placeholder={isLoading ? "Loading…" : "Select item"}
                      noneLabel="— Select —"
                      disabled={disabled || !mapping.entity_type}
                    />
                  </td>
                  <td className="px-3 py-2 text-slate-700">
                    {mapping.entity_name || <span className="text-slate-400">—</span>}
                  </td>
                  <td className="px-3 py-2 text-center">
                    {!disabled && (
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-red-400 hover:text-red-600" onClick={() => removeRow(index)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {!disabled && mappings.length < MAX_MAPPINGS && (
        <Button variant="outline" size="sm" onClick={addRow} className="gap-2">
          <Plus className="w-4 h-4" /> Add Mapping ({mappings.length}/{MAX_MAPPINGS})
        </Button>
      )}
      {!disabled && mappings.length >= MAX_MAPPINGS && (
        <p className="text-xs text-amber-600">Maximum of {MAX_MAPPINGS} mappings reached.</p>
      )}
    </div>
  );
}