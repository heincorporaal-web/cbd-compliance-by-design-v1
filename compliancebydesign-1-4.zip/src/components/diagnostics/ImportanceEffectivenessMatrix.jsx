import React from "react";
import { Badge } from "@/components/ui/badge";
import { RULE_META, IMPORTANCE_LEVELS, EFFECTIVENESS_BANDS, effectivenessBand } from "@/lib/diagnosticsConfig";

const TONE = {
  red: "bg-red-50 border-red-200",
  amber: "bg-amber-50 border-amber-200",
  green: "bg-emerald-50 border-emerald-200",
  slate: "bg-slate-50 border-slate-200",
};

// Quadrant tone: top-left (high importance, low effectiveness) is the priority zone.
function cellTone(importanceKey, bandKey) {
  if (!bandKey) return "slate";
  const highImportance = ["critical", "high"].includes(importanceKey);
  if (bandKey === "low" && highImportance) return "red";
  if (bandKey === "low") return "amber";
  if (bandKey === "medium" && highImportance) return "amber";
  return "green";
}

export default function ImportanceEffectivenessMatrix({ rules }) {
  const assessed = rules.filter((r) => r.state === "assessed" && RULE_META[r.rule_id]);

  // Build a map of "importance|band" -> [rule chips]
  const cells = {};
  for (const r of assessed) {
    const imp = RULE_META[r.rule_id].importance;
    const band = effectivenessBand(r.coverage_pct);
    if (!band) continue;
    const key = `${imp}|${band}`;
    (cells[key] ||= []).push(r);
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-semibold text-slate-900">Importance vs Effectiveness</h3>
        <p className="text-xs text-slate-500">Top-left is the priority zone: critical areas with low coverage.</p>
      </div>

      <div className="overflow-x-auto -mx-1 px-1">
        <div className="min-w-[420px]">
          {/* Column headers */}
          <div className="grid grid-cols-[88px_repeat(3,1fr)] gap-2 mb-2">
            <div />
            {EFFECTIVENESS_BANDS.map((b) => (
              <div key={b.key} className="text-center text-xs font-medium text-slate-600">
                {b.label}
                <div className="text-[10px] text-slate-400">effectiveness</div>
              </div>
            ))}
          </div>

          {/* Rows: importance high to low */}
          {IMPORTANCE_LEVELS.map((imp) => (
            <div key={imp.key} className="grid grid-cols-[88px_repeat(3,1fr)] gap-2 mb-2">
              <div className="flex items-center justify-end pr-1 text-right">
                <div>
                  <div className="text-xs font-medium text-slate-700">{imp.label}</div>
                  <div className="text-[10px] text-slate-400">importance</div>
                </div>
              </div>
              {EFFECTIVENESS_BANDS.map((band) => {
                const chips = cells[`${imp.key}|${band.key}`] || [];
                const tone = cellTone(imp.key, band.key);
                return (
                  <div key={band.key} className={`rounded-lg border p-2 min-h-[64px] ${TONE[tone]}`}>
                    <div className="flex flex-wrap gap-1">
                      {chips.length === 0 ? (
                        <span className="text-[11px] text-slate-300">—</span>
                      ) : (
                        chips.map((r) => (
                          <span
                            key={r.rule_id}
                            title={`${r.name}: ${r.coverage_pct}%`}
                            className="inline-flex items-center gap-1 rounded bg-white/80 border border-slate-200 px-1.5 py-0.5 text-[11px] font-medium text-slate-700"
                          >
                            {r.rule_id}
                            <span className="text-slate-400">{r.coverage_pct}%</span>
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}