import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { buildAreas, areaPriority, importanceRank, RULE_META } from "@/lib/diagnosticsConfig";

const PRIORITY_TONE = {
  red: { ring: "border-l-red-500", badge: "bg-red-100 text-red-700 border-red-200" },
  amber: { ring: "border-l-amber-500", badge: "bg-amber-100 text-amber-700 border-amber-200" },
  green: { ring: "border-l-emerald-500", badge: "bg-emerald-100 text-emerald-700 border-emerald-200" },
  slate: { ring: "border-l-slate-300", badge: "bg-slate-100 text-slate-600 border-slate-200" },
};

const IMPORTANCE_BADGE = {
  critical: "bg-red-100 text-red-700",
  high: "bg-orange-100 text-orange-700",
  medium: "bg-sky-100 text-sky-700",
  low: "bg-slate-100 text-slate-600",
};

export default function AreaScorecards({ rules }) {
  const areas = buildAreas(rules).sort((a, b) => importanceRank(b.importance) - importanceRank(a.importance));

  return (
    <div className="space-y-3">
      <h3 className="font-semibold text-slate-900">Area scorecards</h3>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        {areas.map((area) => {
          const priority = areaPriority(area);
          const tone = PRIORITY_TONE[priority.tone];
          return (
            <Card key={area.key} className={`border-l-4 ${tone.ring}`}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <h4 className="font-semibold text-slate-900 text-sm leading-tight">{area.label}</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">{area.description}</p>
                  </div>
                  <Badge variant="outline" className={`shrink-0 text-[10px] ${tone.badge}`}>{priority.label}</Badge>
                </div>

                <div className="flex items-end justify-between">
                  <div>
                    <div className="text-2xl font-bold text-slate-900 leading-none">
                      {area.effectiveness === null ? "N/A" : `${area.effectiveness}%`}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1">avg effectiveness</div>
                  </div>
                  <Badge className={`text-[10px] ${IMPORTANCE_BADGE[area.importance] || IMPORTANCE_BADGE.low}`}>
                    {area.importance}
                  </Badge>
                </div>

                <div className="space-y-1 pt-1 border-t border-slate-100">
                  {area.rules.map((r) => (
                    <div key={r.rule_id} className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-600 truncate pr-2">{r.rule_id} · {r.name}</span>
                      <span className="text-slate-500 shrink-0">
                        {r.state === "not_applicable" ? "N/A" : `${r.coverage_pct}%`}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}