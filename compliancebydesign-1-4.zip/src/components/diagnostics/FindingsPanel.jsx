import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { ClipboardList, Loader2 } from "lucide-react";

const STATUS_OPTIONS = [
  { value: "open", label: "Open", badge: "bg-slate-100 text-slate-700" },
  { value: "in_progress", label: "In progress", badge: "bg-blue-100 text-blue-700" },
  { value: "remediated", label: "Remediated", badge: "bg-amber-100 text-amber-700" },
  { value: "closed", label: "Closed", badge: "bg-emerald-100 text-emerald-700" },
  { value: "cancelled", label: "Cancelled", badge: "bg-slate-100 text-slate-400 line-through" },
];

const PRIORITY_BADGE = {
  critical: "bg-red-100 text-red-700",
  high: "bg-orange-100 text-orange-700",
  medium: "bg-sky-100 text-sky-700",
  low: "bg-slate-100 text-slate-600",
};

const statusBadge = (s) => STATUS_OPTIONS.find((o) => o.value === s)?.badge || STATUS_OPTIONS[0].badge;

export default function FindingsPanel({ cycleId, companyId }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("all");
  const [busy, setBusy] = useState(false);

  const { data: findings = [], isLoading } = useQuery({
    queryKey: ["diagnostic-findings", cycleId],
    enabled: !!cycleId,
    queryFn: async () =>
      (await base44.entities.DiagnosticFinding.filter({ cycle_id: cycleId }, { sort: "-created_date", limit: 500 })).items,
  });

  const filtered = statusFilter === "all" ? findings : findings.filter((f) => f.status === statusFilter);

  const changeStatus = async (finding, newStatus) => {
    setBusy(true);
    const patch = { status: newStatus };
    if (newStatus === "closed" && !finding.closed_date) patch.closed_date = new Date().toISOString().slice(0, 10);
    if (newStatus !== "closed") patch.closed_date = null;
    try {
      await base44.entities.DiagnosticFinding.update(finding.id, patch);
      queryClient.invalidateQueries({ queryKey: ["diagnostic-findings", cycleId] });
    } catch (e) {
      toast({ title: "Could not update finding", description: e.message, variant: "destructive" });
    }
    setBusy(false);
  };

  const counts = STATUS_OPTIONS.map((o) => ({ ...o, count: findings.filter((f) => f.status === o.value).length }));

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <ClipboardList className="w-4 h-4" /> Findings
            {findings.length > 0 && <Badge variant="secondary">{findings.length}</Badge>}
          </CardTitle>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {STATUS_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        {findings.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {counts.map((c) => (
              <span key={c.value} className="text-[11px] text-slate-500">
                <span className={`px-1.5 py-0.5 rounded ${c.badge}`}>{c.count}</span> {c.label}
              </span>
            ))}
          </div>
        )}
      </CardHeader>
      <CardContent>
        {!cycleId ? (
          <p className="text-sm text-slate-500">Select a cycle to manage its findings.</p>
        ) : isLoading ? (
          <div className="flex items-center gap-2 text-sm text-slate-500"><Loader2 className="w-4 h-4 animate-spin" /> Loading findings…</div>
        ) : filtered.length === 0 ? (
          <p className="text-sm text-slate-500">
            {findings.length === 0
              ? "No findings yet. Open a rule's gap list and create findings from the uncovered items."
              : "No findings match this filter."}
          </p>
        ) : (
          <div className="space-y-2">
            {filtered.map((f) => (
              <div key={f.id} className="flex flex-col sm:flex-row sm:items-center gap-2 border border-slate-200 rounded-lg p-2.5">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="text-[10px]">{f.rule_id}</Badge>
                    <Badge className={`text-[10px] ${PRIORITY_BADGE[f.priority] || PRIORITY_BADGE.medium}`}>{f.priority}</Badge>
                    <span className="text-xs text-slate-400">{f.entity_code || f.entity_id}</span>
                  </div>
                  <p className="text-sm font-medium text-slate-800 truncate" title={f.title}>{f.title}</p>
                  {f.assigned_to && <p className="text-[11px] text-slate-500">Assigned: {f.assigned_to}{f.due_date ? ` · due ${f.due_date}` : ""}</p>}
                </div>
                <Select value={f.status} onValueChange={(v) => changeStatus(f, v)} disabled={busy}>
                  <SelectTrigger className="w-full sm:w-36 h-8 text-xs">
                    <span className={`px-1.5 py-0.5 rounded text-[11px] ${statusBadge(f.status)}`}>{STATUS_OPTIONS.find((o) => o.value === f.status)?.label}</span>
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}