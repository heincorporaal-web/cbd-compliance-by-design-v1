import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function CycleFormDialog({ open, onOpenChange, companyId, onCreated }) {
  const [form, setForm] = useState({ name: "", cutoff_date: "", assessment_mode: "objective", notes: "" });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    setSaving(true);
    const me = await base44.auth.me();
    const cycle = await base44.entities.DiagnosticCycle.create({
      ...form,
      company_id: companyId,
      status: "draft",
      template_version: "1.0",
      owner_email: me?.email,
      time_zone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    });
    setSaving(false);
    setForm({ name: "", cutoff_date: "", assessment_mode: "objective", notes: "" });
    onCreated(cycle);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>Create diagnostic cycle</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Name *</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
          <div><Label>Reporting cut-off date</Label><Input type="date" value={form.cutoff_date} onChange={(e) => set("cutoff_date", e.target.value)} /></div>
          <div>
            <Label>Assessment mode</Label>
            <Select value={form.assessment_mode} onValueChange={(v) => set("assessment_mode", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="objective">Objective data only</SelectItem>
                <SelectItem value="perception">Perception survey only</SelectItem>
                <SelectItem value="blended">Blended</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500 mt-1">This release calculates objective coverage measures only.</p>
          </div>
          <div><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={!form.name.trim() || saving} onClick={submit}>{saving ? "Creating…" : "Create cycle"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}