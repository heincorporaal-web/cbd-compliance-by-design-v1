import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";
import { AREAS, RULE_META, buildAreas } from "@/lib/diagnosticsConfig";

const AREA_COLORS = {
  process_governance: "#0ea5e9",
  risk_control_mapping: "#6366f1",
  assessment_coverage: "#f59e0b",
  strategic_alignment: "#10b981",
};

export default function TrendChart({ companyId }) {
  const { data: cycles = [] } = useQuery({
    queryKey: ["diagnostic-cycles", companyId],
    enabled: !!companyId,
    queryFn: async () =>
      (await base44.entities.DiagnosticCycle.filter({ company_id: companyId }, { sort: "created_date", limit: 50 })).items,
  });

  const points = useMemo(() => {
    const withResults = cycles.filter((c) => c.results?.rules);
    return withResults.map((c) => {
      const areas = buildAreas(c.results.rules);
      const row = { name: c.name, date: c.last_run_at || c.created_date };
      for (const a of areas) row[a.key] = a.effectiveness;
      return row;
    });
  }, [cycles]);

  if (points.length < 2) {
    return (
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Coverage trend</CardTitle></CardHeader>
        <CardContent><p className="text-sm text-slate-500">At least two cycles with saved results are needed to show a trend.</p></CardContent>
      </Card>
    );
  }

  // Build inline SVG line chart
  const width = 560, height = 200, pad = 36;
  const xCount = points.length;
  const xStep = xCount > 1 ? (width - pad * 2) / (xCount - 1) : 0;
  const yMax = 100;
  const xy = (i, v) => [pad + i * xStep, height - pad - (v == null ? 0 : v) / yMax * (height - pad * 2)];

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Coverage trend across cycles</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <svg width={width} height={height} className="min-w-full" role="img" aria-label="Coverage trend">
            {/* Y grid */}
            {[0, 25, 50, 75, 100].map((g) => {
              const [, y] = xy(0, g);
              return <g key={g}><line x1={pad} y1={y} x2={width - pad} y2={y} stroke="#e2e8f0" strokeWidth={1} /><text x={4} y={y + 4} fontSize={10} fill="#94a3b8">{g}</text></g>;
            })}
            {/* X labels */}
            {points.map((p, i) => {
              const [x] = xy(i, 0);
              const label = p.date ? new Date(p.date).toLocaleDateString("en-GB", { day: "2-digit", month: "short" }) : `C${i + 1}`;
              return <text key={i} x={x} y={height - pad + 14} fontSize={9} fill="#94a3b8" textAnchor="middle">{label}</text>;
            })}
            {/* Lines per area */}
            {AREAS.map((area) => {
              const pts = points.map((p, i) => { const v = p[area.key]; return v == null ? null : xy(i, v); }).filter(Boolean);
              if (pts.length < 2) return null;
              const d = pts.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x},${y}`).join(" ");
              return <g key={area.key}><path d={d} fill="none" stroke={AREA_COLORS[area.key]} strokeWidth={2} />{pts.map(([x, y], i) => <circle key={i} cx={x} cy={y} r={3} fill={AREA_COLORS[area.key]} />)}</g>;
            })}
          </svg>
        </div>
        <div className="flex flex-wrap gap-3 mt-2">
          {AREAS.map((a) => (
            <span key={a.key} className="flex items-center gap-1.5 text-xs text-slate-600">
              <span className="w-3 h-3 rounded-full" style={{ background: AREA_COLORS[a.key] }} /> {a.label}
            </span>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}