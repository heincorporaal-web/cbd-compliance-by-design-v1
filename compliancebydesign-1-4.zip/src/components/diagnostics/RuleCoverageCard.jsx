import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function RuleCoverageCard({ rule, generatedAt, onDrill }) {
  const na = rule.state === "not_applicable";
  return (
    <Card>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-xs text-slate-500">{rule.rule_id} · {rule.entity}</p>
            <h3 className="font-semibold text-slate-900">{rule.name}</h3>
          </div>
          <Badge variant="outline">{na ? "Not applicable" : "Assessed"}</Badge>
        </div>
        <div>
          <p className="text-3xl font-bold text-primary">{na ? "N/A" : `${rule.coverage_pct}%`}</p>
          <p className="text-sm text-slate-600">
            {na ? "No eligible items in scope" : `${rule.covered_count} of ${rule.eligible_count} eligible covered`}
          </p>
        </div>
        {!na && <Progress value={rule.coverage_pct} />}
        <p className="text-xs text-slate-500">{rule.definition}</p>
        {rule.associations !== undefined && (
          <p className="text-xs text-slate-500">
            Reported separately: {rule.associations} associations to {rule.distinct_targets} distinct records.
          </p>
        )}
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-slate-400">
            {generatedAt ? `Calculated ${new Date(generatedAt).toLocaleString("en-GB")}` : ""}
          </span>
          <Button size="sm" variant="outline" disabled={!rule.uncovered_count} onClick={() => onDrill(rule)}>
            View {rule.uncovered_count || 0} gaps
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}