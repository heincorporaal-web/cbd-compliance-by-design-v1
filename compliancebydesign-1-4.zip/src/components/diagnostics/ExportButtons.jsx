import React from "react";
import { Button } from "@/components/ui/button";
import { Download, FileSpreadsheet } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { buildAreas } from "@/lib/diagnosticsConfig";

function downloadCsv(filename, rows) {
  const csv = rows.map((r) => r.map((c) => {
    const s = c === null || c === undefined ? "" : String(c);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function ExportResultsButton({ result, cycleName }) {
  const exportResults = () => {
    const areas = buildAreas(result.rules);
    const rows = [
      ["Section", "ID", "Name", "Entity", "Eligible", "Covered", "Uncovered", "Coverage %", "State", "Importance", "Priority"],
      ...result.rules.map((r) => {
        const area = areas.find((a) => a.rules.some((rr) => rr.rule_id === r.rule_id));
        const priority = area ? (["critical", "high"].includes(area.importance) && area.band === "low" ? "Priority gap" : area.band === "low" || (area.band === "medium" && ["critical", "high"].includes(area.importance)) ? "Watch" : "On track") : "";
        return ["Rule", r.rule_id, r.name, r.entity, r.eligible_count, r.covered_count, r.uncovered_count, r.coverage_pct ?? "", r.state, area?.importance ?? "", priority];
      }),
      [],
      ["Section", "Area", "Rules", "Avg effectiveness %", "Importance", "Priority"],
      ...areas.map((a) => ["Area", a.label, a.rules.map((r) => r.rule_id).join(" "), a.effectiveness ?? "", a.importance, a.band === "low" && ["critical", "high"].includes(a.importance) ? "Priority gap" : a.effectiveness === null ? "Not assessed" : "On track"]),
      [],
      ["Reconciliation", "ID", "Label", "Pass", "Detail"],
      ...result.reconciliation.map((c) => ["Reconciliation", c.id, c.label, c.pass ? "Pass" : "Fail", c.detail]),
    ];
    const stamp = new Date().toISOString().slice(0, 10);
    downloadCsv(`diagnostic-results-${cycleName || "preview"}-${stamp}.csv`, rows);
  };

  return (
    <Button variant="outline" size="sm" onClick={exportResults} disabled={!result}>
      <Download className="w-4 h-4 mr-1" /> Export results
    </Button>
  );
}

export function ExportFindingsButton({ cycleId, cycleName }) {
  const exportFindings = async () => {
    const items = (await base44.entities.DiagnosticFinding.filter({ cycle_id: cycleId }, { sort: "-created_date", limit: 1000 })).items;
    const rows = [
      ["Finding ID", "Rule", "Entity type", "Entity code", "Entity name", "Title", "Status", "Priority", "Assigned to", "Due date", "Closed date", "Source", "Created date"],
      ...items.map((f) => [f.id, f.rule_id, f.entity_type, f.entity_code, f.entity_name, f.title, f.status, f.priority, f.assigned_to || "", f.due_date || "", f.closed_date || "", f.source, f.created_date?.slice(0, 10) || ""]),
    ];
    const stamp = new Date().toISOString().slice(0, 10);
    downloadCsv(`diagnostic-findings-${cycleName || "cycle"}-${stamp}.csv`, rows);
  };

  return (
    <Button variant="outline" size="sm" onClick={exportFindings} disabled={!cycleId}>
      <FileSpreadsheet className="w-4 h-4 mr-1" /> Export findings
    </Button>
  );
}