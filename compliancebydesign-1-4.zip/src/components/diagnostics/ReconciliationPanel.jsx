import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, XCircle } from "lucide-react";

export default function ReconciliationPanel({ checks }) {
  const failed = checks.filter((c) => !c.pass).length;
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">
          Reconciliation checks {failed ? `· ${failed} failed` : "· all passed"}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-1">
        {checks.map((c) => (
          <div key={c.id} className="flex items-start gap-2 text-sm">
            {c.pass ? <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" /> : <XCircle className="w-4 h-4 text-red-600 mt-0.5" />}
            <span className="font-medium">{c.pass ? "Pass" : "Fail"}</span>
            <span className="text-slate-700">{c.label}</span>
            <span className="text-slate-400 text-xs ml-auto">{c.detail}</span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}