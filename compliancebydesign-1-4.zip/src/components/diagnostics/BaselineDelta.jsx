import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { buildAreas } from "@/lib/diagnosticsConfig";

const Delta = ({ value }) => {
  if (value == null || Number.isNaN(value)) return <span className="text-slate-400">—</span>;
  if (value > 0) return <span className="inline-flex items-center text-emerald-600 font-medium"><ArrowUpRight className="w-3 h-3" />+{value}</span>;
  if (value < 0) return <span className="inline-flex items-center text-red-600 font-medium"><ArrowDownRight className="w-3 h-3" />{value}</span>;
  return <span className="inline-flex items-center text-slate-400"><Minus className="w-3 h-3" />0</span>;
};

export default function BaselineDelta({ cycle }) {
  const baselineId = cycle?.baseline_cycle_id;
  const { data: baseline } = useQuery({
    queryKey: ["diagnostic-cycle", baselineId],
    enabled: !!baselineId,
    queryFn: async () => await base44.entities.DiagnosticCycle.get(baselineId),
  });

  const rows = useMemo(() => {
    if (!cycle?.results?.rules || !baseline?.results?.rules) return null;
    const cur = cycle.results.rules;
    const base = baseline.results.rules;
    const byId = new Map(base.map((r) => [r.rule_id, r]));
    return cur.map((r) => {
      const b = byId.get(r.rule_id);
      const covDelta = b?.coverage_pct != null && r.coverage_pct != null ? Math.round((r.coverage_pct - b.coverage_pct) * 10) / 10 : null;
      const uncovDelta = b?.uncovered_count != null && r.uncovered_count != null ? r.uncovered_count - b.uncovered_count : null;
      return { rule_id: r.rule_id, name: r.name, current: r.coverage_pct, baseline: b?.coverage_pct ?? null, covDelta, uncovDelta };
    });
  }, [cycle, baseline]);

  const areaRows = useMemo(() => {
    if (!cycle?.results?.rules || !baseline?.results?.rules) return null;
    const curAreas = buildAreas(cycle.results.rules);
    const baseAreas = buildAreas(baseline.results.rules);
    const byKey = new Map(baseAreas.map((a) => [a.key, a]));
    return curAreas.map((a) => {
      const b = byKey.get(a.key);
      const delta = b?.effectiveness != null && a.effectiveness != null ? Math.round((a.effectiveness - b.effectiveness) * 10) / 10 : null;
      return { key: a.key, label: a.label, current: a.effectiveness, baseline: b?.effectiveness ?? null, delta };
    });
  }, [cycle, baseline]);

  if (!baselineId) return null;
  if (!rows) {
    return (
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-base">Baseline comparison</CardTitle></CardHeader>
        <CardContent><p className="text-sm text-slate-500">The baseline cycle has no saved results. Run coverage on it first.</p></CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Baseline comparison vs "{baseline?.name}"</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="text-xs font-medium text-slate-500 mb-1">By area</p>
          <table className="w-full text-sm">
            <thead><tr className="text-left text-slate-400 border-b"><th className="py-1">Area</th><th className="text-right">Baseline</th><th className="text-right">Current</th><th className="text-right">Δ</th></tr></thead>
            <tbody>
              {areaRows.map((a) => (
                <tr key={a.key} className="border-b last:border-0">
                  <td className="py-1">{a.label}</td>
                  <td className="text-right text-slate-500">{a.baseline ?? "—"}{a.baseline != null ? "%" : ""}</td>
                  <td className="text-right font-medium">{a.current ?? "—"}{a.current != null ? "%" : ""}</td>
                  <td className="text-right"><Delta value={a.delta} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div>
          <p className="text-xs font-medium text-slate-500 mb-1">By rule</p>
          <table className="w-full text-sm">
            <thead><tr className="text-left text-slate-400 border-b"><th className="py-1">Rule</th><th className="text-right">Baseline</th><th className="text-right">Current</th><th className="text-right">Δ cov</th><th className="text-right">Δ gaps</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.rule_id} className="border-b last:border-0">
                  <td className="py-1"><span className="text-xs text-slate-400 mr-1">{r.rule_id}</span>{r.name}</td>
                  <td className="text-right text-slate-500">{r.baseline ?? "—"}{r.baseline != null ? "%" : ""}</td>
                  <td className="text-right font-medium">{r.current ?? "—"}{r.current != null ? "%" : ""}</td>
                  <td className="text-right"><Delta value={r.covDelta} /></td>
                  <td className="text-right"><Delta value={r.uncovDelta} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}