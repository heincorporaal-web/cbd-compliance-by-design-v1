import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { RULE_META, importanceToPriority } from "@/lib/diagnosticsConfig";
import { Loader2, Plus } from "lucide-react";

export default function RuleDrilldownDialog({ rule, filters, companyId, cycleId, onClose }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [creating, setCreating] = useState(false);

  const createFindings = async () => {
    if (!cycleId) {
      toast({ title: "Select a cycle first", description: "Findings can only be created against a saved cycle.", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      // Dedup against existing open/in-progress findings for this rule + cycle
      const existing = (await base44.entities.DiagnosticFinding.filter(
        { cycle_id: cycleId, rule_id: rule.rule_id, status: { $in: ["open", "in_progress"] } },
        { limit: 500, fields: ["entity_id"] }
      )).items;
      const existingIds = new Set(existing.map((f) => f.entity_id));
      const toCreate = rule.uncovered_items
        .filter((i) => !existingIds.has(i.id))
        .map((i) => ({
          company_id: companyId,
          cycle_id: cycleId,
          rule_id: rule.rule_id,
          rule_name: rule.name,
          entity_type: rule.entity,
          entity_id: i.id,
          entity_code: i.code || "",
          entity_name: i.name,
          title: `${rule.name}: ${i.code || i.name}`,
          description: rule.definition,
          priority: importanceToPriority(RULE_META[rule.rule_id]?.importance),
          source: "Diagnostic Coverage",
          status: "open",
        }));
      if (toCreate.length === 0) {
        toast({ title: "No new findings to create", description: "All shown gaps already have an open finding." });
      } else {
        await base44.entities.DiagnosticFinding.bulkCreate(toCreate);
        toast({ title: "Findings created", description: `${toCreate.length} finding${toCreate.length === 1 ? "" : "s"} created for ${rule.rule_id}.` });
      }
      queryClient.invalidateQueries({ queryKey: ["diagnostic-findings", cycleId] });
    } catch (e) {
      toast({ title: "Could not create findings", description: e.message, variant: "destructive" });
    }
    setCreating(false);
  };

  return (
    <Dialog open={!!rule} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        {rule && (
          <>
            <DialogHeader><DialogTitle>{rule.rule_id} · {rule.name}: gaps</DialogTitle></DialogHeader>
            <div className="text-sm text-slate-600 space-y-1">
              <p>Numerator: {rule.covered_count} covered · Denominator: {rule.eligible_count} eligible · Excluded: {rule.excluded_count ?? 0}</p>
              <p>Eligibility applied: {rule.entity === "OrgObjective" ? filters?.objective_eligibility : filters?.process_eligibility}</p>
              <p className="text-xs text-slate-500">
                These items have no recorded mapping. This is a data-coverage finding, not proof the control or risk is absent in practice.
              </p>
            </div>
            <div className="flex items-center justify-between gap-2">
              <Button size="sm" onClick={createFindings} disabled={creating || !cycleId}>
                {creating ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Plus className="w-4 h-4 mr-1" />}
                Create findings from gaps
              </Button>
              {!cycleId && <span className="text-xs text-amber-600">Select a cycle to enable finding creation.</span>}
            </div>
            <table className="w-full text-sm mt-2">
              <thead>
                <tr className="text-left text-slate-500 border-b"><th className="py-1 pr-2">Code</th><th>Name</th><th className="text-right">Record ID</th></tr>
              </thead>
              <tbody>
                {rule.uncovered_items.map((i) => (
                  <tr key={i.id} className="border-b last:border-0">
                    <td className="py-1 pr-2 whitespace-nowrap">{i.code || "-"}</td>
                    <td>{i.name}</td>
                    <td className="text-right text-xs text-slate-400">{i.id}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rule.uncovered_truncated && (
              <p className="text-xs text-amber-700">Showing the first 500 of {rule.uncovered_count} gaps. Findings are created for the shown items only.</p>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}