import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Clock } from "lucide-react";

const INACTIVITY_LIMIT_MS = 30 * 60 * 1000; // 30 minutes
const WARNING_THRESHOLD_MS = 5 * 60 * 1000; // warn 5 min before logout
const ACTIVITY_EVENTS = ["mousedown", "keydown", "mousemove", "scroll", "touchstart"];

/**
 * Auto-logs out inactive regular users after 30 minutes.
 * Product Owners and platform admins are exempt.
 * Shows a warning dialog 5 minutes before the timeout with a "Stay logged in" option.
 */
export default function SessionTimeout() {
  const { user, logout, isAuthenticated } = useAuth();
  const [showWarning, setShowWarning] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const lastActivityRef = useRef(Date.now());
  const warnedRef = useRef(false);

  const { data: ucr = [] } = useQuery({
    queryKey: ["userCompanyRoles", user?.id],
    queryFn: () => base44.entities.UserCompanyRole.filter({ user_id: user.id }),
    enabled: !!user,
  });

  const { data: roles = [] } = useQuery({
    queryKey: ["userRoles"],
    queryFn: () => base44.entities.UserRole.list("-created_date", 500),
    enabled: !!user,
  });

  const isExempt = (() => {
    if (!user) return true;
    if (user.role === "admin") return true;
    const customRoleIds = Array.from(
      new Set(
        []
          .concat((ucr || []).map((r) => r.custom_role_id).filter(Boolean))
          .concat(user?.custom_role_id ? [user.custom_role_id] : [])
      )
    );
    const myRoles = (roles || []).filter((r) => customRoleIds.includes(r.id));
    return myRoles.some((r) => r.is_product_owner);
  })();

  const resetSession = () => {
    lastActivityRef.current = Date.now();
    warnedRef.current = false;
    setShowWarning(false);
  };

  useEffect(() => {
    if (isExempt || !isAuthenticated) {
      setShowWarning(false);
      return;
    }

    lastActivityRef.current = Date.now();
    warnedRef.current = false;

    let lastThrottle = Date.now();
    const handleActivity = () => {
      const now = Date.now();
      if (now - lastThrottle > 2000) {
        lastThrottle = now;
        lastActivityRef.current = now;
        if (warnedRef.current) {
          resetSession();
        }
      }
    };

    ACTIVITY_EVENTS.forEach((event) => {
      window.addEventListener(event, handleActivity, { passive: true });
    });

    const checkInterval = setInterval(() => {
      const elapsed = Date.now() - lastActivityRef.current;
      if (elapsed >= INACTIVITY_LIMIT_MS) {
        clearInterval(checkInterval);
        logout(true);
      } else if (elapsed >= INACTIVITY_LIMIT_MS - WARNING_THRESHOLD_MS && !warnedRef.current) {
        warnedRef.current = true;
        setShowWarning(true);
      }
      if (warnedRef.current) {
        setSecondsLeft(Math.max(0, Math.ceil((INACTIVITY_LIMIT_MS - elapsed) / 1000)));
      }
    }, 1000);

    return () => {
      clearInterval(checkInterval);
      ACTIVITY_EVENTS.forEach((event) => {
        window.removeEventListener(event, handleActivity);
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isExempt, isAuthenticated, logout]);

  if (isExempt || !isAuthenticated) return null;

  const formatTime = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  return (
    <Dialog
      open={showWarning}
      onOpenChange={(open) => {
        if (!open) resetSession();
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-500" />
            Session Expiring
          </DialogTitle>
          <DialogDescription>
            You will be automatically logged out in{" "}
            <strong className="text-slate-900">{formatTime(secondsLeft)}</strong> due to
            inactivity. Click "Stay logged in" to continue your session.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => logout(true)}>
            Log out now
          </Button>
          <Button onClick={resetSession}>Stay logged in</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}