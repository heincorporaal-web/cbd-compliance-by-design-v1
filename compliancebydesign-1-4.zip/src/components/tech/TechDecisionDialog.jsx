import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import SearchableMultiPicker from "@/components/objectives/SearchableMultiPicker";
import WorkflowPanel from "@/components/workflows/WorkflowPanel";

const DECISIONS = ["retain", "optimize", "modernize", "consolidate", "replace", "retire"];
const STATUSES = ["proposed", "under_review", "approved", "rejected", "implemented"];

export default function TechDecisionDialog({ open, opportunity, companyId, existing, onClose }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({
    decision: "optimize",
    rationale: "",
    status: "proposed",
    owner_name: "",
    target_date: "",
    notes: "",
    linked_goal_ids: [],
    linked_objective_ids: [],
    linked_risk_ids: [],
  });
  const [saving, setSaving] = useState(false);
  const [options, setOptions] = useState({ goals: [], objectives: [], risks: [] });

  useEffect(() => {
    if (open) {
      const base = existing || {};
      setForm({
        decision: base.decision || opportunity?.opportunity_type || "optimize",
        rationale: base.rationale || opportunity?.rationale || "",
        status: base.status || "proposed",
        owner_name: base.owner_name || "",
        target_date: base.target_date || "",
        notes: base.notes || "",
        linked_goal_ids: base.linked_goal_ids || [],
        linked_objective_ids: base.linked_objective_ids || [],
        linked_risk_ids: base.linked_risk_ids || [],
      });
      if (companyId) {
        Promise.all([
          base44.entities.GRCGoal.filter({ company_id: companyId }, { sort: "-created_date", limit: 200, fields: ["title"] }).then(r => r.items || r),
          base44.entities.OrgObjective.filter({ company_id: companyId }, { sort: "-created_date", limit: 200, fields: ["title", "reference_number"] }).then(r => r.items || r),
          base44.entities.Risk.filter({ company_id: companyId }, { sort: "-created_date", limit: 200, fields: ["title"] }).then(r => r.items || r),
        ]).then(([goals, objectives, risks]) => setOptions({ goals, objectives, risks }))
          .catch(() => {});
      }
    }
  }, [open, existing, opportunity, companyId]);

  const toggle = (field, id) =>
    setForm(prev => {
      const arr = prev[field] || [];
      return { ...prev, [field]: arr.includes(id) ? arr.filter(x => x !== id) : [...arr, id] };
    });

  const save = async () => {
    setSaving(true);
    try {
      const payload = {
        company_id: companyId,
        asset_type: opportunity?.asset_type || "ICTSystem",
        asset_id: opportunity?.asset_id || "",
        asset_name: opportunity?.asset_name || "",
        ...form,
      };
      if (existing?.id) {
        await base44.entities.TechnologyDecision.update(existing.id, payload);
      } else {
        await base44.entities.TechnologyDecision.create(payload);
      }
      queryClient.invalidateQueries({ queryKey: ["tech-decisions", companyId] });
      toast({ title: "Decision saved" });
      onClose();
    } catch (e) {
      toast({ title: "Could not save decision", description: e.message, variant: "destructive" });
    }
    setSaving(false);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Strategic decision — {opportunity?.asset_name}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label className="text-xs">Decision</Label>
            <Select value={form.decision} onValueChange={(v) => setForm({ ...form, decision: v })}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>{DECISIONS.map((d) => <SelectItem key={d} value={d} className="capitalize">{d}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label className="text-xs">Rationale</Label>
            <Textarea className="mt-1" rows={3} value={form.rationale} onChange={(e) => setForm({ ...form, rationale: e.target.value })} placeholder="Why this decision…" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace("_", " ")}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label className="text-xs">Owner</Label>
              <Input className="mt-1" value={form.owner_name} onChange={(e) => setForm({ ...form, owner_name: e.target.value })} placeholder="Decision owner" />
            </div>
          </div>
          <div><Label className="text-xs">Target date</Label>
            <Input type="date" className="mt-1" value={form.target_date} onChange={(e) => setForm({ ...form, target_date: e.target.value })} />
          </div>
          <div><Label className="text-xs">Notes</Label>
            <Input className="mt-1" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>

          <div className="pt-2 border-t space-y-3">
            <SearchableMultiPicker
              label="Strategic Goals"
              items={options.goals}
              selectedIds={form.linked_goal_ids}
              onToggle={(id) => toggle("linked_goal_ids", id)}
              getLabel={(g) => g.title || "Untitled"}
            />
            <SearchableMultiPicker
              label="Objectives"
              items={options.objectives}
              selectedIds={form.linked_objective_ids}
              onToggle={(id) => toggle("linked_objective_ids", id)}
              getLabel={(o) => (o.reference_number ? `${o.reference_number} — ` : "") + (o.title || "Untitled")}
            />
            <SearchableMultiPicker
              label="Risks Addressed"
              items={options.risks}
              selectedIds={form.linked_risk_ids}
              onToggle={(id) => toggle("linked_risk_ids", id)}
              getLabel={(r) => r.title || "Untitled"}
            />
          </div>

          {existing?.id && (
            <div className="pt-2 border-t">
              <WorkflowPanel
                entityType="TechnologyDecision"
                entityId={existing.id}
                entityName={opportunity?.asset_name || existing.asset_name || "Decision"}
                companyId={companyId}
                record={{ ...existing, ...form }}
                onInstanceCreated={() => {
                  setForm((f) => ({ ...f, status: "under_review" }));
                  queryClient.invalidateQueries({ queryKey: ["tech-decisions", companyId] });
                }}
              />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving || !form.decision}>{saving ? "Saving…" : "Save decision"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}