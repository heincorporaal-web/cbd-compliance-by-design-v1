import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, ShieldAlert, Users, Boxes, Layers } from "lucide-react";

const WORKFLOW_STATUS_BADGE = {
  pending: "bg-slate-100 text-slate-700",
  in_progress: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  completed: "bg-purple-100 text-purple-700",
  returned: "bg-orange-100 text-orange-700",
};

function FlagList({ title, icon: Icon, items, color = "text-amber-600", decisionFor }) {
  return (
    <div>
      <p className={`text-xs font-medium flex items-center gap-1 mb-1 ${color}`}><Icon className="w-3.5 h-3.5" /> {title} ({items.length})</p>
      {items.length === 0 ? <p className="text-xs text-slate-400">None identified</p> : (
        <ul className="space-y-0.5 max-h-40 overflow-y-auto">
          {items.slice(0, 50).map((i) => {
            const dec = decisionFor?.(i.id);
            const ws = dec?.id && decisionFor._workflowStatus?.[dec.id];
            return (
              <li key={i.id || i.name} className="text-xs text-slate-600 flex items-center gap-1.5 flex-wrap">
                <span className="font-medium">{i.name}</span>{i.reason ? <span className="text-slate-400"> — {i.reason}</span> : null}
                {ws && <Badge className={`text-[9px] ${WORKFLOW_STATUS_BADGE[ws] || "bg-slate-100 text-slate-700"}`}>{ws.replace(/_/g, " ")}</Badge>}
              </li>
            );
          })}
          {items.length > 50 && <li className="text-xs text-slate-400">…and {items.length - 50} more</li>}
        </ul>
      )}
    </div>
  );
}

export default function TechHealthExposure({ health, decisions, workflowStatusByDecision }) {
  if (!health) return null;
  const { eol_unsupported, obsolescence, security_exposure, concentration, ownership_gaps, inventory_gaps } = health;
  const decisionFor = (assetId) => (decisions || []).find((d) => d.asset_id === assetId && d.asset_type === "ICTSystem");
  decisionFor._workflowStatus = workflowStatusByDecision;
  return (
    <Card>
      <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><AlertTriangle className="w-4 h-4" /> Technology health & exposure</CardTitle></CardHeader>
      <CardContent className="grid sm:grid-cols-2 gap-4">
        <FlagList title="End-of-life / unsupported" icon={AlertTriangle} items={eol_unsupported} color="text-red-600" decisionFor={decisionFor} />
        <FlagList title="Obsolescence" icon={Layers} items={obsolescence} color="text-amber-600" decisionFor={decisionFor} />
        <FlagList title="Security exposure" icon={ShieldAlert} items={security_exposure} color="text-red-600" decisionFor={decisionFor} />
        <FlagList title="Ownership gaps" icon={Users} items={ownership_gaps} color="text-amber-600" decisionFor={decisionFor} />
        <FlagList title="Inventory completeness" icon={Boxes} items={inventory_gaps} color="text-amber-600" decisionFor={decisionFor} />
        <div>
          <p className="text-xs font-medium text-slate-500 mb-1 flex items-center gap-1"><Layers className="w-3.5 h-3.5" /> Concentration risk</p>
          {concentration.vendor_concentration.length === 0 && concentration.hosting_concentration.length === 0 ? (
            <p className="text-xs text-slate-400">No concentration thresholds breached</p>
          ) : (
            <div className="space-y-1">
              {concentration.vendor_concentration.map((v) => (
                <div key={v.vendor} className="text-xs text-slate-600"><span className="font-medium">{v.vendor}</span>: {v.count} systems ({v.pct}%)</div>
              ))}
              {concentration.hosting_concentration.map((h) => (
                <div key={h.hosting_type} className="text-xs text-slate-500 capitalize">{h.hosting_type.replace("_", " ")}: {h.count} ({h.pct}%)</div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}