import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShieldCheck } from "lucide-react";

export default function TechReadinessPanel({ readiness }) {
  if (!readiness) return null;
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2"><ShieldCheck className="w-4 h-4" /> Analysis readiness</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <div className="flex items-baseline justify-between">
            <span className="text-sm text-slate-600">Overall readiness</span>
            <span className="text-2xl font-bold text-slate-900">{readiness.overall_pct ?? "—"}%</span>
          </div>
          <p className="text-xs text-slate-500">Share of technology records with sufficient ownership, classification, lifecycle, risk, dependency and strategic-alignment information to produce reliable analysis.</p>
        </div>
        <div className="space-y-1.5">
          {readiness.dimensions.map((d) => (
            <div key={d.key}>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">{d.label}</span>
                <span className="text-slate-500">{d.pct ?? "—"}%{d.missing_count > 0 && <span className="text-amber-600 ml-1">({d.missing_count} missing)</span>}</span>
              </div>
              <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                <div className={`h-full rounded-full ${(d.pct ?? 0) >= 75 ? "bg-emerald-500" : (d.pct ?? 0) >= 40 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${d.pct ?? 0}%` }} />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}