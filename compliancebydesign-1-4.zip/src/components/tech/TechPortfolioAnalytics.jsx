import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, GitBranch } from "lucide-react";

const RISK_COLORS = { none: "#f1f5f9", low: "#fef3c7", medium: "#fed7aa", high: "#fca5a5" };
const CRIT_LABELS = { critical: "Critical", important: "Important", supporting: "Supporting" };
const WORKFLOW_STATUS_BADGE = {
  pending: "bg-slate-100 text-slate-700",
  in_progress: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  completed: "bg-purple-100 text-purple-700",
  returned: "bg-orange-100 text-orange-700",
};
const WORKFLOW_ORDER = ["in_progress", "pending", "returned", "approved", "rejected", "completed"];

function MiniBars({ title, rows, color = "#0ea5e9" }) {
  const max = Math.max(1, ...rows.map((r) => r.count));
  return (
    <div>
      <p className="text-xs font-medium text-slate-500 mb-1">{title}</p>
      <div className="space-y-1">
        {rows.length === 0 && <p className="text-xs text-slate-400">No data</p>}
        {rows.map((r) => (
          <div key={r.key} className="flex items-center gap-2">
            <span className="text-xs text-slate-600 w-28 truncate" title={r.key}>{r.key || "(unset)"}</span>
            <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${(r.count / max) * 100}%`, background: color }} />
            </div>
            <span className="text-xs text-slate-500 w-6 text-right">{r.count}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function TechPortfolioAnalytics({ analytics, decisions, workflowStatusByDecision }) {
  if (!analytics) return null;
  const { by_category, by_status, by_criticality, capability_maturity, risk_exposure_heatmap, strategic_alignment_matrix } = analytics;
  const critLevels = ["critical", "important", "supporting"];
  const riskLevels = ["none", "low", "medium", "high"];

  const workflowCounts = {};
  (decisions || []).forEach((d) => {
    const ws = workflowStatusByDecision?.[d.id];
    if (ws) workflowCounts[ws] = (workflowCounts[ws] || 0) + 1;
  });
  const totalDecisions = (decisions || []).length;
  const inWorkflow = Object.values(workflowCounts).reduce((a, b) => a + b, 0);

  return (
    <Card>
      <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><BarChart3 className="w-4 h-4" /> Portfolio analytics</CardTitle></CardHeader>
      <CardContent className="space-y-4">
        {totalDecisions > 0 && (
          <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/50">
            <p className="text-xs font-medium text-slate-500 mb-2 flex items-center gap-1"><GitBranch className="w-3.5 h-3.5" /> Decision workflow status ({inWorkflow} of {totalDecisions} in workflow)</p>
            <div className="flex flex-wrap gap-1.5">
              {WORKFLOW_ORDER.filter((s) => workflowCounts[s]).map((s) => (
                <Badge key={s} className={`text-[10px] ${WORKFLOW_STATUS_BADGE[s]}`}>{s.replace(/_/g, " ")}: {workflowCounts[s]}</Badge>
              ))}
              {inWorkflow === 0 && <span className="text-xs text-slate-400">No decisions routed through a workflow yet</span>}
            </div>
          </div>
        )}
        <div className="grid sm:grid-cols-2 gap-4">
          <MiniBars title="Systems by type" rows={by_category} color="#0ea5e9" />
          <MiniBars title="Systems by status" rows={by_status} color="#6366f1" />
          <MiniBars title="Systems by criticality" rows={by_criticality} color="#f59e0b" />
          <MiniBars title="Capabilities by maturity" rows={capability_maturity} color="#10b981" />
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1">Risk exposure heatmap (criticality × exposure)</p>
            <div className="overflow-x-auto">
              <table className="text-xs border-collapse">
                <thead><tr><th className="p-1"></th>{riskLevels.map((r) => <th key={r} className="p-1 text-slate-500 capitalize">{r}</th>)}</tr></thead>
                <tbody>
                  {critLevels.map((c) => (
                    <tr key={c}>
                      <td className="p-1 text-slate-600 font-medium">{CRIT_LABELS[c]}</td>
                      {riskLevels.map((r) => {
                        const cell = risk_exposure_heatmap.find((x) => x.criticality === c && x.risk_level === r);
                        const count = cell?.count || 0;
                        return <td key={r} className="p-1"><div className="w-12 h-8 rounded flex items-center justify-center font-medium text-slate-700" style={{ background: RISK_COLORS[r] }}>{count || ""}</div></td>;
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1">Strategic alignment (criticality × aligned)</p>
            <div className="overflow-x-auto">
              <table className="text-xs border-collapse">
                <thead><tr><th className="p-1"></th><th className="p-1 text-slate-500">Aligned</th><th className="p-1 text-slate-500">Not aligned</th></tr></thead>
                <tbody>
                  {critLevels.map((c) => (
                    <tr key={c}>
                      <td className="p-1 text-slate-600 font-medium">{CRIT_LABELS[c]}</td>
                      {[true, false].map((al) => {
                        const cell = strategic_alignment_matrix.find((x) => x.criticality === c && x.aligned === al);
                        return <td key={String(al)} className="p-1"><div className={`w-14 h-8 rounded flex items-center justify-center font-medium ${al ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{cell?.count || 0}</div></td>;
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}