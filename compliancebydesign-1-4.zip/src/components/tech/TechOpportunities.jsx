import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lightbulb } from "lucide-react";

const PRIORITY_BADGE = {
  critical: "bg-red-100 text-red-700",
  high: "bg-orange-100 text-orange-700",
  medium: "bg-sky-100 text-sky-700",
  low: "bg-slate-100 text-slate-600",
};
const TYPE_LABEL = { retain: "Retain", optimize: "Optimize", modernize: "Modernize", consolidate: "Consolidate", replace: "Replace", retire: "Retire" };
const WORKFLOW_STATUS_BADGE = {
  pending: "bg-slate-100 text-slate-700",
  in_progress: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  completed: "bg-purple-100 text-purple-700",
  returned: "bg-orange-100 text-orange-700",
};

export default function TechOpportunities({ opportunities, decisions, workflowStatusByDecision, onDecide }) {
  if (!opportunities) return null;
  const decisionFor = (o) => decisions?.find((d) => d.asset_id === o.asset_id && d.asset_type === o.asset_type);
  return (
    <Card>
      <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><Lightbulb className="w-4 h-4" /> Prioritised opportunities</CardTitle></CardHeader>
      <CardContent>
        {opportunities.length === 0 ? <p className="text-sm text-slate-500">No opportunities identified from the current data.</p> : (
          <div className="space-y-2">
            {opportunities.map((o) => (
              <div key={o.id} className="flex flex-col sm:flex-row sm:items-center gap-2 border border-slate-200 rounded-lg p-2.5">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="text-[10px]">{o.id}</Badge>
                    <Badge className={`text-[10px] ${PRIORITY_BADGE[o.priority] || PRIORITY_BADGE.medium}`}>{o.priority}</Badge>
                    <span className="text-xs font-medium text-slate-700">{TYPE_LABEL[o.opportunity_type]}</span>
                    <span className="text-xs text-slate-400">· {o.asset_name}</span>
                    {(() => { const dec = decisionFor(o); const ws = dec && workflowStatusByDecision?.[dec.id]; return ws ? <Badge className={`text-[10px] ${WORKFLOW_STATUS_BADGE[ws] || "bg-slate-100 text-slate-700"}`}>{ws.replace(/_/g, " ")}</Badge> : null; })()}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{o.rationale}</p>
                </div>
                {o.asset_id && <Button size="sm" variant="outline" onClick={() => onDecide(o)}>Set decision</Button>}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}