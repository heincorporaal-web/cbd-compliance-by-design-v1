import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Cpu, Gavel } from "lucide-react";

const DECISION_BADGE = {
  retain: "bg-emerald-100 text-emerald-700",
  optimize: "bg-sky-100 text-sky-700",
  modernize: "bg-amber-100 text-amber-700",
  consolidate: "bg-indigo-100 text-indigo-700",
  replace: "bg-orange-100 text-orange-700",
  retire: "bg-slate-200 text-slate-600",
};
const HEALTH_BADGE = { no_owner: "bg-amber-100 text-amber-700", no_classification: "bg-amber-100 text-amber-700", decommissioned: "bg-slate-200 text-slate-600", assessment_overdue: "bg-red-100 text-red-700" };
const WORKFLOW_STATUS_BADGE = {
  pending: "bg-slate-100 text-slate-700",
  in_progress: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  completed: "bg-purple-100 text-purple-700",
  returned: "bg-orange-100 text-orange-700",
};

export default function TechSystemsTable({ systems, decisions, workflowStatusByDecision, onDecide }) {
  if (!systems) return null;
  const decisionFor = (id) => decisions.find((d) => d.asset_id === id && d.asset_type === "ICTSystem");
  return (
    <Card>
      <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><Cpu className="w-4 h-4" /> Technology portfolio ({systems.length})</CardTitle></CardHeader>
      <CardContent>
        {systems.length === 0 ? <p className="text-sm text-slate-500">No ICT systems found for this company.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-slate-400 border-b text-xs">
                <th className="py-1 pr-2">System</th><th className="pr-2">Criticality</th><th className="pr-2">Status</th>
                <th className="pr-2 text-right">Strategic value</th><th className="pr-2">Risk</th><th className="pr-2">Health</th>
                <th className="pr-2">Recommended</th><th className="pr-2">Decision</th><th className="pr-2">Workflow</th><th></th>
              </tr></thead>
              <tbody>
                {systems.map((s) => {
                  const dec = decisionFor(s.id);
                  return (
                    <tr key={s.id} className="border-b last:border-0 hover:bg-slate-50">
                      <td className="py-1.5 pr-2"><p className="font-medium text-slate-800 truncate max-w-[160px]" title={s.name}>{s.name}</p><p className="text-[10px] text-slate-400">{s.system_type}</p></td>
                      <td className="pr-2 capitalize text-xs">{s.criticality}</td>
                      <td className="pr-2 text-xs">{s.status}</td>
                      <td className="pr-2 text-right font-medium">{s.strategic_value}<span className="text-slate-400 text-[10px]">/100</span></td>
                      <td className="pr-2 text-xs capitalize">{s.risk_exposure}</td>
                      <td className="pr-2">
                        {s.health_flags.length === 0 ? <span className="text-xs text-emerald-600">Healthy</span> :
                          <div className="flex flex-wrap gap-0.5">{s.health_flags.map((f) => <Badge key={f} className={`text-[9px] ${HEALTH_BADGE[f] || "bg-slate-100 text-slate-600"}`}>{f.replace(/_/g, " ")}</Badge>)}</div>}
                      </td>
                      <td className="pr-2"><Badge className={`text-[10px] ${DECISION_BADGE[s.recommended_decision]}`}>{s.recommended_decision}</Badge></td>
                      <td className="pr-2">{dec ? <Badge className={`text-[10px] ${DECISION_BADGE[dec.decision]}`}>{dec.decision}</Badge> : <span className="text-xs text-slate-400">—</span>}</td>
                      <td className="pr-2">{dec && workflowStatusByDecision?.[dec.id] ? <Badge className={`text-[10px] ${WORKFLOW_STATUS_BADGE[workflowStatusByDecision[dec.id]] || "bg-slate-100 text-slate-700"}`}>{workflowStatusByDecision[dec.id].replace(/_/g, " ")}</Badge> : <span className="text-xs text-slate-400">—</span>}</td>
                      <td><Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => onDecide({ asset_id: s.id, asset_name: s.name, asset_type: "ICTSystem", opportunity_type: s.recommended_decision, rationale: `Recommended: ${s.recommended_decision}. Strategic value ${s.strategic_value}/100.`, priority: s.priority })}><Gavel className="w-3.5 h-3.5" /></Button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}