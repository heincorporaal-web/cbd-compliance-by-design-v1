import React from "react";
import { Link, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import {
  LayoutDashboard, Workflow, GitBranch,
  ShieldAlert, Handshake,
  BarChart3, Boxes, AppWindow, Radar, Server,
  BookOpen,
} from "lucide-react";

const MODULE_TABS = {
  obd: [
    { label: "Dashboard", path: "/OperationsByDesign", icon: LayoutDashboard },
    { label: "Process Diagrams", path: "/AdvancedProcessModelling", icon: Workflow },
    { label: "Process Management", path: "/ProcessManagement", icon: GitBranch },
  ],
  pbd: [
    { label: "Dashboard", path: "/PartnerByDesign", icon: LayoutDashboard },
    { label: "Third Party Risk", path: "/AdvancedThirdPartyRiskManagement", icon: ShieldAlert },
    { label: "Third Parties", path: "/ThirdParties", icon: Handshake },
  ],
  abd: [
    { label: "Dashboard", path: "/AssetsByDesign", icon: LayoutDashboard },
    { label: "CMDB Dashboard", path: "/CMDBDashboard", icon: BarChart3 },
    { label: "CI Inventory", path: "/CMDBInventory", icon: Boxes },
    { label: "Applications", path: "/CMDBApplications", icon: AppWindow },
    { label: "Discovery", path: "/AdvancedAssetManagement", icon: Radar },
    { label: "ICT Systems", path: "/ICTSystems", icon: Server },
  ],
  gbd: [
    { label: "Dashboard", path: "/GovernanceByDesign", icon: LayoutDashboard },
    { label: "Governance Library", path: "/GovernanceByDesignModule", icon: BookOpen },
  ],
};

export default function ModuleRibbon({ moduleKey }) {
  const { pathname } = useLocation();
  const tabs = MODULE_TABS[moduleKey] || [];

  return (
    <div className={`bg-gradient-to-r from-slate-800 to-slate-900 text-white shadow-md sticky top-0 z-20`}>
      <div className="px-3 lg:px-6 py-2 flex items-center gap-3 flex-wrap">
        {/* Brand */}
        <Link to="/" className="flex items-center gap-2 shrink-0 hover:opacity-90 transition-opacity">
          <ArrowLeft className="w-4 h-4 text-white/60" />
          <span className="text-white/60 text-xs font-medium hidden sm:inline">CBD</span>
        </Link>

        <div className="w-px h-5 bg-white/20 hidden sm:block" />

        {/* Nav tabs */}
        <nav className="flex items-center gap-1 flex-wrap flex-1 min-w-0">
          {tabs.map((tab) => {
            const isActive = pathname === tab.path;
            const TabIcon = tab.icon;
            return (
              <Link
                key={tab.path}
                to={tab.path}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  isActive
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-white/70 hover:bg-white/10 hover:text-white"
                }`}
              >
                <TabIcon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{tab.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}