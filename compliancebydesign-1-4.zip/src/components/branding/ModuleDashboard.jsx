import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import ModuleRibbon from "@/components/branding/ModuleRibbon";
import { InfoTileColumn } from "@/components/dashboard/InfoTile";

export default function ModuleDashboard({ brand, Icon, logoUrl, metrics, isLoading, enterPath, enterLabel, features, moduleKey }) {
  const attentionMetrics = metrics.filter((m) => m.attention && m.value > 0);

  return (
    <div>
      <ModuleRibbon moduleKey={moduleKey} />
      <div className="p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
        {/* Module title strip */}
        <section className={`rounded-xl bg-gradient-to-br ${brand.gradient} text-white shadow-md overflow-hidden`}>
          <div className="p-5 lg:p-6 flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3 min-w-0">
              {logoUrl ? (
                <div className="w-12 h-12 rounded-xl bg-white shadow flex items-center justify-center shrink-0 overflow-hidden">
                  <img src={logoUrl} alt={brand.name} className="w-9 h-9 object-contain" />
                </div>
              ) : (
                <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                  <Icon className="w-6 h-6" />
                </div>
              )}
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl font-bold">{brand.name}</h1>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-white/20">{brand.short}</span>
                </div>
                <p className="text-white/80 text-xs mt-0.5 max-w-2xl">{brand.tagline}</p>
              </div>
            </div>
            <Link to={enterPath}>
              <Button className="bg-white text-slate-900 hover:bg-white/90 shadow gap-2 shrink-0">
                {enterLabel} <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </section>

        {/* Needs attention banner */}
        {!isLoading && attentionMetrics.length > 0 && (
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="p-4 flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-orange-600 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-orange-900">
                  {attentionMetrics.length} area{attentionMetrics.length > 1 ? "s" : ""} need attention
                </p>
                <p className="text-xs text-orange-700 mt-0.5">
                  {attentionMetrics.map((m) => `${m.value} ${m.label.toLowerCase()}`).join(" · ")}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Metric tiles — compact column of split tiles */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-600 rounded-full animate-spin" />
          </div>
        ) : (
          <div className="max-w-sm">
            <InfoTileColumn
              title="Dashboard overview"
              items={metrics.map(m => ({
                label: m.label,
                value: m.value,
                to: m.link || enterPath,
                attention: m.attention && m.value > 0,
              }))}
            />
          </div>
        )}

        {/* Feature cards */}
        {features && features.length > 0 && (
          <div>
            <h2 className="text-sm font-semibold text-slate-700 mb-3">Module capabilities</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {features.map((f, i) => (
                <Card key={i} className="p-4">
                  <div className={`w-8 h-8 p-[2px] bg-gradient-to-br ${brand.gradient} rounded-lg mb-2`}>
                    <div className="w-full h-full bg-slate-100 rounded-md flex items-center justify-center">
                      <f.icon className={`w-4 h-4 ${brand.softText}`} />
                    </div>
                  </div>
                  <h3 className="font-semibold text-sm text-slate-800">{f.title}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">{f.desc}</p>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Suite footer */}
        <div className={`rounded-2xl border ${brand.border} ${brand.softBg} p-4 flex items-center gap-3`}>
          {logoUrl ? (
            <div className="w-9 h-9 rounded-lg bg-white flex items-center justify-center shrink-0 overflow-hidden ring-1 ring-slate-200">
              <img src={logoUrl} alt={brand.name} className="w-7 h-7 object-contain" />
            </div>
          ) : (
            <div className={`w-9 h-9 p-[2px] bg-gradient-to-br ${brand.gradient} rounded-lg shrink-0`}>
              <div className="w-full h-full bg-slate-100 rounded-md flex items-center justify-center">
                <Icon className={`w-5 h-5 ${brand.softText}`} />
              </div>
            </div>
          )}
          <div>
            <p className={`text-sm font-semibold ${brand.softText}`}>{brand.name} is part of the CBD suite</p>
            <p className="text-xs text-slate-500">
              Shares the same companies, stakeholders, risks, controls and frameworks as the rest of Compliance by Design.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}