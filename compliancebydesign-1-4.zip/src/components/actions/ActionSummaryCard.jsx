import React from "react";
import { Card } from "@/components/ui/card";

/**
 * Compact summary card matching the reworked dashboard language:
 * white surface, coloured icon badge top-right, large count, label and sub-text.
 *
 * Props:
 *  - icon: lucide icon component
 *  - value: number / string shown large
 *  - label: small bold label under the value
 *  - sub: tiny muted sub-text
 *  - accent: tailwind text color class for the icon (e.g. "text-red-600")
 *  - tint: tailwind bg gradient for the icon badge (e.g. "from-red-50 to-orange-50")
 *  - active: boolean — highlighted border when this filter is active
 *  - onClick: optional click handler (turns the card into a button)
 */
export default function ActionSummaryCard({ icon: Icon, value, label, sub, accent = "text-slate-600", tint = "bg-slate-100", active = false, onClick }) {
  const inner = (
    <Card className={`border shadow-sm transition-all overflow-hidden ${active ? "border-primary ring-2 ring-primary/20" : "border-slate-200"} ${onClick ? "cursor-pointer hover:shadow-md hover:border-slate-300" : ""}`}>
      <div className="p-4 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-3xl font-bold text-slate-900 leading-none">{value}</p>
          <p className="text-sm font-medium text-slate-700 mt-2">{label}</p>
          {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
        </div>
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 bg-gradient-to-br ${tint}`}>
          {Icon && <Icon className={`w-5 h-5 ${accent}`} />}
        </div>
      </div>
    </Card>
  );
  return onClick ? (
    <button onClick={onClick} className="text-left w-full">{inner}</button>
  ) : inner;
}