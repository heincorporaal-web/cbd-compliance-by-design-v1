import React from "react";
import { Card } from "@/components/ui/card";

/**
 * Summary widget matching the dashboard reference style:
 *  - white card with subtle border
 *  - dark primary header bar with icon + uppercase white title
 *  - body rows of label (left) / bold value (right)
 *  - optional highlight rows (light orange background) for attention items
 *
 * Props:
 *  - icon: lucide icon component
 *  - title: uppercase widget title
 *  - rows: [{ label, value, highlight?: boolean }]
 */
export default function ActionSummaryWidget({ icon: Icon, title, rows = [] }) {
  return (
    <Card className="border border-slate-200 shadow-sm overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground">
        {Icon && <Icon className="w-4 h-4 shrink-0" />}
        <h3 className="text-xs font-bold tracking-wider uppercase truncate">{title}</h3>
      </div>
      <div className="divide-y divide-slate-100">
        {rows.map((r, i) => (
          <div
            key={i}
            className={`flex items-center justify-between px-4 py-2 text-sm ${r.highlight ? "bg-orange-50" : ""}`}
          >
            <span className="text-slate-600">{r.label}</span>
            <span className="font-bold text-slate-900">{r.value}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}