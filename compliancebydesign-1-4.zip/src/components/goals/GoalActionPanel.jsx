import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, ListChecks, Pencil } from "lucide-react";
import { format } from "date-fns";

const PRIORITY_STYLES = {
  low: "bg-slate-100 text-slate-700 border-slate-300",
  medium: "bg-blue-100 text-blue-700 border-blue-300",
  high: "bg-orange-100 text-orange-700 border-orange-300",
  critical: "bg-red-100 text-red-700 border-red-300",
};

const STATUS_STYLES = {
  open: "bg-slate-100 text-slate-700 border-slate-300",
  in_progress: "bg-blue-100 text-blue-700 border-blue-300",
  completed: "bg-green-100 text-green-700 border-green-300",
  cancelled: "bg-slate-100 text-slate-500 border-slate-300",
  overdue: "bg-red-100 text-red-700 border-red-300",
};

/** Generate the next action reference number: A + YYYYMM + - + 3-digit seq */
function generateActionRef(existingActions) {
  const now = new Date();
  const yearMonth = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}`;
  const prefix = `A${yearMonth}-`;
  let max = 0;
  for (const a of existingActions) {
    const ref = a?.reference_number || "";
    if (ref.startsWith(prefix)) {
      const seq = parseInt(ref.slice(prefix.length), 10);
      if (!isNaN(seq) && seq > max) max = seq;
    }
  }
  return `${prefix}${String(max + 1).padStart(3, "0")}`;
}

const EMPTY_ACTION = {
  title: "",
  description: "",
  priority: "medium",
  planned_completion_date: "",
  action_owner: "",
  expected_results: "",
  status: "open",
  notes: "",
};

export default function GoalActionPanel({ goalId, companyId }) {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAction, setEditingAction] = useState(null);
  const [formData, setFormData] = useState(EMPTY_ACTION);

  const { data: actions = [], isLoading } = useQuery({
    queryKey: ["goalActions", goalId],
    queryFn: () => base44.entities.GoalAction.filter({ goal_id: goalId }, { sort: "created_date" }),
    enabled: !!goalId,
  });

  const actionList = actions?.items || actions || [];

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.GoalAction.create(data),
    onSuccess: () => queryClient.invalidateQueries(["goalActions", goalId]),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.GoalAction.update(id, data),
    onSuccess: () => queryClient.invalidateQueries(["goalActions", goalId]),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.GoalAction.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["goalActions", goalId]),
  });

  const openCreate = () => {
    setEditingAction(null);
    setFormData(EMPTY_ACTION);
    setIsDialogOpen(true);
  };

  const openEdit = (action) => {
    setEditingAction(action);
    setFormData({
      title: action.title || "",
      description: action.description || "",
      priority: action.priority || "medium",
      planned_completion_date: action.planned_completion_date || "",
      action_owner: action.action_owner || "",
      expected_results: action.expected_results || "",
      status: action.status || "open",
      notes: action.notes || "",
    });
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.title.trim()) return;
    if (editingAction) {
      await updateMutation.mutateAsync({ id: editingAction.id, data: formData });
    } else {
      const refNumber = generateActionRef(actionList);
      await createMutation.mutateAsync({
        ...formData,
        reference_number: refNumber,
        goal_id: goalId,
        company_id: companyId,
      });
    }
    setIsDialogOpen(false);
    setFormData(EMPTY_ACTION);
    setEditingAction(null);
  };

  const handleDelete = async (id) => {
    await deleteMutation.mutateAsync(id);
  };

  const completedCount = actionList.filter(a => a.status === "completed").length;

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <ListChecks className="w-5 h-5 text-emerald-600" />
            Action Plan
            {actionList.length > 0 && (
              <Badge variant="outline" className="ml-1 bg-slate-50">
                {completedCount}/{actionList.length} done
              </Badge>
            )}
          </CardTitle>
          {goalId && (
            <Button type="button" variant="outline" size="sm" onClick={openCreate}>
              <Plus className="w-4 h-4 mr-1" /> Add Action
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        {!goalId ? (
          <p className="text-sm text-slate-500 text-center py-4">Save the goal first to add action items</p>
        ) : isLoading ? (
          <p className="text-sm text-slate-500 text-center py-4">Loading actions…</p>
        ) : actionList.length === 0 ? (
          <p className="text-sm text-slate-500 text-center py-4">No action items yet</p>
        ) : (
          <div className="space-y-3">
            {actionList.map((action) => (
              <div key={action.id} className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-mono text-xs font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                        {action.reference_number}
                      </span>
                      <Badge variant="outline" className={PRIORITY_STYLES[action.priority]}>
                        {action.priority}
                      </Badge>
                      <Badge variant="outline" className={STATUS_STYLES[action.status]}>
                        {action.status?.replace("_", " ")}
                      </Badge>
                    </div>
                    <p className="font-medium text-slate-900">{action.title}</p>
                    {action.description && (
                      <p className="text-sm text-slate-600 mt-1">{action.description}</p>
                    )}
                    {action.expected_results && (
                      <p className="text-sm text-slate-500 mt-1">
                        <span className="font-medium">Expected results:</span> {action.expected_results}
                      </p>
                    )}
                    <div className="flex items-center gap-4 mt-2 text-xs text-slate-500 flex-wrap">
                      {action.action_owner && <span>Owner: {action.action_owner}</span>}
                      {action.planned_completion_date && (
                        <span>Due: {format(new Date(action.planned_completion_date), "d MMM yyyy")}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button type="button" variant="ghost" size="icon" onClick={() => openEdit(action)}>
                      <Pencil className="w-4 h-4 text-slate-500" />
                    </Button>
                    <Button type="button" variant="ghost" size="icon" onClick={() => handleDelete(action.id)}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingAction ? "Edit Action Item" : "New Action Item"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Action Title *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Enter action title"
              />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                placeholder="Describe the action"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Priority</Label>
                <Select value={formData.priority} onValueChange={(v) => setFormData({ ...formData, priority: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Planned Completion Date</Label>
                <Input
                  type="date"
                  value={formData.planned_completion_date}
                  onChange={(e) => setFormData({ ...formData, planned_completion_date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Action Owner</Label>
                <Input
                  value={formData.action_owner}
                  onChange={(e) => setFormData({ ...formData, action_owner: e.target.value })}
                  placeholder="Owner name"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Expected Results</Label>
              <Textarea
                value={formData.expected_results}
                onChange={(e) => setFormData({ ...formData, expected_results: e.target.value })}
                rows={2}
                placeholder="What are the expected outcomes?"
              />
            </div>
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={2}
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button type="button" onClick={handleSave} disabled={!formData.title.trim()}>
                {editingAction ? "Save Changes" : "Create Action"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}