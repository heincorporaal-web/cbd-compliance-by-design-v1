import React, { useState, useRef, useMemo, useEffect } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Upload, FileCheck2, AlertTriangle, AlertCircle, CheckCircle2, XCircle,
  Search, GitBranch, FileText, Download, ArrowRight, ArrowLeft, Loader2,
  Network, Users, ShieldCheck, ClipboardList,
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { validateBpmnXml, extractProcessHints } from "@/components/processmodelling/bpmnValidator";
import { EMPTY_BPMN_XML } from "@/components/processmodelling/BpmnDesigner";

const STEPS = [
  { key: "upload", label: "Upload", icon: Upload },
  { key: "validate", label: "Validate", icon: FileCheck2 },
  { key: "resolve", label: "Resolve", icon: Search },
  { key: "preview", label: "Preview", icon: Network },
  { key: "review", label: "Review", icon: ClipboardList },
  { key: "import", label: "Import", icon: ArrowRight },
  { key: "report", label: "Report", icon: FileText },
];

// Simple BPMN viewer for the preview step (lazy-loaded bpmn-js)
function BpmnPreview({ xml }) {
  const containerRef = useRef(null);
  useEffect(() => {
    let viewer;
    let cancelled = false;
    (async () => {
      const BpmnViewer = (await import("bpmn-js/lib/NavigatedViewer")).default;
      await import("bpmn-js/dist/assets/diagram-js.css");
      await import("bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css");
      if (cancelled || !containerRef.current) return;
      viewer = new BpmnViewer({ container: containerRef.current });
      try {
        await viewer.importXML(xml);
        viewer.get("canvas").zoom("fit-viewport");
      } catch (e) {
        // ignore — validation step already flagged errors
      }
    })();
    return () => {
      cancelled = true;
      try { viewer?.destroy(); } catch {}
    };
  }, [xml]);
  return <div ref={containerRef} className="w-full h-[300px] bg-slate-50 rounded-lg border border-slate-200" />;
}

export default function BpmnImportWizard({ open, onClose, companyId, processes, onImported }) {
  const [step, setStep] = useState(0);
  const [fileName, setFileName] = useState("");
  const [fileType, setFileType] = useState(""); // bpmn_xml | json | csv
  const [xml, setXml] = useState("");
  const [validation, setValidation] = useState(null);
  const [validating, setValidating] = useState(false);
  const [selectedProcessId, setSelectedProcessId] = useState("");
  const [matchScore, setMatchScore] = useState(null);
  const [stakeholders, setStakeholders] = useState([]);
  const [importing, setImporting] = useState(false);
  const [reconciliation, setReconciliation] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef(null);

  // Reset when opened
  useEffect(() => {
    if (open) {
      setStep(0);
      setFileName("");
      setFileType("");
      setXml("");
      setValidation(null);
      setSelectedProcessId("");
      setMatchScore(null);
      setReconciliation(null);
    }
  }, [open]);

  // Load stakeholders for swimlane resolution
  useEffect(() => {
    if (!open || !companyId) return;
    base44.entities.Stakeholder.filter({ company_id: companyId }, { limit: 200, fields: ["full_name", "job_title", "email", "stakeholder_group_ids"] })
      .then((res) => setStakeholders(res.items || res || []))
      .catch(() => {});
  }, [open, companyId]);

  const validationPassed = validation && validation.valid;

  // ---- Step 1: Upload ----
  const handleFile = async (file) => {
    if (!file) return;
    const name = file.name.toLowerCase();
    setFileName(file.name);
    try {
      const text = await file.text();
      if (name.endsWith(".bpmn") || name.endsWith(".xml")) {
        setFileType("bpmn_xml");
        setXml(text);
      } else if (name.endsWith(".json")) {
        setFileType("json");
        const parsed = JSON.parse(text);
        setXml(jsonToBpmnXml(parsed));
      } else if (name.endsWith(".csv")) {
        setFileType("csv");
        setXml(csvToBpmnXml(text));
      } else {
        toast.error("Unsupported file type. Use .bpmn, .xml, .json, or .csv");
        return;
      }
      setStep(1);
      runValidation(text.endsWith(">") ? text : (name.endsWith(".bpmn") || name.endsWith(".xml") ? text : xml));
    } catch (e) {
      toast.error("Could not read file: " + (e?.message || e));
    }
  };

  const runValidation = (xmlStr) => {
    setValidating(true);
    setTimeout(() => {
      const result = validateBpmnXml(xmlStr);
      setValidation(result);
      setValidating(false);
    }, 100);
  };

  // ---- Step 2: Validate → proceed ----
  const proceedFromValidate = () => {
    if (!validation) return;
    // Auto-match process references
    const hints = extractProcessHints(xml);
    const bestMatch = findBestProcessMatch(hints, processes);
    if (bestMatch) {
      setSelectedProcessId(bestMatch.id);
      setMatchScore(bestMatch.score);
    }
    setStep(2);
  };

  // ---- Step 3: Resolve → proceed ----
  const proceedFromResolve = () => {
    if (!selectedProcessId) {
      toast.error("Select a target process to continue");
      return;
    }
    setStep(3);
  };

  // ---- Step 5: Import ----
  const handleImport = async () => {
    setImporting(true);
    try {
      const proc = processes.find((p) => p.id === selectedProcessId);
      if (!proc) throw new Error("Selected process not found");

      // Check for existing diagram
      const existing = await base44.entities.ProcessDiagram.filter({ process_id: proc.id, company_id: companyId });
      const existingDraft = (existing.items || existing || []).find((d) => d.status === "draft");

      const hints = extractProcessHints(xml);
      const laneNames = hints.laneNames;
      const unmatchedLanes = laneNames.filter((ln) =>
        !stakeholders.some((s) => (s.full_name || "").toLowerCase() === ln.toLowerCase() || (s.job_title || "").toLowerCase().includes(ln.toLowerCase()))
      );

      const recon = {
        created: 0, updated: 0, skipped: 0, rejected: 0,
        resolved: { process: 1, stakeholders: laneNames.length - unmatchedLanes.length },
        unmatched: { lanes: unmatchedLanes, stakeholders: [] },
        unsupportedElements: validation.unsupportedElements,
        validationErrors: validation.errors.length,
        validationWarnings: validation.warnings.length,
      };

      const payload = {
        process_id: proc.id,
        process_code: proc.process_code,
        process_name: proc.name,
        company_id: companyId,
        bpmn_xml: xml,
        canvas_meta: {
          diagram_process_id: proc.id,
          process_reference: proc.process_code,
          process_level: "L" + (proc.level ?? 3),
          process_owner: proc.process_owner || "",
        },
        element_meta: {},
        status: "draft",
        version_number: 1,
        import_source: fileType === "bpmn_xml" ? "bpmn_xml_import" : fileType === "json" ? "json_import" : "csv_import",
        import_reconciliation: recon,
        validation_results: {
          valid: validation.valid,
          error_count: validation.errors.length,
          warning_count: validation.warnings.length,
          errors: validation.errors.slice(0, 50),
          warnings: validation.warnings.slice(0, 50),
          stats: validation.stats,
          validated_at: new Date().toISOString(),
        },
        change_log: [{
          action: "imported",
          actor: "import-wizard",
          timestamp: new Date().toISOString(),
          summary: `Imported from ${fileName} (${fileType})`,
        }],
      };

      let saved;
      if (existingDraft && existingDraft.id !== proc.id) {
        // Overwrite existing draft
        saved = await base44.entities.ProcessDiagram.update(existingDraft.id, payload);
        recon.updated = 1;
      } else if (existingDraft) {
        saved = await base44.entities.ProcessDiagram.update(existingDraft.id, payload);
        recon.updated = 1;
      } else {
        saved = await base44.entities.ProcessDiagram.create(payload);
        recon.created = 1;
      }

      setReconciliation({ ...recon, diagramId: saved.id });
      setImporting(false);
      setStep(6);
      if (onImported) onImported();
    } catch (e) {
      setImporting(false);
      toast.error("Import failed: " + (e?.message || e));
    }
  };

  const downloadReport = () => {
    if (!reconciliation) return;
    const report = {
      timestamp: new Date().toISOString(),
      file: fileName,
      fileType,
      targetProcess: processes.find((p) => p.id === selectedProcessId)?.process_code,
      ...reconciliation,
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `import-reconciliation-${fileName.replace(/\.[^.]+$/, "")}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const canClose = !importing;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (canClose) onClose(v); }}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-indigo-600" />
            Import BPMN 2.0 Process Diagram
          </DialogTitle>
        </DialogHeader>

        {/* Step indicator */}
        <div className="flex items-center gap-1 mb-4 overflow-x-auto pb-1">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            const active = i === step;
            const done = i < step;
            return (
              <div key={s.key} className="flex items-center gap-1 flex-shrink-0">
                <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  active ? "bg-indigo-600 text-white" : done ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-400"
                }`}>
                  <Icon className="w-3.5 h-3.5" />
                  {s.label}
                </div>
                {i < STEPS.length - 1 && <ArrowRight className="w-3 h-3 text-slate-300 flex-shrink-0" />}
              </div>
            );
          })}
        </div>

        {/* Step 0: Upload */}
        {step === 0 && (
          <div className="space-y-4">
            <div
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files[0]); }}
              className={`border-2 border-dashed rounded-xl p-10 text-center transition-colors cursor-pointer ${
                dragOver ? "border-indigo-500 bg-indigo-50" : "border-slate-300 hover:border-indigo-400 hover:bg-slate-50"
              }`}
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="w-10 h-10 mx-auto mb-3 text-slate-300" />
              <p className="font-medium text-slate-700">Drop a BPMN file here or click to browse</p>
              <p className="text-sm text-slate-400 mt-1">Supports .bpmn, .xml (BPMN 2.0), .json, .csv</p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".bpmn,.xml,.json,.csv"
                className="hidden"
                onChange={(e) => { handleFile(e.target.files[0]); e.target.value = ""; }}
              />
            </div>
            <div className="text-xs text-slate-500 space-y-1">
              <p className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> BPMN 2.0 XML with tasks, events, gateways, sub-processes, pools and swimlanes</p>
              <p className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Structured JSON or CSV process definitions (converted to BPMN)</p>
              <p className="flex items-center gap-1.5"><AlertTriangle className="w-3.5 h-3.5 text-amber-500" /> Unsupported BPMN elements are flagged, not silently removed</p>
              <p className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5 text-indigo-500" /> Imports as Draft — approved versions are never overwritten</p>
            </div>
          </div>
        )}

        {/* Step 1: Validate */}
        {step === 1 && (
          <div className="space-y-3">
            {validating ? (
              <div className="flex items-center justify-center py-10 text-slate-400">
                <Loader2 className="w-6 h-6 animate-spin mr-2" /> Validating BPMN structure…
              </div>
            ) : validation ? (
              <>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">{fileName}</Badge>
                  {validationPassed ? (
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">
                      <CheckCircle2 className="w-3 h-3 mr-1" /> Valid
                    </Badge>
                  ) : (
                    <Badge className="bg-red-100 text-red-700 border-red-200">
                      <XCircle className="w-3 h-3 mr-1" /> {validation.errors.length} error(s)
                    </Badge>
                  )}
                  {validation.warnings.length > 0 && (
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200">
                      <AlertTriangle className="w-3 h-3 mr-1" /> {validation.warnings.length} warning(s)
                    </Badge>
                  )}
                </div>

                {/* Stats */}
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: "Processes", value: validation.stats.processes },
                    { label: "Tasks", value: validation.stats.tasks },
                    { label: "Gateways", value: validation.stats.gateways },
                    { label: "Events", value: validation.stats.events },
                    { label: "Flows", value: validation.stats.flows },
                    { label: "Pools", value: validation.stats.pools },
                    { label: "Lanes", value: validation.stats.lanes },
                    { label: "Unsupported", value: validation.stats.unsupported },
                  ].map((s) => (
                    <div key={s.label} className="bg-slate-50 rounded-lg p-2 text-center">
                      <div className="text-lg font-semibold text-slate-700">{s.value}</div>
                      <div className="text-[10px] uppercase text-slate-400">{s.label}</div>
                    </div>
                  ))}
                </div>

                {/* Errors */}
                {validation.errors.length > 0 && (
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {validation.errors.slice(0, 20).map((e, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-red-700 bg-red-50 rounded p-2">
                        <AlertCircle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                        <span>{e.message}</span>
                      </div>
                    ))}
                    {validation.errors.length > 20 && (
                      <p className="text-xs text-slate-400 px-2">…and {validation.errors.length - 20} more errors</p>
                    )}
                  </div>
                )}

                {/* Warnings */}
                {validation.warnings.length > 0 && (
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {validation.warnings.slice(0, 15).map((w, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 rounded p-2">
                        <AlertTriangle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                        <span>{w.message}</span>
                      </div>
                    ))}
                    {validation.warnings.length > 15 && (
                      <p className="text-xs text-slate-400 px-2">…and {validation.warnings.length - 15} more warnings</p>
                    )}
                  </div>
                )}

                {validation.unsupportedElements.length > 0 && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                    <p className="text-xs font-semibold text-amber-800 mb-1">Unsupported BPMN elements (flagged for review):</p>
                    <div className="flex flex-wrap gap-1">
                      {validation.unsupportedElements.slice(0, 10).map((u, i) => (
                        <Badge key={i} variant="outline" className="text-[10px] bg-white">{u.tag}{u.name ? `: ${u.name}` : ""}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : null}
          </div>
        )}

        {/* Step 2: Resolve */}
        {step === 2 && (
          <div className="space-y-3">
            <p className="text-sm text-slate-600">Match the imported diagram to an existing organisational process. This links the BPMN diagram to your value chain, workstream and process hierarchy without creating duplicates.</p>
            {matchScore && (
              <div className="flex items-center gap-2 text-xs">
                <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200">
                  <Search className="w-3 h-3 mr-1" /> Best match: {Math.round(matchScore * 100)}%
                </Badge>
              </div>
            )}
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Target Organisational Process</label>
              <select
                value={selectedProcessId}
                onChange={(e) => setSelectedProcessId(e.target.value)}
                className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">— Select a process —</option>
                {processes.map((p) => (
                  <option key={p.id} value={p.id}>
                    L{p.level} · {p.process_code} · {p.name}
                  </option>
                ))}
              </select>
            </div>
            {selectedProcessId && (() => {
              const p = processes.find((x) => x.id === selectedProcessId);
              if (!p) return null;
              return (
                <Card className="p-3 space-y-1.5 text-xs">
                  <div className="flex items-center gap-1.5 font-medium text-slate-700">
                    <GitBranch className="w-3.5 h-3.5 text-indigo-500" /> {p.name}
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-slate-500">
                    <span>Code: <span className="font-mono">{p.process_code}</span></span>
                    <span>Level: L{p.level}</span>
                    <span>Owner: {p.process_owner || "—"}</span>
                    <span>Criticality: {p.criticality || "—"}</span>
                  </div>
                </Card>
              );
            })()}
            {/* Swimlane resolution preview */}
            {validation && (() => {
              const hints = extractProcessHints(xml);
              if (!hints.laneNames.length) return null;
              return (
                <div className="space-y-1.5">
                  <p className="text-xs font-medium text-slate-500 flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> Swimlane resolution</p>
                  {hints.laneNames.map((ln, i) => {
                    const matched = stakeholders.find((s) => (s.full_name || "").toLowerCase() === ln.toLowerCase());
                    return (
                      <div key={i} className="flex items-center justify-between text-xs bg-slate-50 rounded px-2 py-1.5">
                        <span className="text-slate-600">{ln}</span>
                        {matched ? (
                          <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 text-[10px]">Resolved: {matched.full_name}</Badge>
                        ) : (
                          <Badge className="bg-amber-50 text-amber-700 border-amber-200 text-[10px]">Unmatched — review</Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        )}

        {/* Step 3: Preview */}
        {step === 3 && (
          <div className="space-y-3">
            <p className="text-sm text-slate-600">Preview of the imported BPMN diagram. You can edit it further after import.</p>
            {validationPassed || (validation && validation.errors.length === 0) ? (
              <BpmnPreview xml={xml} />
            ) : (
              <div className="flex items-center justify-center h-[300px] bg-slate-50 rounded-lg border border-slate-200 text-slate-400 text-sm">
                <div className="text-center">
                  <AlertCircle className="w-8 h-8 mx-auto mb-2 text-red-300" />
                  Diagram has structural errors and cannot be fully rendered. You can still import it as a Draft to fix in the designer.
                </div>
              </div>
            )}
          </div>
        )}

        {/* Step 4: Review */}
        {step === 4 && (
          <div className="space-y-3">
            <p className="text-sm text-slate-600">Review the proposed changes before importing. The diagram will be saved as a <strong>Draft</strong> — no approved versions will be overwritten.</p>
            <Card className="p-3 space-y-2">
              <div className="text-xs font-semibold text-slate-700 uppercase tracking-wide">Summary</div>
              <div className="space-y-1 text-sm">
                <ReviewRow icon={<FileText className="w-3.5 h-3.5 text-slate-400" />} label="File" value={fileName} />
                <ReviewRow icon={<GitBranch className="w-3.5 h-3.5 text-indigo-500" />} label="Target process" value={(() => { const p = processes.find((x) => x.id === selectedProcessId); return p ? `${p.process_code} · ${p.name}` : "—"; })()} />
                <ReviewRow icon={<FileCheck2 className="w-3.5 h-3.5 text-emerald-500" />} label="Validation" value={validation?.valid ? "Passed" : `${validation?.errors.length || 0} errors, ${validation?.warnings.length || 0} warnings`} />
                <ReviewRow icon={<Network className="w-3.5 h-3.5 text-slate-400" />} label="Elements" value={`${validation?.stats.tasks || 0} tasks, ${validation?.stats.gateways || 0} gateways, ${validation?.stats.events || 0} events`} />
                <ReviewRow icon={<Upload className="w-3.5 h-3.5 text-indigo-500" />} label="Import as" value="Draft (editable)" />
              </div>
            </Card>
            {validation?.unsupportedElements?.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800">
                <strong>Unsupported elements flagged:</strong> {validation.unsupportedElements.length} element(s) will be preserved in the XML but flagged for review. They are not removed.
              </div>
            )}
          </div>
        )}

        {/* Step 5: Import (action) */}
        {step === 5 && (
          <div className="space-y-3 text-center py-6">
            {importing ? (
              <>
                <Loader2 className="w-10 h-10 mx-auto text-indigo-500 animate-spin" />
                <p className="text-sm text-slate-600">Importing diagram as Draft…</p>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500" />
                <p className="text-sm text-slate-600">Ready to import. Click "Import as Draft" to save.</p>
              </>
            )}
          </div>
        )}

        {/* Step 6: Report */}
        {step === 6 && reconciliation && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              <span className="font-medium text-slate-700">Import complete</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <ReconTile label="Created" value={reconciliation.created} color="emerald" />
              <ReconTile label="Updated" value={reconciliation.updated} color="indigo" />
              <ReconTile label="Skipped" value={reconciliation.skipped} color="slate" />
              <ReconTile label="Rejected" value={reconciliation.rejected} color="red" />
            </div>
            <Card className="p-3 space-y-1.5 text-xs">
              <div className="font-semibold text-slate-700 uppercase tracking-wide">Reconciliation</div>
              <ReviewRow icon={<GitBranch className="w-3.5 h-3.5 text-indigo-500" />} label="Process resolved" value={`${reconciliation.resolved.process} matched`} />
              <ReviewRow icon={<Users className="w-3.5 h-3.5 text-slate-400" />} label="Swimlanes resolved" value={`${reconciliation.resolved.stakeholders} of ${reconciliation.resolved.stakeholders + (reconciliation.unmatched?.lanes?.length || 0)}`} />
              <ReviewRow icon={<AlertTriangle className="w-3.5 h-3.5 text-amber-500" />} label="Validation warnings" value={String(reconciliation.validationWarnings)} />
              <ReviewRow icon={<AlertCircle className="w-3.5 h-3.5 text-red-500" />} label="Validation errors" value={String(reconciliation.validationErrors)} />
              {reconciliation.unsupportedElements?.length > 0 && (
                <ReviewRow icon={<AlertTriangle className="w-3.5 h-3.5 text-amber-500" />} label="Unsupported elements" value={`${reconciliation.unsupportedElements.length} flagged`} />
              )}
              {reconciliation.unmatched?.lanes?.length > 0 && (
                <div className="pt-1">
                  <span className="text-slate-500">Unmatched swimlanes: </span>
                  <span className="text-amber-700">{reconciliation.unmatched.lanes.join(", ")}</span>
                </div>
              )}
            </Card>
            <Button variant="outline" size="sm" onClick={downloadReport} className="gap-1.5">
              <Download className="w-3.5 h-3.5" /> Download reconciliation report
            </Button>
          </div>
        )}

        {/* Footer */}
        <DialogFooter className="flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => onClose(false)} disabled={!canClose}>
            {step === 6 ? "Close" : "Cancel"}
          </Button>
          <div className="flex items-center gap-2">
            {step > 0 && step < 5 && (
              <Button variant="outline" size="sm" onClick={() => setStep(step - 1)} className="gap-1.5">
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </Button>
            )}
            {step === 1 && validation && (
              <Button size="sm" onClick={proceedFromValidate} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                {validationPassed ? "Continue" : "Continue with warnings"} <ArrowRight className="w-3.5 h-3.5" />
              </Button>
            )}
            {step === 2 && (
              <Button size="sm" onClick={proceedFromResolve} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                Continue <ArrowRight className="w-3.5 h-3.5" />
              </Button>
            )}
            {step === 3 && (
              <Button size="sm" onClick={() => setStep(4)} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                Continue <ArrowRight className="w-3.5 h-3.5" />
              </Button>
            )}
            {step === 4 && (
              <Button size="sm" onClick={() => setStep(5)} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                Continue <ArrowRight className="w-3.5 h-3.5" />
              </Button>
            )}
            {step === 5 && !importing && (
              <Button size="sm" onClick={handleImport} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                <Upload className="w-3.5 h-3.5" /> Import as Draft
              </Button>
            )}
            {step === 6 && (
              <Button size="sm" onClick={() => onClose(false)} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                Done
              </Button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ReviewRow({ icon, label, value }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="flex items-center gap-1.5 text-slate-500">{icon} {label}</span>
      <span className="text-slate-700 font-medium text-right">{value}</span>
    </div>
  );
}

function ReconTile({ label, value, color }) {
  const colors = {
    emerald: "bg-emerald-50 text-emerald-700",
    indigo: "bg-indigo-50 text-indigo-700",
    slate: "bg-slate-50 text-slate-600",
    red: "bg-red-50 text-red-700",
  };
  return (
    <div className={`rounded-lg p-3 text-center ${colors[color] || colors.slate}`}>
      <div className="text-2xl font-semibold">{value}</div>
      <div className="text-[10px] uppercase tracking-wide">{label}</div>
    </div>
  );
}

// ---- Fuzzy process matching ----
function findBestProcessMatch(hints, processes) {
  if (!processes?.length) return null;
  let best = null;
  let bestScore = 0;
  for (const p of processes) {
    let score = 0;
    // Match by process_code
    for (const id of hints.processIds) {
      if (id && p.process_code && id.toLowerCase().replace(/[^a-z0-9]/g, "") === p.process_code.toLowerCase().replace(/[^a-z0-9]/g, "")) {
        score = Math.max(score, 1.0);
      }
    }
    // Match by name similarity
    for (const name of hints.processNames) {
      if (name && p.name) {
        const sim = nameSimilarity(name.toLowerCase(), p.name.toLowerCase());
        score = Math.max(score, sim);
      }
    }
    if (score > bestScore) {
      bestScore = score;
      best = p;
    }
  }
  return bestScore > 0.3 ? { id: best.id, score: bestScore } : null;
}

function nameSimilarity(a, b) {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const wordsA = new Set(a.split(/\s+/).filter(Boolean));
  const wordsB = new Set(b.split(/\s+/).filter(Boolean));
  let common = 0;
  for (const w of wordsA) if (wordsB.has(w)) common++;
  return common / Math.max(wordsA.size, wordsB.size);
}

// ---- JSON → BPMN XML conversion ----
function jsonToBpmnXml(data) {
  // Expected JSON shape: { process: { id, name }, tasks: [{ id, name, lane }], flows: [{ from, to, name }], lanes: [{ name }] }
  const procId = data.process?.id || "Process_Imported";
  const procName = data.process?.name || "Imported Process";
  const tasks = data.tasks || data.activities || [];
  const flows = data.flows || [];
  const lanes = data.lanes || [];

  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" id="Definitions_import" targetNamespace="http://bpmn.io/schema/bpmn">\n`;
  xml += `  <bpmn:process id="${procId}" name="${escapeXml(procName)}" isExecutable="false">\n`;
  xml += `    <bpmn:startEvent id="StartEvent_1" name="Start" />\n`;
  let x = 250;
  for (const t of tasks) {
    const tid = t.id || `Task_${x}`;
    xml += `    <bpmn:task id="${escapeXml(tid)}" name="${escapeXml(t.name || "")}" />\n`;
    x += 120;
  }
  xml += `    <bpmn:endEvent id="EndEvent_1" name="End" />\n`;
  // Flows
  xml += `    <bpmn:sequenceFlow id="Flow_start" sourceRef="StartEvent_1" targetRef="${escapeXml(tasks[0]?.id || "EndEvent_1")}" />\n`;
  for (const f of flows) {
    xml += `    <bpmn:sequenceFlow id="Flow_${escapeXml(f.from)}_${escapeXml(f.to)}" sourceRef="${escapeXml(f.from)}" targetRef="${escapeXml(f.to)}"${f.name ? ` name="${escapeXml(f.name)}"` : ""} />\n`;
  }
  if (tasks.length > 0) {
    xml += `    <bpmn:sequenceFlow id="Flow_end" sourceRef="${escapeXml(tasks[tasks.length - 1]?.id || "StartEvent_1")}" targetRef="EndEvent_1" />\n`;
  }
  xml += `  </bpmn:process>\n`;
  // Minimal DI
  xml += `  <bpmndi:BPMNDiagram id="BPMNDiagram_1">\n    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="${procId}">\n`;
  xml += `      <bpmndi:BPMNShape id="StartEvent_1_di" bpmnElement="StartEvent_1"><dc:Bounds x="172" y="102" width="36" height="36" /></bpmndi:BPMNShape>\n`;
  let dx = 250;
  for (const t of tasks) {
    const tid = t.id || `Task_${dx}`;
    xml += `      <bpmndi:BPMNShape id="${tid}_di" bpmnElement="${escapeXml(tid)}"><dc:Bounds x="${dx}" y="80" width="100" height="80" /></bpmndi:BPMNShape>\n`;
    dx += 120;
  }
  xml += `      <bpmndi:BPMNShape id="EndEvent_1_di" bpmnElement="EndEvent_1"><dc:Bounds x="${dx}" y="102" width="36" height="36" /></bpmndi:BPMNShape>\n`;
  xml += `    </bpmndi:BPMNPlane>\n  </bpmndi:BPMNDiagram>\n`;
  xml += `</bpmn:definitions>`;
  return xml;
}

// ---- CSV → BPMN XML conversion ----
function csvToBpmnXml(csv) {
  const lines = csv.split(/\r?\n/).filter((l) => l.trim() && !l.trim().startsWith("#"));
  const tasks = [];
  for (const line of lines) {
    const cols = line.split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
    if (cols.length >= 2 && cols[0] && cols[0].toLowerCase() !== "name") {
      tasks.push({ id: `Task_${tasks.length + 1}`, name: cols[0], lane: cols[1] || "" });
    }
  }
  return jsonToBpmnXml({ process: { id: "Process_CSV", name: "CSV Imported Process" }, tasks, flows: [] });
}

function escapeXml(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}