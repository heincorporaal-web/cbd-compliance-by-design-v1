import React, { useState, useRef, useEffect } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Bot, Sparkles, Loader2, CheckCircle2, AlertTriangle, AlertCircle,
  Network, Users, GitBranch, ShieldCheck, ArrowLeftRight, FileText, Wand2,
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { validateBpmnXml } from "@/components/processmodelling/bpmnValidator";

// Reusable BPMN preview (lazy-loaded bpmn-js viewer)
function BpmnPreview({ xml }) {
  const containerRef = useRef(null);
  useEffect(() => {
    let viewer;
    let cancelled = false;
    (async () => {
      const BpmnViewer = (await import("bpmn-js/lib/NavigatedViewer")).default;
      await import("bpmn-js/dist/assets/diagram-js.css");
      await import("bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css");
      if (cancelled || !containerRef.current) return;
      viewer = new BpmnViewer({ container: containerRef.current });
      try {
        await viewer.importXML(xml);
        viewer.get("canvas").zoom("fit-viewport");
      } catch {}
    })();
    return () => {
      cancelled = true;
      try { viewer?.destroy(); } catch {}
    };
  }, [xml]);
  return <div ref={containerRef} className="w-full h-[300px] bg-slate-50 rounded-lg border border-slate-200" />;
}

export default function BpmnGenerateDialog({ open, onClose, companyId, processes, onOpenInDesigner }) {
  const [step, setStep] = useState(0); // 0=configure, 1=generating, 2=preview
  const [selectedProcessId, setSelectedProcessId] = useState("");
  const [instructions, setInstructions] = useState("");
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState(null);
  const [validation, setValidation] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setStep(0);
      setSelectedProcessId("");
      setInstructions("");
      setResult(null);
      setValidation(null);
    }
  }, [open]);

  const selectedProcess = processes?.find((p) => p.id === selectedProcessId) || null;

  const handleGenerate = async () => {
    if (!selectedProcessId) {
      toast.error("Select a process first");
      return;
    }
    setStep(1);
    setGenerating(true);
    try {
      const res = await base44.functions.invoke("generateBpmnFromProcess", {
        process_id: selectedProcessId,
        instructions: instructions || undefined,
      });
      const data = res?.data || res;
      if (data?.error) throw new Error(data.error);
      setResult(data);
      setValidation(validateBpmnXml(data.bpmn_xml));
      setStep(2);
    } catch (e) {
      toast.error("Generation failed: " + (e?.message || e));
      setStep(0);
    } finally {
      setGenerating(false);
    }
  };

  const saveDraft = async () => {
    const proc = selectedProcess;
    if (!proc || !result) return null;
    setSaving(true);
    try {
      const existing = await base44.entities.ProcessDiagram.filter({ process_id: proc.id, company_id: companyId });
      const existingDraft = (existing.items || existing || []).find((d) => d.status === "draft");

      const payload = {
        process_id: proc.id,
        process_code: proc.process_code,
        process_name: proc.name,
        company_id: companyId,
        bpmn_xml: result.bpmn_xml,
        canvas_meta: {
          diagram_process_id: proc.id,
          process_reference: proc.process_code,
          process_level: "L" + (proc.level ?? 3),
          process_owner: proc.process_owner || "",
        },
        element_meta: {},
        status: "draft",
        version_number: 1,
        import_source: "ai_generated",
        validation_results: validation ? {
          valid: validation.valid,
          error_count: validation.errors.length,
          warning_count: validation.warnings.length,
          stats: validation.stats,
          validated_at: new Date().toISOString(),
        } : undefined,
        change_log: [{
          action: "ai_generated",
          actor: "ai-generate",
          timestamp: new Date().toISOString(),
          summary: `AI-generated BPMN from process "${proc.name}"`,
        }],
      };

      let saved;
      if (existingDraft) {
        saved = await base44.entities.ProcessDiagram.update(existingDraft.id, payload);
      } else {
        saved = await base44.entities.ProcessDiagram.create(payload);
      }
      return saved;
    } catch (e) {
      toast.error("Save failed: " + (e?.message || e));
      return null;
    } finally {
      setSaving(false);
    }
  };

  const handleSaveDraft = async () => {
    const saved = await saveDraft();
    if (saved) {
      toast.success("Draft saved");
      onClose(false);
    }
  };

  const handleOpenInDesigner = async () => {
    const saved = await saveDraft();
    if (saved) {
      if (onOpenInDesigner) onOpenInDesigner(selectedProcess);
      onClose(false);
    }
  };

  const canClose = !generating && !saving;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (canClose) onClose(v); }}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-violet-600" />
            Generate BPMN with AI
          </DialogTitle>
        </DialogHeader>

        {/* Step 0: Configure */}
        {step === 0 && (
          <div className="space-y-4">
            <div className="flex items-start gap-3 bg-violet-50 border border-violet-200 rounded-lg p-3">
              <Bot className="w-5 h-5 text-violet-600 mt-0.5 shrink-0" />
              <p className="text-sm text-violet-900">
                The AI reads the process description, value chain, stakeholders, and linked risks to generate a complete BPMN 2.0 diagram with swimlanes, tasks, gateways, and sequence flows. You can edit it in the designer afterwards.
              </p>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Select a process to model</label>
              <select
                value={selectedProcessId}
                onChange={(e) => setSelectedProcessId(e.target.value)}
                className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-violet-500 focus:border-violet-500"
              >
                <option value="">— Select a process —</option>
                {processes?.map((p) => (
                  <option key={p.id} value={p.id}>
                    L{p.level} · {p.process_code} · {p.name}
                  </option>
                ))}
              </select>
            </div>

            {selectedProcess && (
              <Card className="p-3 space-y-2 text-xs">
                <div className="flex items-center gap-1.5 font-medium text-slate-700">
                  <GitBranch className="w-3.5 h-3.5 text-violet-500" /> {selectedProcess.name}
                </div>
                <div className="grid grid-cols-2 gap-1 text-slate-500">
                  <span>Code: <span className="font-mono">{selectedProcess.process_code}</span></span>
                  <span>Level: L{selectedProcess.level}</span>
                  {selectedProcess.process_owner && <span>Owner: {selectedProcess.process_owner}</span>}
                  {selectedProcess.criticality && <span>Criticality: {selectedProcess.criticality}</span>}
                </div>
                {selectedProcess.description && (
                  <p className="text-slate-600 pt-1 border-t border-slate-100">{selectedProcess.description}</p>
                )}
              </Card>
            )}

            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">
                Additional instructions <span className="text-slate-400">(optional)</span>
              </label>
              <textarea
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder="e.g. Include a compliance check step after trade execution. Add an escalation path for rejected trades."
                className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-violet-500 focus:border-violet-500 min-h-[80px] resize-y"
              />
            </div>

            <div className="text-xs text-slate-500 space-y-1">
              <p className="flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5 text-violet-500" /> Generates swimlanes from stakeholders, tasks with action-oriented names, and decision gateways</p>
              <p className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5 text-violet-500" /> Linked risks are used to model control and verification steps</p>
              <p className="flex items-center gap-1.5"><Network className="w-3.5 h-3.5 text-violet-500" /> Output is validated and saved as a Draft — existing approved versions are never overwritten</p>
            </div>
          </div>
        )}

        {/* Step 1: Generating */}
        {step === 1 && (
          <div className="space-y-4 text-center py-10">
            <Loader2 className="w-12 h-12 mx-auto text-violet-500 animate-spin" />
            <div>
              <p className="font-medium text-slate-700">Generating BPMN diagram…</p>
              <p className="text-sm text-slate-500 mt-1">Reading process context, stakeholders, and risks to model the workflow.</p>
            </div>
            {selectedProcess && (
              <Badge variant="outline" className="text-xs">
                {selectedProcess.process_code} · {selectedProcess.name}
              </Badge>
            )}
          </div>
        )}

        {/* Step 2: Preview */}
        {step === 2 && result && (
          <div className="space-y-3">
            {result.process_summary && (
              <Card className="p-3 bg-violet-50 border-violet-200">
                <p className="text-sm text-slate-700">{result.process_summary}</p>
              </Card>
            )}

            {/* Stats */}
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: "Lanes", value: result.stats?.lanes, icon: Users },
                { label: "Tasks", value: result.stats?.tasks, icon: FileText },
                { label: "Gateways", value: result.stats?.gateways, icon: ArrowLeftRight },
                { label: "Events", value: result.stats?.events, icon: Network },
              ].map((s) => {
                const Icon = s.icon;
                return (
                  <div key={s.label} className="bg-slate-50 rounded-lg p-2 text-center">
                    <Icon className="w-3.5 h-3.5 mx-auto text-slate-400 mb-1" />
                    <div className="text-lg font-semibold text-slate-700">{s.value}</div>
                    <div className="text-[10px] uppercase text-slate-400">{s.label}</div>
                  </div>
                );
              })}
            </div>

            {/* Validation badges */}
            {validation && (
              <div className="flex items-center gap-2">
                {validation.valid ? (
                  <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 mr-1" /> Valid
                  </Badge>
                ) : (
                  <Badge className="bg-red-100 text-red-700 border-red-200">
                    <AlertCircle className="w-3 h-3 mr-1" /> {validation.errors.length} error(s)
                  </Badge>
                )}
                {validation.warnings.length > 0 && (
                  <Badge className="bg-amber-100 text-amber-700 border-amber-200">
                    <AlertTriangle className="w-3 h-3 mr-1" /> {validation.warnings.length} warning(s)
                  </Badge>
                )}
              </div>
            )}

            {/* Preview */}
            <div>
              <p className="text-xs font-medium text-slate-500 mb-1">Preview</p>
              <BpmnPreview xml={result.bpmn_xml} />
            </div>

            {/* Context info */}
            <div className="text-xs text-slate-500 flex flex-wrap gap-3">
              {result.context?.value_chain && <span>Value Chain: <strong>{result.context.value_chain}</strong></span>}
              <span>Swimlanes: <strong>{result.context.stakeholders_used}</strong> of {result.context.stakeholders_available} stakeholders</span>
            </div>
          </div>
        )}

        {/* Footer */}
        <DialogFooter className="flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => onClose(false)} disabled={!canClose}>
            {step === 2 ? "Close" : "Cancel"}
          </Button>
          <div className="flex items-center gap-2">
            {step === 0 && (
              <Button size="sm" onClick={handleGenerate} disabled={!selectedProcessId} className="gap-1.5 bg-violet-600 hover:bg-violet-700">
                <Sparkles className="w-3.5 h-3.5" /> Generate
              </Button>
            )}
            {step === 2 && (
              <>
                <Button variant="outline" size="sm" onClick={() => setStep(0)} className="gap-1.5">
                  <ArrowLeftRight className="w-3.5 h-3.5" /> Regenerate
                </Button>
                <Button variant="outline" size="sm" onClick={handleSaveDraft} disabled={saving} className="gap-1.5">
                  {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                  {saving ? "Saving…" : "Save as Draft"}
                </Button>
                <Button size="sm" onClick={handleOpenInDesigner} disabled={saving} className="gap-1.5 bg-violet-600 hover:bg-violet-700">
                  <Wand2 className="w-3.5 h-3.5" /> Open in Designer
                </Button>
              </>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}