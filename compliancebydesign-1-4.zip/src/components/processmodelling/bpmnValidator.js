// BPMN 2.0 structural and quality validation.
// Pure functions that parse BPMN XML (via DOMParser) and return structured
// validation results — no bpmn-js dependency, so this runs in any context
// (import wizard, pre-save check, scheduled validation).
//
// Output shape:
//   {
//     valid: boolean,           // true if no errors (warnings are allowed)
//     errors:   [{ id, type, message, severity }],
//     warnings: [{ id, type, message, severity }],
//     stats: { processes, tasks, gateways, events, flows, pools, lanes, dataObjects, unsupported },
//     unsupportedElements: [{ tag, id, name }],
//     elementIndex: { id: { name, type, incoming, outgoing } }
//   }

const BPMN_NS = "http://www.omg.org/spec/BPMN/20100524/MODEL";

// BPMN element types we fully support in the designer.
const SUPPORTED = new Set([
  "process", "subProcess", "adHocSubProcess", "transaction", "callActivity",
  "task", "userTask", "serviceTask", "scriptTask", "manualTask", "businessRuleTask",
  "receiveTask", "sendTask",
  "startEvent", "endEvent", "intermediateThrowEvent", "intermediateCatchEvent",
  "boundaryEvent",
  "exclusiveGateway", "inclusiveGateway", "parallelGateway", "eventBasedGateway", "complexGateway",
  "sequenceFlow", "messageFlow",
  "participant", "lane", "laneSet",
  "dataObjectReference", "dataStoreReference", "dataObject",
  "ioSpecification", "dataInputAssociation", "dataOutputAssociation",
  "property",
  "definitions",
  // BPMN Diagram Interchange (DI) elements — standard, not "unsupported"
  "BPMNDiagram", "BPMNPlane", "BPMNShape", "BPMNEdge", "BPMNLabel",
  "Bounds", "Point", "Size",
  // Collaboration
  "collaboration", "messageFlow", "conversation", "conversationLink",
  "globalTask", "globalChoreographyTask",
]);

// Event definition types (child elements of events)
const EVENT_DEFINITIONS = new Set([
  "messageEventDefinition", "timerEventDefinition", "errorEventDefinition",
  "escalationEventDefinition", "cancelEventDefinition", "compensateEventDefinition",
  "linkEventDefinition", "signalEventDefinition", "terminateEventDefinition",
  "conditionalEventDefinition",
]);

const ACTION_VERBS = [
  "create", "review", "approve", "send", "receive", "check", "validate",
  "update", "generate", "process", "record", "assign", "notify", "calculate",
  "verify", "confirm", "submit", "reject", "return", "complete", "start",
  "stop", "monitor", "assess", "evaluate", "reconcile", "post", "log",
  "import", "export", "transfer", "match", "flag", "investigate", "decide",
  "execute", "settle", "report", "analyse", "analyze", "maintain", "manage",
  "perform", "prepare", "provide", "request", "authorize", "cancel", "close",
  "collect", "compile", "conduct", "define", "determine", "document", "draft",
  "ensure", "establish", "identify", "implement", "initiate", "issue",
  "obtain", "open", "produce", "propose", "recommend", "resolve", "retrieve",
  "schedule", "store", "track", "update",
];

function localName(tag) {
  return tag.includes(":") ? tag.split(":")[1] : tag;
}

function getDirectChildren(el, ns) {
  const result = [];
  for (const child of el.children) {
    if (!ns || child.namespaceURI === ns || child.localName === ns) {
      result.push(child);
    }
  }
  return result;
}

function getChildrenByLocalName(el, name) {
  const result = [];
  for (const child of el.children) {
    if (localName(child.tagName) === name) result.push(child);
  }
  return result;
}

function getAllByLocalName(root, name) {
  return Array.from(root.getElementsByTagName("*")).filter(
    (el) => localName(el.tagName) === name
  );
}

function isActionOriented(name) {
  if (!name || !name.trim()) return false;
  const firstWord = name.trim().split(/\s+/)[0].toLowerCase().replace(/[^a-z]/g, "");
  if (!firstWord) return false;
  // Check if it starts with a known action verb or ends with "ing" (gerund)
  return ACTION_VERBS.some((v) => firstWord === v || firstWord.startsWith(v)) ||
    firstWord.endsWith("ing") || firstWord.endsWith("ed");
}

/**
 * Parse and validate a BPMN 2.0 XML string.
 * @param {string} xml
 * @returns {{ valid, errors, warnings, stats, unsupportedElements, elementIndex }}
 */
export function validateBpmnXml(xml) {
  const errors = [];
  const warnings = [];
  const unsupportedElements = [];
  const elementIndex = {};
  const stats = {
    processes: 0, tasks: 0, gateways: 0, events: 0, flows: 0,
    pools: 0, lanes: 0, dataObjects: 0, unsupported: 0,
  };

  if (!xml || !xml.trim()) {
    return {
      valid: false,
      errors: [{ id: "xml-empty", type: "structure", message: "No BPMN XML provided", severity: "error" }],
      warnings,
      stats,
      unsupportedElements,
      elementIndex,
    };
  }

  // 1. Well-formed XML check
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, "application/xml");
  const parseError = doc.querySelector("parsererror");
  if (parseError) {
    return {
      valid: false,
      errors: [{
        id: "xml-parse",
        type: "structure",
        message: "Invalid XML: " + (parseError.textContent || "parse error").slice(0, 300),
        severity: "error",
      }],
      warnings,
      stats,
      unsupportedElements,
      elementIndex,
    };
  }

  const root = doc.documentElement;
  if (!root || localName(root.tagName) !== "definitions") {
    errors.push({
      id: "root",
      type: "structure",
      message: "Root element must be <bpmn:definitions>",
      severity: "error",
    });
    return { valid: false, errors, warnings, stats, unsupportedElements, elementIndex };
  }

  // 2. Collect all elements and classify
  const allElements = Array.from(root.getElementsByTagName("*"));
  const processes = getChildrenByLocalName(root, "process");
  const collaborations = getChildrenByLocalName(root, "collaboration");
  stats.processes = processes.length;

  // Build a flat index of all flow elements with their incoming/outgoing refs
  const flowElements = [];   // tasks, events, gateways, subprocesses
  const sequenceFlows = [];
  const participants = [];
  const lanes = [];

  for (const proc of processes) {
    // Process-level flow elements (direct children, not nested in sub-processes)
    collectFlowElements(proc, flowElements, sequenceFlows, stats);
  }

  // Also collect from collaborations (pools/participants)
  for (const collab of collaborations) {
    const parts = getChildrenByLocalName(collab, "participant");
    participants.push(...parts);
  }

  // Lanes inside processes
  for (const proc of processes) {
    const laneSets = getChildrenByLocalName(proc, "laneSet");
    for (const ls of laneSets) {
      lanes.push(...getChildrenByLocalName(ls, "lane"));
    }
  }
  stats.pools = participants.length;
  stats.lanes = lanes.length;

  // 3. Detect unsupported elements
  for (const el of allElements) {
    const ln = localName(el.tagName);
    if (ln === "definitions" || ln === "import" || ln === "relationship" || ln === "extension") continue;
    if (EVENT_DEFINITIONS.has(ln)) continue;
    if (!SUPPORTED.has(ln)) {
      stats.unsupported++;
      unsupportedElements.push({
        tag: el.tagName,
        id: el.getAttribute("id") || "",
        name: el.getAttribute("name") || "",
      });
      warnings.push({
        id: el.getAttribute("id") || ln,
        type: "unsupported",
        message: `Unsupported BPMN element <${el.tagName}>${el.getAttribute("name") ? ' "' + el.getAttribute("name") + '"' : ""} — flagged for review, not removed`,
        severity: "warning",
      });
    }
  }

  // 4. Build element index (id → { name, type, incoming, outgoing })
  for (const fe of flowElements) {
    const id = fe.getAttribute("id") || "";
    const name = fe.getAttribute("name") || "";
    const ln = localName(fe.tagName);
    const incoming = getChildrenByLocalName(fe, "incoming").map((c) => c.textContent.trim());
    const outgoing = getChildrenByLocalName(fe, "outgoing").map((c) => c.textContent.trim());
    elementIndex[id] = { name, type: ln, incoming, outgoing };
  }
  for (const sf of sequenceFlows) {
    const id = sf.getAttribute("id") || "";
    elementIndex[id] = {
      name: sf.getAttribute("name") || "",
      type: "sequenceFlow",
      incoming: [],
      outgoing: [],
      sourceRef: sf.getAttribute("sourceRef") || "",
      targetRef: sf.getAttribute("targetRef") || "",
    };
  }

  // 5. Structural validation per process
  for (const proc of processes) {
    const procId = proc.getAttribute("id") || "(unnamed process)";
    const procFlowEls = [];
    const procFlows = [];
    collectFlowElements(proc, procFlowEls, procFlows, { ...stats, _silent: true });

    const startEvents = procFlowEls.filter((e) => localName(e.tagName).startsWith("startEvent"));
    const endEvents = procFlowEls.filter((e) => localName(e.tagName).startsWith("endEvent"));
    const tasks = procFlowEls.filter((e) => localName(e.tagName).endsWith("Task") || localName(e.tagName) === "task");
    const gateways = procFlowEls.filter((e) => localName(e.tagName).endsWith("Gateway"));

    // Start event check
    if (startEvents.length === 0) {
      warnings.push({
        id: procId,
        type: "start_event",
        message: `Process "${procId}" has no start event`,
        severity: "warning",
      });
    }

    // End event check
    if (endEvents.length === 0) {
      warnings.push({
        id: procId,
        type: "end_event",
        message: `Process "${procId}" has no end event`,
        severity: "warning",
      });
    }

    // Sequence flow integrity
    const flowIds = new Set(procFlows.map((f) => f.getAttribute("id")).filter(Boolean));
    const elById = {};
    for (const fe of procFlowEls) {
      const id = fe.getAttribute("id");
      if (id) elById[id] = fe;
    }
    for (const sf of procFlows) {
      const sfId = sf.getAttribute("id") || "(unnamed flow)";
      const src = sf.getAttribute("sourceRef");
      const tgt = sf.getAttribute("targetRef");
      if (!src) {
        errors.push({
          id: sfId, type: "sequence_flow",
          message: `Sequence flow "${sfId}" has no source element`,
          severity: "error",
        });
      }
      if (!tgt) {
        errors.push({
          id: sfId, type: "sequence_flow",
          message: `Sequence flow "${sfId}" has no target element`,
          severity: "error",
        });
      }
      if (src && !elById[src] && !flowIds.has(src)) {
        errors.push({
          id: sfId, type: "sequence_flow",
          message: `Sequence flow "${sfId}" references unknown source "${src}"`,
          severity: "error",
        });
      }
      if (tgt && !elById[tgt] && !flowIds.has(tgt)) {
        errors.push({
          id: sfId, type: "sequence_flow",
          message: `Sequence flow "${sfId}" references unknown target "${tgt}"`,
          severity: "error",
        });
      }
    }

    // Gateway consistency: each gateway should have at least 1 incoming and 2+ outgoing (or vice versa for merges).
    // Uses sequence flow sourceRef/targetRef to count actual connections.
    for (const gw of gateways) {
      const gwId = gw.getAttribute("id") || localName(gw.tagName);
      let incoming = getChildrenByLocalName(gw, "incoming").length;
      let outgoing = getChildrenByLocalName(gw, "outgoing").length;
      // Also count via sequence flow references (authoritative when <incoming>/<outgoing> are absent)
      for (const sf of procFlows) {
        if (sf.getAttribute("sourceRef") === gwId) outgoing = Math.max(outgoing, 1);
        if (sf.getAttribute("targetRef") === gwId) incoming = Math.max(incoming, 1);
      }
      if (incoming === 0 && outgoing === 0) {
        errors.push({
          id: gwId, type: "gateway",
          message: `Gateway "${gwId}" is unconnected (no incoming or outgoing flows)`,
          severity: "error",
        });
      } else if (outgoing === 0) {
        warnings.push({
          id: gwId, type: "gateway",
          message: `Gateway "${gwId}" has no outgoing flows — a gateway should split or merge flows`,
          severity: "warning",
        });
      }
    }

    // Unconnected elements (no incoming AND no outgoing, excluding start/end events).
    // A flow element is connected if any sequence flow references it as sourceRef
    // or targetRef, OR it has explicit <incoming>/<outgoing> children.
    const referencedIds = new Set();
    for (const sf of procFlows) {
      const src = sf.getAttribute("sourceRef");
      const tgt = sf.getAttribute("targetRef");
      if (src) referencedIds.add(src);
      if (tgt) referencedIds.add(tgt);
    }
    for (const fe of procFlowEls) {
      const ln = localName(fe.tagName);
      if (ln.startsWith("startEvent") || ln.startsWith("endEvent")) continue;
      const id = fe.getAttribute("id") || ln;
      const hasIoChildren = getChildrenByLocalName(fe, "incoming").length > 0 || getChildrenByLocalName(fe, "outgoing").length > 0;
      const isReferenced = referencedIds.has(id);
      if (!hasIoChildren && !isReferenced) {
        errors.push({
          id, type: "unconnected",
          message: `Element "${id}" (${ln}) is unconnected — no incoming or outgoing sequence flows`,
          severity: "error",
        });
      }
    }

    // Action-oriented naming for tasks
    for (const t of tasks) {
      const name = (t.getAttribute("name") || "").trim();
      const id = t.getAttribute("id") || localName(t.tagName);
      if (!name) {
        warnings.push({
          id, type: "naming",
          message: `Task "${id}" has no name`,
          severity: "warning",
        });
      } else if (!isActionOriented(name)) {
        warnings.push({
          id, type: "naming",
          message: `Task "${id}" name "${name}" is not action-oriented (should start with a verb)`,
          severity: "warning",
        });
      }
    }

    // Duplicate element names
    const nameCount = {};
    for (const fe of procFlowEls) {
      const name = (fe.getAttribute("name") || "").trim().toLowerCase();
      if (!name) continue;
      nameCount[name] = (nameCount[name] || 0) + 1;
    }
    for (const [name, count] of Object.entries(nameCount)) {
      if (count > 1) {
        warnings.push({
          id: `dup-${procId}-${name}`,
          type: "duplicate",
          message: `Process "${procId}" has ${count} elements named "${name}" — possible duplicate activities`,
          severity: "warning",
        });
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    stats,
    unsupportedElements,
    elementIndex,
  };
}

// Helper: collect flow elements and sequence flows from a process element
// (direct children only — sub-process children are handled recursively)
function collectFlowElements(procEl, flowElements, sequenceFlows, stats) {
  for (const child of procEl.children) {
    const ln = localName(child.tagName);
    if (ln === "sequenceFlow") {
      sequenceFlows.push(child);
      stats.flows = (stats.flows || 0) + 1;
    } else if (ln.endsWith("Task") || ln === "task") {
      flowElements.push(child);
      stats.tasks = (stats.tasks || 0) + 1;
    } else if (ln.endsWith("Gateway")) {
      flowElements.push(child);
      stats.gateways = (stats.gateways || 0) + 1;
    } else if (ln.endsWith("Event")) {
      flowElements.push(child);
      stats.events = (stats.events || 0) + 1;
    } else if (ln === "subProcess" || ln === "adHocSubProcess" || ln === "transaction" || ln === "callActivity") {
      flowElements.push(child);
      // Recurse into sub-processes
      collectFlowElements(child, flowElements, sequenceFlows, stats);
    } else if (ln === "dataObjectReference" || ln === "dataStoreReference" || ln === "dataObject") {
      stats.dataObjects = (stats.dataObjects || 0) + 1;
    }
  }
}

/**
 * Extract process-reference hints from BPMN XML for entity resolution.
 * Looks for process ids, names, and any extension elements that might
 * carry a process_reference / process_code.
 */
export function extractProcessHints(xml) {
  const hints = { processIds: [], processNames: [], poolNames: [], laneNames: [], taskNames: [] };
  try {
    const doc = new DOMParser().parseFromString(xml, "application/xml");
    if (doc.querySelector("parsererror")) return hints;
    for (const proc of getAllByLocalName(doc.documentElement, "process")) {
      hints.processIds.push(proc.getAttribute("id") || "");
      hints.processNames.push(proc.getAttribute("name") || "");
    }
    for (const p of getAllByLocalName(doc.documentElement, "participant")) {
      hints.poolNames.push(p.getAttribute("name") || "");
    }
    for (const l of getAllByLocalName(doc.documentElement, "lane")) {
      hints.laneNames.push(l.getAttribute("name") || "");
    }
    for (const t of getAllByLocalName(doc.documentElement, "task")) {
      hints.taskNames.push(t.getAttribute("name") || "");
    }
    hints.processIds = hints.processIds.filter(Boolean);
    hints.processNames = hints.processNames.filter(Boolean);
    hints.poolNames = hints.poolNames.filter(Boolean);
    hints.laneNames = hints.laneNames.filter(Boolean);
    hints.taskNames = hints.taskNames.filter(Boolean);
  } catch {}
  return hints;
}