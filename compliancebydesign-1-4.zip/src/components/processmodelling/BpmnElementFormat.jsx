import React, { useState, useEffect } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Palette, Move, RotateCcw } from "lucide-react";

/**
 * Per-element formatting controls (fill, border, size) for a selected
 * BPMN shape. Changes are applied live to the canvas via the bpmn-js
 * modeling service.
 */
export default function BpmnElementFormat({ modelerRef, element, readOnly = false }) {
  const [fill, setFill] = useState("");
  const [stroke, setStroke] = useState("");
  const [width, setWidth] = useState("");
  const [height, setHeight] = useState("");

  useEffect(() => {
    if (!element) return;
    const di = element.di || {};
    const f = typeof di.get === "function" ? di.get("fill") : di.fill;
    const s = typeof di.get === "function" ? di.get("stroke") : di.stroke;
    setFill(f || "");
    setStroke(s || "");
    setWidth(Math.round(element.width));
    setHeight(Math.round(element.height));
  }, [element?.id]);

  if (!element || element.type === "label") return null;

  const isConnection = element.type === "connection";

  const applyColor = (newFill, newStroke) => {
    const modeler = modelerRef?.current;
    if (!modeler || readOnly) return;
    try {
      const modeling = modeler.get("modeling");
      if (!modeling) return;
      const opts = {};
      if (newFill !== undefined) opts.fill = newFill || undefined;
      if (newStroke !== undefined) opts.stroke = newStroke || undefined;
      modeling.setColor(element, opts);
    } catch (e) {
      console.error("Color apply error", e);
    }
  };

  const resetColor = () => {
    const modeler = modelerRef?.current;
    if (!modeler || readOnly) return;
    try {
      const modeling = modeler.get("modeling");
      if (!modeling) return;
      modeling.setColor(element, { fill: null, stroke: null });
      setFill("");
      setStroke("");
    } catch (e) {
      console.error("Reset colour error", e);
    }
  };

  const applyResize = () => {
    const modeler = modelerRef?.current;
    if (!modeler || readOnly) return;
    try {
      const modeling = modeler.get("modeling");
      if (!modeling) return;
      modeling.resizeShape(element, {
        x: element.x,
        y: element.y,
        width: Number(width) || element.width,
        height: Number(height) || element.height,
      });
    } catch (e) {
      console.error("Resize error", e);
    }
  };

  return (
    <div className="rounded-md border border-violet-100 bg-violet-50/30 p-3 space-y-3">
      <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-violet-600">
        <Palette className="w-3.5 h-3.5" /> Element Format
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1">
          <Label className="text-[11px] text-slate-500">Fill Colour</Label>
          <div className="flex gap-1">
            <input
              type="color"
              value={fill || "#ffffff"}
              disabled={readOnly}
              onChange={(e) => {
                setFill(e.target.value);
                applyColor(e.target.value, undefined);
              }}
              className="w-8 h-8 rounded border border-slate-300 cursor-pointer disabled:opacity-40"
            />
            <Input
              value={fill}
              disabled={readOnly}
              onChange={(e) => setFill(e.target.value)}
              onBlur={() => applyColor(fill, undefined)}
              placeholder="none"
              className="h-8 text-xs"
            />
          </div>
        </div>
        <div className="space-y-1">
          <Label className="text-[11px] text-slate-500">Border Colour</Label>
          <div className="flex gap-1">
            <input
              type="color"
              value={stroke || "#000000"}
              disabled={readOnly}
              onChange={(e) => {
                setStroke(e.target.value);
                applyColor(undefined, e.target.value);
              }}
              className="w-8 h-8 rounded border border-slate-300 cursor-pointer disabled:opacity-40"
            />
            <Input
              value={stroke}
              disabled={readOnly}
              onChange={(e) => setStroke(e.target.value)}
              onBlur={() => applyColor(undefined, stroke)}
              placeholder="none"
              className="h-8 text-xs"
            />
          </div>
        </div>
      </div>

      {!readOnly && (
        <Button size="sm" variant="ghost" onClick={resetColor} className="h-7 text-xs w-full text-slate-500">
          <RotateCcw className="w-3 h-3 mr-1" /> Reset Colours
        </Button>
      )}

      {!isConnection && (
        <div className="border-t border-violet-100 pt-2 space-y-2">
          <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">
            <Move className="w-3.5 h-3.5" /> Size
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-[11px] text-slate-500">Width</Label>
              <Input
                type="number"
                value={width}
                disabled={readOnly}
                onChange={(e) => setWidth(e.target.value)}
                className="h-8 text-xs"
              />
            </div>
            <div className="space-y-1">
              <Label className="text-[11px] text-slate-500">Height</Label>
              <Input
                type="number"
                value={height}
                disabled={readOnly}
                onChange={(e) => setHeight(e.target.value)}
                className="h-8 text-xs"
              />
            </div>
          </div>
          {!readOnly && (
            <Button size="sm" onClick={applyResize} className="h-7 text-xs w-full">
              Apply Size
            </Button>
          )}
        </div>
      )}
    </div>
  );
}