import React, { useEffect, useRef, useState } from "react";
import BpmnModeler from "bpmn-js/lib/Modeler";
import BpmnViewer from "bpmn-js/lib/NavigatedViewer";
import "bpmn-js/dist/assets/diagram-js.css";
import "bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Save, ZoomIn, ZoomOut, Maximize2, Download, FileImage, ArrowLeft, PanelRight, Upload, Spline, Expand, Minimize2, Plus, ArrowLeftRight, ShieldAlert, Bot, Settings2, Paintbrush, Undo2, Redo2, ChevronDown, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import BpmnElementPalette from "@/components/processmodelling/BpmnElementPalette";
import BpmnDataPane from "@/components/processmodelling/BpmnDataPane";
import CanvasFormatBar, { getCanvasDimensions, getPageSizeLabel } from "@/components/processmodelling/CanvasFormatBar";
import BpmnStyleSheet from "@/components/processmodelling/BpmnStyleSheet";
import SodScanner from "@/components/processmodelling/SodScanner";
import SodAgentChat from "@/components/agents/SodAgentChat";
import UnlinkedElementsDialog from "@/components/processmodelling/UnlinkedElementsDialog";
import { getElementCategory } from "@/components/processmodelling/bpmnDataConfig";
import { base44 } from "@/api/base44Client";
import { queryClientInstance } from "@/lib/query-client";

export const EMPTY_BPMN_XML = `<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn">
  <bpmn:process id="Process_1" isExecutable="false">
    <bpmn:startEvent id="StartEvent_1" name="Start" />
  </bpmn:process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
      <bpmndi:BPMNShape id="StartEvent_1_di" bpmnElement="StartEvent_1">
        <dc:Bounds x="172" y="102" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="180" y="145" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</bpmn:definitions>`;

const newGuid = () =>
  (typeof crypto !== "undefined" && crypto.randomUUID)
    ? crypto.randomUUID()
    : "g-" + Math.random().toString(36).slice(2) + Date.now().toString(36);

const parseLevel = (v) => {
  if (v == null || v === "") return null;
  if (typeof v === "number") return v;
  const m = String(v).match(/(\d+)/);
  return m ? Number(m[1]) : null;
};

const SUBPROCESS_TYPES = new Set([
  "bpmn:SubProcess",
  "bpmn:AdHocSubProcess",
  "bpmn:Transaction",
]);

const TASK_TYPES = new Set([
  "bpmn:Task",
  "bpmn:ServiceTask",
  "bpmn:UserTask",
  "bpmn:SendTask",
  "bpmn:ReceiveTask",
  "bpmn:ManualTask",
  "bpmn:ScriptTask",
  "bpmn:BusinessRuleTask",
  "bpmn:CallActivity",
]);

const distToSegment = (p, a, b) => {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return Math.hypot(p.x - a.x, p.y - a.y);
  let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
};

export default function BpmnDesigner({
  initialXml,
  initialCanvasMeta,
  initialElementMeta,
  onSave,
  saving,
  onBack,
  processLabel,
  companyId,
  currentProcess,
  readOnly = false,
  saveTrigger = 0,
}) {
  const containerRef = useRef(null);
  const modelerRef = useRef(null);
  const [dirty, setDirty] = useState(false);
  const [canvasMeta, setCanvasMeta] = useState(() => initialCanvasMeta || {});
  const [elementMeta, setElementMeta] = useState(() => initialElementMeta || {});
  const elementMetaRef = useRef(elementMeta);
  elementMetaRef.current = elementMeta;
  const [selection, setSelection] = useState(null); // { id, label, category }
  const [paneOpen, setPaneOpen] = useState(false);
  const [connectMode, setConnectMode] = useState(false);
  const connectModeRef = useRef(false);
  connectModeRef.current = connectMode;
  const fileInputRef = useRef(null);
  const selectedElementRef = useRef(null);
  const [selectedIsExpanded, setSelectedIsExpanded] = useState(false);
  const [unlinked, setUnlinked] = useState(null);
  const [adding, setAdding] = useState(false);
  const [sodOpen, setSodOpen] = useState(false);
  const [agentOpen, setAgentOpen] = useState(false);
  const [formatOpen, setFormatOpen] = useState(false);
  const [styleOpen, setStyleOpen] = useState(false);
  const [modelerReady, setModelerReady] = useState(false);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [toolbarCollapsed, setToolbarCollapsed] = useState(false);
  const realXmlLoadedRef = useRef(false);

  // Exit connect mode on Escape
  useEffect(() => {
    if (!connectMode) return;
    const onKey = (e) => { if (e.key === "Escape") setConnectMode(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [connectMode]);

  // External save trigger (from page-level Save button)
  const saveTriggerRef = useRef(0);
  useEffect(() => {
    if (!saveTrigger || saveTrigger === saveTriggerRef.current) return;
    saveTriggerRef.current = saveTrigger;
    if (!readOnly) handleSave();
  }, [saveTrigger, readOnly]);

  // Keyboard shortcuts: Ctrl+Z undo, Ctrl+Y / Ctrl+Shift+Z redo
  useEffect(() => {
    if (readOnly) return;
    const onKey = (e) => {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod) return;
      if (e.key === "z" && !e.shiftKey) {
        e.preventDefault();
        const modeler = modelerRef.current;
        if (modeler) {
          const cs = modeler.get("commandStack");
          if (cs.canUndo()) cs.undo();
        }
      } else if ((e.key === "y") || (e.key === "z" && e.shiftKey)) {
        e.preventDefault();
        const modeler = modelerRef.current;
        if (modeler) {
          const cs = modeler.get("commandStack");
          if (cs.canRedo()) cs.redo();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [readOnly]);

  // Ensure every BPMN element on the canvas has a stable GUID stored in its
  // element metadata. GUIDs are persisted with the diagram so machine-learning
  // pipelines can link back to a unique element across versions/exports.
  const ensureGuids = () => {
    const modeler = modelerRef.current;
    if (!modeler) return;
    setElementMeta((prev) => {
      const next = { ...prev };
      let changed = false;
      const all = modeler.get("elementRegistry").getAll();
      for (const el of all) {
        if (el.type === "label") continue;
        const cur = next[el.id] || {};
        if (!cur.guid) {
          next[el.id] = { ...cur, guid: newGuid() };
          changed = true;
        }
      }
      return changed ? next : prev;
    });
    setCanvasMeta((prev) => (prev.guid ? prev : { ...prev, guid: newGuid() }));
  };

  // Re-apply dashed line styles from element metadata to connection SVG paths.
  // bpmn-js re-renders connections on modeling changes, resetting any
  // stroke-dasharray we set directly on the SVG, so we re-apply after every
  // command stack change and on import.
  const applyDashPatterns = () => {
    const modeler = modelerRef.current;
    if (!modeler) return;
    try {
      const elementRegistry = modeler.get("elementRegistry");
      for (const el of elementRegistry.getAll()) {
        if (el.type !== "connection") continue;
        const meta = elementMetaRef.current[el.id];
        if (!meta || meta.line_style !== "dashed") continue;
        const gfx = elementRegistry.getGraphics(el);
        if (!gfx) continue;
        const path = gfx.querySelector("path.djs-visual, path");
        if (path) path.setAttribute("stroke-dasharray", "6,4");
      }
    } catch {}
  };

  // Thicken borders on sub-process elements so they're visually distinct from
  // regular tasks — makes it easy to spot where a process has nested sub-processes.
  const thickenSubProcessBorders = () => {
    const modeler = modelerRef.current;
    if (!modeler) return;
    try {
      const elementRegistry = modeler.get("elementRegistry");
      const graphicsFactory = modeler.get("graphicsFactory");
      for (const el of elementRegistry.getAll()) {
        if (SUBPROCESS_TYPES.has(el.type) && el.di && typeof el.di.set === "function") {
          el.di.set("strokeWidth", 3);
          const gfx = elementRegistry.getGraphics(el);
          if (gfx) graphicsFactory.update("shape", el, gfx);
        }
      }
    } catch {}
  };

  // Seed source/target labels for sequence flows into element meta on selection.
  const describeSelection = (el) => {
    if (!el || el.type === "label") return null;
    const bo = el.businessObject || {};
    const label = bo.name || el.id;
    let category = getElementCategory(el);
    const seed = {};
    if (category === "sequence_flow") {
      const src = el.source && el.source.businessObject ? el.source.businessObject.name || el.source.id : "";
      const tgt = el.target && el.target.businessObject ? el.target.businessObject.name || el.target.id : "";
      if (src) seed.from_element = src;
      if (tgt) seed.to_element = tgt;
    }
    return { id: el.id, label, category, seed };
  };

  useEffect(() => {
    const modeler = new (readOnly ? BpmnViewer : BpmnModeler)({ container: containerRef.current });
    modelerRef.current = modeler;

    let isImporting = true;
    modeler
      .importXML(initialXml || EMPTY_BPMN_XML)
      .then(() => {
        isImporting = false;
        modeler.get("canvas").zoom("fit-viewport");
        if (!readOnly) ensureGuids();
        thickenSubProcessBorders();
        setModelerReady(true);
      })
      .catch((err) => toast.error("Failed to load diagram: " + (err?.message || err)));

    // Assign a GUID to newly created elements (tasks, events, flows, …).
    // Also thicken borders on sub-process elements for visual identification.
    const onShapeAdded = (event) => {
      ensureGuids();
      if (isImporting) return;
      const el = event?.element || event?.shape;
      if (!el || !SUBPROCESS_TYPES.has(el.type)) return;
      if (el.di && typeof el.di.set === "function") {
        el.di.set("strokeWidth", 3);
        try {
          const gfx = modeler.get("elementRegistry").getGraphics(el);
          if (gfx) modeler.get("graphicsFactory").update("shape", el, gfx);
        } catch {}
      }
    };
    if (!readOnly) {
      const updateUndoRedo = () => {
        const commandStack = modeler.get("commandStack");
        setCanUndo(commandStack.canUndo());
        setCanRedo(commandStack.canRedo());
      };
      modeler.on("commandStack.changed", () => {
        setDirty(true);
        updateUndoRedo();
        // Re-apply dashed line styles after bpmn-js re-renders connections
        setTimeout(applyDashPatterns, 0);
      });
      // Set initial state after import completes, then re-apply dash patterns
      modeler.on("import.done", () => {
        updateUndoRedo();
        setTimeout(applyDashPatterns, 0);
      });
      modeler.on("shape.added", onShapeAdded);
      modeler.on("connection.added", onShapeAdded);
    }

    const onSelectionChanged = ({ newSelection }) => {
      const el = newSelection && newSelection[0];
      const desc = describeSelection(el);
      if (!desc) {
        setSelection(null);
        selectedElementRef.current = null;
        setSelectedIsExpanded(false);
        setPaneOpen(false);
      } else {
        setSelection(desc);
        selectedElementRef.current = el;
        const bo = el.businessObject || {};
        const di = el.di || {};
        setSelectedIsExpanded(di.isExpanded === true);
        if (desc.seed && Object.keys(desc.seed).length) {
          setElementMeta((prev) => ({
            ...prev,
            [desc.id]: { ...desc.seed, ...(prev[desc.id] || {}) },
          }));
        }
      }
    };
    modeler.on("selection.changed", onSelectionChanged);

    // Connect mode: when active, mousedown on an element starts a connection
    // drag. bpmn-js snaps the resulting flow to the nearest connection point
    // on the target element automatically.
    const eventBus = modeler.get("eventBus");
    const connect = readOnly ? null : modeler.get("connect");
    const onElementMouseDown = (e) => {
      if (!connectModeRef.current) return;
      const { element, originalEvent } = e;
      if (!element || element.type === "label") return;
      if (element.id === "__implicitroot") return;
      try {
        connect.start(originalEvent, element);
      } catch {}
    };
    eventBus.on("element.mousedown", 1500, onElementMouseDown);

    // Add a bendpoint (bend node) to a connector on double-click. The waypoint
    // is inserted at the click position and can then be dragged to bend the
    // connector from that point.
    const onConnectionDblClick = (e) => {
      if (readOnly || connectModeRef.current) return;
      const { element, originalEvent } = e;
      if (!element || element.type !== "connection") return;
      const canvas = modeler.get("canvas");
      const viewbox = canvas.viewbox();
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const x = (originalEvent.clientX - rect.left) / viewbox.scale + viewbox.x;
      const y = (originalEvent.clientY - rect.top) / viewbox.scale + viewbox.y;
      const waypoints = element.waypoints;
      if (!waypoints || waypoints.length < 2) return;
      let minDist = Infinity;
      let insertIdx = 1;
      for (let i = 0; i < waypoints.length - 1; i++) {
        const d = distToSegment({ x, y }, waypoints[i], waypoints[i + 1]);
        if (d < minDist) { minDist = d; insertIdx = i + 1; }
      }
      const newWaypoints = [...waypoints];
      newWaypoints.splice(insertIdx, 0, { x, y });
      modeler.get("modeling").updateWaypoints(element, newWaypoints);
      setDirty(true);
      toast.success("Bend point added — drag to reposition");
    };
    eventBus.on("element.dblclick", onConnectionDblClick);

    return () => {
      eventBus.off("element.mousedown", onElementMouseDown);
      eventBus.off("element.dblclick", onConnectionDblClick);
      modeler.off("selection.changed", onSelectionChanged);
      if (!readOnly) {
        modeler.off("shape.added", onShapeAdded);
        modeler.off("connection.added", onShapeAdded);
      }
      try { modeler.destroy(); } catch {}
      modelerRef.current = null;
    };
  }, []);

  // Re-import the saved diagram when its XML arrives asynchronously.
  // The diagram query (["processDiagram", process_id]) resolves AFTER the
  // modeler is already mounted with the empty starter diagram, so without
  // this effect the canvas would stay on the starter "Start" event forever.
  // The ref guard ensures we only load once — subsequent refetches (e.g. after
  // a save) are ignored so the user's in-progress edits are not wiped.
  useEffect(() => {
    if (!modelerReady || !modelerRef.current) return;
    if (!initialXml || realXmlLoadedRef.current) return;
    realXmlLoadedRef.current = true;
    if (initialCanvasMeta) setCanvasMeta(initialCanvasMeta);
    if (initialElementMeta) setElementMeta(initialElementMeta);
    modelerRef.current
      .importXML(initialXml)
      .then(() => {
        modelerRef.current.get("canvas").zoom("fit-viewport");
        if (!readOnly) ensureGuids();
        thickenSubProcessBorders();
        setDirty(false);
      })
      .catch((err) => toast.error("Failed to load diagram: " + (err?.message || err)));
  }, [initialXml, modelerReady]);

  // Apply grid snapping and grid size to the bpmn-js modeler whenever the
  // canvas formatting settings change or the modeler becomes ready.
  useEffect(() => {
    if (!modelerReady) return;
    const modeler = modelerRef.current;
    if (!modeler) return;
    try {
      const snapToGrid = canvasMeta.snapToGrid ?? false;
      const gridSize = canvasMeta.gridSize ?? 20;

      const grid = modeler.get("grid");
      const gridSnapping = modeler.get("gridSnapping");

      if (snapToGrid) {
        if (grid) grid.setGridSize(gridSize);
        if (grid) grid.setVisible(true);
        if (gridSnapping && !gridSnapping.isActive()) gridSnapping.setActive(true);
      } else {
        if (grid) grid.setVisible(false);
        if (gridSnapping && gridSnapping.isActive()) gridSnapping.setActive(false);
      }
    } catch {}
  }, [modelerReady, canvasMeta.snapToGrid, canvasMeta.gridSize]);

  const onCanvasChange = (key, value) => {
    setCanvasMeta((prev) => ({ ...prev, [key]: value }));
    setDirty(true);
  };

  const onElementChange = (key, value) => {
    if (!selection) return;
    const id = selection.id;
    setElementMeta((prev) => ({ ...prev, [id]: { ...(prev[id] || {}), [key]: value } }));
    // "name" overrides the BPMN element label on the canvas.
    if (key === "name" && modelerRef.current) {
      try {
        const elementRegistry = modelerRef.current.get("elementRegistry");
        const el = elementRegistry.get(id);
        if (el) modelerRef.current.get("modeling").updateProperties(el, { name: value });
      } catch {}
    }
    setDirty(true);
  };

  const paneData = selection ? elementMeta[selection.id] || {} : canvasMeta;
  const paneCategory = selection ? selection.category : "canvas";

  const zoomIn = () => modelerRef.current?.get("zoomScroll").stepZoom(1);
  const zoomOut = () => modelerRef.current?.get("zoomScroll").stepZoom(-1);
  const fit = () => modelerRef.current?.get("canvas").zoom("fit-viewport");

  const undo = () => {
    const modeler = modelerRef.current;
    if (!modeler) return;
    const commandStack = modeler.get("commandStack");
    if (commandStack.canUndo()) commandStack.undo();
  };
  const redo = () => {
    const modeler = modelerRef.current;
    if (!modeler) return;
    const commandStack = modeler.get("commandStack");
    if (commandStack.canRedo()) commandStack.redo();
  };

  // Toggle the selected sub-process between collapsed (plus marker) and
  // expanded (children visible) using the bpmn-js replace service, which
  // preserves the element id and re-lays out the diagram cleanly.
  const toggleSubProcessExpand = () => {
    const modeler = modelerRef.current;
    const el = selectedElementRef.current;
    if (!modeler || !el) return;
    const bo = el.businessObject || {};
    if (bo.$type !== "bpmn:SubProcess") {
      toast.info("Select a sub-process to expand or collapse");
      return;
    }
    try {
      const isExpanded = !((bo.di && bo.di.isExpanded) === true);
      modeler.get("replace").replaceElement(el, {
        type: "bpmn:SubProcess",
        isExpanded,
      });
      setSelectedIsExpanded(isExpanded);
      setDirty(true);
    } catch (e) {
      toast.error("Could not toggle sub-process: " + (e?.message || e));
    }
  };

  const canToggleSubProcess = (() => {
    const el = selectedElementRef.current;
    return !!(el && el.businessObject && el.businessObject.$type === "bpmn:SubProcess");
  })();

  const canAddLane = (() => {
    const el = selectedElementRef.current;
    return !!(el && el.businessObject && el.businessObject.$type === "bpmn:Participant");
  })();

  const selectedPoolHorizontal = (() => {
    const el = selectedElementRef.current;
    if (!el || !el.businessObject || el.businessObject.$type !== "bpmn:Participant") return true;
    const di = el.di || {};
    return di.horizontal !== false;
  })();

  // Add a lane (band) inside the selected pool. The lane orientation follows
  // the pool's current orientation (horizontal pool → horizontal band, etc.).
  const addLaneToPool = () => {
    const modeler = modelerRef.current;
    const el = selectedElementRef.current;
    if (!modeler || !el) return;
    const bo = el.businessObject || {};
    if (bo.$type !== "bpmn:Participant") {
      toast.info("Select a pool to add a lane");
      return;
    }
    try {
      const modeling = modeler.get("modeling");
      const elementFactory = modeler.get("elementFactory");
      const lane = elementFactory.createShape({ type: "bpmn:Lane" });
      modeling.createShape(lane, { x: el.x + el.width / 2, y: el.y + el.height / 2 }, el);
      setDirty(true);
      toast.success("Lane added to pool");
    } catch (e) {
      toast.error("Could not add lane: " + (e?.message || e));
    }
  };

  // Flip the selected pool between horizontal and vertical orientation, which
  // makes its lanes render as horizontal or vertical bands respectively.
  const togglePoolOrientation = () => {
    const modeler = modelerRef.current;
    const el = selectedElementRef.current;
    if (!modeler || !el) return;
    const bo = el.businessObject || {};
    if (bo.$type !== "bpmn:Participant") {
      toast.info("Select a pool to toggle orientation");
      return;
    }
    try {
      const di = el.di || {};
      const isHorizontal = di.horizontal !== false;
      modeler.get("replace").replaceElement(el, {
        type: "bpmn:Participant",
        isExpanded: di.isExpanded === true,
        horizontal: !isHorizontal,
      });
      setDirty(true);
    } catch (e) {
      toast.error("Could not toggle pool orientation: " + (e?.message || e));
    }
  };

  // Start a native bpmn-js drag-create from the docked palette so elements
  // can be dragged onto the canvas with live preview and proper drop targets
  // (lanes, pools, attaching boundary events to activities, etc.).
  const onDragStart = (event, type, options = {}) => {
    try {
      const modeler = modelerRef.current;
      if (!modeler) return;
      if (event.button !== undefined && event.button !== 0) return;
      event.preventDefault();
      const elementFactory = modeler.get("elementFactory");
      const create = modeler.get("create");
      const shapeOpts = { type };
      if (options.isExpanded !== undefined) shapeOpts.isExpanded = options.isExpanded;
      if (options.eventDefinitionType) shapeOpts.eventDefinitionType = options.eventDefinitionType;
      if (options.eventDefinitionTypes) shapeOpts.eventDefinitionTypes = options.eventDefinitionTypes;
      if (options.triggeredByEvent) shapeOpts.triggeredByEvent = options.triggeredByEvent;
      const shape = elementFactory.createShape(shapeOpts);
      create.start(event, shape, options.attach ? { attach: true } : undefined);
      setDirty(true);
    } catch (e) {
      toast.error("Could not start drag: " + (e?.message || e));
    }
  };

  const doSave = async (metaOverride) => {
    try {
      const { xml } = await modelerRef.current.saveXML({ format: true });
      let svg = null;
      try {
        const { svg: svgStr } = await modelerRef.current.saveSVG();
        svg = svgStr;
      } catch {}
      await onSave(xml, svg, canvasMeta, metaOverride || elementMeta);
      setDirty(false);
    } catch (e) {
      toast.error("Save failed: " + (e?.message || e));
    }
  };

  const handleSave = async () => {
    const modeler = modelerRef.current;
    if (!modeler) return;
    const all = modeler.get("elementRegistry").getAll();
    const DEFAULT_NAMES = new Set(["Start"]);
    const LINKABLE = new Set([
      "task", "subprocess", "gateway", "start_event", "end_event", "data_object", "default",
    ]);
    const found = [];
    for (const el of all) {
      if (el.type === "label") continue;
      const cat = getElementCategory(el);
      if (!LINKABLE.has(cat)) continue;
      const meta = elementMeta[el.id] || {};
      if (meta.linked_process) continue;
      const bo = el.businessObject || {};
      const name = meta.name || bo.name || "";
      if (!name || DEFAULT_NAMES.has(name)) continue;
      found.push({ id: el.id, name, category: cat });
    }
    if (found.length) {
      setUnlinked(found);
      return;
    }
    await doSave();
  };

  const handleAddAll = async () => {
    setAdding(true);
    try {
      const parentId = canvasMeta.diagram_process_id || canvasMeta.parent_process_reference || null;
      const canvasLevel = parseLevel(canvasMeta.process_level);
      const parentCode = currentProcess?.process_code || canvasMeta.parent_process_reference || "";
      const newMeta = { ...elementMeta };
      for (const el of unlinked || []) {
        const meta = elementMeta[el.id] || {};
        const code = meta.process_reference || `ELEM-${(meta.guid || el.id).slice(0, 8)}`;
        const level = parseLevel(meta.process_level) ?? canvasLevel ?? 3;
        const desc = [parentCode, meta.activity_description || meta.purpose || ""].filter(Boolean).join(" — ");
        const created = await base44.entities.OrgProcess.create({
          name: el.name,
          process_code: code,
          level,
          parent_id: parentId,
          company_id: companyId,
          description: desc,
          process_owner: meta.process_owner || "",
          status: "active",
        });
        // For L2–L4 activities, convert the BPMN element to a collapsed
        // subprocess on the canvas so it can be expanded to show child processes.
        let metaKey = el.id;
        if (modelerRef.current && level >= 2 && level <= 4) {
          try {
            const elementRegistry = modelerRef.current.get("elementRegistry");
            const element = elementRegistry.get(el.id);
            if (element && TASK_TYPES.has(element.type)) {
              const replaced = modelerRef.current
                .get("replace")
                .replaceElement(element, { type: "bpmn:SubProcess", isExpanded: false });
              metaKey = replaced.id;
            }
          } catch {}
        }
        if (metaKey !== el.id) {
          newMeta[metaKey] = { ...meta, linked_process: created.id };
          delete newMeta[el.id];
        } else {
          newMeta[el.id] = { ...meta, linked_process: created.id };
        }
      }
      setElementMeta(newMeta);
      setUnlinked(null);
      setAdding(false);
      try { await queryClientInstance.invalidateQueries(["dpOrgProcesses"]); } catch {}
      await doSave(newMeta);
    } catch (e) {
      setAdding(false);
      toast.error("Could not add to company process data: " + (e?.message || e));
    }
  };

  const handleGoBack = () => {
    setUnlinked(null);
  };

  const download = (content, filename, mime) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadXml = async () => {
    const { xml } = await modelerRef.current.saveXML({ format: true });
    download(xml, `${(processLabel || "process").replace(/\s+/g, "_")}.bpmn`, "application/xml");
  };

  const handleDownloadSvg = async () => {
    try {
      const { svg } = await modelerRef.current.saveSVG();
      download(svg, `${(processLabel || "process").replace(/\s+/g, "_")}.svg`, "image/svg+xml");
    } catch (e) {
      toast.error("Export SVG failed: " + (e?.message || e));
    }
  };

  const handleImportXml = async (file) => {
    if (!file) return;
    const name = file.name.toLowerCase();
    if (!/\.(bpmn|xml)$/.test(name)) {
      toast.error("Please choose a .bpmn or .xml file");
      return;
    }
    try {
      const text = await file.text();
      await modelerRef.current.importXML(text);
      modelerRef.current.get("canvas").zoom("fit-viewport");
      // Imported elements start with no metadata; keep existing element_meta but
      // assign GUIDs to any new ids so traceability is preserved on save.
      ensureGuids();
      setDirty(true);
      toast.success("Diagram imported");
    } catch (e) {
      toast.error("Import failed: " + (e?.message || e));
    }
  };

  return (
    <div className="flex h-[calc(100vh-240px)] min-h-[400px] bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
      {!readOnly && <BpmnElementPalette onDragStart={onDragStart} />}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex items-center justify-between gap-2 px-3 py-1.5 border-b border-slate-200 bg-slate-50 flex-nowrap overflow-x-auto">
          <div className="flex items-center gap-2 flex-shrink-0">
            {onBack && (
              <Button size="sm" variant="ghost" onClick={onBack} className="gap-1.5">
                <ArrowLeft className="w-4 h-4" /> Back
              </Button>
            )}
            <span className="text-sm font-semibold text-slate-700 truncate max-w-xs">{processLabel || "Process diagram"}</span>
            {readOnly && <Badge variant="outline" className="text-amber-700 border-amber-300 bg-amber-50">Read-only</Badge>}
            {dirty && <span className="w-2 h-2 rounded-full bg-amber-500" title="Unsaved changes" />}
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setToolbarCollapsed((v) => !v)}
              title={toolbarCollapsed ? "Show all tools" : "Hide tools to maximise the canvas"}
              className="gap-1.5"
            >
              {toolbarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </Button>
            <Button size="sm" variant="ghost" onClick={zoomOut} title="Zoom out"><ZoomOut className="w-4 h-4" /></Button>
            <Button size="sm" variant="ghost" onClick={zoomIn} title="Zoom in"><ZoomIn className="w-4 h-4" /></Button>
            <Button size="sm" variant="ghost" onClick={fit} title="Fit to screen"><Maximize2 className="w-4 h-4" /></Button>
            {!readOnly && (
              <>
                <div className="w-px h-6 bg-slate-200 mx-1" />
                <Button size="sm" variant="ghost" onClick={undo} disabled={!canUndo} title="Undo (Ctrl+Z)"><Undo2 className="w-4 h-4" /></Button>
                <Button size="sm" variant="ghost" onClick={redo} disabled={!canRedo} title="Redo (Ctrl+Y)"><Redo2 className="w-4 h-4" /></Button>
              </>
            )}
            {!toolbarCollapsed && (
              <>
                <div className="w-px h-6 bg-slate-200 mx-1" />
                <Button
                  size="sm"
                  variant={formatOpen ? "default" : "ghost"}
                  onClick={() => setFormatOpen((v) => !v)}
                  title="Canvas formatting options (page size, orientation, grid)"
                  className={`gap-1.5 ${formatOpen ? "bg-indigo-600 hover:bg-indigo-700 text-white" : ""}`}
                >
                  <Settings2 className="w-4 h-4" /> Format
                </Button>
                {!readOnly && (
                  <Button
                    size="sm"
                    variant={styleOpen ? "default" : "ghost"}
                    onClick={() => setStyleOpen((v) => !v)}
                    title="Apply a CBD style sheet to all diagram elements"
                    className={`gap-1.5 ${styleOpen ? "bg-violet-600 hover:bg-violet-700 text-white" : "text-violet-600"}`}
                  >
                    <Paintbrush className="w-4 h-4" /> Style
                  </Button>
                )}
                <div className="w-px h-6 bg-slate-200 mx-1" />
                {!readOnly && (
                  <Button
                    size="sm"
                    variant={canToggleSubProcess ? "default" : "ghost"}
                    onClick={toggleSubProcessExpand}
                    disabled={!canToggleSubProcess}
                    title={canToggleSubProcess ? (selectedIsExpanded ? "Collapse sub-process" : "Expand sub-process") : "Select a sub-process to expand/collapse"}
                    className={`gap-1.5 ${canToggleSubProcess && !selectedIsExpanded ? "bg-indigo-600 hover:bg-indigo-700 text-white" : ""}`}
                  >
                    {selectedIsExpanded ? <Minimize2 className="w-4 h-4" /> : <Expand className="w-4 h-4" />}
                    {selectedIsExpanded ? "Collapse" : "Expand"}
                  </Button>
                )}
                {!readOnly && canAddLane && (
                  <>
                    <div className="w-px h-6 bg-slate-200 mx-1" />
                    <Button
                      size="sm"
                      variant="default"
                      onClick={addLaneToPool}
                      title="Add a lane (band) inside the selected pool"
                      className="gap-1.5 bg-indigo-600 hover:bg-indigo-700"
                    >
                      <Plus className="w-4 h-4" /> Add Lane
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={togglePoolOrientation}
                      title={selectedPoolHorizontal ? "Switch pool to vertical (vertical bands)" : "Switch pool to horizontal (horizontal bands)"}
                      className="gap-1.5"
                    >
                      <ArrowLeftRight className="w-4 h-4" /> {selectedPoolHorizontal ? "Horizontal" : "Vertical"}
                    </Button>
                  </>
                )}
                {!readOnly && (
                  <>
                    <div className="w-px h-6 bg-slate-200 mx-1" />
                    <Button
                      size="sm"
                      variant={connectMode ? "default" : "ghost"}
                      onClick={() => setConnectMode((v) => !v)}
                      title={connectMode ? "Connect mode active — click an element, drag to target (Esc to exit)" : "Connect elements (click source, drag to target)"}
                      className={`gap-1.5 ${connectMode ? "bg-indigo-600 hover:bg-indigo-700 text-white" : ""}`}
                    >
                      <Spline className="w-4 h-4" /> {connectMode ? "Connecting…" : "Connect"}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => fileInputRef.current?.click()} title="Import BPMN/XML"><Upload className="w-4 h-4" /></Button>
                  </>
                )}
                <div className="w-px h-6 bg-slate-200 mx-1" />
                <Button
                  size="sm"
                  variant={sodOpen ? "default" : "ghost"}
                  onClick={() => setSodOpen((v) => !v)}
                  title="Scan process steps for Segregation of Duties violations"
                  className={`gap-1.5 ${sodOpen ? "bg-orange-600 hover:bg-orange-700 text-white" : "text-orange-600"}`}
                >
                  <ShieldAlert className="w-4 h-4" /> SOD Scan
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setAgentOpen(true)}
                  title="Ask the SOD Violation Finder agent"
                  className="gap-1.5 text-indigo-600"
                >
                  <Bot className="w-4 h-4" /> SOD Agent
                </Button>
                <Button size="sm" variant="ghost" onClick={handleDownloadSvg} title="Export SVG"><FileImage className="w-4 h-4" /></Button>
                <Button size="sm" variant="ghost" onClick={handleDownloadXml} title="Download .bpmn"><Download className="w-4 h-4" /></Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".bpmn,.xml,application/xml,text/xml"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    handleImportXml(f);
                    e.target.value = "";
                  }}
                />
              </>
            )}
            <div className="w-px h-6 bg-slate-200 mx-1" />
            <Button
              size="sm"
              variant={paneOpen ? "default" : "ghost"}
              onClick={() => setPaneOpen((v) => !v)}
              title={paneOpen ? "Hide data pane" : "Show data pane"}
              className="gap-1.5"
            >
              <PanelRight className="w-4 h-4" /> {paneOpen ? "Hide Data" : "Show Data"}
            </Button>
            {!readOnly && (
              <Button size="sm" onClick={handleSave} disabled={saving} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                <Save className="w-4 h-4" /> {saving ? "Saving…" : "Save"}
              </Button>
            )}
          </div>
        </div>
        {formatOpen && (
          <CanvasFormatBar
            canvasMeta={canvasMeta}
            onChange={onCanvasChange}
            onClose={() => setFormatOpen(false)}
          />
        )}
        {styleOpen && (
          <BpmnStyleSheet
            modelerRef={modelerRef}
            companyId={companyId}
            onClose={() => setStyleOpen(false)}
          />
        )}
        {/* Bounded canvas area: a white "page" on a grey workspace. Everything
            outside the page is clipped (overflow hidden), so the future image
            preview will only capture what is placed inside this canvas. */}
        <div className="flex-1 min-h-0 bg-slate-200 p-3 md:p-5 overflow-auto flex justify-center">
          <div
            className={`relative bg-white rounded-lg shadow-lg overflow-hidden shrink-0 ${
              getCanvasDimensions(canvasMeta) && (canvasMeta.showPageBoundary ?? true)
                ? "border-2 border-dashed border-indigo-400"
                : "ring-1 ring-slate-300"
            }`}
            style={(() => {
              const dims = getCanvasDimensions(canvasMeta);
              if (dims) return { width: `${dims.width}px`, height: `${dims.height}px`, minWidth: `${dims.width}px` };
              return { width: "100%", maxWidth: "1200px", height: "100%", minHeight: "560px" };
            })()}
          >
            <span className="pointer-events-none absolute top-2 left-3 z-10 text-[10px] font-semibold uppercase tracking-wide text-slate-400 select-none">
              {(canvasMeta.showPageSize && getPageSizeLabel(canvasMeta)) || "Canvas"}
            </span>
            {/* CSS overrides live OUTSIDE the bpmn-js container — bpmn-js replaces the
                container's innerHTML on mount, which would wipe any <style> placed inside it. */}
            <style>{`
              .djs-palette { display: none !important; }
              /* Define the CSS variables diagram-js expects for resize handles, so the
                 default variable chain (which references undefined upstream vars) resolves. */
              .djs-container {
                --resizer-fill-color: #4f46e5;
                --resizer-stroke-color: #ffffff;
                --color-blue-205-100-45: #4f46e5;
                --canvas-fill-color: #ffffff;
              }
              /* Resize handles — small squares at corners/edges of selected shapes */
              .djs-resizer { visibility: visible !important; }
              .djs-resizer-visual {
                fill: #4f46e5 !important;
                stroke: #ffffff !important;
                stroke-width: 1.5px !important;
                opacity: 1 !important;
                visibility: visible !important;
              }
              .djs-resizer-hit {
                fill: none !important;
                pointer-events: all !important;
                visibility: visible !important;
              }
              .djs-resizer-nw, .djs-resizer-ne, .djs-resizer-sw, .djs-resizer-se {
                cursor: nwse-resize !important;
              }
              .djs-resizer-n, .djs-resizer-s {
                cursor: ns-resize !important;
              }
              .djs-resizer-w, .djs-resizer-e {
                cursor: ew-resize !important;
              }
              /* Segment draggers for bending connection lines */
              .djs-segment-dragger .djs-visual { display: block !important; }
              .djs-segment-dragger .djs-visual circle { fill: #4f46e5 !important; stroke: #fff !important; }
              /* Bendpoint (waypoint) handles on selected connections */
              .djs-bendpoint .djs-visual {
                fill: #4f46e5 !important;
                stroke: #ffffff !important;
                stroke-width: 1.5px !important;
                visibility: visible !important;
                opacity: 1 !important;
              }
              .djs-bendpoint-hit {
                fill: none !important;
                pointer-events: all !important;
                visibility: visible !important;
              }
            `}</style>
            <div
              ref={containerRef}
              className="w-full h-full"
              style={connectMode ? { cursor: "crosshair" } : undefined}
            >
            </div>
          </div>
        </div>
      </div>

      {paneOpen && (
        <BpmnDataPane
          companyId={companyId}
          currentProcess={currentProcess}
          category={paneCategory}
          elementId={selection?.id}
          elementLabel={selection?.label}
          elementGuid={selection ? elementMeta[selection.id]?.guid : canvasMeta.guid}
          data={paneData}
          onChange={selection ? onElementChange : onCanvasChange}
          onClose={() => setPaneOpen(false)}
          modelerRef={modelerRef}
          selectedElement={selectedElementRef.current}
          readOnly={readOnly}
        />
      )}
      {sodOpen && (
        <SodScanner
          modelerRef={modelerRef}
          elementMeta={elementMeta}
          canvasMeta={canvasMeta}
          companyId={companyId}
          onClose={() => setSodOpen(false)}
        />
      )}
      <SodAgentChat
        open={agentOpen}
        onClose={() => setAgentOpen(false)}
        processContext={currentProcess ? {
          processId: currentProcess.id,
          processName: currentProcess.name,
          processCode: currentProcess.process_code,
          companyId,
        } : { companyId }}
      />
      <UnlinkedElementsDialog
        elements={unlinked}
        adding={adding}
        onAddAll={handleAddAll}
        onGoBack={handleGoBack}
      />
    </div>
  );
}