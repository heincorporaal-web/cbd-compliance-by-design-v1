import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronDown, ChevronRight, ShieldAlert, ShieldX, Search } from "lucide-react";

const SEVERITY_STYLES = {
  high: "bg-red-100 text-red-700 border-red-300",
  medium: "bg-amber-100 text-amber-700 border-amber-300",
  low: "bg-slate-100 text-slate-600 border-slate-300",
};

const CATEGORY_STYLES = {
  technical: "bg-red-50 text-red-600",
  semantic: "bg-blue-50 text-blue-600",
};

const STATUS_STYLES = {
  new: "bg-blue-100 text-blue-700",
  existing: "bg-amber-100 text-amber-700",
  resolved: "bg-green-100 text-green-700",
  exception_active: "bg-purple-100 text-purple-700",
  exception_invalidated: "bg-red-100 text-red-700",
  recurring: "bg-orange-100 text-orange-700",
};

export default function IntegrityFindingsTable({ findings, onAcceptException, onApplyCorrection }) {
  const [search, setSearch] = useState("");
  const [filterSeverity, setFilterSeverity] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterExceptionable, setFilterExceptionable] = useState("all");
  const [expandedRows, setExpandedRows] = useState(new Set());

  const filtered = useMemo(() => {
    return findings.filter((f) => {
      if (search) {
        const q = search.toLowerCase();
        const text = `${f.entity_name} ${f.entity_code} ${f.rule_id} ${f.existing_relationship} ${f.justification}`.toLowerCase();
        if (!text.includes(q)) return false;
      }
      if (filterSeverity !== "all" && f.severity !== filterSeverity) return false;
      if (filterCategory !== "all" && f.validation_category !== filterCategory) return false;
      if (filterExceptionable === "exceptionable" && !f.is_exceptionable) return false;
      if (filterExceptionable === "structural" && f.is_exceptionable) return false;
      return true;
    });
  }, [findings, search, filterSeverity, filterCategory, filterExceptionable]);

  const toggleRow = (id) => {
    setExpandedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center justify-between">
          <span>Findings ({filtered.length})</span>
          <div className="flex items-center gap-2 text-xs font-normal">
            <span className="text-slate-500">{findings.length} total</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <Input
              placeholder="Search findings..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 h-9"
            />
          </div>
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="h-9 text-sm border border-slate-200 rounded-md px-2 bg-white"
          >
            <option value="all">All severities</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="h-9 text-sm border border-slate-200 rounded-md px-2 bg-white"
          >
            <option value="all">All categories</option>
            <option value="technical">Technical</option>
            <option value="semantic">Semantic</option>
          </select>
          <select
            value={filterExceptionable}
            onChange={(e) => setFilterExceptionable(e.target.value)}
            className="h-9 text-sm border border-slate-200 rounded-md px-2 bg-white"
          >
            <option value="all">All findings</option>
            <option value="exceptionable">Exceptionable</option>
            <option value="structural">Structural only</option>
          </select>
        </div>

        {/* Findings list */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <div className="max-h-[600px] overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No findings match the current filters.
              </div>
            ) : (
              filtered.map((f, i) => {
                const rowKey = `${f.rule_id}-${f.entity_id}-${f.related_entity_id || i}`;
                const isExpanded = expandedRows.has(rowKey);
                return (
                  <div key={rowKey} className="border-b border-slate-100 last:border-0">
                    <div
                      className="flex items-start gap-2 p-3 cursor-pointer hover:bg-slate-50"
                      onClick={() => toggleRow(rowKey)}
                    >
                      <div className="pt-0.5">
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4 text-slate-400" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <Badge variant="outline" className={`text-xs ${SEVERITY_STYLES[f.severity]}`}>
                            {f.severity}
                          </Badge>
                          <Badge variant="outline" className={`text-xs ${CATEGORY_STYLES[f.validation_category]}`}>
                            {f.validation_category}
                          </Badge>
                          <span className="text-xs font-mono text-slate-500">{f.rule_id}</span>
                          {!f.is_exceptionable && (
                            <Badge variant="outline" className="text-xs bg-red-50 text-red-600 border-red-200">
                              <ShieldX className="w-3 h-3 mr-1" />Non-negotiable
                            </Badge>
                          )}
                          {f.is_exceptionable && (
                            <Badge variant="outline" className="text-xs bg-purple-50 text-purple-600 border-purple-200">
                              <ShieldAlert className="w-3 h-3 mr-1" />Exceptionable
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm font-medium text-slate-900 truncate">
                          {f.entity_name} <span className="font-mono text-xs text-slate-400">({f.entity_code})</span>
                        </p>
                        <p className="text-xs text-slate-500 truncate">{f.existing_relationship}</p>
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="px-3 pb-3 pl-10 space-y-2 bg-slate-50/50">
                        <div className="text-xs">
                          <span className="font-semibold text-slate-600">Justification: </span>
                          <span className="text-slate-500">{f.justification}</span>
                        </div>
                        {f.proposed_relationship && (
                          <div className="text-xs">
                            <span className="font-semibold text-slate-600">Recommended correction: </span>
                            <span className="text-blue-600">{f.proposed_relationship}</span>
                          </div>
                        )}
                        {f.related_entity_name && (
                          <div className="text-xs">
                            <span className="font-semibold text-slate-600">Related: </span>
                            <span className="text-slate-500">{f.related_entity_name}</span>
                          </div>
                        )}
                        <div className="text-xs">
                          <span className="font-semibold text-slate-600">Fingerprint: </span>
                          <span className="font-mono text-slate-400">{f.relationship_fingerprint}</span>
                        </div>
                        <div className="flex items-center gap-2 pt-1">
                          {f.is_exceptionable && onAcceptException && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 text-xs gap-1 border-purple-300 text-purple-600 hover:bg-purple-50"
                              onClick={(e) => {
                                e.stopPropagation();
                                onAcceptException(f);
                              }}
                            >
                              <ShieldAlert className="w-3 h-3" /> Accept as Exception
                            </Button>
                          )}
                          {f.proposed_relationship && onApplyCorrection && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 text-xs gap-1 border-blue-300 text-blue-600 hover:bg-blue-50"
                              onClick={(e) => {
                                e.stopPropagation();
                                onApplyCorrection(f);
                              }}
                            >
                              Apply Correction
                            </Button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}