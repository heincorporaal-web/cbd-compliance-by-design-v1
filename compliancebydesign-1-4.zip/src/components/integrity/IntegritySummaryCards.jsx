import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, CheckCircle2, ShieldAlert, RotateCcw, FileWarning, Wrench, ShieldX, Layers } from "lucide-react";

export default function IntegritySummaryCards({ dashboard, summary }) {
  const dash = dashboard || {};
  const cards = [
    {
      label: "New Findings",
      value: dash.new_findings,
      icon: AlertCircle,
      color: "text-blue-600",
      bg: "bg-blue-50",
      border: "border-blue-200",
    },
    {
      label: "Existing Unresolved",
      value: dash.existing_unresolved,
      icon: FileWarning,
      color: "text-amber-600",
      bg: "bg-amber-50",
      border: "border-amber-200",
    },
    {
      label: "Resolved",
      value: dash.resolved,
      icon: CheckCircle2,
      color: "text-green-600",
      bg: "bg-green-50",
      border: "border-green-200",
    },
    {
      label: "Accepted Exceptions",
      value: dash.accepted_exceptions,
      icon: ShieldAlert,
      color: "text-purple-600",
      bg: "bg-purple-50",
      border: "border-purple-200",
    },
    {
      label: "Invalidated Exceptions",
      value: dash.invalidated_exceptions,
      icon: ShieldX,
      color: "text-red-600",
      bg: "bg-red-50",
      border: "border-red-200",
    },
    {
      label: "Recurring",
      value: dash.recurring,
      icon: RotateCcw,
      color: "text-orange-600",
      bg: "bg-orange-50",
      border: "border-orange-200",
    },
    {
      label: "Recommended Corrections",
      value: dash.recommended_corrections,
      icon: Wrench,
      color: "text-indigo-600",
      bg: "bg-indigo-50",
      border: "border-indigo-200",
    },
    {
      label: "Structural Failures",
      value: dash.confirmed_structural_failures,
      icon: ShieldX,
      color: "text-red-700",
      bg: "bg-red-100",
      border: "border-red-300",
    },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <Card key={c.label} className={`${c.border} border`}>
              <CardContent className="pt-4 pb-4 px-4">
                <div className="flex items-center gap-2 mb-1">
                  <div className={`w-8 h-8 rounded-lg ${c.bg} flex items-center justify-center`}>
                    <Icon className={`w-4 h-4 ${c.color}`} />
                  </div>
                  <span className="text-xs text-slate-500 font-medium">{c.label}</span>
                </div>
                <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {summary && (
        <Card className="border-slate-200">
          <CardContent className="pt-4 pb-4 px-4">
            <div className="flex items-center gap-4 flex-wrap text-sm">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-slate-400" />
                <span className="text-slate-500">Raw findings:</span>
                <span className="font-semibold text-slate-900">{summary.raw_finding_count}</span>
              </div>
              <div className="text-slate-300">|</div>
              <div>
                <span className="text-slate-500">Distinct affected records:</span>{" "}
                <span className="font-semibold text-slate-900">{summary.distinct_affected_records}</span>
              </div>
              <div className="text-slate-300">|</div>
              <div>
                <span className="text-slate-500">Suppressed by exceptions:</span>{" "}
                <span className="font-semibold text-purple-600">{summary.suppressed_count}</span>
              </div>
              <div className="text-slate-300">|</div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500">Severity:</span>
                <span className="font-semibold text-red-600">{summary.by_severity.high} high</span>
                <span className="font-semibold text-amber-600">{summary.by_severity.medium} med</span>
                <span className="font-semibold text-slate-600">{summary.by_severity.low} low</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}