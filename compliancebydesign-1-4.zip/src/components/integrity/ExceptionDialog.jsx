import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ShieldAlert, ShieldX, Loader2 } from "lucide-react";

export default function ExceptionDialog({ open, finding, onClose, onConfirm }) {
  const [rationale, setRationale] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) setRationale("");
  }, [open]);

  const handleConfirm = async () => {
    if (!rationale.trim()) return;
    setSubmitting(true);
    try {
      await onConfirm(finding, rationale.trim());
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  if (!finding) return null;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-purple-600" />
            Accept Finding as Exception
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-slate-50 rounded-lg p-3 space-y-2 text-sm">
            <div>
              <span className="font-semibold text-slate-600">Rule: </span>
              <span className="font-mono text-slate-900">{finding.rule_id}</span>
            </div>
            <div>
              <span className="font-semibold text-slate-600">Entity: </span>
              <span className="text-slate-900">{finding.entity_name}</span>{" "}
              <span className="font-mono text-xs text-slate-400">({finding.entity_code})</span>
            </div>
            <div>
              <span className="font-semibold text-slate-600">Finding: </span>
              <span className="text-slate-700">{finding.existing_relationship}</span>
            </div>
            {finding.proposed_relationship && (
              <div>
                <span className="font-semibold text-slate-600">Recommended fix: </span>
                <span className="text-blue-600">{finding.proposed_relationship}</span>
              </div>
            )}
          </div>

          <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-700">
            <ShieldX className="w-4 h-4 shrink-0 mt-0.5" />
            <p>
              By accepting this exception, the finding will be suppressed on future audits
              <strong> only while the underlying relationship attributes remain unchanged</strong>.
              If the parent, level, value chain or code changes, the exception will be automatically
              invalidated and the finding will reappear for review.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="rationale">Exception Rationale (required)</Label>
            <Textarea
              id="rationale"
              placeholder="Explain why this anomaly is an accepted deviation..."
              value={rationale}
              onChange={(e) => setRationale(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={submitting}>
            Cancel
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={!rationale.trim() || submitting}
            className="gap-2 bg-purple-600 hover:bg-purple-700"
          >
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldAlert className="w-4 h-4" />}
            Accept Exception
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}