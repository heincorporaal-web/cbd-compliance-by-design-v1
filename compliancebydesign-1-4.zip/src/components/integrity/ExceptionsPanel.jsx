import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ShieldAlert, ShieldX, Loader2, RefreshCw } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function ExceptionsPanel({ companyId, invalidatedCount, onInvalidate }) {
  const [exceptions, setExceptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("active");

  const loadExceptions = async () => {
    setLoading(true);
    try {
      const result = await base44.functions.invoke("manageAuditException", {
        action: "list",
        company_id: companyId,
      });
      setExceptions(result.exceptions || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (companyId) loadExceptions();
  }, [companyId]);

  const filtered = exceptions.filter((e) => {
    if (filter === "active") return e.status === "active";
    if (filter === "invalidated") return e.status === "invalidated";
    return true;
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center justify-between">
          <span className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-purple-600" />
            Exceptions ({filtered.length})
          </span>
          <Button variant="ghost" size="sm" onClick={loadExceptions} className="h-7 text-xs">
            <RefreshCw className="w-3 h-3 mr-1" /> Refresh
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant={filter === "active" ? "default" : "outline"}
            className="h-7 text-xs"
            onClick={() => setFilter("active")}
          >
            Active ({exceptions.filter((e) => e.status === "active").length})
          </Button>
          <Button
            size="sm"
            variant={filter === "invalidated" ? "default" : "outline"}
            className="h-7 text-xs"
            onClick={() => setFilter("invalidated")}
          >
            Invalidated ({exceptions.filter((e) => e.status === "invalidated").length})
          </Button>
          <Button
            size="sm"
            variant={filter === "all" ? "default" : "outline"}
            className="h-7 text-xs"
            onClick={() => setFilter("all")}
          >
            All ({exceptions.length})
          </Button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 animate-spin text-slate-400" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-sm">
            No {filter === "active" ? "active" : filter === "invalidated" ? "invalidated" : ""} exceptions.
          </div>
        ) : (
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="max-h-[500px] overflow-y-auto">
              {filtered.map((ex) => (
                <div key={ex.id} className="border-b border-slate-100 last:border-0 p-3">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <Badge
                      variant="outline"
                      className={
                        ex.status === "active"
                          ? "text-xs bg-purple-50 text-purple-700 border-purple-300"
                          : "text-xs bg-red-50 text-red-700 border-red-300"
                      }
                    >
                      {ex.status === "active" ? (
                        <><ShieldAlert className="w-3 h-3 mr-1" />Active</>
                      ) : (
                        <><ShieldX className="w-3 h-3 mr-1" />Invalidated</>
                      )}
                    </Badge>
                    <span className="text-xs font-mono text-slate-500">{ex.rule_id}</span>
                    <span className="text-xs text-slate-400">
                      {ex.entity_type} · {ex.entity_code}
                    </span>
                  </div>
                  <p className="text-sm font-medium text-slate-900">{ex.entity_name}</p>
                  <p className="text-xs text-slate-500 mt-1">{ex.finding_summary}</p>
                  <div className="mt-2 text-xs">
                    <span className="font-semibold text-slate-600">Rationale: </span>
                    <span className="text-slate-700">{ex.rationale}</span>
                  </div>
                  <div className="mt-1 text-xs text-slate-400">
                    Accepted by {ex.accepted_by} on{" "}
                    {new Date(ex.accepted_at).toLocaleDateString("en-GB")}
                    {ex.invalidated_reason && (
                      <span className="text-red-500"> · {ex.invalidated_reason}</span>
                    )}
                  </div>
                  {ex.status === "active" && onInvalidate && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs text-red-600 hover:bg-red-50 mt-2"
                      onClick={() => onInvalidate(ex.id)}
                    >
                      <ShieldX className="w-3 h-3 mr-1" /> Invalidate
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}