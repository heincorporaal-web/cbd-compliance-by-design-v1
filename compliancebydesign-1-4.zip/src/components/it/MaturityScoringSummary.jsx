import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, AlertCircle, Target, Gauge } from "lucide-react";

// Numeric scores for maturity levels (1-5)
export const MATURITY_SCORES = {
  initial: 1,
  developing: 2,
  defined: 3,
  managed: 4,
  optimising: 5,
};

export const MATURITY_LABELS = {
  initial: "Initial",
  developing: "Developing",
  defined: "Defined",
  managed: "Managed",
  optimising: "Optimising",
};

const IMPORTANCE_WEIGHTS = { low: 1, medium: 2, high: 3, critical: 4 };
const INVESTMENT_GAP_WEIGHTS = { underfunded: 3, adequate: 2, well_funded: 1, over_invested: 0 };

// Compute the numeric maturity gap (target - current)
export function maturityGap(cap) {
  const current = MATURITY_SCORES[cap.maturity_level] || 1;
  const target = MATURITY_SCORES[cap.target_maturity_level] || 3;
  return target - current;
}

// Compute a derived investment priority score (0-20 scale)
// Higher score = more urgent investment need
export function investmentGapScore(cap) {
  const gap = Math.max(0, maturityGap(cap)); // 0-4
  const importance = IMPORTANCE_WEIGHTS[cap.strategic_importance] || 2; // 1-4
  const investment = INVESTMENT_GAP_WEIGHTS[cap.investment_level] ?? 2; // 0-3
  return gap * importance + investment;
}

// Derive a priority label from the score
export function derivedPriority(cap) {
  const score = investmentGapScore(cap);
  if (score >= 16) return "critical";
  if (score >= 10) return "high";
  if (score >= 5) return "medium";
  return "low";
}

const PRIORITY_STYLES = {
  critical: { bg: "bg-rose-100", text: "text-rose-700", border: "border-rose-200", label: "Critical" },
  high: { bg: "bg-orange-100", text: "text-orange-700", border: "border-orange-200", label: "High" },
  medium: { bg: "bg-amber-100", text: "text-amber-700", border: "border-amber-200", label: "Medium" },
  low: { bg: "bg-slate-100", text: "text-slate-600", border: "border-slate-200", label: "Low" },
};

const INVESTMENT_STYLES = {
  underfunded: { bg: "bg-rose-50", text: "text-rose-600", label: "Underfunded" },
  adequate: { bg: "bg-amber-50", text: "text-amber-600", label: "Adequate" },
  well_funded: { bg: "bg-emerald-50", text: "text-emerald-600", label: "Well Funded" },
  over_invested: { bg: "bg-slate-100", text: "text-slate-500", label: "Over-Invested" },
};

const IMPORTANCE_STYLES = {
  critical: { bg: "bg-purple-100", text: "text-purple-700", label: "Critical" },
  high: { bg: "bg-blue-100", text: "text-blue-700", label: "High" },
  medium: { bg: "bg-slate-100", text: "text-slate-600", label: "Medium" },
  low: { bg: "bg-slate-50", text: "text-slate-500", label: "Low" },
};

export function MaturityGapBadge({ cap }) {
  const gap = maturityGap(cap);
  if (gap <= 0) {
    return (
      <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-600 border-emerald-200">
        <Target className="w-3 h-3 mr-1" /> At target
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className={`text-xs border ${gap >= 3 ? "bg-rose-50 text-rose-600 border-rose-200" : gap >= 2 ? "bg-orange-50 text-orange-600 border-orange-200" : "bg-amber-50 text-amber-600 border-amber-200"}`}>
      <TrendingUp className="w-3 h-3 mr-1" /> {gap} level{gap !== 1 ? "s" : ""} to target
    </Badge>
  );
}

export function InvestmentPriorityBadge({ cap }) {
  const priority = cap.investment_priority || derivedPriority(cap);
  const style = PRIORITY_STYLES[priority] || PRIORITY_STYLES.medium;
  return (
    <Badge variant="outline" className={`text-xs border ${style.bg} ${style.text} ${style.border}`}>
      <AlertCircle className="w-3 h-3 mr-1" /> {style.label} priority
    </Badge>
  );
}

export function InvestmentLevelBadge({ cap }) {
  const style = INVESTMENT_STYLES[cap.investment_level] || INVESTMENT_STYLES.adequate;
  return (
    <Badge variant="outline" className={`text-xs ${style.bg} ${style.text}`}>
      {style.label}
    </Badge>
  );
}

export function StrategicImportanceBadge({ cap }) {
  const style = IMPORTANCE_STYLES[cap.strategic_importance] || IMPORTANCE_STYLES.medium;
  return (
    <Badge variant="outline" className={`text-xs ${style.bg} ${style.text}`}>
      {style.label} importance
    </Badge>
  );
}

// Summary panel showing maturity distribution and top investment priorities
export default function MaturityScoringSummary({ capabilities }) {
  const stats = capabilities.reduce(
    (acc, cap) => {
      const gap = maturityGap(cap);
      const priority = cap.investment_priority || derivedPriority(cap);
      acc.byMaturity[cap.maturity_level] = (acc.byMaturity[cap.maturity_level] || 0) + 1;
      acc.byPriority[priority] = (acc.byPriority[priority] || 0) + 1;
      acc.avgGap += gap;
      acc.count += 1;
      if (gap > 0) acc.withGap += 1;
      if (priority === "critical" || priority === "high") acc.highPriority += 1;
      return acc;
    },
    { byMaturity: {}, byPriority: {}, avgGap: 0, count: 0, withGap: 0, highPriority: 0 }
  );

  const avgGap = stats.count > 0 ? (stats.avgGap / stats.count).toFixed(1) : "0";

  // Top investment priorities (sorted by score, descending)
  const topPriorities = [...capabilities]
    .filter((c) => maturityGap(c) > 0)
    .sort((a, b) => investmentGapScore(b) - investmentGapScore(a))
    .slice(0, 5);

  return (
    <div className="space-y-4">
      {/* Stat tiles */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-none shadow-sm">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-1">
              <Gauge className="w-4 h-4 text-slate-400" />
              <span className="text-xs text-slate-500">Avg maturity gap</span>
            </div>
            <p className="text-xl font-bold text-slate-800">{avgGap}</p>
            <p className="text-xs text-slate-400">levels below target</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-slate-500">With maturity gap</span>
            </div>
            <p className="text-xl font-bold text-amber-600">{stats.withGap}</p>
            <p className="text-xs text-slate-400">of {stats.count} capabilities</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-1">
              <AlertCircle className="w-4 h-4 text-rose-400" />
              <span className="text-xs text-slate-500">High/critical priority</span>
            </div>
            <p className="text-xl font-bold text-rose-600">{stats.highPriority}</p>
            <p className="text-xs text-slate-400">need investment</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-1">
              <Target className="w-4 h-4 text-emerald-400" />
              <span className="text-xs text-slate-500">At target maturity</span>
            </div>
            <p className="text-xl font-bold text-emerald-600">{stats.count - stats.withGap}</p>
            <p className="text-xs text-slate-400">capabilities</p>
          </CardContent>
        </Card>
      </div>

      {/* Maturity distribution bar */}
      <Card className="border-none shadow-sm">
        <CardContent className="p-4">
          <h4 className="text-sm font-semibold text-slate-700 mb-3">Maturity Distribution</h4>
          <div className="flex items-end gap-2 h-24">
            {["initial", "developing", "defined", "managed", "optimising"].map((level) => {
              const count = stats.byMaturity[level] || 0;
              const pct = stats.count > 0 ? (count / stats.count) * 100 : 0;
              const colors = {
                initial: "bg-rose-400",
                developing: "bg-orange-400",
                defined: "bg-yellow-400",
                managed: "bg-blue-400",
                optimising: "bg-emerald-400",
              };
              return (
                <div key={level} className="flex-1 flex flex-col items-center gap-1">
                  <span className="text-xs font-semibold text-slate-600">{count}</span>
                  <div className="w-full bg-slate-100 rounded-t flex items-end" style={{ height: "60px" }}>
                    <div
                      className={`w-full rounded-t ${colors[level]}`}
                      style={{ height: `${Math.max(pct, count > 0 ? 8 : 0)}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 capitalize">{MATURITY_LABELS[level]}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Top investment priorities */}
      {topPriorities.length > 0 && (
        <Card className="border-none shadow-sm">
          <CardContent className="p-4">
            <h4 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-rose-400" />
              Top Investment Priorities
            </h4>
            <div className="space-y-2">
              {topPriorities.map((cap, i) => {
                const gap = maturityGap(cap);
                const priority = cap.investment_priority || derivedPriority(cap);
                const style = PRIORITY_STYLES[priority] || PRIORITY_STYLES.medium;
                return (
                  <div key={cap.id} className="flex items-center gap-3 p-2 rounded-lg bg-slate-50">
                    <span className="text-xs font-bold text-slate-400 w-5">#{i + 1}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-800 truncate">{cap.name}</p>
                      <p className="text-xs text-slate-500">
                        {MATURITY_LABELS[cap.maturity_level]} → {MATURITY_LABELS[cap.target_maturity_level]} · {gap} level{gap !== 1 ? "s" : ""} gap
                      </p>
                    </div>
                    <Badge variant="outline" className={`text-xs border ${style.bg} ${style.text} ${style.border} shrink-0`}>
                      {style.label}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}