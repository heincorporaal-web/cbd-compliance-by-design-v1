import React, { useState, useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Search, ChevronDown, ChevronRight, Check, X, AlertTriangle,
  GitBranch, ArrowRight, AlertCircle,
} from "lucide-react";

export const ISSUE_LABELS = {
  PARENT_OUTSIDE_EXPORTED_POPULATION: { label: "Parent Outside Population", color: "bg-amber-100 text-amber-700 border-amber-300" },
  DUPLICATE_LEGACY_CODE: { label: "Duplicate Legacy Code", color: "bg-red-100 text-red-700 border-red-300" },
  LEVEL_MISMATCH: { label: "Level Mismatch", color: "bg-orange-100 text-orange-700 border-orange-300" },
  PARENT_CODE_MISMATCH: { label: "Parent Code Mismatch", color: "bg-purple-100 text-purple-700 border-purple-300" },
  VALUE_CHAIN_CONFLICT: { label: "Value Chain Conflict", color: "bg-cyan-100 text-cyan-700 border-cyan-300" },
  MISSING_PARENT: { label: "Missing Parent", color: "bg-rose-100 text-rose-700 border-rose-300" },
  NONSTANDARD_SEGMENT: { label: "Nonstandard Segment", color: "bg-violet-100 text-violet-700 border-violet-300" },
  NO_ISSUE: { label: "No Issue", color: "bg-slate-100 text-slate-600 border-slate-300" },
};

export const ACTION_LABELS = {
  MAP_TO_L1_FUNCTION_OVERVIEW: { label: "Map to L1 Overview", color: "bg-blue-100 text-blue-700 border-blue-300" },
  MAP_TO_L2_PROCESS_GROUP: { label: "Map to L2 Group", color: "bg-indigo-100 text-indigo-700 border-indigo-300" },
  RECODE_PROCESS: { label: "Recode Process", color: "bg-emerald-100 text-emerald-700 border-emerald-300" },
  REPARENT_PROCESS: { label: "Reparent Process", color: "bg-teal-100 text-teal-700 border-teal-300" },
  REASSIGN_VALUE_CHAIN: { label: "Reassign Value Chain", color: "bg-cyan-100 text-cyan-700 border-cyan-300" },
  KEEP_AS_IS: { label: "Keep As-Is", color: "bg-slate-100 text-slate-600 border-slate-300" },
  EXCEPTION_HANDOFF: { label: "Exception: Handoff", color: "bg-violet-100 text-violet-700 border-violet-300" },
  LEGACY_MIGRATION: { label: "Legacy Migration", color: "bg-amber-100 text-amber-700 border-amber-300" },
};

function getIssueLabel(flag) {
  return ISSUE_LABELS[flag] || { label: flag.replace(/_/g, ' '), color: "bg-slate-100 text-slate-600 border-slate-300" };
}

function getActionLabel(action) {
  return ACTION_LABELS[action] || { label: action.replace(/_/g, ' '), color: "bg-slate-100 text-slate-600 border-slate-300" };
}

function ChangeBadge({ label, changed }) {
  if (!changed) return null;
  return (
    <Badge variant="outline" className="text-xs bg-orange-50 text-orange-600 border-orange-200">
      {label}
    </Badge>
  );
}

function FindingRow({ item, onActionChange }) {
  const [expanded, setExpanded] = useState(false);
  const action = item._action || "pending";

  return (
    <div className="border-b border-slate-100 last:border-b-0">
      <div
        className="flex items-start gap-3 px-4 py-3 cursor-pointer hover:bg-slate-50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="mt-0.5 shrink-0">
          {expanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className="font-mono text-xs px-1.5 py-0.5 rounded border bg-slate-50 text-slate-700">
              {item.current_code}
            </span>
            {item.changes.code && item.proposed_code && (
              <>
                <ArrowRight className="w-3 h-3 text-slate-400" />
                <span className="font-mono text-xs px-1.5 py-0.5 rounded border bg-emerald-50 text-emerald-700 border-emerald-200">
                  {item.proposed_code}
                </span>
              </>
            )}
            <span className="text-sm text-slate-900 truncate">{item.process_name}</span>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            {item.issue_flags.map((flag) => {
              const il = getIssueLabel(flag);
              return <Badge key={flag} variant="outline" className={`text-xs ${il.color}`}>{il.label}</Badge>;
            })}
            {item.target_action && (
              <Badge variant="outline" className={`text-xs ${getActionLabel(item.target_action).color}`}>
                {getActionLabel(item.target_action).label}
              </Badge>
            )}
            {item.target_value_chain_code && (
              <Badge variant="outline" className="text-xs bg-slate-50 text-slate-600 border-slate-200">
                VC: {item.target_value_chain_code}
              </Badge>
            )}
            <ChangeBadge label="Level" changed={item.changes.level} />
            <ChangeBadge label="Parent" changed={item.changes.parent} />
            <ChangeBadge label="VC" changed={item.changes.value_chain} />
            <ChangeBadge label="WS" changed={item.changes.workstream} />
            {!item.process_found && (
              <Badge variant="outline" className="text-xs bg-red-50 text-red-600 border-red-200">
                <AlertCircle className="w-3 h-3 mr-1" />Not in DB
              </Badge>
            )}
            {item.linked_risk_count > 0 && (
              <Badge variant="outline" className="text-xs bg-purple-50 text-purple-600 border-purple-200">
                {item.linked_risk_count} risks
              </Badge>
            )}
            {item.linked_control_count > 0 && (
              <Badge variant="outline" className="text-xs bg-cyan-50 text-cyan-600 border-cyan-200">
                {item.linked_control_count} controls
              </Badge>
            )}
          </div>
        </div>

        {/* Action controls */}
        <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
          <Button
            size="sm"
            variant={action === "approve" ? "default" : "outline"}
            className={`h-7 px-2 ${action === "approve" ? "bg-green-600 hover:bg-green-700" : ""}`}
            onClick={() => onActionChange(item.row_index, action === "approve" ? null : "approve")}
          >
            <Check className="w-3.5 h-3.5" />
          </Button>
          <Button
            size="sm"
            variant={action === "reject" ? "default" : "outline"}
            className={`h-7 px-2 ${action === "reject" ? "bg-red-600 hover:bg-red-700" : ""}`}
            onClick={() => onActionChange(item.row_index, action === "reject" ? null : "reject")}
          >
            <X className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-3 pl-11 bg-slate-50/50">
          <div className="grid md:grid-cols-2 gap-4 text-xs">
            <div>
              <p className="font-semibold text-slate-500 mb-1.5">Current State</p>
              <dl className="space-y-0.5">
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Code:</dt><dd className="font-mono text-slate-700">{item.current_code}</dd></div>
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Level:</dt><dd className="text-slate-700">{item.current_level}</dd></div>
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Parent:</dt><dd className="font-mono text-slate-700">{item.current_parent_code || item.current_parent_id || '—'}</dd></div>
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Status:</dt><dd className="text-slate-700">{item.existing_status}</dd></div>
                {item.db_current && (
                  <div className="flex gap-2"><dt className="text-slate-400 w-20">DB VC:</dt><dd className="text-slate-700">{item.db_current.value_chain_id || '—'}</dd></div>
                )}
              </dl>
            </div>
            <div>
              <p className="font-semibold text-slate-500 mb-1.5">Proposed State</p>
              <dl className="space-y-0.5">
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Code:</dt><dd className="font-mono text-slate-700">{item.proposed_code || '—'}</dd></div>
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Level:</dt><dd className="text-slate-700">{item.proposed_level ?? '—'}</dd></div>
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Parent:</dt><dd className="font-mono text-slate-700">{item.proposed_parent_code || item.proposed_parent_id || '—'}</dd></div>
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Status:</dt><dd className="text-slate-700">{item.proposed_status || '—'}</dd></div>
                <div className="flex gap-2"><dt className="text-slate-400 w-20">VC:</dt><dd className="text-slate-700">{item.target_value_chain_code || '—'} ({item.target_value_chain_name || '—'})</dd></div>
                <div className="flex gap-2"><dt className="text-slate-400 w-20">Workstream:</dt><dd className="text-slate-700">{item.suggested_workstream_code || '—'} ({item.resolved_workstream_name || '—'})</dd></div>
              </dl>
            </div>
          </div>
          {item.migration_status && (
            <p className="mt-2 text-xs text-slate-400">Migration: {item.migration_status}</p>
          )}
        </div>
      )}
    </div>
  );
}

export default function HierarchyFindingsTable({ items, groups, summary, onActionChange, actions }) {
  const [search, setSearch] = useState("");
  const [issueFilter, setIssueFilter] = useState("ALL");
  const [vcFilter, setVcFilter] = useState("ALL");
  const [actionFilter, setActionFilter] = useState("ALL");
  const [showChangesOnly, setShowChangesOnly] = useState(false);
  const [collapsedGroups, setCollapsedGroups] = useState({});

  const issueFlags = Object.keys(summary?.by_issue || {});
  const vcCodes = Object.keys(summary?.by_value_chain || {});
  const actions_list = Object.keys(summary?.by_action || {});

  const filtered = useMemo(() => {
    return items.filter((item) => {
      if (showChangesOnly && !item.has_changes) return false;
      if (issueFilter !== "ALL" && !item.issue_flags.includes(issueFilter)) return false;
      if (vcFilter !== "ALL" && item.target_value_chain_code !== vcFilter) return false;
      if (actionFilter !== "ALL" && item.target_action !== actionFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!item.process_name?.toLowerCase().includes(q) &&
            !item.current_code?.toLowerCase().includes(q) &&
            !item.proposed_code?.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [items, search, issueFilter, vcFilter, actionFilter, showChangesOnly]);

  // Group filtered items by primary issue flag
  const grouped = useMemo(() => {
    const g = {};
    for (const item of filtered) {
      const key = item.issue_flags[0] || "NO_ISSUE";
      if (!g[key]) g[key] = [];
      g[key].push(item);
    }
    return g;
  }, [filtered]);

  const toggleGroup = (key) => setCollapsedGroups((p) => ({ ...p, [key]: !p[key] }));

  const approveCount = Object.values(actions || {}).filter((a) => a === "approve").length;
  const rejectCount = Object.values(actions || {}).filter((a) => a === "reject").length;

  return (
    <div className="space-y-3">
      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search by name or code…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={issueFilter} onValueChange={setIssueFilter}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Issue type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Issues</SelectItem>
            {issueFlags.map((f) => (
              <SelectItem key={f} value={f}>{getIssueLabel(f).label} ({summary.by_issue[f]})</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={vcFilter} onValueChange={setVcFilter}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Value chain" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All VC</SelectItem>
            {vcCodes.map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={actionFilter} onValueChange={setActionFilter}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Action" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Actions</SelectItem>
            {actions_list.map((a) => <SelectItem key={a} value={a}>{getActionLabel(a).label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button
          variant={showChangesOnly ? "default" : "outline"}
          onClick={() => setShowChangesOnly(!showChangesOnly)}
          className="shrink-0"
        >
          Changes Only
        </Button>
      </div>

      {/* Action summary */}
      <div className="flex items-center gap-3 text-sm">
        <span className="text-slate-500">{filtered.length} findings</span>
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
          <Check className="w-3 h-3 mr-1" />{approveCount} approved
        </Badge>
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-300">
          <X className="w-3 h-3 mr-1" />{rejectCount} rejected
        </Badge>
      </div>

      {/* Grouped findings */}
      <div className="space-y-2">
        {Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b)).map(([flag, groupItems]) => {
          const isCollapsed = collapsedGroups[flag];
          const il = getIssueLabel(flag);
          const groupApproved = groupItems.filter((i) => actions?.[i.row_index] === "approve").length;
          return (
            <div key={flag} className="border border-slate-200 rounded-lg overflow-hidden bg-white">
              <div
                className="flex items-center gap-3 px-4 py-2.5 bg-slate-50 cursor-pointer hover:bg-slate-100 transition-colors"
                onClick={() => toggleGroup(flag)}
              >
                {isCollapsed ? <ChevronRight className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                <Badge variant="outline" className={`text-xs ${il.color}`}>{il.label}</Badge>
                <span className="text-xs text-slate-500">{groupItems.length} findings</span>
                {groupApproved > 0 && (
                  <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-300">
                    {groupApproved} approved
                  </Badge>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="ml-auto h-6 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    groupItems.forEach((i) => onActionChange(i.row_index, "approve"));
                  }}
                >
                  Approve All
                </Button>
              </div>
              {!isCollapsed && (
                <div>
                  {groupItems.map((item) => (
                    <FindingRow key={item.row_index} item={item} onActionChange={onActionChange} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="text-center py-12 text-slate-400">
            <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-50" />
            No findings match the current filters.
          </div>
        )}
      </div>
    </div>
  );
}