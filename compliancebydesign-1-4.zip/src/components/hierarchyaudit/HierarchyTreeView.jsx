import React, { useState, useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronRight, GitBranch, AlertTriangle } from "lucide-react";

function TreeNode({ node, itemsMap, depth, changedIds }) {
  const [expanded, setExpanded] = useState(depth < 2);
  const children = node.children || [];
  const hasChanges = changedIds.has(node.item?.process_id);
  const isNotFound = !node.item?.process_found;

  return (
    <div>
      <div
        className={`flex items-center gap-2 py-1 px-2 rounded hover:bg-slate-50 cursor-pointer ${depth === 0 ? "font-semibold" : ""}`}
        style={{ paddingLeft: `${depth * 20 + 8}px` }}
        onClick={() => setExpanded(!expanded)}
      >
        {children.length > 0 ? (
          expanded ? <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        ) : (
          <span className="w-3.5 shrink-0" />
        )}
        <span className={`font-mono text-xs px-1.5 py-0.5 rounded border shrink-0 ${
          hasChanges ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-slate-50 text-slate-600 border-slate-200"
        }`}>
          {node.item?.proposed_code || node.item?.current_code || '—'}
        </span>
        <span className="text-sm text-slate-700 truncate">{node.item?.process_name || '—'}</span>
        <span className="text-xs text-slate-400 shrink-0">L{node.item?.proposed_level ?? node.item?.current_level ?? '?'}</span>
        {node.item?.target_value_chain_code && (
          <Badge variant="outline" className="text-xs shrink-0 bg-slate-50 text-slate-500 border-slate-200">
            {node.item.target_value_chain_code}
          </Badge>
        )}
        {hasChanges && (
          <GitBranch className="w-3 h-3 text-emerald-500 shrink-0" />
        )}
        {isNotFound && (
          <AlertTriangle className="w-3 h-3 text-red-400 shrink-0" />
        )}
        {children.length > 0 && (
          <span className="text-xs text-slate-400 ml-auto shrink-0">{children.length}</span>
        )}
      </div>
      {expanded && children.map((child) => (
        <TreeNode
          key={child.id || child.row_index}
          node={child}
          itemsMap={itemsMap}
          depth={depth + 1}
          changedIds={changedIds}
        />
      ))}
    </div>
  );
}

export default function HierarchyTreeView({ items }) {
  const [view, setView] = useState("proposed"); // "proposed" or "current"

  const { roots, changedIds } = useMemo(() => {
    const changedIds = new Set(items.filter((i) => i.has_changes).map((i) => i.process_id));

    // Build tree from parent-child relationships
    const nodeMap = new Map();
    const rootNodes = [];

    for (const item of items) {
      const parentId = view === "proposed"
        ? (item.proposed_parent_id || item.current_parent_id)
        : item.current_parent_id;
      const id = item.process_id;

      if (!nodeMap.has(id)) nodeMap.set(id, { id, item, children: [] });
      else nodeMap.get(id).item = item;

      const node = nodeMap.get(id);
      if (parentId && parentId !== id) {
        if (!nodeMap.has(parentId)) nodeMap.set(parentId, { id: parentId, item: null, children: [] });
        nodeMap.get(parentId).children.push(node);
      } else {
        rootNodes.push(node);
      }
    }

    // Sort children by code
    const sortChildren = (node) => {
      node.children.sort((a, b) => {
        const aCode = a.item?.proposed_code || a.item?.current_code || '';
        const bCode = b.item?.proposed_code || b.item?.current_code || '';
        return aCode.localeCompare(bCode);
      });
      node.children.forEach(sortChildren);
    };
    rootNodes.forEach(sortChildren);
    rootNodes.sort((a, b) => {
      const aCode = a.item?.proposed_code || a.item?.current_code || '';
      const bCode = b.item?.proposed_code || b.item?.current_code || '';
      return aCode.localeCompare(bCode);
    });

    return { roots: rootNodes, changedIds };
  }, [items, view]);

  return (
    <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
      <div className="flex items-center gap-3 px-4 py-2.5 bg-slate-50 border-b border-slate-200">
        <GitBranch className="w-4 h-4 text-slate-500" />
        <span className="text-sm font-semibold text-slate-700">Process Hierarchy Tree</span>
        <div className="ml-auto flex items-center gap-2">
          <Button
            size="sm"
            variant={view === "proposed" ? "default" : "outline"}
            onClick={() => setView("proposed")}
            className="h-7 text-xs"
          >
            Proposed
          </Button>
          <Button
            size="sm"
            variant={view === "current" ? "default" : "outline"}
            onClick={() => setView("current")}
            className="h-7 text-xs"
          >
            Current
          </Button>
        </div>
      </div>
      <div className="flex items-center gap-3 px-4 py-1.5 text-xs text-slate-400 border-b border-slate-100">
        <span className="flex items-center gap-1"><GitBranch className="w-3 h-3 text-emerald-500" /> Has changes</span>
        <span className="flex items-center gap-1"><AlertTriangle className="w-3 h-3 text-red-400" /> Not in DB</span>
        <span>{roots.length} root nodes</span>
      </div>
      <div className="max-h-[600px] overflow-y-auto p-2">
        {roots.map((node) => (
          <TreeNode
            key={node.id || node.row_index}
            node={node}
            itemsMap={null}
            depth={0}
            changedIds={changedIds}
          />
        ))}
        {roots.length === 0 && (
          <div className="text-center py-8 text-slate-400 text-sm">No hierarchy data available.</div>
        )}
      </div>
    </div>
  );
}