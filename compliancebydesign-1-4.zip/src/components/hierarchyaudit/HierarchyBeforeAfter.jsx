import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";

function DistributionRow({ label, beforeVal, afterVal }) {
  const changed = beforeVal !== afterVal;
  return (
    <div className="flex items-center gap-3 py-1.5 text-sm">
      <span className="flex-1 truncate text-slate-600">{label}</span>
      <span className={`w-12 text-right font-mono ${changed ? "text-slate-400 line-through" : "text-slate-700"}`}>{beforeVal}</span>
      <ArrowRight className="w-3 h-3 text-slate-400 shrink-0" />
      <span className={`w-12 text-right font-mono ${changed ? "text-primary font-bold" : "text-slate-700"}`}>{afterVal}</span>
    </div>
  );
}

export default function HierarchyBeforeAfter({ beforeAfter }) {
  if (!beforeAfter) return null;

  const levels = Array.from(new Set([
    ...Object.keys(beforeAfter.before.by_level).map(Number),
    ...Object.keys(beforeAfter.after.by_level).map(Number),
  ])).sort((a, b) => a - b);

  const vcs = Array.from(new Set([
    ...Object.keys(beforeAfter.before.by_value_chain),
    ...Object.keys(beforeAfter.after.by_value_chain),
  ])).sort();

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Level Distribution (Before → After)</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="border-b border-slate-100 flex items-center gap-3 py-1.5 text-xs font-medium text-slate-400">
            <span className="flex-1">Level</span>
            <span className="w-12 text-right">Before</span>
            <span className="w-3" />
            <span className="w-12 text-right">After</span>
          </div>
          {levels.map((lvl) => (
            <DistributionRow
              key={lvl}
              label={`Level ${lvl}`}
              beforeVal={beforeAfter.before.by_level[lvl] || 0}
              afterVal={beforeAfter.after.by_level[lvl] || 0}
            />
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Value Chain Distribution (Before → After)</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="border-b border-slate-100 flex items-center gap-3 py-1.5 text-xs font-medium text-slate-400">
            <span className="flex-1">Value Chain</span>
            <span className="w-12 text-right">Before</span>
            <span className="w-3" />
            <span className="w-12 text-right">After</span>
          </div>
          <div className="max-h-64 overflow-y-auto">
            {vcs.map((vc) => (
              <DistributionRow
                key={vc}
                label={vc}
                beforeVal={beforeAfter.before.by_value_chain[vc] || 0}
                afterVal={beforeAfter.after.by_value_chain[vc] || 0}
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}