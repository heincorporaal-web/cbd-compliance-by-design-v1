import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GitBranch, AlertTriangle, CheckCircle2, Database, Link2, Shield } from "lucide-react";

export default function HierarchySummaryCards({ summary }) {
  if (!summary) return null;

  const cards = [
    { label: "Total Processes", value: summary.total, icon: Database, color: "text-blue-600", bg: "bg-blue-50" },
    { label: "Found in DB", value: summary.process_found, icon: CheckCircle2, color: "text-green-600", bg: "bg-green-50" },
    { label: "Not Found", value: summary.process_not_found, icon: AlertTriangle, color: "text-red-600", bg: "bg-red-50" },
    { label: "With Changes", value: summary.total - summary.changes.no_change, icon: GitBranch, color: "text-orange-600", bg: "bg-orange-50" },
    { label: "Linked Risks", value: summary.downstream.linked_risks, icon: Shield, color: "text-purple-600", bg: "bg-purple-50" },
    { label: "Linked Controls", value: summary.downstream.linked_controls, icon: Link2, color: "text-cyan-600", bg: "bg-cyan-50" },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {cards.map((c) => (
        <Card key={c.label} className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <div className={`w-8 h-8 rounded-lg ${c.bg} flex items-center justify-center`}>
              <c.icon className={`w-4 h-4 ${c.color}`} />
            </div>
            <span className="text-xs text-slate-500">{c.label}</span>
          </div>
          <p className="text-2xl font-bold text-slate-900">{c.value}</p>
        </Card>
      ))}
    </div>
  );
}