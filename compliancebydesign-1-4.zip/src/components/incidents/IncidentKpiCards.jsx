import React from "react";
import { InfoTileColumn } from "@/components/dashboard/InfoTile";

export default function IncidentKpiCards({ incidents }) {
  const total = incidents.length;
  const open = incidents.filter(i => !["closed", "resolved"].includes(i.status)).length;
  const critical = incidents.filter(i => i.severity === "critical").length;
  const major = incidents.filter(i => i.major_incident).length;
  const slaBreached = incidents.filter(i => i.sla_breached).length;
  const pirPending = incidents.filter(i => i.pir_required && !i.pir_completed).length;

  // Mean Time to Resolve (hours) for resolved/closed incidents
  const resolved = incidents.filter(i => i.resolved_date && i.detected_date);
  const mttrHours = resolved.length > 0
    ? Math.round(resolved.reduce((sum, i) => {
        const diff = new Date(i.resolved_date) - new Date(i.detected_date);
        return sum + (diff / (1000 * 60 * 60));
      }, 0) / resolved.length)
    : 0;

  // Priority metrics — things that need attention now
  const priorityItems = [
    { label: "Critical Severity", value: critical, sub: "Immediate action", attention: critical > 0 },
    { label: "SLA Breached", value: slaBreached, sub: `${total > 0 ? Math.round((slaBreached / total) * 100) : 0}% of all`, attention: slaBreached > 0 },
    { label: "Major Incidents", value: major, sub: "Declared" },
    { label: "PIR Pending", value: pirPending, sub: "Reviews due" },
  ];

  // Volume summary — rolled-up counts
  const volumeItems = [
    { label: "Total Incidents", value: total, sub: `${open} open` },
    { label: "Open / Active", value: open, sub: "In progress" },
    { label: "Resolved / Closed", value: total - open, sub: `${total > 0 ? Math.round(((total - open) / total) * 100) : 0}% rate` },
    { label: "Avg Resolution", value: `${mttrHours}h`, sub: "Mean time" },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      <InfoTileColumn title="Priority Metrics" items={priorityItems} />
      <InfoTileColumn title="Volume Summary" items={volumeItems} />
    </div>
  );
}