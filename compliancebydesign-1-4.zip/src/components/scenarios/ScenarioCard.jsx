import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GitCompare, Calendar, DollarSign, Clock, TrendingDown, AlertCircle } from "lucide-react";

const STATUS_STYLES = {
  draft: "bg-slate-100 text-slate-600",
  proposed: "bg-blue-100 text-blue-700",
  under_review: "bg-amber-100 text-amber-700",
  approved: "bg-emerald-100 text-emerald-700",
  rejected: "bg-rose-100 text-rose-700",
  archived: "bg-slate-200 text-slate-500",
};

const COMPLEXITY_STYLES = {
  low: "text-emerald-600",
  medium: "text-amber-600",
  high: "text-orange-600",
  very_high: "text-rose-600",
};

const RISK_IMPACT_STYLES = {
  very_positive: "text-emerald-600",
  positive: "text-emerald-500",
  neutral: "text-slate-500",
  negative: "text-amber-500",
  very_negative: "text-rose-600",
};

export default function ScenarioCard({ scenario, onClick, selected, onSelect }) {
  return (
    <Card
      className={`cursor-pointer transition-all hover:shadow-md ${
        selected ? "ring-2 ring-primary" : ""
      }`}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center shrink-0">
              <GitCompare className="w-4 h-4 text-indigo-600" />
            </div>
            <h3 className="font-semibold text-slate-900 text-sm truncate">
              {scenario.name}
            </h3>
          </div>
          <Badge className={STATUS_STYLES[scenario.status] || "bg-slate-100"}>
            {scenario.status?.replace("_", " ")}
          </Badge>
        </div>

        {scenario.description && (
          <p className="text-xs text-slate-500 line-clamp-2 mb-3">
            {scenario.description}
          </p>
        )}

        <div className="grid grid-cols-2 gap-2 text-xs">
          {scenario.target_date && (
            <div className="flex items-center gap-1.5 text-slate-600">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>
                {new Date(scenario.target_date).toLocaleDateString("en-GB", {
                  day: "2-digit",
                  month: "short",
                  year: "numeric",
                })}
              </span>
            </div>
          )}
          {scenario.cost_estimate != null && (
            <div className="flex items-center gap-1.5 text-slate-600">
              <DollarSign className="w-3.5 h-3.5 text-slate-400" />
              <span>
                {scenario.cost_currency || "USD"}{" "}
                {Number(scenario.cost_estimate).toLocaleString()}
              </span>
            </div>
          )}
          {scenario.timeline_months != null && (
            <div className="flex items-center gap-1.5 text-slate-600">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>{scenario.timeline_months} months</span>
            </div>
          )}
          {scenario.complexity && (
            <div className="flex items-center gap-1.5">
              <AlertCircle
                className={`w-3.5 h-3.5 ${COMPLEXITY_STYLES[scenario.complexity] || "text-slate-400"}`}
              />
              <span className={COMPLEXITY_STYLES[scenario.complexity] || "text-slate-600"}>
                {scenario.complexity.replace("_", " ")}
              </span>
            </div>
          )}
        </div>

        {scenario.risk_impact_level && (
          <div className="flex items-center gap-1.5 text-xs mt-2 pt-2 border-t border-slate-100">
            <TrendingDown
              className={`w-3.5 h-3.5 ${RISK_IMPACT_STYLES[scenario.risk_impact_level] || "text-slate-400"}`}
            />
            <span className="text-slate-500">Risk impact:</span>
            <span className={RISK_IMPACT_STYLES[scenario.risk_impact_level] || "text-slate-600"}>
              {scenario.risk_impact_level.replace("_", " ")}
            </span>
          </div>
        )}

        {onSelect && (
          <div className="mt-3 pt-2 border-t border-slate-100" onClick={(e) => e.stopPropagation()}>
            <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
              <input
                type="checkbox"
                checked={selected || false}
                onChange={(e) => onSelect(scenario.id, e.target.checked)}
                className="rounded border-slate-300"
              />
              Select for comparison
            </label>
          </div>
        )}
      </CardContent>
    </Card>
  );
}