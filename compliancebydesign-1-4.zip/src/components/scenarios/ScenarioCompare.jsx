import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DollarSign,
  Clock,
  AlertCircle,
  TrendingDown,
  GitCompare,
  X,
} from "lucide-react";

const STATUS_STYLES = {
  draft: "bg-slate-100 text-slate-600",
  proposed: "bg-blue-100 text-blue-700",
  under_review: "bg-amber-100 text-amber-700",
  approved: "bg-emerald-100 text-emerald-700",
  rejected: "bg-rose-100 text-rose-700",
  archived: "bg-slate-200 text-slate-500",
};

function MetricRow({ icon: Icon, label, values, format }) {
  return (
    <div className="grid grid-cols-[140px_1fr] gap-2 py-2 border-b border-slate-100 last:border-0">
      <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
        <Icon className="w-3.5 h-3.5 text-slate-400" />
        {label}
      </div>
      <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${values.length}, 1fr)` }}>
        {values.map((v, i) => (
          <div key={i} className="text-sm text-slate-700 font-medium">
            {format ? format(v) : v || "—"}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ScenarioCompare({ scenarios, onClose }) {
  if (!scenarios || scenarios.length === 0) return null;
  const n = scenarios.length;

  return (
    <Card className="border-indigo-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-indigo-600" />
            <CardTitle className="text-base">Side-by-Side Comparison</CardTitle>
            <Badge variant="secondary">{n} scenarios</Badge>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 p-1 rounded hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {/* Scenario name headers */}
        <div className="grid gap-2 mb-3" style={{ gridTemplateColumns: `140px repeat(${n}, 1fr)` }}>
          <div />
          {scenarios.map((s) => (
            <div key={s.id} className="font-semibold text-sm text-slate-900 truncate">
              {s.name}
            </div>
          ))}
        </div>

        {/* Status row */}
        <div className="grid gap-2 py-2 border-b border-slate-100" style={{ gridTemplateColumns: `140px repeat(${n}, 1fr)` }}>
          <div className="text-xs text-slate-500 font-medium">Status</div>
          {scenarios.map((s) => (
            <div key={s.id}>
              <Badge className={STATUS_STYLES[s.status] || "bg-slate-100"}>
                {s.status?.replace("_", " ")}
              </Badge>
            </div>
          ))}
        </div>

        <MetricRow
          icon={DollarSign}
          label="Cost Estimate"
          values={scenarios.map((s) => s.cost_estimate)}
          format={(v) => (v != null ? `${scenarios[0].cost_currency || "USD"} ${Number(v).toLocaleString()}` : "—")}
        />
        <MetricRow
          icon={Clock}
          label="Timeline"
          values={scenarios.map((s) => s.timeline_months)}
          format={(v) => (v != null ? `${v} months` : "—")}
        />
        <MetricRow
          icon={AlertCircle}
          label="Complexity"
          values={scenarios.map((s) => s.complexity)}
          format={(v) => (v ? v.replace("_", " ") : "—")}
        />
        <MetricRow
          icon={TrendingDown}
          label="Risk Impact"
          values={scenarios.map((s) => s.risk_impact_level)}
          format={(v) => (v ? v.replace("_", " ") : "—")}
        />
        <MetricRow
          icon={TrendingDown}
          label="Risk Reduction"
          values={scenarios.map((s) => s.risk_score_reduction)}
          format={(v) => (v != null ? `${v} pts` : "—")}
        />

        {/* Current vs Future state */}
        <div className="mt-4 space-y-3">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            State Comparison
          </h4>
          {scenarios.map((s) => (
            <div key={s.id} className="border rounded-lg p-3 bg-slate-50/50">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs font-semibold text-slate-500 mb-1">Current (As-Is)</p>
                  <p className="text-xs text-slate-600">
                    {s.current_state_summary || "—"}
                  </p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-indigo-600 mb-1">Future (To-Be)</p>
                  <p className="text-xs text-slate-600">
                    {s.future_state_summary || "—"}
                  </p>
                </div>
              </div>
              {s.key_changes?.length > 0 && (
                <div className="mt-2 pt-2 border-t border-slate-200">
                  <p className="text-xs font-semibold text-slate-500 mb-1">Key Changes</p>
                  <ul className="space-y-0.5">
                    {s.key_changes.map((c, i) => (
                      <li key={i} className="text-xs text-slate-600 flex items-start gap-1.5">
                        <span className="text-indigo-400 mt-0.5">•</span>
                        <span>
                          {c.change_type?.replace("_", " ")}: {c.description}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Linked entities summary */}
        <div className="mt-4">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
            Linked Entities
          </h4>
          <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${n}, 1fr)` }}>
            {scenarios.map((s) => (
              <div key={s.id} className="text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Processes:</span>
                  <span className="font-medium text-slate-700">
                    {s.linked_process_ids?.length || 0}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Systems:</span>
                  <span className="font-medium text-slate-700">
                    {s.linked_system_ids?.length || 0}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Risks:</span>
                  <span className="font-medium text-slate-700">
                    {s.linked_risk_ids?.length || 0}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Controls:</span>
                  <span className="font-medium text-slate-700">
                    {s.linked_control_ids?.length || 0}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}