import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const SCENARIO_TYPES = [
  { value: "process_change", label: "Process Change" },
  { value: "system_migration", label: "System Migration" },
  { value: "risk_mitigation", label: "Risk Mitigation" },
  { value: "org_restructure", label: "Org Restructure" },
  { value: "regulatory_response", label: "Regulatory Response" },
  { value: "technology_modernisation", label: "Technology Modernisation" },
  { value: "other", label: "Other" },
];

const COMPLEXITY_LEVELS = [
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "very_high", label: "Very High" },
];

const RISK_IMPACT_LEVELS = [
  { value: "very_positive", label: "Very Positive" },
  { value: "positive", label: "Positive" },
  { value: "neutral", label: "Neutral" },
  { value: "negative", label: "Negative" },
  { value: "very_negative", label: "Very Negative" },
];

const PRIORITIES = [
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "critical", label: "Critical" },
];

export default function ScenarioFormDialog({ open, onClose, onSave, scenario, companyId }) {
  const [form, setForm] = useState({
    name: "",
    description: "",
    scenario_type: "process_change",
    priority: "medium",
    status: "draft",
    target_date: "",
    cost_estimate: "",
    cost_currency: "USD",
    complexity: "medium",
    timeline_months: "",
    risk_impact_level: "neutral",
    risk_score_reduction: "",
    current_state_summary: "",
    future_state_summary: "",
    assumptions: "",
    dependencies: "",
    benefits: "",
    risks: "",
  });

  useEffect(() => {
    if (scenario) {
      setForm({
        name: scenario.name || "",
        description: scenario.description || "",
        scenario_type: scenario.scenario_type || "process_change",
        priority: scenario.priority || "medium",
        status: scenario.status || "draft",
        target_date: scenario.target_date || "",
        cost_estimate: scenario.cost_estimate ?? "",
        cost_currency: scenario.cost_currency || "USD",
        complexity: scenario.complexity || "medium",
        timeline_months: scenario.timeline_months ?? "",
        risk_impact_level: scenario.risk_impact_level || "neutral",
        risk_score_reduction: scenario.risk_score_reduction ?? "",
        current_state_summary: scenario.current_state_summary || "",
        future_state_summary: scenario.future_state_summary || "",
        assumptions: scenario.assumptions || "",
        dependencies: scenario.dependencies || "",
        benefits: scenario.benefits || "",
        risks: scenario.risks || "",
      });
    } else {
      setForm({
        name: "",
        description: "",
        scenario_type: "process_change",
        priority: "medium",
        status: "draft",
        target_date: "",
        cost_estimate: "",
        cost_currency: "USD",
        complexity: "medium",
        timeline_months: "",
        risk_impact_level: "neutral",
        risk_score_reduction: "",
        current_state_summary: "",
        future_state_summary: "",
        assumptions: "",
        dependencies: "",
        benefits: "",
        risks: "",
      });
    }
  }, [scenario, open]);

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    if (!form.name.trim()) return;
    const payload = {
      ...form,
      company_id: companyId,
      cost_estimate: form.cost_estimate === "" ? null : Number(form.cost_estimate),
      timeline_months: form.timeline_months === "" ? null : Number(form.timeline_months),
      risk_score_reduction:
        form.risk_score_reduction === "" ? null : Number(form.risk_score_reduction),
    };
    onSave(payload);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {scenario ? "Edit Scenario" : "Create Future-State Scenario"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>Scenario Name *</Label>
            <Input
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="e.g. Automate Purchase Order Approval"
            />
          </div>

          <div className="space-y-1.5">
            <Label>Description</Label>
            <Textarea
              value={form.description}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="High-level description of the proposed future state"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Scenario Type</Label>
              <Select
                value={form.scenario_type}
                onValueChange={(v) => handleChange("scenario_type", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SCENARIO_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>Priority</Label>
              <Select
                value={form.priority}
                onValueChange={(v) => handleChange("priority", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p.value} value={p.value}>
                      {p.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Target Date</Label>
              <Input
                type="date"
                value={form.target_date}
                onChange={(e) => handleChange("target_date", e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Timeline (months)</Label>
              <Input
                type="number"
                value={form.timeline_months}
                onChange={(e) => handleChange("timeline_months", e.target.value)}
                placeholder="e.g. 6"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Cost Estimate</Label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  value={form.cost_estimate}
                  onChange={(e) => handleChange("cost_estimate", e.target.value)}
                  placeholder="e.g. 150000"
                />
                <Input
                  value={form.cost_currency}
                  onChange={(e) => handleChange("cost_currency", e.target.value)}
                  className="w-20"
                  placeholder="USD"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Complexity</Label>
              <Select
                value={form.complexity}
                onValueChange={(v) => handleChange("complexity", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {COMPLEXITY_LEVELS.map((c) => (
                    <SelectItem key={c.value} value={c.value}>
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Risk Impact</Label>
              <Select
                value={form.risk_impact_level}
                onValueChange={(v) => handleChange("risk_impact_level", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {RISK_IMPACT_LEVELS.map((r) => (
                    <SelectItem key={r.value} value={r.value}>
                      {r.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Risk Score Reduction</Label>
              <Input
                type="number"
                value={form.risk_score_reduction}
                onChange={(e) => handleChange("risk_score_reduction", e.target.value)}
                placeholder="e.g. 15"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Current State (As-Is)</Label>
            <Textarea
              value={form.current_state_summary}
              onChange={(e) => handleChange("current_state_summary", e.target.value)}
              placeholder="Describe how things work today"
              rows={2}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Future State (To-Be)</Label>
            <Textarea
              value={form.future_state_summary}
              onChange={(e) => handleChange("future_state_summary", e.target.value)}
              placeholder="Describe the proposed future state"
              rows={2}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Benefits</Label>
            <Textarea
              value={form.benefits}
              onChange={(e) => handleChange("benefits", e.target.value)}
              placeholder="Expected benefits if implemented"
              rows={2}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Risks & Downsides</Label>
            <Textarea
              value={form.risks}
              onChange={(e) => handleChange("risks", e.target.value)}
              placeholder="Risks of implementing this scenario"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Assumptions</Label>
              <Textarea
                value={form.assumptions}
                onChange={(e) => handleChange("assumptions", e.target.value)}
                rows={2}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Dependencies</Label>
              <Textarea
                value={form.dependencies}
                onChange={(e) => handleChange("dependencies", e.target.value)}
                rows={2}
              />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!form.name.trim()}>
            {scenario ? "Save Changes" : "Create Scenario"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}