import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import {
  ArrowLeft,
  Pencil,
  Trash2,
  Plus,
  X,
  Link2,
  Network,
  Server,
  TriangleAlert,
  Shield,
} from "lucide-react";

const STATUS_STYLES = {
  draft: "bg-slate-100 text-slate-600",
  proposed: "bg-blue-100 text-blue-700",
  under_review: "bg-amber-100 text-amber-700",
  approved: "bg-emerald-100 text-emerald-700",
  rejected: "bg-rose-100 text-rose-700",
  archived: "bg-slate-200 text-slate-500",
};

const CHANGE_TYPES = [
  { value: "new_process", label: "New Process" },
  { value: "modified_process", label: "Modified Process" },
  { value: "retired_process", label: "Retired Process" },
  { value: "new_system", label: "New System" },
  { value: "modified_system", label: "Modified System" },
  { value: "retired_system", label: "Retired System" },
  { value: "new_control", label: "New Control" },
  { value: "modified_control", label: "Modified Control" },
  { value: "retired_control", label: "Retired Control" },
  { value: "risk_mitigated", label: "Risk Mitigated" },
  { value: "risk_accepted", label: "Risk Accepted" },
  { value: "org_change", label: "Org Change" },
  { value: "other", label: "Other" },
];

export default function ScenarioDetail({ scenario, onBack, onEdit, onDelete, onUpdate, companyId }) {
  const [newChange, setNewChange] = useState({ change_type: "other", description: "", impact_level: "medium" });
  const [linkMode, setLinkMode] = useState(null);

  const { data: processes = [] } = useQuery({
    queryKey: ["scenarios-processes", companyId],
    queryFn: () => base44.entities.OrgProcess.filter({ company_id: companyId }, { limit: 500, fields: ["name", "process_code"] }),
    enabled: !!companyId,
  });
  const { data: systems = [] } = useQuery({
    queryKey: ["scenarios-systems", companyId],
    queryFn: () => base44.entities.ICTSystem.filter({ company_id: companyId }, { limit: 500, fields: ["name"] }),
    enabled: !!companyId,
  });
  const { data: risks = [] } = useQuery({
    queryKey: ["scenarios-risks", companyId],
    queryFn: () => base44.entities.Risk.filter({ company_id: companyId }, { limit: 500, fields: ["title", "risk_reference_nr"] }),
    enabled: !!companyId,
  });
  const { data: controls = [] } = useQuery({
    queryKey: ["scenarios-controls", companyId],
    queryFn: () => base44.entities.Control.filter({ company_id: companyId }, { limit: 500, fields: ["title", "control_id"] }),
    enabled: !!companyId,
  });

  const linkedProcesses = (scenario.linked_process_ids || []).map((id) => {
    const p = processes.find((x) => x.id === id);
    return { id, name: p?.name || p?.process_code || "Unknown" };
  });
  const linkedSystems = (scenario.linked_system_ids || []).map((id) => {
    const s = systems.find((x) => x.id === id);
    return { id, name: s?.name || "Unknown" };
  });
  const linkedRisks = (scenario.linked_risk_ids || []).map((id) => {
    const r = risks.find((x) => x.id === id);
    return { id, name: r?.title || r?.risk_reference_nr || "Unknown" };
  });
  const linkedControls = (scenario.linked_control_ids || []).map((id) => {
    const c = controls.find((x) => x.id === id);
    return { id, name: c?.title || c?.control_id || "Unknown" };
  });

  const addChange = () => {
    if (!newChange.description.trim()) return;
    const changes = [...(scenario.key_changes || []), { ...newChange }];
    onUpdate(scenario.id, { key_changes: changes });
    setNewChange({ change_type: "other", description: "", impact_level: "medium" });
  };

  const removeChange = (index) => {
    const changes = (scenario.key_changes || []).filter((_, i) => i !== index);
    onUpdate(scenario.id, { key_changes: changes });
  };

  const toggleLink = (type, id) => {
    const fieldMap = {
      process: "linked_process_ids",
      system: "linked_system_ids",
      risk: "linked_risk_ids",
      control: "linked_control_ids",
    };
    const field = fieldMap[type];
    const current = scenario[field] || [];
    const next = current.includes(id)
      ? current.filter((x) => x !== id)
      : [...current, id];
    onUpdate(scenario.id, { [field]: next });
  };

  const linkConfigs = [
    { type: "process", label: "Processes", icon: Network, items: processes, linked: linkedProcesses, nameField: "name" },
    { type: "system", label: "ICT Systems", icon: Server, items: systems, linked: linkedSystems, nameField: "name" },
    { type: "risk", label: "Risks", icon: TriangleAlert, items: risks, linked: linkedRisks, nameField: "title" },
    { type: "control", label: "Controls", icon: Shield, items: controls, linked: linkedControls, nameField: "title" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} className="gap-2">
          <ArrowLeft className="w-4 h-4" /> Back to scenarios
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onEdit} className="gap-2">
            <Pencil className="w-4 h-4" /> Edit
          </Button>
          <Button variant="outline" onClick={onDelete} className="gap-2 text-rose-600 hover:text-rose-700">
            <Trash2 className="w-4 h-4" /> Delete
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <h1 className="text-xl font-bold text-slate-900">{scenario.name}</h1>
              {scenario.description && (
                <p className="text-sm text-slate-500 mt-1">{scenario.description}</p>
              )}
            </div>
            <Badge className={STATUS_STYLES[scenario.status] || "bg-slate-100"}>
              {scenario.status?.replace("_", " ")}
            </Badge>
          </div>

          {/* Current vs Future state */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="border rounded-lg p-4 bg-slate-50/50">
              <h3 className="text-sm font-semibold text-slate-600 mb-2">Current State (As-Is)</h3>
              <p className="text-sm text-slate-600 whitespace-pre-wrap">
                {scenario.current_state_summary || "No current state description provided."}
              </p>
            </div>
            <div className="border rounded-lg p-4 bg-indigo-50/50 border-indigo-100">
              <h3 className="text-sm font-semibold text-indigo-600 mb-2">Future State (To-Be)</h3>
              <p className="text-sm text-slate-600 whitespace-pre-wrap">
                {scenario.future_state_summary || "No future state description provided."}
              </p>
            </div>
          </div>

          {/* Metrics grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {[
              { label: "Cost", value: scenario.cost_estimate != null ? `${scenario.cost_currency || "USD"} ${Number(scenario.cost_estimate).toLocaleString()}` : "—" },
              { label: "Timeline", value: scenario.timeline_months != null ? `${scenario.timeline_months} months` : "—" },
              { label: "Complexity", value: scenario.complexity?.replace("_", " ") || "—" },
              { label: "Risk Impact", value: scenario.risk_impact_level?.replace("_", " ") || "—" },
            ].map((m) => (
              <div key={m.label} className="border rounded-lg p-3">
                <p className="text-xs text-slate-400 mb-1">{m.label}</p>
                <p className="text-sm font-semibold text-slate-700">{m.value}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Key Changes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Key Changes</CardTitle>
        </CardHeader>
        <CardContent>
          {scenario.key_changes?.length > 0 ? (
            <ul className="space-y-2 mb-4">
              {scenario.key_changes.map((c, i) => (
                <li key={i} className="flex items-start justify-between gap-2 p-2 rounded-lg bg-slate-50">
                  <div className="flex-1">
                    <Badge variant="outline" className="mb-1 text-xs">
                      {c.change_type?.replace("_", " ")}
                    </Badge>
                    <p className="text-sm text-slate-700">{c.description}</p>
                  </div>
                  <button
                    onClick={() => removeChange(i)}
                    className="text-slate-400 hover:text-rose-600 p-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate-400 italic mb-4">No key changes recorded yet.</p>
          )}

          <div className="flex gap-2 items-end">
            <div className="w-40">
              <Label className="text-xs">Change Type</Label>
              <Select
                value={newChange.change_type}
                onValueChange={(v) => setNewChange((p) => ({ ...p, change_type: v }))}
              >
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CHANGE_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <Label className="text-xs">Description</Label>
              <Input
                value={newChange.description}
                onChange={(e) => setNewChange((p) => ({ ...p, description: e.target.value }))}
                placeholder="Describe the change..."
                className="h-8 text-sm"
              />
            </div>
            <Button onClick={addChange} size="sm" className="gap-1">
              <Plus className="w-3.5 h-3.5" /> Add
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Linked entities */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Link2 className="w-4 h-4 text-slate-400" /> Linked Entities
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {linkConfigs.map((cfg) => (
              <div key={cfg.type} className="border rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5">
                    <cfg.icon className="w-4 h-4 text-slate-400" />
                    <h4 className="text-sm font-semibold text-slate-700">{cfg.label}</h4>
                    <Badge variant="secondary" className="text-xs">
                      {cfg.linked.length}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setLinkMode(linkMode === cfg.type ? null : cfg.type)}
                    className="text-xs h-7"
                  >
                    {linkMode === cfg.type ? "Done" : "Manage"}
                  </Button>
                </div>

                {linkMode === cfg.type ? (
                  <div className="max-h-48 overflow-y-auto space-y-1 border rounded p-2 bg-slate-50">
                    {cfg.items.length === 0 && (
                      <p className="text-xs text-slate-400 italic">No {cfg.label.toLowerCase()} available.</p>
                    )}
                    {cfg.items.map((item) => {
                      const isLinked = (scenario[`linked_${cfg.type}_ids`] || []).includes(item.id);
                      return (
                        <label
                          key={item.id}
                          className="flex items-center gap-2 text-xs cursor-pointer hover:bg-white rounded p-1"
                        >
                          <input
                            type="checkbox"
                            checked={isLinked}
                            onChange={() => toggleLink(cfg.type, item.id)}
                            className="rounded border-slate-300"
                          />
                          <span className="truncate">{item[cfg.nameField] || item.id}</span>
                        </label>
                      );
                    })}
                  </div>
                ) : (
                  <div className="space-y-1">
                    {cfg.linked.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">None linked.</p>
                    ) : (
                      cfg.linked.map((l) => (
                        <div key={l.id} className="text-xs text-slate-600 truncate">
                          • {l.name}
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Benefits & Risks */}
      {(scenario.benefits || scenario.risks || scenario.assumptions || scenario.dependencies) && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Benefits, Risks & Context</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              {scenario.benefits && (
                <div>
                  <p className="text-xs font-semibold text-emerald-600 mb-1">Benefits</p>
                  <p className="text-slate-600 whitespace-pre-wrap">{scenario.benefits}</p>
                </div>
              )}
              {scenario.risks && (
                <div>
                  <p className="text-xs font-semibold text-rose-600 mb-1">Risks & Downsides</p>
                  <p className="text-slate-600 whitespace-pre-wrap">{scenario.risks}</p>
                </div>
              )}
              {scenario.assumptions && (
                <div>
                  <p className="text-xs font-semibold text-slate-500 mb-1">Assumptions</p>
                  <p className="text-slate-600 whitespace-pre-wrap">{scenario.assumptions}</p>
                </div>
              )}
              {scenario.dependencies && (
                <div>
                  <p className="text-xs font-semibold text-slate-500 mb-1">Dependencies</p>
                  <p className="text-slate-600 whitespace-pre-wrap">{scenario.dependencies}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}