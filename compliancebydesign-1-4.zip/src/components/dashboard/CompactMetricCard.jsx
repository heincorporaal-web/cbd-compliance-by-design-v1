import React from "react";
import { Card } from "@/components/ui/card";
import { Link } from "react-router-dom";
import SvgIcon from "@/components/ui/SvgIcon";

/**
 * Compact stat tile used inside a CompactMetricCard.
 * Renders a small coloured icon badge, a bold value, a label, and optional sub-text.
 */
function StatTile({ icon: Icon, svg, label, value, sub, to, gradient, tint, iconColor }) {
  const badgeClass = gradient
    ? `bg-gradient-to-br ${gradient}`
    : tint
    ? `bg-gradient-to-br ${tint} border border-slate-100`
    : "bg-slate-100";
  const iconCls = gradient ? "text-white" : iconColor || "text-slate-500";

  const inner = (
    <div
      className={`flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-100 transition-colors ${
        to ? "hover:bg-slate-50 hover:border-slate-200 cursor-pointer" : ""
      }`}
    >
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${badgeClass}`}>
        {svg ? (
          <SvgIcon svg={svg} white={!!gradient} className="w-4 h-4" />
        ) : Icon ? (
          <Icon className={`w-4 h-4 ${iconCls}`} />
        ) : null}
      </div>
      <div className="min-w-0 flex-1">
        <span className="text-lg font-bold text-slate-900 leading-none block">{value}</span>
        <p className="text-xs text-slate-500 mt-1 truncate">{label}</p>
        {sub && <p className="text-[11px] text-slate-400 truncate mt-0.5">{sub}</p>}
      </div>
    </div>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}

/**
 * A compact dashboard card with a dark header bar (matching the CBD design language)
 * and a grid of small stat tiles inside.
 */
export default function CompactMetricCard({ title, icon: Icon, items, className }) {
  if (!items || items.length === 0) return null;
  return (
    <Card className={`border shadow-sm overflow-hidden ${className || ""}`}>
      <div className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground">
        {Icon && <Icon className="w-4 h-4 shrink-0" />}
        <h2 className="text-sm font-semibold tracking-wide truncate">{title}</h2>
      </div>
      <div className="p-2.5 grid grid-cols-2 gap-2">
        {items.map((it, i) => (
          <StatTile key={i} {...it} />
        ))}
      </div>
    </Card>
  );
}