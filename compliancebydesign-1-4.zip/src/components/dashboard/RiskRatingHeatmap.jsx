import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Grid3x3, Filter } from "lucide-react";
import { Link } from "react-router-dom";

const RISK_STATUSES = [
  "draft", "identified", "auto_assigned", "pending_review",
  "returned", "approved", "assessed", "mitigated", "accepted", "closed",
];

const STATUS_LABELS = {
  draft: "Draft", identified: "Identified", auto_assigned: "Auto-Assigned",
  pending_review: "Pending Review", returned: "Returned", approved: "Approved",
  assessed: "Assessed", mitigated: "Mitigated", accepted: "Accepted", closed: "Closed",
};

// Fixed rating bands based on inherent_risk_score (0-25 scale)
const RATING_BANDS = [
  { label: "Very Low", min: 0, max: 4, color_hex: "#22c55e" },
  { label: "Low", min: 5, max: 9, color_hex: "#84cc16" },
  { label: "Medium", min: 10, max: 14, color_hex: "#eab308" },
  { label: "High", min: 15, max: 19, color_hex: "#f97316" },
  { label: "Critical", min: 20, max: 25, color_hex: "#dc2626" },
];

const LIKELIHOOD_RANK = { very_low: 1, low: 2, medium: 3, high: 4, very_high: 5 };

function hexToRgb(hex) {
  const h = hex.replace("#", "");
  const n = parseInt(h, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function scoreOf(risk) {
  if (typeof risk.inherent_risk_score === "number" && risk.inherent_risk_score > 0) {
    return risk.inherent_risk_score;
  }
  return (LIKELIHOOD_RANK[risk.likelihood] || 3) * (LIKELIHOOD_RANK[risk.impact] || 3);
}

function bandOf(score) {
  for (const b of RATING_BANDS) {
    if (score >= b.min && score <= b.max) return b;
  }
  return score > 25 ? RATING_BANDS[4] : RATING_BANDS[0];
}

function Chip({ label, active, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-2.5 py-1 rounded-full text-xs font-medium border transition-all ${
        active
          ? "bg-primary text-white border-primary"
          : "bg-white text-slate-600 border-slate-200 hover:border-primary/50"
      }`}
    >
      {label}
    </button>
  );
}

export default function RiskRatingHeatmap({ risks, companyId }) {
  const { data: businessUnits = [] } = useQuery({
    queryKey: ["businessUnits", companyId],
    queryFn: () => base44.entities.BusinessUnit.list(),
  });
  const { data: valueChains = [] } = useQuery({
    queryKey: ["valueChains", companyId],
    queryFn: () => base44.entities.ValueChain.list(),
  });

  const filteredBUs = useMemo(
    () => (companyId === "all" ? businessUnits : businessUnits.filter((b) => b.company_id === companyId)),
    [businessUnits, companyId]
  );

  const [statuses, setStatuses] = useState(() => new Set(RISK_STATUSES));
  const [displayMode, setDisplayMode] = useState("value");

  // Bridge risks → business units via value chain name/code matching
  const { buByVcId, vcMatchers } = useMemo(() => {
    const map = {};
    filteredBUs.forEach((bu) => {
      if (bu.value_chain_id) (map[bu.value_chain_id] ||= []).push(bu);
    });
    const matchers = valueChains
      .filter((vc) => companyId === "all" || vc.company_id === companyId)
      .map((vc) => ({
        id: vc.id,
        name: (vc.name || "").toLowerCase(),
        code: (vc.value_chain_code || "").toLowerCase(),
      }));
    return { buByVcId: map, vcMatchers: matchers };
  }, [filteredBUs, valueChains, companyId]);

  const riskToBUIds = useMemo(() => {
    const cache = new Map();
    risks.forEach((r) => {
      if (cache.has(r.id)) return;
      const ids = new Set();
      const vc = (r.value_chain || "").toLowerCase();
      if (vc) {
        for (const m of vcMatchers) {
          if ((m.name && vc.includes(m.name)) || (m.code && vc.includes(m.code))) {
            (buByVcId[m.id] || []).forEach((b) => ids.add(b.id));
          }
        }
      }
      cache.set(r.id, ids);
    });
    return cache;
  }, [risks, vcMatchers, buByVcId]);

  const sliced = useMemo(
    () => risks.filter((r) => statuses.has(r.status)),
    [risks, statuses]
  );

  const { rows, columnTotals, maxCount } = useMemo(() => {
    const buMap = new Map();
    filteredBUs.forEach((bu) =>
      buMap.set(bu.id, { name: bu.name, type: bu.type, counts: RATING_BANDS.map(() => 0) })
    );
    const unassigned = RATING_BANDS.map(() => 0);

    sliced.forEach((r) => {
      const score = scoreOf(r);
      const band = bandOf(score);
      const bi = RATING_BANDS.indexOf(band);
      if (bi < 0) return;
      const buIds = riskToBUIds.get(r.id) || new Set();
      if (buIds.size === 0) {
        unassigned[bi] += 1;
      } else {
        buIds.forEach((id) => {
          const row = buMap.get(id);
          if (row) row.counts[bi] += 1;
        });
      }
    });

    const allRows = Array.from(buMap.values())
      .map((r) => ({ ...r, total: r.counts.reduce((s, c) => s + c, 0) }))
      .filter((r) => r.total > 0);
    allRows.sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));

    const unTotal = unassigned.reduce((s, c) => s + c, 0);
    if (unTotal > 0) allRows.push({ name: "Unassigned", type: "", counts: unassigned, total: unTotal });

    const columnTotals = RATING_BANDS.map((_, i) => allRows.reduce((s, r) => s + r.counts[i], 0));
    const maxCount = Math.max(1, ...allRows.flatMap((r) => r.counts));

    return { rows: allRows, columnTotals, maxCount };
  }, [sliced, filteredBUs, riskToBUIds]);

  const totalShown = sliced.length;

  if (risks.length === 0) return null;

  const toggle = (val) => {
    setStatuses((prev) => {
      const next = new Set(prev);
      if (next.has(val)) next.delete(val);
      else next.add(val);
      return next;
    });
  };

  return (
    <Card className="border shadow-sm overflow-hidden">
      <div className="flex items-center justify-between flex-wrap gap-2 px-4 py-2.5 bg-gradient-to-r from-slate-700 to-slate-800 text-white">
        <div className="flex items-center gap-2">
          <Grid3x3 className="w-4 h-4 shrink-0" />
          <h2 className="text-sm font-semibold tracking-wide">Risk Rating Heatmap — Business Unit × Inherent Rating</h2>
        </div>
        <Link to="/RiskRegister" className="text-xs font-medium text-white/80 hover:text-white hover:underline">
          View all
        </Link>
      </div>
      <CardContent className="p-4 space-y-4">
        {/* Status filter */}
        <div className="flex items-center gap-2 flex-wrap p-3 rounded-lg bg-slate-50 border border-slate-100">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
            <Filter className="w-3.5 h-3.5" /> Status
          </span>
          <Chip
            label="All"
            active={statuses.size === RISK_STATUSES.length}
            onClick={() =>
              setStatuses(statuses.size === RISK_STATUSES.length ? new Set() : new Set(RISK_STATUSES))
            }
          />
          {RISK_STATUSES.map((s) => (
            <Chip
              key={s}
              label={STATUS_LABELS[s]}
              active={statuses.has(s)}
              onClick={() => toggle(s)}
            />
          ))}
          <div className="flex items-center gap-3 ml-auto">
            <span className="text-xs font-semibold text-slate-600">Display</span>
            <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
              <input
                type="radio"
                name="displayMode-riskRatingHeatmap"
                value="value"
                checked={displayMode === "value"}
                onChange={() => setDisplayMode("value")}
                className="w-3.5 h-3.5 accent-primary"
              />
              Value
            </label>
            <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
              <input
                type="radio"
                name="displayMode-riskRatingHeatmap"
                value="percent"
                checked={displayMode === "percent"}
                onChange={() => setDisplayMode("percent")}
                className="w-3.5 h-3.5 accent-primary"
              />
              %
            </label>
            <span className="text-[11px] text-slate-400">{totalShown} risks shown</span>
          </div>
        </div>

        {/* Heatmap table */}
        {rows.length === 0 ? (
          <div className="py-8 text-center text-sm text-slate-500">
            No risks match the selected status filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-sm" style={{ minWidth: `${RATING_BANDS.length * 64 + 260}px` }}>
              <thead>
                <tr>
                  <th className="text-left font-semibold text-slate-600 px-3 py-2 sticky left-0 bg-white">
                    Business Unit
                  </th>
                  {RATING_BANDS.map((b, i) => (
                    <th key={i} className="text-center font-semibold px-2 py-2">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: b.color_hex }} />
                        {b.label}
                      </span>
                    </th>
                  ))}
                  <th className="text-center font-semibold text-slate-600 px-3 py-2">Total</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={`${row.name}-${i}`} className={i % 2 ? "bg-slate-50/50" : ""}>
                    <td className="px-3 py-2 sticky left-0 bg-inherit">
                      <div className="font-medium text-slate-800 truncate max-w-[200px]">{row.name}</div>
                      {row.type && <div className="text-[11px] text-slate-400">{row.type}</div>}
                    </td>
                    {row.counts.map((count, bi) => {
                      const { r, g, b } = hexToRgb(RATING_BANDS[bi].color_hex);
                      const intensity = count === 0 ? 0 : 0.2 + 0.8 * (count / maxCount);
                      const dark = count / maxCount > 0.5;
                      const pct = row.total > 0 ? ((count / row.total) * 100).toFixed(1) : "0.0";
                      return (
                        <td key={bi} className="px-2 py-2 text-center">
                          <div
                            className="flex items-center justify-center rounded-md font-semibold"
                            style={{
                              backgroundColor: `rgba(${r}, ${g}, ${b}, ${intensity.toFixed(2)})`,
                              color: count === 0 ? "#cbd5e1" : dark ? "#ffffff" : "#1e293b",
                              minHeight: "36px",
                              minWidth: "56px",
                            }}
                            title={`${count} risk${count === 1 ? "" : "s"} rated "${RATING_BANDS[bi].label}" in ${row.name}${displayMode === "percent" ? ` (${pct}% of BU)` : ""}`}
                          >
                            {displayMode === "percent" ? `${pct}%` : count}
                          </div>
                        </td>
                      );
                    })}
                    <td className="px-3 py-2 text-center">
                      <span className="inline-flex items-center justify-center min-w-[36px] px-2 py-1 rounded-md bg-slate-800 text-white font-bold text-xs">
                        {row.total}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-slate-200">
                  <td className="px-3 py-2 font-semibold text-slate-700 sticky left-0 bg-white">Total</td>
                  {columnTotals.map((c, i) => (
                    <td key={i} className="px-3 py-2 text-center font-bold text-slate-800">{c}</td>
                  ))}
                  <td className="px-3 py-2 text-center font-bold text-slate-900">{totalShown}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}

        <div className="flex items-center justify-between flex-wrap gap-2 text-[11px] text-slate-500">
          <div className="flex items-center gap-2">
            <span>Low</span>
            <div className="flex items-center gap-1">
              {[0.2, 0.45, 0.7, 1].map((op) => (
                <div key={op} className="w-5 h-3 rounded-sm" style={{ backgroundColor: `rgba(220, 38, 38, ${op})` }} />
              ))}
            </div>
            <span>High count</span>
          </div>
          <span>Rating bands from inherent risk score · risks mapped to business units via value chain</span>
        </div>
      </CardContent>
    </Card>
  );
}