import React from "react";
import { Link } from "react-router-dom";

/**
 * Compact split tile — label on the left (tinted background), value on the
 * right (white background, bold). Matches the operational dashboard template.
 *
 * Props:
 *  - label: small label (left, tinted)
 *  - value: bold value (right, white)
 *  - sub: optional tiny sub-text under the value
 *  - to: optional route — makes the tile clickable
 *  - attention: optional boolean — orange-tinted label side for items needing attention
 */
export function InfoTile({ label, value, sub, to, attention, disabled }) {
  const inner = (
    <div
      className={`flex items-stretch overflow-hidden border border-slate-200 shadow-sm transition-shadow ${
        to ? "cursor-pointer hover:shadow-md" : ""
      }`}
    >
      <div
        className={`flex-1 px-3 py-2 flex items-center min-w-0 ${
          attention ? "bg-orange-50" : "bg-slate-50"
        } ${disabled ? "!bg-slate-100" : ""}`}
      >
        <p
          className={`text-[11px] font-medium leading-snug ${
            disabled ? "text-slate-400" : attention ? "text-orange-700" : "text-slate-500"
          }`}
        >
          {label}
        </p>
      </div>
      <div className={`w-24 px-3 py-2 flex items-center justify-end shrink-0 ${disabled ? "bg-slate-50" : "bg-white"}`}>
        <div className="text-right">
          <span className={`text-base font-bold leading-none block ${disabled ? "text-slate-400" : "text-slate-800"}`}>
            {value}
          </span>
          {sub && <p className="text-[10px] text-slate-400 mt-0.5">{sub}</p>}
        </div>
      </div>
    </div>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}

/**
 * A titled column of compact split tiles — dark header bar with stacked tiles below.
 * Matches the operational executive dashboard template layout.
 */
export function InfoTileColumn({ title, items, icon: Icon, headerGradient, disabled }) {
  if (!items || items.length === 0) return null;
  return (
    <div className={`rounded-lg overflow-hidden border shadow-sm bg-white ${disabled ? "border-slate-300" : "border-slate-200"}`}>
      <div className={`px-3 py-2 flex items-center gap-1.5 ${disabled ? "bg-slate-300 text-slate-600" : headerGradient ? `text-white ${headerGradient}` : "bg-primary text-primary-foreground"}`}>
        {Icon && <Icon className="w-3.5 h-3.5 shrink-0" />}
        <h2 className="text-xs font-bold uppercase tracking-wide truncate flex-1">{title}</h2>
        {disabled && <span className="text-[9px] font-semibold uppercase tracking-wide bg-slate-200 text-slate-500 px-1.5 py-0.5 rounded shrink-0">Not Enabled</span>}
      </div>
      <div className="divide-y divide-slate-100">
        {items.map((it, i) => (
          <InfoTile
            key={i}
            label={it.label}
            value={it.value}
            sub={it.sub}
            to={disabled ? undefined : it.to}
            attention={it.attention}
            disabled={disabled}
          />
        ))}
      </div>
    </div>
  );
}

/**
 * A responsive grid of titled columns.
 */
export default function InfoTileGrid({ columns }) {
  if (!columns || columns.length === 0) return null;
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3">
      {columns.map((col, i) => (
        <InfoTileColumn key={i} title={col.title} items={col.items} icon={col.icon} />
      ))}
    </div>
  );
}