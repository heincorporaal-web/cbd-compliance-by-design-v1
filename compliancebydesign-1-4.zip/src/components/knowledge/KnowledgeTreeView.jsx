import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronRight, ChevronDown, FolderOpen, Folder, FileText, Eye, Edit2, Trash2, Download, Printer, Paperclip } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { KNOWLEDGE_CATEGORY_ICONS, KNOWLEDGE_CATEGORY_ICON_COLOR } from "@/lib/knowledgeCategories";

// Visual language follows the shared reference: a clean file-directory tree.
//   background: white · selected row: neutral-200 (#E5E5E5)
//   folder icon: neutral-700 (#404040) · text: neutral-800 (#262626) · 14px
//   ~20px indentation per level · leaf nodes carry no chevron.

const ROW_BASE = "flex items-center gap-2 w-full text-left rounded-md transition-colors select-none";
const ROW_PAD = "py-1.5 pr-2";
const CHEVRON = "w-4 h-4 text-neutral-400 flex-shrink-0";
const FOLDER_ICON = "w-4 h-4 text-neutral-700 flex-shrink-0";
const LEAF_ICON = "w-4 h-4 text-neutral-500 flex-shrink-0";
const LABEL = "text-sm text-neutral-800 truncate";
const COUNT = "text-xs text-neutral-400 ml-1";

function ArticleNode({ article, onView, onDelete, canEdit, selected, onSelect, depth }) {
  const attachmentCount = (article.pdf_url ? 1 : 0) + (article.attachments?.length || 0);
  return (
    <div
      onClick={() => { onSelect?.(article.id); onView?.(article); }}
      className={`${ROW_BASE} ${ROW_PAD} cursor-pointer ${selected ? "bg-neutral-200" : "hover:bg-neutral-100"}`}
      style={{ paddingLeft: depth * 20 + 28 }}
    >
      <span className="w-4 flex-shrink-0" />
      <FileText className="w-4 h-4 flex-shrink-0 text-neutral-500" />
      <span className={`${LABEL} flex-1 min-w-0 ${selected ? "font-medium" : ""}`}>{article.title}</span>
      {attachmentCount > 0 && (
        <span className="flex items-center gap-0.5 flex-shrink-0 text-xs text-neutral-400 mr-1" title={`${attachmentCount} attachment${attachmentCount > 1 ? "s" : ""} (PDF + additional documents)`}>
          <Paperclip className="w-3 h-3" />
          <span>{attachmentCount}</span>
        </span>
      )}
      <span className="flex gap-0.5 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
        {canEdit && (
          <Link to={createPageUrl(`KnowledgeArticleDetail?id=${article.id}`)} title="Edit article" onClick={(e) => e.stopPropagation()}>
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
              <Edit2 className="w-3.5 h-3.5 text-neutral-500" />
            </Button>
          </Link>
        )}
        {article.pdf_url && (
          <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={(e) => { e.stopPropagation(); window.open(article.pdf_url, '_blank'); }} title="Download PDF">
            <Download className="w-3.5 h-3.5 text-neutral-500" />
          </Button>
        )}
        {canEdit && onDelete && (
          <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={(e) => { e.stopPropagation(); onDelete(article.id); }} title="Delete article">
            <Trash2 className="w-3.5 h-3.5 text-red-400" />
          </Button>
        )}
      </span>
    </div>
  );
}

function ChapterNode({ chapter, articles, onView, onDelete, canEdit, selectedId, onSelect, depth, defaultOpen }) {
  const [expanded, setExpanded] = useState(defaultOpen ?? false);
  // Derive the chapter's category from its articles (most common category)
  const categoryCounts = {};
  articles.forEach(a => { categoryCounts[a.category] = (categoryCounts[a.category] || 0) + 1; });
  const dominantCategory = Object.entries(categoryCounts).sort((a, b) => b[1] - a[1])[0]?.[0];
  const ChapterIcon = KNOWLEDGE_CATEGORY_ICONS[dominantCategory] || FolderOpen;
  const chapterColor = KNOWLEDGE_CATEGORY_ICON_COLOR[dominantCategory] || "text-neutral-700";
  return (
    <div>
      <button
        onClick={() => setExpanded(!expanded)}
        className={`${ROW_BASE} ${ROW_PAD} hover:bg-neutral-100`}
        style={{ paddingLeft: depth * 20 + 8 }}
      >
        {expanded ? <ChevronDown className={CHEVRON} /> : <ChevronRight className={CHEVRON} />}
        <ChapterIcon className={`w-4 h-4 flex-shrink-0 ${chapterColor}`} />
        <span className={`${LABEL} font-medium`}>{chapter}</span>
        <span className={COUNT}>({articles.length})</span>
      </button>
      {expanded && (
        <div className="group/children">
          {articles.map(article => (
            <div key={article.id} className="group">
              <ArticleNode
                article={article}
                onView={onView}
                onDelete={onDelete}
                canEdit={canEdit}
                selected={selectedId === article.id}
                onSelect={onSelect}
                depth={depth + 1}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function FrameworkNode({ frameworkId, frameworkName, chapters, onView, onDelete, canEdit, onPrintFramework, selectedId, onSelect, defaultOpen }) {
  const [expanded, setExpanded] = useState(defaultOpen ?? false);
  const totalArticles = Object.values(chapters).reduce((acc, arr) => acc + arr.length, 0);
  const chapterCount = Object.keys(chapters).length;

  return (
    <div>
      <div className="flex items-center">
        <button
          onClick={() => setExpanded(!expanded)}
          className={`${ROW_BASE} ${ROW_PAD} flex-1 min-w-0 hover:bg-neutral-100`}
          style={{ paddingLeft: 8 }}
        >
          {expanded ? <ChevronDown className={CHEVRON} /> : <ChevronRight className={CHEVRON} />}
          {expanded ? <FolderOpen className={FOLDER_ICON} /> : <Folder className={FOLDER_ICON} />}
          <span className={`${LABEL} font-semibold flex-1 min-w-0`}>{frameworkName}</span>
          <span className={COUNT}>{chapterCount} chapters · {totalArticles} articles</span>
        </button>
        {onPrintFramework && (
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 mr-1"
            title="Print full framework implementation"
            onClick={() => onPrintFramework({ id: frameworkId, name: frameworkName })}
          >
            <Printer className="w-3.5 h-3.5 text-neutral-500" />
          </Button>
        )}
      </div>
      {expanded && (
        <div className="mt-0.5">
          {Object.entries(chapters).map(([chapter, articles]) => (
            <ChapterNode
              key={chapter}
              chapter={chapter}
              articles={articles}
              onView={onView}
              onDelete={onDelete}
              canEdit={canEdit}
              selectedId={selectedId}
              onSelect={onSelect}
              depth={1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function KnowledgeTreeView({ articles, frameworks, onView, onDelete, canEdit, onPrintFramework }) {
  const [selectedId, setSelectedId] = useState(null);
  const tree = {};

  articles.forEach(article => {
    const fw = frameworks.find(f => f.id === article.framework_id);
    const fwKey = fw ? fw.id : '__none__';
    const fwName = fw ? fw.name : 'No Framework';
    const chapter = article.chapter || 'General';
    if (!tree[fwKey]) tree[fwKey] = { name: fwName, chapters: {} };
    if (!tree[fwKey].chapters[chapter]) tree[fwKey].chapters[chapter] = [];
    tree[fwKey].chapters[chapter].push(article);
  });

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-3">
      {Object.entries(tree)
        .sort(([, a], [, b]) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }))
        .map(([fwId, { name, chapters }]) => (
          <FrameworkNode
            key={fwId}
            frameworkId={fwId}
            frameworkName={name}
            chapters={chapters}
            onView={onView}
            onDelete={onDelete}
            canEdit={canEdit}
            onPrintFramework={onPrintFramework}
            selectedId={selectedId}
            onSelect={setSelectedId}
          />
        ))}
    </div>
  );
}