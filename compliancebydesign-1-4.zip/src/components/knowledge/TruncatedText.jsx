import React, { useRef, useState } from "react";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";

/**
 * Renders text with truncation and shows a tooltip on hover ONLY when the
 * text is actually cut off (overflowing its box).
 *
 * Props:
 *  - text: the full text to display (and show in the tooltip when truncated)
 *  - className: layout/typography classes, must include a truncation class
 *      e.g. "truncate" (single line) or "line-clamp-2" (multi-line)
 *  - as: element tag to render (default "span")
 */
export default function TruncatedText({ text, className = "", as: Tag = "span", ...rest }) {
  const ref = useRef(null);
  const [isTruncated, setIsTruncated] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const checkTruncation = () => {
    const el = ref.current;
    if (!el) return;
    // Works for both single-line `truncate` (scrollWidth > clientWidth)
    // and multi-line `line-clamp-N` (scrollHeight > clientHeight)
    const truncated = el.scrollWidth > el.clientWidth + 1 || el.scrollHeight > el.clientHeight + 1;
    setIsTruncated(truncated);
  };

  const handleEnter = () => {
    checkTruncation();
    setIsHovered(true);
  };

  const handleLeave = () => {
    setIsHovered(false);
  };

  return (
    <TooltipProvider delayDuration={300}>
      <Tooltip open={isTruncated && isHovered}>
        <TooltipTrigger asChild>
          <Tag
            ref={ref}
            className={className}
            onMouseEnter={handleEnter}
            onMouseLeave={handleLeave}
            {...rest}
          >
            {text}
          </Tag>
        </TooltipTrigger>
        <TooltipContent className="max-w-xs break-words text-center">
          {text}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}