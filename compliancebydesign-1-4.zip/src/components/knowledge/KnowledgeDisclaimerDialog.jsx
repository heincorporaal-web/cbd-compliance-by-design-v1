import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ShieldCheck } from "lucide-react";
import { toast } from "sonner";

const DISCLAIMER_PARAGRAPHS = [
  "The information, guidance, implementation examples, framework mappings, checklists, templates, opinions and other materials provided within Compliance by Design (CBD) are made available for general informational, educational and reference purposes only.",
  "The content is intended to assist users in understanding and considering governance, risk, compliance, security, operational and financial-management practices. It does not constitute legal, regulatory, accounting, audit, tax, information-security, investment or other professional advice, nor should it be relied upon as a substitute for advice from appropriately qualified professionals.",
  "CBD does not represent or warrant that any content is complete, accurate, current, suitable for a particular organisation or sufficient to demonstrate compliance with any law, regulation, standard or contractual obligation. Regulatory requirements, professional standards and industry guidance may change, and their application depends on the specific circumstances, jurisdiction, risk profile and operating environment of each organisation.",
  "References to standards, regulations and frameworks are provided for convenience and interpretation. Users should consult the applicable authoritative source, including the official legislation, regulatory guidance or licensed version of a standard, before making compliance or implementation decisions.",
  "Framework mappings and cross-references within CBD represent practical interpretations of relationships between requirements and controls. A mapping does not imply equivalence, certification, regulatory acceptance or that implementation of one control automatically satisfies another requirement.",
  "Any examples, recommendations, maturity assessments, implementation guidance or opinions should be independently evaluated before use. Users remain responsible for determining the appropriateness of any information or recommendation and for obtaining relevant professional advice where required.",
  "Where content has been generated, assisted, summarised or analysed using artificial intelligence, it should be treated as supporting information and independently reviewed before being relied upon for material business, regulatory, legal, financial or risk decisions.",
  "To the fullest extent permitted by applicable law, the developers, contributors and operators of CBD accept no responsibility or liability for any loss, damage, cost, claim or consequence arising from reliance on, use of, or decisions made on the basis of information contained within the platform."
];

export default function KnowledgeDisclaimerDialog({ open, onAcknowledged, readOnly = false }) {
  const [submitting, setSubmitting] = useState(false);

  const handleAcknowledge = async () => {
    if (readOnly) {
      onAcknowledged?.();
      return;
    }
    setSubmitting(true);
    try {
      await base44.auth.updateMe({
        knowledge_disclaimer_acknowledged_date: new Date().toISOString(),
      });
      toast.success("Disclaimer acknowledged. Thank you.");
      onAcknowledged?.();
    } catch (err) {
      toast.error("Could not record your acknowledgement. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v && readOnly) onAcknowledged?.(); }}>
      <DialogContent
        className="max-w-3xl max-h-[90vh] overflow-y-auto"
        onInteractOutside={readOnly ? undefined : (e) => e.preventDefault()}
        onEscapeKeyDown={readOnly ? undefined : (e) => e.preventDefault()}
      >
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-amber-600" />
            </div>
            <DialogTitle className="text-xl">Disclaimer</DialogTitle>
          </div>
        </DialogHeader>

        <div className="space-y-4 text-sm text-slate-600 leading-relaxed">
          {DISCLAIMER_PARAGRAPHS.map((para, idx) => (
            <p key={idx}>{para}</p>
          ))}
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-3 pt-4 border-t">
          <p className="text-xs text-slate-400 flex-1">
            {readOnly
              ? ""
              : "You must acknowledge this disclaimer before accessing Knowledge Management content."}
          </p>
          <Button
            onClick={handleAcknowledge}
            disabled={submitting}
            className="bg-indigo-600 hover:bg-indigo-700 min-w-[180px]"
          >
            {readOnly ? "Close" : submitting ? "Recording..." : "I Acknowledge"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}