import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { SlidersHorizontal, Save, Loader2 } from "lucide-react";
import { toast } from "sonner";

// Reusable panel that renders the configured Additional Attributes for a record.
// Props: entityType (string), entityId (string), companyId (string, optional)
export default function AdditionalAttributesPanel({ entityType, entityId, companyId }) {
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState({}); // { attribute_id: rawValue }
  const [saving, setSaving] = useState(false);

  const { data: attributesPage } = useQuery({
    queryKey: ["additional-attributes", entityType],
    queryFn: () => base44.entities.AdditionalAttribute.filter({ entity_type: entityType, is_active: true }, { sort: "sort_order" }),
  });
  const attributes = attributesPage?.items || [];

  // Scope attributes to this company (global + this company's)
  const scopedAttrs = attributes.filter(
    (a) => !a.company_id || !companyId || a.company_id === companyId
  );

  const { data: valuesPage, refetch } = useQuery({
    queryKey: ["additional-attribute-values", entityType, entityId],
    queryFn: () => base44.entities.AdditionalAttributeValue.filter({ entity_type: entityType, entity_id: entityId }),
    enabled: !!entityId,
  });
  const values = valuesPage?.items || [];

  // Build initial draft from loaded values
  useEffect(() => {
    const next = {};
    for (const attr of scopedAttrs) {
      const v = values.find((x) => x.attribute_id === attr.id);
      if (!v) {
        next[attr.id] = "";
      } else if (attr.data_type === "boolean") {
        next[attr.id] = !!v.value_boolean;
      } else if (attr.data_type === "number") {
        next[attr.id] = v.value_number ?? "";
      } else if (attr.data_type === "date") {
        next[attr.id] = v.value_date || "";
      } else if (attr.data_type === "long_text") {
        next[attr.id] = v.value_longtext || "";
      } else {
        next[attr.id] = v.value_text || "";
      }
    }
    setDraft(next);
  }, [values, attributes]);

  if (!entityId) return null;
  if (scopedAttrs.length === 0) return null;

  const setVal = (id, val) => setDraft((prev) => ({ ...prev, [id]: val }));

  const handleSave = async () => {
    setSaving(true);
    try {
      // For each attribute, create or update the value record
      const ops = scopedAttrs.map(async (attr) => {
        const raw = draft[attr.id];
        const existing = values.find((x) => x.attribute_id === attr.id);
        const payload = {
          attribute_id: attr.id,
          attribute_name: attr.name,
          entity_type: entityType,
          entity_id: entityId,
          company_id: companyId || null,
          value_text: null,
          value_longtext: null,
          value_date: null,
          value_number: null,
          value_boolean: null,
        };
        if (attr.data_type === "text") payload.value_text = raw ?? "";
        else if (attr.data_type === "long_text") payload.value_longtext = raw ?? "";
        else if (attr.data_type === "date") payload.value_date = raw || null;
        else if (attr.data_type === "number") payload.value_number = raw === "" || raw == null ? null : Number(raw);
        else if (attr.data_type === "boolean") payload.value_boolean = !!raw;

        if (existing) {
          return base44.entities.AdditionalAttributeValue.update(existing.id, payload);
        } else {
          // Only create if there's an actual value
          const hasValue = payload.value_text || payload.value_longtext || payload.value_date ||
            payload.value_number != null || payload.value_boolean;
          if (!hasValue) return null;
          return base44.entities.AdditionalAttributeValue.create(payload);
        }
      });
      await Promise.all(ops);
      await refetch();
      queryClient.invalidateQueries(["additional-attribute-values", entityType, entityId]);
      toast.success("Additional attributes saved");
    } catch (e) {
      toast.error(e?.response?.data?.error || e?.message || "Could not save attributes");
    } finally {
      setSaving(false);
    }
  };

  const renderField = (attr) => {
    const val = draft[attr.id];
    const id = `attr-${attr.id}`;
    switch (attr.data_type) {
      case "long_text":
        return (
          <Textarea
            id={id}
            value={val || ""}
            onChange={(e) => setVal(attr.id, e.target.value)}
            rows={3}
          />
        );
      case "date":
        return (
          <Input
            id={id}
            type="date"
            value={val || ""}
            onChange={(e) => setVal(attr.id, e.target.value)}
          />
        );
      case "number":
        return (
          <Input
            id={id}
            type="number"
            value={val ?? ""}
            onChange={(e) => setVal(attr.id, e.target.value === "" ? "" : Number(e.target.value))}
          />
        );
      case "boolean":
        return (
          <label className="flex items-center gap-2 h-9">
            <Checkbox checked={!!val} onCheckedChange={(v) => setVal(attr.id, !!v)} />
            <span className="text-sm text-slate-600">{val ? "Yes" : "No"}</span>
          </label>
        );
      default:
        return (
          <Input
            id={id}
            value={val || ""}
            onChange={(e) => setVal(attr.id, e.target.value)}
          />
        );
    }
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="flex items-center justify-between gap-2 text-base">
          <span className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-primary" />
            Additional Attributes
          </span>
          <Button size="sm" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Save className="w-4 h-4 mr-1.5" />}
            Save Attributes
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 space-y-4">
        {scopedAttrs.map((attr) => (
          <div key={attr.id} className="space-y-1.5">
            <div className="flex items-center gap-2">
              <Label htmlFor={`attr-${attr.id}`} className="text-sm font-medium">
                {attr.label}
                {attr.is_required && <span className="text-red-500 ml-0.5">*</span>}
              </Label>
              <Badge variant="outline" className="text-[10px] text-slate-400">{attr.data_type}</Badge>
            </div>
            {attr.description && (
              <p className="text-xs text-slate-500">{attr.description}</p>
            )}
            {renderField(attr)}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}