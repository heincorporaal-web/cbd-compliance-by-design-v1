import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, ChevronDown, ChevronUp, Lock, RefreshCw } from "lucide-react";
import EvidencePicker from "@/components/maturity/EvidencePicker";
import {
  DEFAULT_SCORING_CONFIG,
  EVIDENCE_STATUSES,
  calculateScaledScore,
  calculateWeightedScore,
  calculateDimensionScore,
  calculateOverallScore,
  calculateQuestionCompletion,
  calculateEvidenceCompletion,
  getMaturityBand,
} from "@/lib/maturityScoring";

function ResponseCard({ response, onChange, scoringConfig, readOnly }) {
  const scaled = calculateScaledScore(response.raw_score, scoringConfig);
  const weighted = calculateWeightedScore(scaled, response.weight);
  const levelColor = (scoringConfig.responseLevels || []).find((l) => l.value === response.response_level)?.color || "#9ca3af";
  const scale = scoringConfig.scoreScale;
  const reassessFlag = response.validation_status === "reassess";

  return (
    <div className={`border rounded-lg p-3 space-y-2 bg-white ${reassessFlag ? "border-amber-300 bg-amber-50" : "border-slate-200"} ${readOnly && !reassessFlag ? "opacity-60" : ""}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="outline" className="text-xs font-mono bg-slate-50">{response.question_id}</Badge>
            <Badge variant="outline" className="text-xs">{response.weight}%</Badge>
            {reassessFlag && <Badge variant="outline" className="text-xs text-amber-600 border-amber-300 bg-amber-100">Reassess</Badge>}
          </div>
          <p className="text-xs font-medium text-slate-700">{response.mandatory_artefact}</p>
          <p className="text-xs text-slate-500">{response.assessment_question}</p>
          {reassessFlag && response.validation_justification && (
            <p className="text-xs text-amber-600 italic mt-1">↻ {response.validation_justification}</p>
          )}
        </div>
        <div className="text-right shrink-0">
          <p className="text-sm font-bold" style={{ color: levelColor }}>{scaled.toFixed(2)}/{scale}</p>
          <p className="text-xs text-slate-400">w: {weighted.toFixed(2)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        <div className="space-y-1">
          <Label className="text-xs">Response</Label>
          <Select
            value={String(response.response_level)}
            onValueChange={(v) => onChange({ ...response, response_level: Number(v), raw_score: Number(v) })}
            disabled={readOnly && !reassessFlag}
          >
            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              {(scoringConfig.responseLevels || []).map((l) => (
                <SelectItem key={l.value} value={String(l.value)} className="text-xs">
                  <span style={{ color: l.color }}>{l.label}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Evidence Status</Label>
          <Select
            value={response.evidence_status}
            onValueChange={(v) => onChange({ ...response, evidence_status: v })}
            disabled={readOnly && !reassessFlag}
          >
            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              {EVIDENCE_STATUSES.map((s) => (
                <SelectItem key={s.value} value={s.value} className="text-xs">{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <EvidencePicker response={response} onChange={onChange} disabled={readOnly && !reassessFlag} />
    </div>
  );
}

export default function MaturityAssessmentForm({ assessment, templateDimensions, onSave, saving, scoringConfig = DEFAULT_SCORING_CONFIG, validationStage }) {
  const [responses, setResponses] = useState(assessment.responses || []);
  const [meta, setMeta] = useState({
    assessment_name: assessment.assessment_name || "",
    assessment_date: assessment.assessment_date || "",
    target_score: assessment.target_score || 0,
    assessor: assessment.assessor || "",
    status: assessment.status || "draft",
    notes: assessment.notes || "",
  });
  const [expandedDims, setExpandedDims] = useState({});
  const scale = scoringConfig.scoreScale;

  const stage = validationStage || assessment.validation_stage || "not_started";
  const isLocked = stage !== "not_started" && stage !== "reassess_pending";
  const reassessCount = responses.filter((r) => r.validation_status === "reassess").length;

  const updateResponse = (idx, updated) => {
    const next = [...responses];
    next[idx] = updated;
    setResponses(next);
  };

  const overallScore = useMemo(() => calculateOverallScore(responses, scoringConfig), [responses, scoringConfig]);
  const qCompletion = useMemo(() => calculateQuestionCompletion(responses), [responses]);
  const eCompletion = useMemo(() => calculateEvidenceCompletion(responses), [responses]);
  const band = getMaturityBand(overallScore, scoringConfig);

  const toggleDim = (name) => setExpandedDims((p) => ({ ...p, [name]: !p[name] }));

  const handleSave = () => {
    const dimensionScores = (templateDimensions || []).map((dim) => ({
      dimension: dim.name,
      weight: dim.weight,
      score_5: calculateDimensionScore(responses, dim.name, scoringConfig),
      target_score_5: 0,
    }));
    onSave({
      ...assessment,
      ...meta,
      responses,
      dimension_scores: dimensionScores,
      overall_score: overallScore,
      maturity_band: band.label.toLowerCase(),
      question_completion: qCompletion,
      evidence_completion: eCompletion,
    });
  };

  const responsesByDimension = (templateDimensions || []).map((dim) => ({
    dim,
    items: responses
      .map((r, i) => ({ r, i }))
      .filter(({ r }) => r.dimension === dim.name),
  }));

  return (
    <div className="space-y-4">
      {isLocked && (
        <div className="flex items-center gap-2 text-xs text-slate-600 bg-slate-100 border border-slate-200 rounded-lg px-3 py-2">
          <Lock className="w-4 h-4 text-slate-400" />
          Responses are locked — this assessment is in the <strong className="capitalize">{stage.replace(/_/g, " ")}</strong> validation stage.
          {stage === "reassess_pending" && reassessCount > 0 && (
            <span className="text-amber-600 ml-1">{reassessCount} item(s) flagged for reassessment — fix the highlighted responses below.</span>
          )}
        </div>
      )}
      {stage === "reassess_pending" && reassessCount > 0 && !isLocked && (
        <div className="flex items-center gap-2 text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
          <RefreshCw className="w-4 h-4" />
          {reassessCount} item(s) flagged for reassessment. Fix the highlighted responses below, then resubmit from the Validation tab.
        </div>
      )}
      <Card className="border-slate-200">
        <CardContent className="p-4 grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="space-y-1">
            <Label className="text-xs">Assessment Name</Label>
            <Input value={meta.assessment_name} onChange={(e) => setMeta({ ...meta, assessment_name: e.target.value })} className="h-8 text-sm" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Assessment Date</Label>
            <Input type="date" value={meta.assessment_date} onChange={(e) => setMeta({ ...meta, assessment_date: e.target.value })} className="h-8 text-sm" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Target Score /{scale}</Label>
            <Input type="number" step="0.01" value={meta.target_score} onChange={(e) => setMeta({ ...meta, target_score: Number(e.target.value) })} className="h-8 text-sm" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Status</Label>
            <Select value={meta.status} onValueChange={(v) => setMeta({ ...meta, status: v })}>
              <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="provisional">Provisional</SelectItem>
                <SelectItem value="final">Final</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-3">
          <Badge className="text-sm capitalize" style={{ backgroundColor: band.color + "20", color: band.color, border: 0 }}>
            Score: {overallScore.toFixed(2)} / {scale} — {band.label}
          </Badge>
          <span className="text-xs text-slate-500">Questions: {Math.round(qCompletion)}% • Evidence: {Math.round(eCompletion)}%</span>
        </div>
        <Button size="sm" onClick={handleSave} disabled={saving}>
          <Save className="w-4 h-4 mr-1" /> {saving ? "Saving..." : "Save Assessment"}
        </Button>
      </div>

      {responsesByDimension.map(({ dim, items }) => {
        const dimScore = calculateDimensionScore(responses, dim.name, scoringConfig);
        const isOpen = expandedDims[dim.name] !== false;
        return (
          <Card key={dim.name} className="border-slate-200">
            <CardHeader className="pb-2 cursor-pointer" onClick={() => toggleDim(dim.name)}>
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2">
                  {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  {dim.name}
                  <Badge variant="outline" className="text-xs">{dim.weight}%</Badge>
                  <span className="text-xs text-slate-400">— {dim.description}</span>
                </CardTitle>
                <Badge variant="outline" className="text-xs">Score: {dimScore.toFixed(2)}/{scale}</Badge>
              </div>
            </CardHeader>
            {isOpen && (
              <CardContent className="space-y-2">
                {items.length === 0 && <p className="text-xs text-slate-400">No questions in this dimension.</p>}
                {items.map(({ r, i }) => (
                  <ResponseCard key={i} response={r} onChange={(updated) => updateResponse(i, updated)} scoringConfig={scoringConfig} readOnly={isLocked} />
                ))}
              </CardContent>
            )}
          </Card>
        );
      })}
    </div>
  );
}