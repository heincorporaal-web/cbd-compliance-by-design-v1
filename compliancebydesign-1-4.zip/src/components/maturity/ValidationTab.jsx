import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ChevronDown, ChevronUp, Send, CheckCircle2, RefreshCw, SlidersHorizontal, Shield, Mail, ArrowRight } from "lucide-react";
import ResponseValidationCard from "@/components/maturity/ResponseValidationCard";
import ValidationStageBanner, { getStageIndex } from "@/components/maturity/ValidationStageBanner";
import { calculateScaledScore, calculateDimensionScore, getMaturityBand } from "@/lib/maturityScoring";

export default function ValidationTab({ assessment, template, stakeholders, scoringConfig, onSave, saving, currentUser }) {
  const [responses, setResponses] = useState(assessment.responses || []);
  const [expandedDims, setExpandedDims] = useState({});
  const [calibrationDecision, setCalibrationDecision] = useState("");
  const [calibrationNotes, setCalibrationNotes] = useState("");

  const stage = assessment.validation_stage || "not_started";
  const scale = scoringConfig.scoreScale;

  const assessorIds = assessment.assessor_stakeholder_ids || [];
  const isAssessor = assessorIds.length > 0; // simplified — any logged-in user with assessors assigned can validate
  const isOpeLead = true; // simplified — OPEX lead approval available when calibrations exist
  const isOwner = true; // simplified — owner can fix reassess items and enter aspirations

  const validationSummary = useMemo(() => {
    const total = responses.length;
    const concur = responses.filter((r) => r.validation_status === "concur").length;
    const reassess = responses.filter((r) => r.validation_status === "reassess").length;
    const calibrate = responses.filter((r) => r.validation_status === "calibrate").length;
    const pending = responses.filter((r) => r.validation_status === "pending" || !r.validation_status).length;
    return { total, concur, reassess, calibrate, pending };
  }, [responses]);

  const updateResponse = (idx, updated) => {
    const next = [...responses];
    next[idx] = updated;
    setResponses(next);
  };

  const toggleDim = (name) => setExpandedDims((p) => ({ ...p, [name]: !p[name] }));

  const handleStartValidation = () => {
    onSave({
      ...assessment,
      responses,
      validation_stage: "in_validation",
      status: "provisional",
    });
  };

  const handleSubmitValidation = () => {
    const hasCalibrate = responses.some((r) => r.validation_status === "calibrate");
    const hasReassess = responses.some((r) => r.validation_status === "reassess");
    let nextStage = "validated";
    if (hasCalibrate) nextStage = "calibration_pending";
    else if (hasReassess) nextStage = "reassess_pending";

    onSave({
      ...assessment,
      responses,
      validation_stage: nextStage,
    });
  };

  const handleResubmitAfterFix = () => {
    // Clear reassess flags on fixed responses
    const cleared = responses.map((r) =>
      r.validation_status === "reassess"
        ? { ...r, validation_status: "concur", validation_justification: "", validated_by: r.validated_by, validated_date: new Date().toISOString().split("T")[0] }
        : r
    );
    onSave({
      ...assessment,
      responses: cleared,
      validation_stage: "in_validation",
    });
  };

  const handleApproveCalibration = (approved) => {
    const today = new Date().toISOString().split("T")[0];
    onSave({
      ...assessment,
      responses,
      validation_stage: approved ? "validated" : "in_validation",
      calibration_approved: approved,
      calibration_approved_date: approved ? today : null,
      calibration_approved_by: approved ? (currentUser?.full_name || "OPEX Lead") : null,
    });
    setCalibrationDecision("");
    setCalibrationNotes("");
  };

  const handleProceedToAspirations = () => {
    const today = new Date().toISOString().split("T")[0];
    // Calculate final scores with calibrations applied
    const finalResponses = responses.map((r) => {
      if (r.validation_status === "calibrate" && r.calibrated_score_5 != null) {
        return { ...r, score_5: r.calibrated_score_5, raw_score: (r.calibrated_score_5 / scale) * (scoringConfig.maxRaw || 4) };
      }
      return r;
    });

    const dimensionScores = (template?.dimensions || []).map((dim) => {
      const score = calculateDimensionScore(finalResponses, dim.name, scoringConfig);
      return {
        dimension: dim.name,
        weight: dim.weight,
        score_5: score,
        final_score_5: score,
        target_score_5: 0,
      };
    });

    const finalScore = finalResponses
      .filter((r) => r.response_level > 0)
      .reduce((sum, r) => sum + (calculateScaledScore(r.raw_score, scoringConfig) * r.weight) / 100, 0);

    onSave({
      ...assessment,
      responses: finalResponses,
      dimension_scores: dimensionScores,
      final_score: finalScore,
      validation_stage: "aspirations_pending",
      validation_completed_date: today,
    });
  };

  const responsesByDimension = (template?.dimensions || []).map((dim) => ({
    dim,
    items: responses.map((r, i) => ({ r, i })).filter(({ r }) => r.dimension === dim.name),
  }));

  // Calibration approval section
  const calibrations = responses.filter((r) => r.validation_status === "calibrate");
  const reassessItems = responses.filter((r) => r.validation_status === "reassess");

  // Final scores view (when validated)
  const showFinalScores = stage === "validated" || stage === "aspirations_pending" || stage === "completed";

  return (
    <div className="space-y-4">
      <ValidationStageBanner stage={stage} validationSummary={validationSummary} />

      {/* Stage: not_started — submit for validation */}
      {stage === "not_started" && (
        <Card className="border-slate-200">
          <CardContent className="p-6 text-center space-y-3">
            <Send className="w-8 h-8 text-slate-400 mx-auto" />
            <p className="text-sm text-slate-600">
              Once all responses and evidence have been submitted, send this assessment for validation.
              Assessors will review each answer and mark it as Concur, Reassess, or Calibrate.
            </p>
            <Button onClick={handleStartValidation} disabled={saving || validationSummary.pending === validationSummary.total}>
              <Send className="w-4 h-4 mr-1" /> Submit for Validation
            </Button>
            {validationSummary.pending === validationSummary.total && validationSummary.total > 0 && (
              <p className="text-xs text-amber-600">All responses are still pending — ensure the owner has completed answers first.</p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Stage: in_validation — assessor review */}
      {(stage === "in_validation" || stage === "reassess_pending") && (
        <>
          {stage === "reassess_pending" && (
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 text-amber-500" />
                  <p className="text-sm font-medium text-amber-700">{reassessItems.length} item(s) sent back for reassessment</p>
                </div>
                <div className="space-y-1">
                  {reassessItems.map((r) => (
                    <div key={r.question_id} className="text-xs text-amber-600 bg-white rounded p-2 border border-amber-100">
                      <span className="font-mono font-semibold">{r.question_id}</span> — {r.mandatory_artefact}
                      {r.validation_justification && <p className="italic mt-1">"{r.validation_justification}"</p>}
                    </div>
                  ))}
                </div>
                <p className="text-xs text-amber-600">Fix the responses in the Edit Responses tab, then resubmit for validation.</p>
                <Button size="sm" variant="outline" onClick={handleResubmitAfterFix} disabled={saving}>
                  <CheckCircle2 className="w-4 h-4 mr-1" /> Resubmit for Validation
                </Button>
              </CardContent>
            </Card>
          )}

          <div className="flex items-center justify-between px-1">
            <p className="text-sm text-slate-600">Review each response and mark as Concur, Reassess, or Calibrate</p>
            <Button size="sm" onClick={handleSubmitValidation} disabled={saving || validationSummary.pending === validationSummary.total}>
              <CheckCircle2 className="w-4 h-4 mr-1" /> Submit Validation
            </Button>
          </div>

          {responsesByDimension.map(({ dim, items }) => {
            const isOpen = expandedDims[dim.name] !== false;
            return (
              <Card key={dim.name} className="border-slate-200">
                <CardHeader className="pb-2 cursor-pointer" onClick={() => toggleDim(dim.name)}>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm flex items-center gap-2">
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      {dim.name}
                      <Badge variant="outline" className="text-xs">{dim.weight}%</Badge>
                    </CardTitle>
                    <Badge variant="outline" className="text-xs">{items.length} questions</Badge>
                  </div>
                </CardHeader>
                {isOpen && (
                  <CardContent className="space-y-2">
                    {items.map(({ r, i }) => (
                      <ResponseValidationCard
                        key={i}
                        response={r}
                        onChange={(updated) => updateResponse(i, updated)}
                        scoringConfig={scoringConfig}
                        readOnly={false}
                        assessorName={currentUser?.full_name}
                      />
                    ))}
                  </CardContent>
                )}
              </Card>
            );
          })}
        </>
      )}

      {/* Stage: calibration_pending — OPEX lead approval */}
      {stage === "calibration_pending" && (
        <>
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-500" /> Calibration Approval Required
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-xs text-blue-600">
                The following {calibrations.length} calibration(s) require OPEX lead approval before final scores can be presented.
                The original respondent will be notified after approval.
              </p>
              <div className="space-y-2">
                {calibrations.map((r) => (
                  <div key={r.question_id} className="bg-white rounded p-2 border border-blue-100 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-semibold text-slate-600">{r.question_id}</span>
                      <span className="text-slate-500">
                        {calculateScaledScore(r.raw_score, scoringConfig).toFixed(2)} → <span className="font-bold text-blue-600">{(r.calibrated_score_5 ?? 0).toFixed(2)}</span>
                      </span>
                    </div>
                    <p className="text-slate-600">{r.mandatory_artefact}</p>
                    {r.calibration_justification && <p className="text-blue-500 italic">"{r.calibration_justification}"</p>}
                  </div>
                ))}
              </div>
              <div className="space-y-1 pt-2 border-t border-blue-100">
                <Label className="text-xs text-blue-700">Approval notes (optional)</Label>
                <Textarea
                  value={calibrationNotes}
                  onChange={(e) => setCalibrationNotes(e.target.value)}
                  placeholder="Add any notes about this calibration approval..."
                  className="text-xs h-16 bg-white"
                />
              </div>
              <div className="flex items-center gap-2">
                <Button size="sm" onClick={() => handleApproveCalibration(true)} disabled={saving}>
                  <CheckCircle2 className="w-4 h-4 mr-1" /> Approve Calibrations
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleApproveCalibration(false)} disabled={saving}>
                  Reject & Return
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Also show the validation cards in read-only mode */}
          {responsesByDimension.map(({ dim, items }) => (
            <Card key={dim.name} className="border-slate-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">{dim.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {items.map(({ r, i }) => (
                  <ResponseValidationCard key={i} response={r} scoringConfig={scoringConfig} readOnly={true} />
                ))}
              </CardContent>
            </Card>
          ))}
        </>
      )}

      {/* Stage: validated — final scores */}
      {stage === "validated" && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" /> Validation Complete — Final Scores
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {(assessment.dimension_scores || []).map((ds) => {
                const finalScore = ds.final_score_5 ?? ds.score_5 ?? 0;
                const band = getMaturityBand(finalScore, scoringConfig);
                return (
                  <div key={ds.dimension} className="bg-white rounded p-3 border border-slate-200">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-slate-700">{ds.dimension}</span>
                      <Badge variant="outline" className="text-xs" style={{ color: band.color, border: 0, backgroundColor: band.color + "15" }}>
                        {band.label}
                      </Badge>
                    </div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-xl font-bold" style={{ color: band.color }}>{finalScore.toFixed(2)}</span>
                      <span className="text-xs text-slate-400">/ {scale}</span>
                      <span className="text-xs text-slate-400 ml-auto">weight {ds.weight}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-green-100">
              <div>
                <p className="text-xs text-slate-500">Overall Final Score</p>
                <p className="text-2xl font-bold" style={{ color: getMaturityBand(assessment.final_score || assessment.overall_score || 0, scoringConfig).color }}>
                  {(assessment.final_score || assessment.overall_score || 0).toFixed(2)} / {scale}
                </p>
              </div>
              <Button onClick={handleProceedToAspirations} disabled={saving}>
                Proceed to Aspirations <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}