import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DEFAULT_SCORING_CONFIG, getMaturityBand } from "@/lib/maturityScoring";

const STATUS_STYLES = {
  draft: { bg: "bg-slate-100", text: "text-slate-600", label: "Draft" },
  in_progress: { bg: "bg-blue-100", text: "text-blue-700", label: "In Progress" },
  provisional: { bg: "bg-amber-100", text: "text-amber-700", label: "Provisional" },
  final: { bg: "bg-green-100", text: "text-green-700", label: "Final" },
};

export default function MaturityScoreSummary({
  overallScore = 0,
  targetScore = 0,
  maturityBand,
  questionCompletion = 0,
  evidenceCompletion = 0,
  status = "draft",
  scoringConfig = DEFAULT_SCORING_CONFIG,
}) {
  const band = getMaturityBand(overallScore, scoringConfig);
  const statusStyle = STATUS_STYLES[status] || STATUS_STYLES.draft;
  const scale = scoringConfig.scoreScale;

  return (
    <Card className="border-slate-200">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wide">Overall Baseline Score</p>
            <p className="text-4xl font-bold text-slate-800">{overallScore.toFixed(2)}</p>
            <p className="text-xs text-slate-400">out of {scale.toFixed(0).replace(".0", "")}.00</p>
          </div>
          <div className="text-right space-y-1">
            <Badge className={`${statusStyle.bg} ${statusStyle.text} border-0`}>
              {statusStyle.label}
            </Badge>
            {targetScore > 0 && (
              <p className="text-xs text-slate-500">
                Target: <span className="font-semibold text-slate-700">{targetScore.toFixed(2)}</span>
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
          <span className="text-xs text-slate-500">Maturity band:</span>
          <Badge style={{ backgroundColor: band.color + "20", color: band.color }} className="border-0 capitalize">
            {band.label}
          </Badge>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-1">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-500">Question completion</span>
              <span className="font-semibold text-slate-700">{Math.round(questionCompletion)}%</span>
            </div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500 rounded-full" style={{ width: `${questionCompletion}%` }} />
            </div>
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-500">Evidence completion</span>
              <span className="font-semibold text-slate-700">{Math.round(evidenceCompletion)}%</span>
            </div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-amber-500 rounded-full" style={{ width: `${evidenceCompletion}%` }} />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}