import React, { useState, useCallback, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { BarChart3, Plus, Link2, Unlink, ExternalLink, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { calculateProcessMaturityRollup } from "@/lib/maturityScoring";
import ProcessMaturityRollup from "@/components/maturity/ProcessMaturityRollup";


const STATUS_STYLES = {
  draft: "bg-slate-100 text-slate-700",
  in_progress: "bg-blue-100 text-blue-700",
  provisional: "bg-amber-100 text-amber-700",
  final: "bg-green-100 text-green-700",
};

export default function ProcessMaturityLinkTab({ processAssessmentId, companyId, processName }) {
  const [linked, setLinked] = useState([]);
  const [capabilities, setCapabilities] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showLink, setShowLink] = useState(false);
  const [unlinked, setUnlinked] = useState([]);
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState(false);
  const [newMeta, setNewMeta] = useState({ name: "", date: new Date().toISOString().split("T")[0], capability_id: "", target_score: 60 });

  const loadLinked = useCallback(async () => {
    if (!processAssessmentId) return;
    const res = await base44.entities.CapabilityMaturityAssessment.filter(
      { process_assessment_id: processAssessmentId },
      { sort: "-assessment_date", limit: 50 }
    );
    setLinked(res.items || []);
  }, [processAssessmentId]);

  const loadCapabilities = useCallback(async () => {
    if (!companyId) return;
    const res = await base44.entities.ITCapability.filter({ company_id: companyId }, { sort: "name", limit: 500 });
    setCapabilities(res.items || []);
  }, [companyId]);

  const loadTemplates = useCallback(async () => {
    if (!companyId) return;
    const res = await base44.entities.MaturityAssessmentTemplate.filter({ company_id: companyId }, { limit: 10 });
    setTemplates(res.items || []);
  }, [companyId]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await Promise.all([loadLinked(), loadCapabilities(), loadTemplates()]);
      setLoading(false);
    })();
  }, [loadLinked, loadCapabilities, loadTemplates]);

  const activeTemplate = templates[0] || null;

  // Auto-calculate and persist the process assessment's maturity_score from linked assessments
  const lastSyncedScore = useRef(null);
  const rollup = calculateProcessMaturityRollup(linked);

  useEffect(() => {
    if (!processAssessmentId || loading || linked.length === 0) return;
    const newScore = Number(rollup.overallScore5.toFixed(2));
    // Only update when the score actually changes (avoids loops and redundant writes)
    if (lastSyncedScore.current !== newScore) {
      lastSyncedScore.current = newScore;
      base44.entities.ProcessAssessment.update(processAssessmentId, {
        maturity_score: newScore,
      }).catch((e) => console.error("Failed to sync maturity score:", e));
    }
  }, [processAssessmentId, loading, linked, rollup.overallScore5]);

  const handleCreate = async () => {
    if (!newMeta.capability_id || !newMeta.name || !activeTemplate) return;
    setSaving(true);
    try {
      const responses = [];
      for (const dim of activeTemplate.dimensions || []) {
        for (const q of dim.questions || []) {
          responses.push({
            question_id: q.question_id,
            dimension: dim.name,
            mandatory_artefact: q.mandatory_artefact,
            assessment_question: q.assessment_question,
            weight: q.weight,
            response_level: 0,
            raw_score: 0,
            score_5: 0,
            weighted_score: 0,
            evidence_reference: "",
            evidence_status: "pending",
            comments: "",
          });
        }
      }
      await base44.entities.CapabilityMaturityAssessment.create({
        capability_id: newMeta.capability_id,
        company_id: companyId,
        template_id: activeTemplate.id,
        assessment_model_id: activeTemplate.assessment_model_id || null,
        process_assessment_id: processAssessmentId,
        assessment_name: newMeta.name,
        assessment_date: newMeta.date,
        status: "draft",
        target_score: newMeta.target_score,
        responses,
        dimension_scores: [],
        overall_score: 0,
        question_completion: 0,
        evidence_completion: 0,
      });
      await loadLinked();
      setShowCreate(false);
      setNewMeta({ name: "", date: new Date().toISOString().split("T")[0], capability_id: "", target_score: 60 });
    } catch (e) {
      console.error(e);
    }
    setSaving(false);
  };

  const loadUnlinked = useCallback(async () => {
    if (!companyId) return;
    const res = await base44.entities.CapabilityMaturityAssessment.filter(
      { company_id: companyId, process_assessment_id: { $exists: false } },
      { sort: "-assessment_date", limit: 200 }
    );
    setUnlinked(res.items || []);
  }, [companyId]);

  const openLinkDialog = async () => {
    await loadUnlinked();
    setShowLink(true);
  };

  const handleLink = async (assessmentId) => {
    setSaving(true);
    try {
      await base44.entities.CapabilityMaturityAssessment.update(assessmentId, { process_assessment_id: processAssessmentId });
      await loadLinked();
      setUnlinked((prev) => prev.filter((a) => a.id !== assessmentId));
    } catch (e) {
      console.error(e);
    }
    setSaving(false);
  };

  const handleUnlink = async (assessmentId) => {
    if (!confirm("Unlink this maturity assessment from this process assessment?")) return;
    setSaving(true);
    try {
      await base44.entities.CapabilityMaturityAssessment.update(assessmentId, { process_assessment_id: null });
      await loadLinked();
    } catch (e) {
      console.error(e);
    }
    setSaving(false);
  };

  const filteredUnlinked = unlinked.filter((a) => {
    if (!search) return true;
    const cap = capabilities.find((c) => c.id === a.capability_id);
    const text = `${a.assessment_name || ""} ${cap?.name || ""}`.toLowerCase();
    return text.includes(search.toLowerCase());
  });

  return (
    <div className="space-y-4">
      {rollup.assessmentCount > 0 && <ProcessMaturityRollup rollup={rollup} />}

      <Card className="border-none shadow-lg">
        <CardHeader className="border-b border-slate-100">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Linked Maturity Assessments
            </CardTitle>
            <div className="flex gap-2">
              <Button type="button" variant="outline" size="sm" onClick={openLinkDialog} disabled={!companyId || saving}>
                <Link2 className="w-4 h-4 mr-1" /> Link Existing
              </Button>
              <Button type="button" size="sm" onClick={() => setShowCreate(true)} disabled={!companyId || !activeTemplate || saving}>
                <Plus className="w-4 h-4 mr-1" /> New Maturity Assessment
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {!companyId ? (
            <div className="text-center py-8 text-slate-500 text-sm">
              Select a company to link maturity assessments.
            </div>
          ) : !activeTemplate ? (
            <div className="text-center py-8">
              <BarChart3 className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-500 text-sm mb-2">No maturity template found for this company.</p>
              <Link to={createPageUrl("CapabilityMaturity")}>
                <Button type="button" variant="outline" size="sm">
                  <ExternalLink className="w-4 h-4 mr-1" /> Set up a template
                </Button>
              </Link>
            </div>
          ) : loading ? (
            <div className="text-center py-8 text-slate-500 text-sm">Loading...</div>
          ) : linked.length === 0 ? (
            <div className="text-center py-8">
              <BarChart3 className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-500 text-sm">No maturity assessments linked yet.</p>
              <p className="text-xs text-slate-400 mt-1">
                Create a new maturity assessment or link an existing one to score this process against the maturity model.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {linked.map((a) => {
                const cap = capabilities.find((c) => c.id === a.capability_id);
                return (
                  <div key={a.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-sm text-slate-800 truncate">{a.assessment_name || "Untitled"}</p>
                        <Badge variant="outline" className={STATUS_STYLES[a.status] || "bg-slate-100 text-slate-700"}>{a.status}</Badge>
                      </div>
                      <p className="text-xs text-slate-500">
                        {cap?.name || "Unknown capability"} • {a.assessment_date || "No date"} • Score: {(a.overall_score || 0).toFixed(1)}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Link to={createPageUrl(`CapabilityMaturity?capability_id=${a.capability_id}`)}>
                        <Button type="button" variant="ghost" size="icon" title="Open in Capability Maturity">
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </Link>
                      <Button type="button" variant="ghost" size="icon" title="Unlink" onClick={() => handleUnlink(a.id)} disabled={saving}>
                        <Unlink className="w-4 h-4 text-red-400" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New Maturity Assessment</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label>IT Capability</Label>
              <Select value={newMeta.capability_id} onValueChange={(v) => setNewMeta({ ...newMeta, capability_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select a capability..." /></SelectTrigger>
                <SelectContent>
                  {capabilities.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Assessment Name</Label>
              <Input value={newMeta.name} onChange={(e) => setNewMeta({ ...newMeta, name: e.target.value })} placeholder="e.g. 2026 Process Maturity Baseline" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Assessment Date</Label>
                <Input type="date" value={newMeta.date} onChange={(e) => setNewMeta({ ...newMeta, date: e.target.value })} />
              </div>
              <div className="space-y-1">
                <Label>Target Score</Label>
                <Input type="number" step="0.01" value={newMeta.target_score} onChange={(e) => setNewMeta({ ...newMeta, target_score: Number(e.target.value) })} />
              </div>
            </div>
            <p className="text-xs text-slate-500">
              This assessment will be linked to <strong>{processName || "this process assessment"}</strong> and scored using the company's maturity template.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving || !newMeta.name || !newMeta.capability_id}>
              {saving ? "Creating..." : "Create & Link"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Link existing dialog */}
      <Dialog open={showLink} onOpenChange={setShowLink}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Link Existing Maturity Assessment</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input placeholder="Search assessments..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
            </div>
            <div className="max-h-80 overflow-y-auto space-y-1">
              {filteredUnlinked.length === 0 ? (
                <p className="text-center text-sm text-slate-500 py-6">No unlinked maturity assessments found.</p>
              ) : (
                filteredUnlinked.map((a) => {
                  const cap = capabilities.find((c) => c.id === a.capability_id);
                  return (
                    <div key={a.id} className="flex items-center justify-between p-2 rounded-lg border border-slate-200 hover:bg-slate-50">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm text-slate-800 truncate">{a.assessment_name || "Untitled"}</p>
                        <p className="text-xs text-slate-500">{cap?.name || "Unknown"} • {a.assessment_date || "No date"}</p>
                      </div>
                      <Button type="button" size="sm" variant="outline" onClick={() => handleLink(a.id)} disabled={saving}>
                        <Link2 className="w-4 h-4 mr-1" /> Link
                      </Button>
                    </div>
                  );
                })
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLink(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}