import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Target, ArrowRight, CheckCircle2, TrendingUp } from "lucide-react";
import { getMaturityBand } from "@/lib/maturityScoring";

export default function AspirationsTab({ assessment, scoringConfig, onSave, saving, onConvertToGoals }) {
  const [aspirations, setAspirations] = useState(
    assessment.aspirations ||
      (assessment.dimension_scores || []).map((ds) => ({
        dimension: ds.dimension,
        current_score_5: ds.final_score_5 ?? ds.score_5 ?? 0,
        aspiration_score_5: ds.final_score_5 ?? ds.score_5 ?? 0,
        gap: 0,
        notes: "",
      }))
  );
  const [goalsCreated, setGoalsCreated] = useState(assessment.goals_created || false);

  const scale = scoringConfig.scoreScale;

  const updateAspiration = (idx, field, value) => {
    const next = [...aspirations];
    next[idx] = { ...next[idx], [field]: value };
    if (field === "aspiration_score_5") {
      next[idx].gap = Number(value) - (next[idx].current_score_5 || 0);
    }
    setAspirations(next);
  };

  const handleSaveAspirations = () => {
    const dimensionScores = (assessment.dimension_scores || []).map((ds) => {
      const asp = aspirations.find((a) => a.dimension === ds.dimension);
      return {
        ...ds,
        aspiration_score_5: asp?.aspiration_score_5 ?? ds.aspiration_score_5 ?? 0,
      };
    });
    onSave({
      ...assessment,
      aspirations,
      dimension_scores: dimensionScores,
      validation_stage: "completed",
    });
  };

  const handleConvertToGoals = async () => {
    await onConvertToGoals(aspirations);
    setGoalsCreated(true);
  };

  const totalGap = aspirations.reduce((s, a) => s + (a.gap || 0), 0);
  const avgAspiration = aspirations.length > 0 ? aspirations.reduce((s, a) => s + (a.aspiration_score_5 || 0), 0) / aspirations.length : 0;

  return (
    <div className="space-y-4">
      <Card className="border-slate-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Target className="w-4 h-4 text-purple-500" /> Aspiration Targets per Dimension
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-slate-500">
            Review the validated final scores below and set the aspiration (target) score for each dimension.
            These aspirations will be converted into goals to drive the improvement roadmap.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {aspirations.map((asp, idx) => {
              const band = getMaturityBand(asp.current_score_5, scoringConfig);
              const aspBand = getMaturityBand(asp.aspiration_score_5, scoringConfig);
              const gap = asp.gap || (asp.aspiration_score_5 || 0) - (asp.current_score_5 || 0);
              return (
                <div key={asp.dimension} className="border border-slate-200 rounded-lg p-3 space-y-2 bg-white">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-700">{asp.dimension}</span>
                    <Badge variant="outline" className="text-xs" style={{ color: band.color, border: 0, backgroundColor: band.color + "15" }}>
                      {band.label}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 items-end">
                    <div className="space-y-0.5">
                      <Label className="text-xs text-slate-500">Current</Label>
                      <div className="text-lg font-bold text-slate-600">{(asp.current_score_5 || 0).toFixed(2)}</div>
                    </div>
                    <div className="space-y-0.5 text-center">
                      <Label className="text-xs text-slate-400">Gap</Label>
                      <div className={`text-lg font-bold ${gap > 0 ? "text-amber-500" : gap < 0 ? "text-red-500" : "text-slate-400"}`}>
                        {gap > 0 ? "+" : ""}{gap.toFixed(2)}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-purple-600">Aspiration /{scale}</Label>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        max={scale}
                        value={asp.aspiration_score_5}
                        onChange={(e) => updateAspiration(idx, "aspiration_score_5", Number(e.target.value))}
                        className="h-8 text-sm"
                      />
                    </div>
                  </div>
                  {aspBand.label !== band.label && (
                    <p className="text-xs text-purple-500 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" /> Target band: <span className="font-medium">{aspBand.label}</span>
                    </p>
                  )}
                  <Textarea
                    value={asp.notes}
                    onChange={(e) => updateAspiration(idx, "notes", e.target.value)}
                    placeholder="Notes on this aspiration target..."
                    className="text-xs h-12"
                  />
                </div>
              );
            })}
          </div>
          <div className="flex items-center justify-between pt-3 border-t border-slate-100">
            <div className="flex items-center gap-4 text-xs text-slate-500">
              <span>Average aspiration: <strong className="text-purple-600">{avgAspiration.toFixed(2)}/{scale}</strong></span>
              <span>Total gap: <strong className={totalGap > 0 ? "text-amber-500" : "text-slate-400"}>{totalGap > 0 ? "+" : ""}{totalGap.toFixed(2)}</strong></span>
            </div>
            <Button onClick={handleSaveAspirations} disabled={saving}>
              <CheckCircle2 className="w-4 h-4 mr-1" /> Save Aspirations
            </Button>
          </div>
        </CardContent>
      </Card>

      {assessment.validation_stage === "completed" && (
        <Card className="border-purple-200 bg-purple-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <ArrowRight className="w-4 h-4 text-purple-500" /> Convert Aspirations to Goals
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-xs text-purple-600">
              Convert the aspiration targets into GRC Goal records. Each dimension with a gap will create a goal
              with the current maturity, target maturity, and gap pre-filled.
            </p>
            {goalsCreated && (
              <div className="flex items-center gap-2 text-xs text-green-600 bg-green-50 rounded p-2">
                <CheckCircle2 className="w-4 h-4" /> Goals have been created from these aspirations.
              </div>
            )}
            <Button onClick={handleConvertToGoals} disabled={saving || goalsCreated} variant={goalsCreated ? "outline" : "default"}>
              <Target className="w-4 h-4 mr-1" /> {goalsCreated ? "Goals Created" : "Convert to Goals"}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}