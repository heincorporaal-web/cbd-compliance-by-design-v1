import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, TrendingUp } from "lucide-react";
import { MATURITY_BANDS } from "@/lib/maturityScoring";

/**
 * Read-only roll-up summary showing the aggregated maturity score and
 * dimension-level averages across all linked CapabilityMaturityAssessment records.
 */
export default function ProcessMaturityRollup({ rollup }) {
  if (!rollup || rollup.assessmentCount === 0) return null;

  const { overallScore5, band, dimensions, assessmentCount } = rollup;

  return (
    <Card className="border-none shadow-lg bg-gradient-to-br from-slate-50 to-blue-50/30">
      <CardHeader className="border-b border-slate-100 pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <TrendingUp className="w-4 h-4 text-blue-600" />
          Maturity Roll-up
          <Badge variant="outline" className="ml-1 text-xs font-normal">
            {assessmentCount} assessment{assessmentCount !== 1 ? "s" : ""}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 space-y-4">
        {/* Overall score */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 mb-0.5">Calculated Maturity Score</p>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-slate-900">{overallScore5.toFixed(1)}</span>
              <span className="text-sm text-slate-400">/ 5.0</span>
            </div>
          </div>
          <Badge
            style={{ backgroundColor: band.color + "20", color: band.color, borderColor: band.color + "40" }}
            className="text-sm font-semibold capitalize border"
          >
            {band.label}
          </Badge>
        </div>

        {/* Maturity bar */}
        <div className="relative h-2.5 rounded-full bg-slate-200 overflow-hidden">
          <div
            className="absolute top-0 left-0 h-full rounded-full transition-all"
            style={{ width: `${(overallScore5 / 5) * 100}%`, backgroundColor: band.color }}
          />
        </div>

        {/* Dimension roll-up */}
        {dimensions.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">Dimension Averages</p>
            {dimensions.map((d) => (
              <div key={d.dimension} className="flex items-center gap-3">
                <span className="text-xs text-slate-600 w-32 truncate shrink-0">{d.dimension}</span>
                <div className="flex-1 relative h-2 rounded-full bg-slate-200 overflow-hidden">
                  <div
                    className="absolute top-0 left-0 h-full rounded-full"
                    style={{ width: `${(d.avgScore5 / 5) * 100}%`, backgroundColor: d.band.color }}
                  />
                </div>
                <span className="text-xs font-medium text-slate-700 w-8 text-right">{d.avgScore5.toFixed(1)}</span>
              </div>
            ))}
          </div>
        )}

        <p className="text-xs text-slate-400 italic">
          This score is auto-calculated from linked maturity assessments and cannot be manually entered.
        </p>
      </CardContent>
    </Card>
  );
}