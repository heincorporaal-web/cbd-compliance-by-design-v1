import React from "react";
import {
  ComposedChart,
  Bar,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Legend,
} from "recharts";
import { DEFAULT_SCORING_CONFIG } from "@/lib/maturityScoring";

const BAR_COLOR = "#1f4e79";
const TARGET_COLOR = "#0d9488";
const BASELINE_COLOR = "#ffc000";
const IT_BASELINE_COLOR = "#0d9488";

const StarShape = (props) => {
  const { cx, cy, fill } = props;
  const path =
    "M0,-9 L2.65,-2.78 L9.52,-2.78 L4.04,1.19 L6.62,7.28 L0,3.7 L-6.62,7.28 L-4.04,1.19 L-9.52,-2.78 L-2.65,-2.78 Z";
  return <path d={path} transform={`translate(${cx},${cy})`} fill={fill} />;
};

export default function MaturityScoreChart({
  dimensionScores = [],
  overallScore = 0,
  targetScore = 0,
  itBaselineScore = null,
  height = 320,
  scoringConfig = DEFAULT_SCORING_CONFIG,
}) {
  const scale = scoringConfig.scoreScale;
  const chartData = dimensionScores.map((d) => ({
    dimension: d.dimension,
    score_5: Number(d.score_5 || 0).toFixed(2),
    target_5: Number(d.target_score_5 || 0).toFixed(2),
  }));

  if (chartData.length === 0) {
    return (
      <div className="flex items-center justify-center text-slate-400 text-sm h-64">
        No dimension scores to display
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={height}>
      <ComposedChart data={chartData} margin={{ top: 30, right: 10, bottom: 5, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis dataKey="dimension" tick={{ fontSize: 12, fill: "#475569" }} />
        <YAxis domain={[0, scale]} tick={{ fontSize: 12, fill: "#475569" }} label={{ value: `Score / ${scale}`, angle: -90, position: "insideLeft", style: { fontSize: 11, fill: "#64748b" } }} />
        <Tooltip
          formatter={(value, name) => {
            if (name === "score_5") return [`${value} / ${scale}`, "Dimension Score"];
            if (name === "target_5") return [`${value} / ${scale}`, "Target"];
            return [value, name];
          }}
          contentStyle={{ fontSize: 12, borderRadius: 8 }}
        />
        <Legend
          formatter={(value) => {
            if (value === "score_5") return `Dimension Score / ${scale}`;
            if (value === "target_5") return "Target Score";
            return value;
          }}
          wrapperStyle={{ fontSize: 11 }}
        />
        <Bar dataKey="score_5" fill={BAR_COLOR} radius={[4, 4, 0, 0]} barSize={40} />
        <Scatter dataKey="target_5" shape={StarShape} fill={TARGET_COLOR} />
        <ReferenceLine
          y={overallScore}
          stroke={BASELINE_COLOR}
          strokeWidth={2}
          label={{ value: `Baseline ${overallScore.toFixed(2)}`, position: "right", fill: BASELINE_COLOR, fontSize: 10 }}
        />
        {itBaselineScore != null && (
          <ReferenceLine
            y={itBaselineScore}
            stroke={IT_BASELINE_COLOR}
            strokeDasharray="5 5"
            strokeWidth={1.5}
            label={{ value: `IT Baseline ${itBaselineScore.toFixed(2)}`, position: "left", fill: IT_BASELINE_COLOR, fontSize: 10 }}
          />
        )}
      </ComposedChart>
    </ResponsiveContainer>
  );
}