import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, Link2, FileText, X, Loader2, ExternalLink } from "lucide-react";
import { createFileSignedUrl } from "@/lib/fileUtils";

/**
 * EvidencePicker — lets the user choose between uploading a file or providing a URL
 * as evidence for a maturity assessment response.
 *
 * Props:
 *   response  — the response object (must include evidence_type, evidence_file_uri,
 *                evidence_file_name, evidence_url, evidence_reference, evidence_status)
 *   onChange   — callback(updatedResponse)
 */
export default function EvidencePicker({ response, onChange, disabled }) {
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef(null);

  const evidenceType = response.evidence_type || "none";

  const setType = (type) => {
    onChange({
      ...response,
      evidence_type: type,
      // Clear the unused field when switching type
      evidence_file_uri: type === "upload" ? response.evidence_file_uri || "" : "",
      evidence_file_name: type === "upload" ? response.evidence_file_name || "" : "",
      evidence_url: type === "url" ? response.evidence_url || "" : "",
      evidence_reference: type === "url" ? response.evidence_url || "" : response.evidence_file_name || "",
      evidence_status: type === "none" ? "pending" : "provided",
    });
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const result = await base44.integrations.Core.UploadPrivateFile({ file });
      onChange({
        ...response,
        evidence_type: "upload",
        evidence_file_uri: result.file_uri,
        evidence_file_name: file.name,
        evidence_reference: file.name,
        evidence_status: "provided",
      });
    } catch (err) {
      console.error("Evidence upload failed", err);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const handleUrlChange = (value) => {
    onChange({
      ...response,
      evidence_type: "url",
      evidence_url: value,
      evidence_reference: value,
      evidence_status: value ? "provided" : "pending",
    });
  };

  const clearEvidence = () => {
    onChange({
      ...response,
      evidence_type: "none",
      evidence_file_uri: "",
      evidence_file_name: "",
      evidence_url: "",
      evidence_reference: "",
      evidence_status: "pending",
    });
  };

  const viewUploadedFile = async () => {
    if (!response.evidence_file_uri) return;
    try {
      const { signed_url } = await createFileSignedUrl(response.evidence_file_uri);
      window.open(signed_url, "_blank");
    } catch (err) {
      console.error("Failed to create signed URL", err);
    }
  };

  // Already has evidence attached — show it with a clear option
  if (evidenceType === "upload" && response.evidence_file_uri) {
    return (
      <div className="flex items-center gap-2 px-2 py-1.5 bg-green-50 border border-green-200 rounded-md">
        <FileText className="w-3.5 h-3.5 text-green-600 shrink-0" />
        <span className="text-xs text-green-700 truncate flex-1">{response.evidence_file_name || "Uploaded file"}</span>
        <Button type="button" size="sm" variant="ghost" onClick={viewUploadedFile} className="h-6 px-1.5 text-xs">
          <ExternalLink className="w-3 h-3" />
        </Button>
        {!disabled && (
          <Button type="button" size="sm" variant="ghost" onClick={clearEvidence} className="h-6 px-1.5 text-xs">
            <X className="w-3 h-3 text-red-400" />
          </Button>
        )}
      </div>
    );
  }

  if (evidenceType === "url" && response.evidence_url) {
    return (
      <div className="flex items-center gap-2 px-2 py-1.5 bg-green-50 border border-green-200 rounded-md">
        <Link2 className="w-3.5 h-3.5 text-green-600 shrink-0" />
        <a href={response.evidence_url} target="_blank" rel="noopener noreferrer" className="text-xs text-green-700 truncate flex-1 hover:underline">
          {response.evidence_url}
        </a>
        {!disabled && (
          <Button type="button" size="sm" variant="ghost" onClick={clearEvidence} className="h-6 px-1.5 text-xs">
            <X className="w-3 h-3 text-red-400" />
          </Button>
        )}
      </div>
    );
  }

  // No evidence yet — show the choice
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-slate-500">Evidence (choose one)</Label>
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={uploading || disabled}
          onClick={() => inputRef.current?.click()}
          className="h-8 text-xs"
        >
          {uploading ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> : <Upload className="w-3.5 h-3.5 mr-1" />}
          {uploading ? "Uploading..." : "Upload File"}
        </Button>
        <span className="text-xs text-slate-400">or</span>
        <div className="flex-1 flex items-center gap-1">
          <Link2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <Input
            type="url"
            value={response.evidence_url || ""}
            onChange={(e) => handleUrlChange(e.target.value)}
            placeholder="Paste evidence URL..."
            className="h-8 text-xs"
            disabled={disabled}
          />
        </div>
      </div>
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        onChange={handleFileSelect}
        accept=".pdf,.png,.jpg,.jpeg,.gif,.webp,.csv,.txt,.md,.docx,.xlsx"
      />
    </div>
  );
}