import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, TrendingUp } from "lucide-react";
import { getMaturityBand } from "@/lib/maturityScoring";

/**
 * MaturityOwnerRollup — groups maturity assessments by capability owner,
 * showing a sub-total (average score) per owner and an overall organisational roll-up.
 *
 * Props:
 *   assessments     — all CapabilityMaturityAssessment records for the company
 *   capabilities    — all ITCapability records (has .owner field)
 *   scoringConfig   — the active scoring config (for band labels / scale)
 */
export default function MaturityOwnerRollup({ assessments = [], capabilities = [], scoringConfig }) {
  const capById = new Map((capabilities || []).map((c) => [c.id, c]));
  const scale = scoringConfig?.scoreScale || 5;

  // Group assessments by capability owner
  const byOwner = {};
  for (const a of assessments) {
    const cap = capById.get(a.capability_id);
    const owner = cap?.owner || "Unassigned";
    if (!byOwner[owner]) {
      byOwner[owner] = { owner, capabilities: {}, assessmentCount: 0 };
    }
    if (!byOwner[owner].capabilities[a.capability_id]) {
      byOwner[owner].capabilities[a.capability_id] = {
        name: cap?.name || "Unknown capability",
        scores: [],
      };
    }
    byOwner[owner].capabilities[a.capability_id].scores.push(a.overall_score || 0);
    byOwner[owner].assessmentCount++;
  }

  const owners = Object.values(byOwner)
    .map((o) => {
      const capList = Object.values(o.capabilities).map((c) => {
        const avg = c.scores.reduce((s, v) => s + v, 0) / (c.scores.length || 1);
        const latest = c.scores[c.scores.length - 1] || 0;
        return { name: c.name, avgScore: avg, latestScore: latest, assessmentCount: c.scores.length };
      });
      const ownerAvg = capList.length > 0 ? capList.reduce((s, c) => s + c.avgScore, 0) / capList.length : 0;
      return {
        owner: o.owner,
        capabilityCount: capList.length,
        assessmentCount: o.assessmentCount,
        avgScore: ownerAvg,
        capabilities: capList.sort((a, b) => b.avgScore - a.avgScore),
      };
    })
    .sort((a, b) => b.avgScore - a.avgScore);

  const overallAvg = owners.length > 0 ? owners.reduce((s, o) => s + o.avgScore, 0) / owners.length : 0;
  const overallBand = getMaturityBand(overallAvg, scoringConfig);

  if (assessments.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="p-8 text-center text-slate-400">
          <Users className="w-10 h-10 mx-auto mb-2 opacity-40" />
          <p>No maturity assessments yet. Create assessments for your capabilities to see the owner roll-up.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Overall roll-up card */}
      <Card className="border-slate-200 bg-gradient-to-br from-slate-50 to-white">
        <CardContent className="p-4 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wide">Organisational Maturity Roll-up</p>
            <p className="text-3xl font-bold text-slate-800">{overallAvg.toFixed(2)}</p>
            <p className="text-xs text-slate-400">out of {scale.toFixed(0).replace(".0", "")} • across {owners.length} owner(s)</p>
          </div>
          <div className="text-right">
            <Badge style={{ backgroundColor: overallBand.color + "20", color: overallBand.color }} className="border-0 capitalize text-sm">
              {overallBand.label}
            </Badge>
            <p className="text-xs text-slate-500 mt-1">{assessments.length} assessment(s) • {capabilities.length} capability(ies)</p>
          </div>
        </CardContent>
      </Card>

      {/* Per-owner sub-totals */}
      {owners.map((o) => {
        const band = getMaturityBand(o.avgScore, scoringConfig);
        return (
          <Card key={o.owner} className="border-slate-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Users className="w-4 h-4 text-slate-400" />
                  {o.owner}
                  <Badge variant="outline" className="text-xs">{o.capabilityCount} cap • {o.assessmentCount} assess.</Badge>
                </CardTitle>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                  <Badge style={{ backgroundColor: band.color + "20", color: band.color }} className="border-0 capitalize">
                    {o.avgScore.toFixed(2)} / {scale.toFixed(0).replace(".0", "")} — {band.label}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-1.5">
                {o.capabilities.map((c) => (
                  <div key={c.name} className="flex items-center justify-between px-2 py-1.5 bg-slate-50 rounded-md border border-slate-100">
                    <span className="text-xs text-slate-700 truncate flex-1">{c.name}</span>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-xs text-slate-400">{c.assessmentCount} assess.</span>
                      <span className="text-xs font-semibold text-slate-700">{c.avgScore.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}