import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle2, RefreshCw, SlidersHorizontal, Paperclip, Link as LinkIcon, FileText } from "lucide-react";
import { calculateScaledScore } from "@/lib/maturityScoring";

const VOTE_STYLES = {
  concur: { color: "#22c55e", bg: "#22c55e15", label: "Concur", icon: CheckCircle2 },
  reassess: { color: "#f59e0b", bg: "#f59e0b15", label: "Reassess", icon: RefreshCw },
  calibrate: { color: "#3b82f6", bg: "#3b82f615", label: "Calibrate", icon: SlidersHorizontal },
  pending: { color: "#9ca3af", bg: "#9ca3af15", label: "Pending", icon: null },
};

export default function ResponseValidationCard({ response, onChange, scoringConfig, readOnly, assessorName }) {
  const [showCalibrate, setShowCalibrate] = useState(response.validation_status === "calibrate");
  const scale = scoringConfig.scoreScale;
  const scaled = calculateScaledScore(response.raw_score, scoringConfig);
  const vote = VOTE_STYLES[response.validation_status] || VOTE_STYLES.pending;
  const VoteIcon = vote.icon;

  const setVote = (status) => {
    const updates = { validation_status: status, validated_by: assessorName || "Assessor", validated_date: new Date().toISOString().split("T")[0] };
    if (status !== "calibrate") {
      updates.calibrated_score_5 = null;
      updates.calibration_justification = "";
    }
    if (status !== "reassess") {
      updates.validation_justification = "";
    }
    setShowCalibrate(status === "calibrate");
    onChange({ ...response, ...updates });
  };

  return (
    <div className="border border-slate-200 rounded-lg p-3 space-y-2 bg-white">
      {/* Header: question info + respondent's answer */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="outline" className="text-xs font-mono bg-slate-50">{response.question_id}</Badge>
            <Badge variant="outline" className="text-xs">{response.weight}%</Badge>
            {VoteIcon && <VoteIcon className="w-3.5 h-3.5" style={{ color: vote.color }} />}
          </div>
          <p className="text-xs font-medium text-slate-700">{response.mandatory_artefact}</p>
          <p className="text-xs text-slate-500">{response.assessment_question}</p>
        </div>
        <div className="text-right shrink-0">
          <p className="text-sm font-bold text-slate-700">{scaled.toFixed(2)}/{scale}</p>
          <p className="text-xs text-slate-400">Level: {response.response_level}</p>
        </div>
      </div>

      {/* Evidence display */}
      {response.evidence_type === "upload" && response.evidence_file_name && (
        <div className="flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 rounded px-2 py-1">
          <Paperclip className="w-3 h-3" /> {response.evidence_file_name}
        </div>
      )}
      {response.evidence_type === "url" && response.evidence_url && (
        <a href={response.evidence_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-xs text-blue-500 hover:underline bg-blue-50 rounded px-2 py-1">
          <LinkIcon className="w-3 h-3" /> {response.evidence_url}
        </a>
      )}
      {response.comments && (
        <div className="text-xs text-slate-500 bg-slate-50 rounded px-2 py-1 italic">"{response.comments}"</div>
      )}

      {/* Validation controls */}
      {!readOnly && (
        <div className="flex items-center gap-1.5 pt-1 border-t border-slate-100">
          <Button size="sm" variant={response.validation_status === "concur" ? "default" : "outline"} className="h-7 text-xs" onClick={() => setVote("concur")} style={response.validation_status === "concur" ? { backgroundColor: "#22c55e" } : {}}>
            <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Concur
          </Button>
          <Button size="sm" variant={response.validation_status === "reassess" ? "default" : "outline"} className="h-7 text-xs" onClick={() => setVote("reassess")} style={response.validation_status === "reassess" ? { backgroundColor: "#f59e0b" } : {}}>
            <RefreshCw className="w-3.5 h-3.5 mr-1" /> Reassess
          </Button>
          <Button size="sm" variant={response.validation_status === "calibrate" ? "default" : "outline"} className="h-7 text-xs" onClick={() => setVote("calibrate")} style={response.validation_status === "calibrate" ? { backgroundColor: "#3b82f6" } : {}}>
            <SlidersHorizontal className="w-3.5 h-3.5 mr-1" /> Calibrate
          </Button>
        </div>
      )}

      {/* Reassess justification */}
      {response.validation_status === "reassess" && (
        <div className="space-y-1 bg-amber-50 rounded p-2 border border-amber-100">
          <Label className="text-xs text-amber-700">Justification for reassessment (sent to owner for fix)</Label>
          <Textarea
            value={response.validation_justification || ""}
            onChange={(e) => onChange({ ...response, validation_justification: e.target.value })}
            placeholder="Explain why this response needs to be reassessed..."
            className="text-xs h-16 bg-white"
            readOnly={readOnly}
          />
        </div>
      )}

      {/* Calibrate score adjustment */}
      {response.validation_status === "calibrate" && showCalibrate && (
        <div className="space-y-2 bg-blue-50 rounded p-2 border border-blue-100">
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-xs text-blue-700">Calibrated Score /{scale}</Label>
              <Input
                type="number"
                step="0.01"
                min="0"
                max={scale}
                value={response.calibrated_score_5 ?? ""}
                onChange={(e) => onChange({ ...response, calibrated_score_5: Number(e.target.value) })}
                className="h-8 text-sm bg-white"
                readOnly={readOnly}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-blue-700">Original Score</Label>
              <div className="h-8 flex items-center text-sm text-slate-500">{scaled.toFixed(2)}/{scale}</div>
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs text-blue-700">Calibration justification</Label>
            <Textarea
              value={response.calibration_justification || ""}
              onChange={(e) => onChange({ ...response, calibration_justification: e.target.value })}
              placeholder="Explain why the score is being adjusted..."
              className="text-xs h-16 bg-white"
              readOnly={readOnly}
            />
          </div>
        </div>
      )}

      {/* Read-only validation display */}
      {readOnly && response.validation_status !== "pending" && (
        <div className="pt-1 border-t border-slate-100 space-y-1">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs" style={{ color: vote.color, backgroundColor: vote.bg, border: 0 }}>
              {vote.label}
            </Badge>
            {response.validated_by && <span className="text-xs text-slate-400">by {response.validated_by}</span>}
          </div>
          {response.validation_justification && (
            <p className="text-xs text-amber-600 italic">Reassess: {response.validation_justification}</p>
          )}
          {response.calibration_justification && (
            <p className="text-xs text-blue-600 italic">Calibrated to {(response.calibrated_score_5 ?? 0).toFixed(2)}: {response.calibration_justification}</p>
          )}
        </div>
      )}
    </div>
  );
}