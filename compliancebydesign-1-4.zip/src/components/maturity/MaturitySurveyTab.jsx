import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Send, ArrowRight, RefreshCw, Mail, Users, CheckCircle2 } from "lucide-react";
import { createMaturitySurvey, importSurveyResponseToAssessment } from "@/lib/maturitySurveySync";
import { format } from "date-fns";

export default function MaturitySurveyTab({ capability, template, companyId, onAssessmentCreated, scoringConfig }) {
  const navigate = useNavigate();
  const [surveys, setSurveys] = useState([]);
  const [responsesMap, setResponsesMap] = useState({});
  const [loading, setLoading] = useState(true);
  const [launching, setLaunching] = useState(false);
  const [importing, setImporting] = useState(null);
  const [dueDate, setDueDate] = useState("");

  const loadSurveys = useCallback(async () => {
    if (!capability?.id) return;
    setLoading(true);
    try {
      const res = await base44.entities.Survey.filter(
        { linked_entity_type: "ITCapability", linked_entity_id: capability.id },
        { sort: "-created_date", limit: 100 }
      );
      const surveyList = res.items || [];
      setSurveys(surveyList);

      // Load responses for each survey
      const rMap = {};
      for (const s of surveyList) {
        const rRes = await base44.entities.SurveyResponse.filter(
          { survey_id: s.id },
          { limit: 500 }
        );
        rMap[s.id] = rRes.items || [];
      }
      setResponsesMap(rMap);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  }, [capability?.id]);

  useEffect(() => {
    loadSurveys();
  }, [loadSurveys]);

  const handleLaunch = async () => {
    if (!template || !capability) return;
    setLaunching(true);
    try {
      const survey = await createMaturitySurvey(template, capability, dueDate, scoringConfig);
      await loadSurveys();
      navigate(`/SurveyDetail?id=${survey.id}`);
    } catch (e) {
      console.error(e);
    }
    setLaunching(false);
  };

  const handleImport = async (surveyId, responseId) => {
    if (!template) return;
    setImporting(responseId);
    try {
      const survey = surveys.find((s) => s.id === surveyId);
      const response = (responsesMap[surveyId] || []).find((r) => r.id === responseId);
      if (!survey || !response) return;
      const defaultTarget = scoringConfig ? scoringConfig.scoreScale * 0.6 : 3;
      await importSurveyResponseToAssessment(
        survey,
        response,
        template,
        capability.id,
        companyId,
        defaultTarget,
        scoringConfig
      );
      if (onAssessmentCreated) onAssessmentCreated();
    } catch (e) {
      console.error(e);
    }
    setImporting(null);
  };

  const handleImportAll = async (surveyId) => {
    if (!template) return;
    setImporting(`all-${surveyId}`);
    try {
      const survey = surveys.find((s) => s.id === surveyId);
      const responses = responsesMap[surveyId] || [];
      const defaultTarget = scoringConfig ? scoringConfig.scoreScale * 0.6 : 3;
      for (const r of responses) {
        await importSurveyResponseToAssessment(
          survey,
          r,
          template,
          capability.id,
          companyId,
          defaultTarget,
          scoringConfig
        );
      }
      if (onAssessmentCreated) onAssessmentCreated();
    } catch (e) {
      console.error(e);
    }
    setImporting(null);
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: "bg-slate-100 text-slate-700 border-slate-200",
      active: "bg-green-100 text-green-700 border-green-200",
      closed: "bg-red-100 text-red-700 border-red-200",
    };
    return colors[status] || "bg-slate-100 text-slate-700";
  };

  return (
    <div className="space-y-4">
      {/* Launch panel */}
      <Card className="border-slate-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Send className="w-4 h-4" /> Launch Assessment Survey
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-slate-500">
            Generate a survey from your maturity template and distribute it to respondents.
            Responses are imported back as maturity assessments with automatic scoring.
          </p>
          {!template && (
            <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded p-2">
              No template found for this company. Go to <strong>Template Setup</strong> to create one first.
            </div>
          )}
          <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-end">
            <div className="space-y-1 flex-1">
              <Label className="text-xs text-slate-500">Due date (optional)</Label>
              <Input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
            <Button
              onClick={handleLaunch}
              disabled={launching || !template}
              className="sm:self-end"
            >
              <Plus className="w-4 h-4 mr-1" />
              {launching ? "Creating..." : "Launch Survey"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Existing surveys */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-600">
          {surveys.length} survey(s) linked to this capability
        </p>
        <Button size="sm" variant="ghost" onClick={loadSurveys} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
        </Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-32">
          <div className="w-6 h-6 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
        </div>
      ) : surveys.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="p-8 text-center text-slate-400">
            <Mail className="w-10 h-10 mx-auto mb-2 opacity-40" />
            <p>No surveys yet for this capability. Click "Launch Survey" to create one.</p>
          </CardContent>
        </Card>
      ) : (
        surveys.map((survey) => {
          const responses = responsesMap[survey.id] || [];
          const completedCount = (survey.recipients || []).filter((r) => r.completed).length;
          return (
            <Card key={survey.id} className="border-slate-200 hover:shadow-md transition-shadow">
              <CardContent className="p-3 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-slate-800 truncate">{survey.title}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <Badge variant="outline" className={`${getStatusColor(survey.status)} border text-xs`}>
                        {survey.status}
                      </Badge>
                      <span className="text-xs text-slate-500">
                        {survey.questions?.length || 0} questions
                      </span>
                      {survey.due_date && (
                        <span className="text-xs text-slate-500">
                          Due: {format(new Date(survey.due_date), "d MMM yyyy")}
                        </span>
                      )}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => navigate(`/SurveyDetail?id=${survey.id}`)}
                  >
                    Open <ArrowRight className="w-3 h-3 ml-1" />
                  </Button>
                </div>

                {responses.length > 0 ? (
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-medium text-slate-600 flex items-center gap-1">
                        <Users className="w-3 h-3" /> {responses.length} response(s)
                      </p>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleImportAll(survey.id)}
                        disabled={importing === `all-${survey.id}`}
                        className="text-xs h-7"
                      >
                        {importing === `all-${survey.id}` ? "Importing..." : "Import All"}
                      </Button>
                    </div>
                    {responses.map((r) => (
                      <div
                        key={r.id}
                        className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-100"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium text-slate-700 truncate">
                            {r.respondent_name || "Anonymous"}
                          </p>
                          <p className="text-xs text-slate-500 truncate">
                            {r.respondent_email || ""}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {r.completed_date && (
                            <span className="text-xs text-slate-400">
                              {format(new Date(r.completed_date), "d MMM yyyy")}
                            </span>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleImport(survey.id, r.id)}
                            disabled={importing === r.id}
                            className="h-7 text-xs"
                          >
                            {importing === r.id ? "..." : "Import"}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="pt-2 border-t border-slate-100">
                    <p className="text-xs text-slate-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> No responses yet. Distribute the survey to collect answers.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })
      )}
    </div>
  );
}