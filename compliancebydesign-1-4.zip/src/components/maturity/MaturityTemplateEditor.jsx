import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, GripVertical, Save, Sliders } from "lucide-react";
import { DEFAULT_MATURITY_TEMPLATE } from "@/lib/defaultMaturityTemplate";
import { DEFAULT_SCORING_CONFIG, buildScoringConfig } from "@/lib/maturityScoring";

export default function MaturityTemplateEditor({ template, onSave, saving, assessmentModels = [] }) {
  const [draft, setDraft] = useState(
    template || {
      ...DEFAULT_MATURITY_TEMPLATE,
      name: "IT Capability Maturity Model",
      company_id: null,
      assessment_model_id: "",
    }
  );

  const linkedModel = assessmentModels.find((m) => m.id === draft.assessment_model_id) || null;
  const scoringConfig = linkedModel ? buildScoringConfig(linkedModel) : DEFAULT_SCORING_CONFIG;
  const usingModel = scoringConfig !== DEFAULT_SCORING_CONFIG;

  const totalWeight = draft.dimensions?.reduce((s, d) => s + (d.weight || 0), 0) || 0;

  // Per-dimension question weight validation (each dimension's questions must sum to 100%)
  const dimensionWeightErrors = (draft.dimensions || []).map((dim) => {
    const qWeight = (dim.questions || []).reduce((s, q) => s + (q.weight || 0), 0);
    return { name: dim.name, questionWeight: qWeight, hasQuestions: (dim.questions || []).length > 0 };
  });
  const hasQuestionWeightErrors = dimensionWeightErrors.some((d) => d.hasQuestions && d.questionWeight !== 100);
  const canSave = totalWeight === 100 && !hasQuestionWeightErrors;

  const updateDimension = (idx, field, value) => {
    const dims = [...(draft.dimensions || [])];
    dims[idx] = { ...dims[idx], [field]: value };
    setDraft({ ...draft, dimensions: dims });
  };

  const addDimension = () => {
    const dims = [...(draft.dimensions || [])];
    dims.push({
      name: "New Dimension",
      description: "",
      weight: 0,
      sort_order: dims.length + 1,
      questions: [],
    });
    setDraft({ ...draft, dimensions: dims });
  };

  const removeDimension = (idx) => {
    const dims = [...(draft.dimensions || [])];
    dims.splice(idx, 1);
    setDraft({ ...draft, dimensions: dims });
  };

  const updateQuestion = (dimIdx, qIdx, field, value) => {
    const dims = [...(draft.dimensions || [])];
    const questions = [...dims[dimIdx].questions];
    questions[qIdx] = { ...questions[qIdx], [field]: value };
    dims[dimIdx] = { ...dims[dimIdx], questions };
    setDraft({ ...draft, dimensions: dims });
  };

  const addQuestion = (dimIdx) => {
    const dims = [...(draft.dimensions || [])];
    const dim = dims[dimIdx];
    const prefix = (dim.name || "DIM").substring(0, 3).toUpperCase();
    const qNum = (dim.questions?.length || 0) + 1;
    const questions = [...(dim.questions || []), {
      question_id: `${prefix}-${String(qNum).padStart(2, "0")}`,
      mandatory_artefact: "",
      assessment_question: "",
      weight: 0,
    }];
    dims[dimIdx] = { ...dim, questions };
    setDraft({ ...draft, dimensions: dims });
  };

  const removeQuestion = (dimIdx, qIdx) => {
    const dims = [...(draft.dimensions || [])];
    const questions = [...dims[dimIdx].questions];
    questions.splice(qIdx, 1);
    dims[dimIdx] = { ...dims[dimIdx], questions };
    setDraft({ ...draft, dimensions: dims });
  };

  const handleSave = () => {
    onSave(draft);
  };

  return (
    <div className="space-y-4">
      <Card className="border-slate-200">
        <CardContent className="p-4 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Template Name</Label>
              <Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label>Description</Label>
              <Input value={draft.description || ""} onChange={(e) => setDraft({ ...draft, description: e.target.value })} />
            </div>
          </div>

          {/* Assessment Model linkage */}
          <div className="space-y-1">
            <Label className="flex items-center gap-1.5"><Sliders className="w-3.5 h-3.5" /> Assessment Model (Scoring Parameters)</Label>
            <Select
              value={draft.assessment_model_id || "default"}
              onValueChange={(v) => setDraft({ ...draft, assessment_model_id: v === "default" ? "" : v })}
            >
              <SelectTrigger><SelectValue placeholder="Default CMM scale (0–4 / 5)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default CMM scale (0–4 / 5)</SelectItem>
                {assessmentModels.map((m) => (
                  <SelectItem key={m.id} value={m.id}>
                    {m.name}{m.analysis_type === "Maturity Assessment" ? "" : ` (${m.analysis_type})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              {usingModel
                ? `Using "${linkedModel.name}" — ${scoringConfig.responseLevels.length - 1} maturity levels, scored out of ${scoringConfig.scoreScale}. Bands: ${scoringConfig.bands.map((b) => b.label).join(" → ")}.`
                : "No model linked — the default CMM scale (0–4 raw, scored /5, Informal → Optimising) is used."}
            </p>
          </div>

          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="space-y-1">
              <Badge variant={totalWeight === 100 ? "default" : "destructive"}>
                Total Dimension Weight: {totalWeight}% {totalWeight !== 100 && "— must be 100%"}
              </Badge>
              {hasQuestionWeightErrors && (
                <Badge variant="destructive" className="block">
                  Per-dimension question weights must each total 100%
                </Badge>
              )}
            </div>
            <Button size="sm" onClick={handleSave} disabled={saving || !canSave} title={!canSave ? "Fix weight errors before saving" : ""}>
              <Save className="w-4 h-4 mr-1" /> {saving ? "Saving..." : "Save Template"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {(draft.dimensions || []).map((dim, dimIdx) => {
        const dimQuestionWeight = (dim.questions || []).reduce((s, q) => s + (q.weight || 0), 0);
        return (
          <Card key={dimIdx} className="border-slate-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2">
                  <GripVertical className="w-4 h-4 text-slate-300" />
                  <Input
                    value={dim.name}
                    onChange={(e) => updateDimension(dimIdx, "name", e.target.value)}
                    className="font-semibold border-0 px-0 h-auto focus-visible:ring-0"
                  />
                </CardTitle>
                <Button size="sm" variant="ghost" onClick={() => removeDimension(dimIdx)}>
                  <Trash2 className="w-4 h-4 text-red-400" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <div className="md:col-span-2 space-y-1">
                  <Label className="text-xs">Description</Label>
                  <Textarea
                    value={dim.description || ""}
                    onChange={(e) => updateDimension(dimIdx, "description", e.target.value)}
                    rows={1}
                    className="text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Weight (%)</Label>
                  <Input
                    type="number"
                    value={dim.weight}
                    onChange={(e) => updateDimension(dimIdx, "weight", Number(e.target.value))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-medium ${dim.questions?.length > 0 && dimQuestionWeight !== 100 ? "text-red-600" : "text-slate-600"}`}>
                    Questions ({dim.questions?.length || 0}) — Total weight: {dimQuestionWeight}%{dim.questions?.length > 0 && dimQuestionWeight !== 100 && " ✗ must be 100%"}
                  </span>
                  <Button size="sm" variant="outline" onClick={() => addQuestion(dimIdx)}>
                    <Plus className="w-3.5 h-3.5 mr-1" /> Add Question
                  </Button>
                </div>
                {(dim.questions || []).map((q, qIdx) => (
                  <div key={qIdx} className="border border-slate-200 rounded-lg p-2 space-y-2 bg-slate-50/50">
                    <div className="flex items-start gap-2">
                      <Input
                        value={q.question_id}
                        onChange={(e) => updateQuestion(dimIdx, qIdx, "question_id", e.target.value)}
                        className="w-24 text-xs font-mono"
                        placeholder="GOV-01"
                      />
                      <Input
                        value={q.mandatory_artefact}
                        onChange={(e) => updateQuestion(dimIdx, qIdx, "mandatory_artefact", e.target.value)}
                        className="text-xs flex-1"
                        placeholder="Mandatory artefact"
                      />
                      <Input
                        type="number"
                        value={q.weight}
                        onChange={(e) => updateQuestion(dimIdx, qIdx, "weight", Number(e.target.value))}
                        className="w-20 text-xs"
                        placeholder="Weight %"
                      />
                      <Button size="sm" variant="ghost" onClick={() => removeQuestion(dimIdx, qIdx)}>
                        <Trash2 className="w-3.5 h-3.5 text-red-400" />
                      </Button>
                    </div>
                    <Textarea
                      value={q.assessment_question}
                      onChange={(e) => updateQuestion(dimIdx, qIdx, "assessment_question", e.target.value)}
                      rows={1}
                      className="text-xs"
                      placeholder="Assessment question"
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );
      })}

      <Button variant="outline" onClick={addDimension} className="w-full">
        <Plus className="w-4 h-4 mr-1" /> Add Dimension
      </Button>
    </div>
  );
}