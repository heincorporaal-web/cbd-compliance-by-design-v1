import React from "react";
import { CheckCircle2, Circle, Clock, AlertCircle } from "lucide-react";

const STAGES = [
  { key: "not_started", label: "Responses", description: "Owner completes answers & evidence" },
  { key: "in_validation", label: "Validation", description: "Assessors review answers" },
  { key: "calibration_pending", label: "Calibration Approval", description: "OPEX lead approves calibrations" },
  { key: "validated", label: "Final Scores", description: "Validated scores presented" },
  { key: "aspirations_pending", label: "Aspirations", description: "Respondent sets target per dimension" },
  { key: "completed", label: "Goals", description: "Aspirations converted to goals" },
];

const STAGE_ORDER = STAGES.map((s) => s.key);

export function getStageIndex(stage) {
  const idx = STAGE_ORDER.indexOf(stage);
  return idx < 0 ? 0 : idx;
}

export function getStageInfo(stage) {
  return STAGES.find((s) => s.key === stage) || STAGES[0];
}

export default function ValidationStageBanner({ stage, validationSummary }) {
  const currentIdx = getStageIndex(stage);

  const counts = validationSummary || {};
  const total = counts.total || 0;
  const concur = counts.concur || 0;
  const reassess = counts.reassess || 0;
  const calibrate = counts.calibrate || 0;
  const pending = counts.pending || 0;

  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-slate-700">Validation Workflow</h3>
        {stage === "reassess_pending" && (
          <span className="flex items-center gap-1 text-xs font-medium text-amber-600">
            <AlertCircle className="w-3.5 h-3.5" /> Awaiting owner fix on {reassess} item(s)
          </span>
        )}
        {stage === "calibration_pending" && (
          <span className="flex items-center gap-1 text-xs font-medium text-blue-600">
            <Clock className="w-3.5 h-3.5" /> Awaiting OPEX lead approval on {calibrate} calibration(s)
          </span>
        )}
      </div>

      <div className="flex items-center gap-1 overflow-x-auto pb-1">
        {STAGES.map((s, i) => {
          const isDone = i < currentIdx;
          const isCurrent = i === currentIdx;
          const isFuture = i > currentIdx;
          const Icon = isDone ? CheckCircle2 : isCurrent ? Clock : Circle;
          const color = isDone
            ? "text-green-500"
            : isCurrent
            ? "text-blue-500"
            : "text-slate-300";
          const labelColor = isDone
            ? "text-green-600"
            : isCurrent
            ? "text-blue-600 font-semibold"
            : "text-slate-400";
          return (
            <React.Fragment key={s.key}>
              <div className="flex flex-col items-center min-w-[100px] text-center">
                <Icon className={`w-5 h-5 ${color} mb-1`} />
                <span className={`text-xs ${labelColor} leading-tight`}>{s.label}</span>
                <span className="text-[10px] text-slate-400 leading-tight hidden md:block">{s.description}</span>
              </div>
              {i < STAGES.length - 1 && (
                <div className={`flex-1 h-0.5 mx-1 mt-[-12px] ${i < currentIdx ? "bg-green-300" : "bg-slate-200"}`} style={{ minWidth: 20 }} />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {(stage === "in_validation" || stage === "calibration_pending" || stage === "reassess_pending") && total > 0 && (
        <div className="flex items-center gap-3 mt-3 pt-3 border-t border-slate-100 text-xs">
          <span className="text-slate-500">{total} responses:</span>
          <span className="text-green-600 font-medium">✓ {concur} Concur</span>
          <span className="text-amber-600 font-medium">↻ {reassess} Reassess</span>
          <span className="text-blue-600 font-medium">⊕ {calibrate} Calibrate</span>
          <span className="text-slate-400 font-medium">○ {pending} Pending</span>
        </div>
      )}
    </div>
  );
}