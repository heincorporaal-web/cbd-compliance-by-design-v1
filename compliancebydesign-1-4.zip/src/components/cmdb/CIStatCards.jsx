import React from "react";
import { InfoTileColumn } from "@/components/dashboard/InfoTile";

export default function CIStatCards({ cis = [] }) {
  const total = cis.length;
  const managed = cis.filter(c => c.managed_unmanaged === "managed").length;
  const unmanaged = cis.filter(c => c.managed_unmanaged === "unmanaged").length;
  const stale = cis.filter(c => c.stale_status === "stale" || c.stale_status === "retirement_candidate").length;
  const unknown = cis.filter(c => !c.ci_class_name).length;

  const items = [
    { label: "Total CIs", value: total },
    { label: "Managed", value: managed },
    { label: "Unmanaged", value: unmanaged, attention: unmanaged > 0 },
    { label: "Stale", value: stale, attention: stale > 0 },
    { label: "Unclassified", value: unknown, attention: unknown > 0 },
  ];

  return (
    <div className="max-w-xs">
      <InfoTileColumn title="CI Inventory" items={items} />
    </div>
  );
}