import React, { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { STEP_TYPES, getStepTypeDef, createBlankStep } from "@/lib/workflowStepTypes";
import StepConfigForm from "./StepConfigForm";
import { Plus, Trash2, Settings, Play, Flag, GripVertical, ChevronDown } from "lucide-react";

export default function VisualWorkflowCanvas({ steps = [], onChange, entityType = "" }) {
  const [configStepId, setConfigStepId] = useState(null);
  const configStep = steps.find(s => s.id === configStepId);

  const addStep = (type) => {
    const newStep = createBlankStep(type, steps.length);
    onChange([...steps, newStep]);
  };

  const insertStep = (index, type) => {
    const newStep = createBlankStep(type, index);
    const updated = [...steps];
    updated.splice(index, 0, newStep);
    updated.forEach((s, i) => { s.order = i; });
    onChange(updated);
  };

  const removeStep = (index) => {
    const updated = steps.filter((_, i) => i !== index).map((s, i) => ({ ...s, order: i }));
    onChange(updated);
  };

  const updateStep = (index, updatedStep) => {
    const updated = [...steps];
    updated[index] = updatedStep;
    onChange(updated);
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const updated = [...steps];
    const [moved] = updated.splice(result.source.index, 1);
    updated.splice(result.destination.index, 0, moved);
    updated.forEach((s, i) => { s.order = i; });
    onChange(updated);
  };

  return (
    <div className="space-y-4">
      {/* Step Palette */}
      <div>
        <p className="text-xs font-semibold text-slate-600 mb-2">Step Palette — click to add</p>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {STEP_TYPES.map(t => (
            <button
              key={t.value}
              type="button"
              onClick={() => addStep(t.value)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border ${t.bg} ${t.color} text-xs font-medium whitespace-nowrap hover:shadow-md transition-all shrink-0`}
            >
              <t.icon className="w-3.5 h-3.5" />
              {t.short}
              <Plus className="w-3 h-3" />
            </button>
          ))}
        </div>
      </div>

      {/* Flowchart Canvas */}
      <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 min-h-[200px]">
        {steps.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Play className="w-10 h-10 text-slate-300 mb-3" />
            <p className="font-medium text-slate-500 mb-1">No steps yet</p>
            <p className="text-sm text-slate-400">Click a step type above to start building your workflow.</p>
          </div>
        ) : (
          <>
            {/* Start node */}
            <div className="flex justify-center mb-2">
              <div className="flex flex-col items-center gap-1">
                <div className="px-4 py-1.5 rounded-full bg-green-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm">
                  <Play className="w-3 h-3 fill-white" />
                  Start
                </div>
              </div>
            </div>
            <div className="flex justify-center mb-1">
              <div className="w-px h-6 bg-slate-300" />
            </div>

            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="workflow-canvas">
                {(provided) => (
                  <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-0">
                    {steps.map((step, index) => (
                      <React.Fragment key={step.id}>
                        <Draggable draggableId={step.id} index={index}>
                          {(prov, snapshot) => (
                            <div
                              ref={prov.innerRef}
                              {...prov.draggableProps}
                              className={`relative ${snapshot.isDragging ? 'z-50' : ''}`}
                            >
                              <StepNode
                                step={step}
                                index={index}
                                total={steps.length}
                                dragHandleProps={prov.dragHandleProps}
                                onConfigure={() => setConfigStepId(step.id)}
                                onDelete={() => removeStep(index)}
                                onInsertAfter={(type) => insertStep(index + 1, type)}
                              />
                            </div>
                          )}
                        </Draggable>
                        {/* Connector */}
                        {index < steps.length - 1 && (
                          <div className="flex justify-center py-1">
                            <div className="flex flex-col items-center">
                              <div className="w-px h-5 bg-slate-300" />
                              <div className="w-0 h-0 border-l-[4px] border-l-slate-300 border-y-[3px] border-y-transparent" />
                            </div>
                          </div>
                        )}
                      </React.Fragment>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>

            {/* End node */}
            <div className="flex justify-center mt-1">
              <div className="flex flex-col items-center">
                <div className="w-px h-6 bg-slate-300" />
                <div className="w-0 h-0 border-l-[4px] border-l-slate-300 border-y-[3px] border-y-transparent" />
                <div className="px-4 py-1.5 rounded-full bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm mt-1">
                  <Flag className="w-3 h-3" />
                  End
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Step Configuration Dialog */}
      <Dialog open={!!configStepId} onOpenChange={(open) => { if (!open) setConfigStepId(null); }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {configStep && (() => {
                const def = getStepTypeDef(configStep.type);
                return def ? <def.icon className={`w-4 h-4 ${def.color}`} /> : null;
              })()}
              Configure Step {configStep ? `— ${configStep.name || 'Untitled'}` : ''}
            </DialogTitle>
          </DialogHeader>
          {configStep && (
            <StepConfigForm
              step={configStep}
              onChange={(updated) => updateStep(steps.findIndex(s => s.id === configStepId), updated)}
              entityType={entityType}
            />
          )}
          <div className="flex justify-end pt-2">
            <Button type="button" onClick={() => setConfigStepId(null)}>Done</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StepNode({ step, index, total, dragHandleProps, onConfigure, onDelete, onInsertAfter }) {
  const def = getStepTypeDef(step.type);
  const Icon = def?.icon || Play;
  const [showInsert, setShowInsert] = useState(false);

  const summary = getStepSummary(step);

  return (
    <div className="flex justify-center">
      <div className="w-full max-w-md">
        <div className={`relative bg-white rounded-xl border-2 shadow-sm hover:shadow-md transition-all ${def?.bg?.replace('bg-', 'border-').split(' ')[0] || 'border-slate-200'}`}>
          {/* Drag handle */}
          <div {...dragHandleProps} className="absolute left-2 top-1/2 -translate-y-1/2 cursor-grab active:cursor-grabbing text-slate-300 hover:text-slate-500">
            <GripVertical className="w-4 h-4" />
          </div>

          <div className="pl-8 pr-3 py-3">
            {/* Header */}
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <div className={`w-8 h-8 rounded-lg ${def?.dotBg || 'bg-slate-400'} flex items-center justify-center shrink-0`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-400">#{index + 1}</span>
                    <span className="font-semibold text-slate-900 text-sm truncate">
                      {step.name || `Step ${index + 1}`}
                    </span>
                  </div>
                  <Badge variant="outline" className={`text-[10px] mt-0.5 ${def?.bg || ''} ${def?.color || ''} border`}>
                    {def?.label || step.type}
                  </Badge>
                </div>
              </div>
              <div className="flex gap-1 shrink-0">
                <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={onConfigure}>
                  <Settings className="w-3.5 h-3.5 mr-1" />
                  Configure
                </Button>
                <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={onDelete}>
                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                </Button>
              </div>
            </div>

            {/* Summary */}
            {summary && (
              <p className="text-xs text-slate-500 mt-2 pl-10">{summary}</p>
            )}

            {/* Conditional branch labels */}
            {step.type === 'conditional' && (
              <div className="flex gap-2 mt-2 pl-10">
                <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded">
                  ✓ → {step.condition_true_step != null ? `Step ${step.condition_true_step + 1}` : 'next'}
                </span>
                <span className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded">
                  ✗ → {step.condition_false_step != null ? `Step ${step.condition_false_step + 1}` : 'next'}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Insert button */}
        {index < total - 0 && (
          <div className="relative flex justify-center py-1 group">
            <button
              type="button"
              onClick={() => setShowInsert(!showInsert)}
              className="w-5 h-5 rounded-full bg-white border border-slate-300 flex items-center justify-center text-slate-400 hover:bg-purple-50 hover:border-purple-400 hover:text-purple-600 transition-all shadow-sm"
            >
              <Plus className="w-3 h-3" />
            </button>
            {showInsert && (
              <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 z-20 bg-white rounded-lg shadow-xl border border-slate-200 p-1 flex gap-1 min-w-[200px]">
                {STEP_TYPES.map(t => (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => { onInsertAfter(t.type); setShowInsert(false); }}
                    className={`flex items-center gap-1.5 px-2 py-1.5 rounded ${t.bg} ${t.color} text-xs hover:shadow-sm w-full text-left`}
                  >
                    <t.icon className="w-3 h-3" />
                    {t.short}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function getStepSummary(step) {
  switch (step.type) {
    case 'approval':
    case 'parallel_approval':
      if (step.assignee_type === 'stakeholder_group' && step.stakeholder_group_ids?.length) return `${step.stakeholder_group_ids.length} group(s) assigned`;
      if (step.assignee_type === 'named_stakeholders' && step.named_stakeholder_ids?.length) return `${step.named_stakeholder_ids.length} named stakeholder(s)`;
      if (step.assignee_type === 'dynamic_role' && step.dynamic_role_field) return `Role: ${step.dynamic_role_field}`;
      if (step.approvers?.length) return `${step.approvers.length} approver(s)`;
      return 'No approvers configured';
    case 'notification':
      if (step.recipients?.length) return `${step.recipients.length} recipient(s)`;
      return 'No recipients configured';
    case 'action':
      if (step.recipients?.length) return `${step.recipients.length} assignee(s)`;
      return 'No assignees configured';
    case 'conditional':
      return `If ${step.condition_field || '?'} ${step.condition_operator || '='} ${step.condition_value || '?'}`;
    case 'escalation':
      return `After ${step.escalation_after_days || 3} day(s)${step.escalation_emails?.length ? ` to ${step.escalation_emails.length} email(s)` : ''}`;
    case 'delay':
      return `Wait ${step.delay_hours || 24} hour(s)`;
    case 'return_to_originator':
      return step.return_reason_required !== false ? 'Returns to originator (reason required)' : 'Returns to originator';
    default:
      return null;
  }
}