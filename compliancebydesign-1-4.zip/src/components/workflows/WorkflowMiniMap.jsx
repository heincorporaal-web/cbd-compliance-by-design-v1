import React from "react";
import { getStepTypeDef } from "@/lib/workflowStepTypes";
import { Play, Flag } from "lucide-react";

export default function WorkflowMiniMap({ steps = [], maxSteps = 8 }) {
  const visibleSteps = steps.slice(0, maxSteps);
  const hiddenCount = steps.length - visibleSteps.length;

  return (
    <div className="flex items-center gap-1 overflow-x-auto pb-1">
      {/* Start node */}
      <div className="flex flex-col items-center gap-0.5 shrink-0">
        <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center shadow-sm">
          <Play className="w-3 h-3 text-white fill-white" />
        </div>
        <span className="text-[8px] text-slate-400 font-medium">Start</span>
      </div>

      {visibleSteps.length === 0 ? (
        <div className="flex-1 flex items-center justify-center px-4">
          <span className="text-xs text-slate-400 italic">No steps defined</span>
        </div>
      ) : (
        visibleSteps.map((step, i) => {
          const def = getStepTypeDef(step.type);
          const Icon = def?.icon || Play;
          return (
            <React.Fragment key={step.id || i}>
              {/* Connector */}
              <div className="flex items-center shrink-0">
                <div className="w-3 h-px bg-slate-300" />
                <div className="w-0 h-0 border-l-[4px] border-l-slate-300 border-y-[3px] border-y-transparent" />
              </div>
              {/* Step node */}
              <div className="flex flex-col items-center gap-0.5 shrink-0">
                <div className={`w-7 h-7 rounded-lg ${def?.dotBg || 'bg-slate-400'} flex items-center justify-center shadow-sm ring-1 ring-white`}>
                  <Icon className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="text-[8px] text-slate-500 font-medium max-w-[40px] truncate">
                  {step.name || def?.short || `Step ${i + 1}`}
                </span>
              </div>
            </React.Fragment>
          );
        })
      )}

      {hiddenCount > 0 && (
        <>
          <div className="flex items-center shrink-0">
            <div className="w-3 h-px bg-slate-300" />
          </div>
          <div className="flex flex-col items-center gap-0.5 shrink-0">
            <div className="w-7 h-7 rounded-lg bg-slate-200 flex items-center justify-center text-[9px] font-bold text-slate-500">
              +{hiddenCount}
            </div>
          </div>
        </>
      )}

      {/* End node */}
      {visibleSteps.length > 0 && (
        <>
          <div className="flex items-center shrink-0">
            <div className="w-3 h-px bg-slate-300" />
            <div className="w-0 h-0 border-l-[4px] border-l-slate-300 border-y-[3px] border-y-transparent" />
          </div>
          <div className="flex flex-col items-center gap-0.5 shrink-0">
            <div className="w-6 h-6 rounded-full bg-slate-700 flex items-center justify-center shadow-sm">
              <Flag className="w-3 h-3 text-white" />
            </div>
            <span className="text-[8px] text-slate-400 font-medium">End</span>
          </div>
        </>
      )}
    </div>
  );
}