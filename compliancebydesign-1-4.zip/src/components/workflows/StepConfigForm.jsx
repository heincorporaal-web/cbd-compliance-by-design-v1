import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { STEP_TYPES, getStepTypeDef } from "@/lib/workflowStepTypes";
import StepAssigneePicker from "./StepAssigneePicker";
import { Info } from "lucide-react";

export default function StepConfigForm({ step, onChange, entityType = "" }) {
  const { data: stakeholders = [] } = useQuery({ queryKey: ['stakeholders'], queryFn: () => base44.entities.Stakeholder.list() });
  const { data: stakeholderGroups = [] } = useQuery({ queryKey: ['stakeholderGroups'], queryFn: () => base44.entities.StakeholderGroup.list() });
  const { data: valueChains = [] } = useQuery({ queryKey: ['valueChains'], queryFn: () => base44.entities.ValueChain.list() });
  const { data: workstreams = [] } = useQuery({ queryKey: ['workstreams'], queryFn: () => base44.entities.Workstream.list() });

  const update = (field, value) => onChange({ ...step, [field]: value });
  const updatePatch = (patch) => onChange({ ...step, ...patch });

  const handleApproverChange = ({ assigneeType, emails, groupIds, stakeholderIds, dynamicField }) => {
    onChange({ ...step, assignee_type: assigneeType, approvers: emails, stakeholder_group_ids: groupIds, named_stakeholder_ids: stakeholderIds, dynamic_role_field: dynamicField });
  };

  const handleRecipientChange = ({ assigneeType, emails, groupIds, stakeholderIds, dynamicField }) => {
    onChange({ ...step, recipient_assignee_type: assigneeType, recipients: emails, recipient_stakeholder_group_ids: groupIds, recipient_named_stakeholder_ids: stakeholderIds, recipient_dynamic_role_field: dynamicField });
  };

  const typeDef = getStepTypeDef(step.type);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-xs">Step Name *</Label>
          <Input value={step.name || ""} onChange={(e) => update("name", e.target.value)} placeholder="e.g., Manager Approval" className="h-8 text-sm" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">Step Type *</Label>
          <Select value={step.type} onValueChange={(v) => update("type", v)}>
            <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              {STEP_TYPES.map(t => (
                <SelectItem key={t.value} value={t.value}>
                  <div className="flex items-center gap-2">
                    <t.icon className={`w-3.5 h-3.5 ${t.color}`} />
                    {t.label}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {typeDef && (
        <div className={`flex items-start gap-2 p-2.5 rounded-lg border text-xs ${typeDef.bg} ${typeDef.color}`}>
          <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
          {typeDef.description}
        </div>
      )}

      {valueChains.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-600">Value Chain <span className="text-slate-400">(optional)</span></Label>
            <Select
              value={step.value_chain_id || ""}
              onValueChange={(v) => {
                const vc = valueChains.find(c => c.id === v);
                const ws = workstreams.find(w => w.id === step.workstream_id);
                updatePatch({ value_chain_id: v || null, value_chain_name: vc?.name || "", ...(ws && ws.value_chain_id !== v ? { workstream_id: null, workstream_name: "" } : {}) });
              }}
            >
              <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="All value chains" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>All value chains</SelectItem>
                {valueChains.filter(vc => vc.status !== 'archived').map(vc => <SelectItem key={vc.id} value={vc.id}>{vc.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-600">Workstream <span className="text-slate-400">(optional)</span></Label>
            <Select
              value={step.workstream_id || ""}
              onValueChange={(v) => { const ws = workstreams.find(w => w.id === v); updatePatch({ workstream_id: v || null, workstream_name: ws?.name || "" }); }}
              disabled={!step.value_chain_id}
            >
              <SelectTrigger className="h-8 text-sm"><SelectValue placeholder={step.value_chain_id ? "All workstreams" : "Select a value chain first"} /></SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>All workstreams</SelectItem>
                {workstreams.filter(w => w.value_chain_id === step.value_chain_id && w.status !== 'archived').map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
      )}

      {step.type === 'approval' && (
        <div className="space-y-3">
          <StepAssigneePicker label="Approvers" assigneeType={step.assignee_type || 'named_emails'} emails={step.approvers || []} groupIds={step.stakeholder_group_ids || []} stakeholderIds={step.named_stakeholder_ids || []} dynamicField={step.dynamic_role_field || ''} entityType={entityType} stakeholders={stakeholders} stakeholderGroups={stakeholderGroups} onChange={handleApproverChange} />
          <div className="flex flex-wrap gap-4">
            <label className="flex items-center gap-2 cursor-pointer"><Checkbox checked={!!step.require_all_approvers} onCheckedChange={(c) => update("require_all_approvers", c)} /><span className="text-xs text-slate-700">Require ALL approvers to approve</span></label>
            <label className="flex items-center gap-2 cursor-pointer"><Checkbox checked={!!step.comment_required} onCheckedChange={(c) => update("comment_required", c)} /><span className="text-xs text-slate-700">Require a comment when approving</span></label>
          </div>
        </div>
      )}

      {step.type === 'parallel_approval' && (
        <div className="space-y-3">
          <StepAssigneePicker label="Approvers" assigneeType={step.assignee_type || 'named_emails'} emails={step.approvers || []} groupIds={step.stakeholder_group_ids || []} stakeholderIds={step.named_stakeholder_ids || []} dynamicField={step.dynamic_role_field || ''} entityType={entityType} stakeholders={stakeholders} stakeholderGroups={stakeholderGroups} onChange={handleApproverChange} />
          <div className="space-y-1.5">
            <Label className="text-xs">Minimum approvals required</Label>
            <Input type="number" min={1} value={step.min_approvals || 1} onChange={(e) => update("min_approvals", parseInt(e.target.value) || 1)} className="h-8 text-sm w-32" />
            <p className="text-xs text-slate-400">Leave at 0 to require all approvers</p>
          </div>
          <label className="flex items-center gap-2 cursor-pointer"><Checkbox checked={!!step.comment_required} onCheckedChange={(c) => update("comment_required", c)} /><span className="text-xs text-slate-700">Require a comment when approving</span></label>
        </div>
      )}

      {step.type === 'return_to_originator' && (
        <div className="space-y-3">
          <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg text-sm text-orange-700"><strong>When this step is reached</strong>, the item is sent back to the person who originally submitted it with a mandatory reason. The workflow pauses until they resubmit.</div>
          <div className="space-y-1.5">
            <Label className="text-xs">Return message / instruction to originator</Label>
            <Textarea value={step.notification_template || ''} onChange={(e) => update("notification_template", e.target.value)} placeholder="Please review the comments below and resubmit with the required changes..." rows={2} className="text-sm" />
          </div>
          <label className="flex items-center gap-2 cursor-pointer"><Checkbox checked={step.return_reason_required !== false} onCheckedChange={(c) => update("return_reason_required", c)} /><span className="text-xs text-slate-700">Require return reason (recommended)</span></label>
          <div className="space-y-1.5">
            <Label className="text-xs">Additional CC emails when returning <span className="text-slate-400">(optional)</span></Label>
            <Input value={step.recipients?.join(', ') || ''} onChange={(e) => update("recipients", e.target.value.split(',').map(s => s.trim()).filter(Boolean))} placeholder="manager@example.com" className="h-8 text-sm" />
          </div>
        </div>
      )}

      {step.type === 'notification' && (
        <div className="space-y-3">
          <StepAssigneePicker label="Recipients" assigneeType={step.recipient_assignee_type || 'named_emails'} emails={step.recipients || []} groupIds={step.recipient_stakeholder_group_ids || []} stakeholderIds={step.recipient_named_stakeholder_ids || []} dynamicField={step.recipient_dynamic_role_field || ''} entityType={entityType} stakeholders={stakeholders} stakeholderGroups={stakeholderGroups} onChange={handleRecipientChange} />
          <div className="space-y-1.5">
            <Label className="text-xs">Email Template</Label>
            <Textarea value={step.notification_template || ''} onChange={(e) => update("notification_template", e.target.value)} placeholder="Your item {{entity_name}} requires attention..." rows={3} className="text-sm" />
            <p className="text-xs text-slate-400">Use {"{{entity_name}}"}, {"{{entity_type}}"}, {"{{actor}}"} as placeholders.</p>
          </div>
        </div>
      )}

      {step.type === 'action' && (
        <div className="space-y-3">
          <StepAssigneePicker label="Assigned To" assigneeType={step.recipient_assignee_type || 'named_emails'} emails={step.recipients || []} groupIds={step.recipient_stakeholder_group_ids || []} stakeholderIds={step.recipient_named_stakeholder_ids || []} dynamicField={step.recipient_dynamic_role_field || ''} entityType={entityType} stakeholders={stakeholders} stakeholderGroups={stakeholderGroups} onChange={handleRecipientChange} />
          <div className="space-y-1.5">
            <Label className="text-xs">Action Description / Instructions</Label>
            <Textarea value={step.notification_template || ''} onChange={(e) => update("notification_template", e.target.value)} placeholder="Describe the action to be performed..." rows={2} className="text-sm" />
          </div>
          <label className="flex items-center gap-2 cursor-pointer"><Checkbox checked={!!step.comment_required} onCheckedChange={(c) => update("comment_required", c)} /><span className="text-xs text-slate-700">Require completion comment</span></label>
        </div>
      )}

      {step.type === 'conditional' && (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-1.5"><Label className="text-xs">Field Name</Label><Input value={step.condition_field || ''} onChange={(e) => update("condition_field", e.target.value)} placeholder="e.g. criticality" className="h-8 text-sm" /></div>
            <div className="space-y-1.5"><Label className="text-xs">Operator</Label><Select value={step.condition_operator || 'equals'} onValueChange={(v) => update("condition_operator", v)}><SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="equals">Equals</SelectItem><SelectItem value="not_equals">Not Equals</SelectItem><SelectItem value="contains">Contains</SelectItem><SelectItem value="greater_than">Greater Than</SelectItem><SelectItem value="less_than">Less Than</SelectItem></SelectContent></Select></div>
            <div className="space-y-1.5"><Label className="text-xs">Value</Label><Input value={step.condition_value || ''} onChange={(e) => update("condition_value", e.target.value)} placeholder="e.g. critical" className="h-8 text-sm" /></div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5"><Label className="text-xs">If TRUE → go to step #</Label><Input type="number" min={1} value={step.condition_true_step != null ? step.condition_true_step + 1 : ''} onChange={(e) => update("condition_true_step", e.target.value ? parseInt(e.target.value) - 1 : null)} placeholder="Step number" className="h-8 text-sm" /></div>
            <div className="space-y-1.5"><Label className="text-xs">If FALSE → go to step #</Label><Input type="number" min={1} value={step.condition_false_step != null ? step.condition_false_step + 1 : ''} onChange={(e) => update("condition_false_step", e.target.value ? parseInt(e.target.value) - 1 : null)} placeholder="Step number" className="h-8 text-sm" /></div>
          </div>
        </div>
      )}

      {step.type === 'escalation' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label className="text-xs">Escalate after (days)</Label><Input type="number" min={1} value={step.escalation_after_days || 3} onChange={(e) => update("escalation_after_days", parseInt(e.target.value) || 3)} className="h-8 text-sm" /></div>
            <div className="space-y-1.5"><Label className="text-xs">Escalate to (emails)</Label><Input value={step.escalation_emails?.join(', ') || ''} onChange={(e) => update("escalation_emails", e.target.value.split(',').map(s => s.trim()).filter(Boolean))} placeholder="manager@example.com" className="h-8 text-sm" /></div>
          </div>
          <div className="space-y-1.5"><Label className="text-xs">Escalation message</Label><Textarea value={step.notification_template || ''} onChange={(e) => update("notification_template", e.target.value)} placeholder="This item has been escalated because no action was taken within {{days}} days..." rows={2} className="text-sm" /></div>
        </div>
      )}

      {step.type === 'delay' && (
        <div className="space-y-1.5">
          <Label className="text-xs">Wait duration (hours)</Label>
          <Input type="number" min={1} value={step.delay_hours || 24} onChange={(e) => update("delay_hours", parseInt(e.target.value) || 24)} className="h-8 text-sm w-40" />
          <p className="text-xs text-slate-400">The workflow will pause for this many hours before advancing to the next step.</p>
        </div>
      )}
    </div>
  );
}