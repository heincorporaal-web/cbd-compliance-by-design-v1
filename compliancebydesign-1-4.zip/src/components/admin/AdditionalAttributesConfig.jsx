import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Pencil, Trash2, GripVertical, Tag } from "lucide-react";
import { toast } from "sonner";

const ENTITY_TYPES = ["Risk", "Control", "OrgProcess", "ICTSystem", "ThirdPartyProvider", "Incident"];
const DATA_TYPES = [
  { value: "text", label: "Text (single line)" },
  { value: "long_text", label: "Long Text (multi-line)" },
  { value: "date", label: "Date" },
  { value: "number", label: "Number" },
  { value: "boolean", label: "Yes/No (Boolean)" },
];

const emptyForm = {
  name: "",
  label: "",
  description: "",
  data_type: "text",
  entity_type: "Risk",
  company_id: "",
  sort_order: 0,
  is_required: false,
  is_active: true,
};

export default function AdditionalAttributesConfig() {
  const queryClient = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [filterEntity, setFilterEntity] = useState("all");

  const { data: attributes = [], isLoading } = useQuery({
    queryKey: ["additional-attributes"],
    queryFn: () => base44.entities.AdditionalAttribute.list("sort_order"),
  });

  const { data: companies = [] } = useQuery({
    queryKey: ["companies"],
    queryFn: () => base44.entities.Company.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.AdditionalAttribute.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["additional-attributes"]);
      toast.success("Additional attribute created");
      setShowDialog(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AdditionalAttribute.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["additional-attributes"]);
      toast.success("Additional attribute updated");
      setShowDialog(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.AdditionalAttribute.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(["additional-attributes"]);
      toast.success("Additional attribute deleted");
    },
  });

  const openCreate = () => {
    setForm(emptyForm);
    setEditingId(null);
    setShowDialog(true);
  };

  const openEdit = (attr) => {
    setForm({
      name: attr.name || "",
      label: attr.label || "",
      description: attr.description || "",
      data_type: attr.data_type || "text",
      entity_type: attr.entity_type || "Risk",
      company_id: attr.company_id || "",
      sort_order: attr.sort_order || 0,
      is_required: !!attr.is_required,
      is_active: attr.is_active !== false,
    });
    setEditingId(attr.id);
    setShowDialog(true);
  };

  const handleSave = () => {
    if (!form.name.trim() || !form.label.trim()) {
      toast.error("Name and Label are required");
      return;
    }
    const payload = { ...form, name: form.name.trim().replace(/\s+/g, "_") };
    if (editingId) {
      updateMutation.mutate({ id: editingId, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const filtered = attributes
    .filter((a) => filterEntity === "all" || a.entity_type === filterEntity)
    .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

  const companyName = (id) => companies.find((c) => c.id === id)?.name;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-base font-semibold text-slate-800">Additional Attributes</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Define configurable custom fields (text, long text, date, number, boolean) that appear on Risk, Control, Process, ICT System, Third Party and Incident records. Option lists are not supported.
          </p>
        </div>
        <Button onClick={openCreate} size="sm">
          <Plus className="w-4 h-4 mr-1.5" /> New Attribute
        </Button>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs text-slate-500">Filter by record type:</span>
        <Select value={filterEntity} onValueChange={setFilterEntity}>
          <SelectTrigger className="w-48 h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All record types</SelectItem>
            {ENTITY_TYPES.map((t) => (
              <SelectItem key={t} value={t}>{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <p className="text-sm text-slate-500">Loading…</p>
      ) : filtered.length === 0 ? (
        <Card className="border-2 border-dashed border-slate-200 bg-slate-50">
          <CardContent className="p-10 text-center text-slate-500">
            <Tag className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            No additional attributes defined yet. Click "New Attribute" to create one.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((attr) => (
            <Card key={attr.id} className="border border-slate-200 shadow-sm">
              <CardContent className="p-3 flex items-center gap-3 flex-wrap">
                <GripVertical className="w-4 h-4 text-slate-300 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-slate-900 text-sm">{attr.label}</span>
                    <Badge variant="outline" className="text-[10px]">{attr.name}</Badge>
                    <Badge variant="secondary" className="text-[10px]">{attr.data_type}</Badge>
                    <Badge variant="outline" className="text-[10px]">{attr.entity_type}</Badge>
                    {attr.is_required && (
                      <Badge className="text-[10px] bg-amber-100 text-amber-700 border-amber-200">Required</Badge>
                    )}
                    {!attr.is_active && (
                      <Badge variant="outline" className="text-[10px] text-slate-400">Inactive</Badge>
                    )}
                  </div>
                  {attr.description && (
                    <p className="text-xs text-slate-500 mt-0.5 truncate">{attr.description}</p>
                  )}
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Scope: {attr.company_id ? companyName(attr.company_id) || "Specific company" : "All companies"}
                  </p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => openEdit(attr)} title="Edit">
                  <Pencil className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    if (confirm(`Delete attribute "${attr.label}"? Stored values on existing records will be preserved but no longer displayed.`)) {
                      deleteMutation.mutate(attr.id);
                    }
                  }}
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Additional Attribute" : "New Additional Attribute"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Field Name (key) *</Label>
                <Input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. regulatory_reference"
                  className="h-9"
                />
                <p className="text-[10px] text-slate-400">No spaces; used as the storage key.</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Display Label *</Label>
                <Input
                  value={form.label}
                  onChange={(e) => setForm({ ...form, label: e.target.value })}
                  placeholder="e.g. Regulatory Reference"
                  className="h-9"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Record Type *</Label>
                <Select value={form.entity_type} onValueChange={(v) => setForm({ ...form, entity_type: v })}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ENTITY_TYPES.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Data Type *</Label>
                <Select value={form.data_type} onValueChange={(v) => setForm({ ...form, data_type: v })}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DATA_TYPES.map((d) => (
                      <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Company Scope</Label>
                <Select
                  value={form.company_id || "__all__"}
                  onValueChange={(v) => setForm({ ...form, company_id: v === "__all__" ? "" : v })}
                >
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__all__">All companies (global)</SelectItem>
                    {companies.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Sort Order</Label>
                <Input
                  type="number"
                  value={form.sort_order}
                  onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) })}
                  className="h-9"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs">Description / Help Text</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={2}
                placeholder="Optional guidance shown under the field"
              />
            </div>

            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={form.is_required} onCheckedChange={(v) => setForm({ ...form, is_required: !!v })} />
                Required
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: !!v })} />
                Active
              </label>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowDialog(false)}>Cancel</Button>
              <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
                {editingId ? "Save Changes" : "Create Attribute"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}