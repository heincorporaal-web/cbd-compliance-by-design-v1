import React, { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ClipboardCheck, Download, Upload, Loader2, CheckCircle, AlertCircle, Trash2, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const CSV_HEADERS = [
  "ControlRef", "ControlTitle", "ControlDesc", "Category", "Framework",
  "Global", "ControlCCM", "SelfAssessment",
  "ControlCriticality", "ControlOwner", "KeyControl", "ControlExecutionType",
  "ControlType", "FinanceControlConsideration", "ControlFrequency",
  "CompensatingControl", "CompensatingControlRisk", "ControlNarrativeURL",
  "Upload Document", "ControlObjectiveID", "ProcessPhase", "RiskID",
];

function escapeCsv(val) {
  if (val === null || val === undefined) return "";
  const s = String(val);
  if (s.includes(",") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export default function ControlLibraryImportPanel() {
  const queryClient = useQueryClient();
  const fileRef = useRef(null);
  const [mode, setMode] = useState("append");
  const [result, setResult] = useState(null);

  const { data: libraryControls = [], isLoading } = useQuery({
    queryKey: ["libraryControls"],
    queryFn: () => base44.entities.Control.filter({ is_library_control: true }, "-created_date", 10000),
  });

  const importMutation = useMutation({
    mutationFn: async ({ file, importMode }) => {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      return base44.functions.invoke("importControlLibrary", { file_url, mode: importMode });
    },
    onSuccess: (data) => {
      const d = data?.data ?? data;
      if (d?.success) {
        const skippedNote = d.skipped > 0 ? ` Skipped ${d.skipped} rows (unresolved framework).` : "";
        const msg = d.mode === "purge"
          ? `Purged ${d.purged} controls, then imported ${d.created} new controls.${skippedNote}`
          : `Updated ${d.updated} existing controls, created ${d.created} new controls.${skippedNote}`;
        const fullMsg = d.skippedRefs?.length > 0
          ? `${msg} Skipped refs: ${d.skippedRefs.join(", ")}${d.skipped > d.skippedRefs.length ? "…" : ""}`
          : msg;
        setResult({ success: true, message: fullMsg });
        toast.success(`Control Library: ${msg}`);
      } else {
        setResult({ success: false, message: d?.error || "Import failed" });
        toast.error("Control Library import failed");
      }
      queryClient.invalidateQueries({ queryKey: ["libraryControls"] });
    },
    onError: (err) => {
      const msg = err?.response?.data?.error || err.message || "Import failed";
      setResult({ success: false, message: msg });
      toast.error("Control Library import failed: " + msg);
    },
  });

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setResult(null);
    importMutation.mutate({ file, importMode: mode });
    e.target.value = "";
  };

  const handleDownload = () => {
    if (libraryControls.length === 0) {
      toast.error("No library controls to export");
      return;
    }
    const rows = libraryControls.map(c => [
      c.control_id || "",
      c.title || "",
      c.description || "",
      c.category || "",
      c.framework_id || "",
      c.global ? "1" : "0",
      c.control_ccm ? "1" : "0",
      c.self_assessment ? "1" : "0",
      c.control_criticality || "Should Have",
      c.control_owner || "",
      c.key_control ? "1" : "0",
      c.control_execution_type || "Manual",
      c.control_type || "Preventive",
      c.finance_control_consideration ? "1" : "0",
      c.control_frequency || "Monthly",
      c.compensating_control ? "1" : "0",
      c.compensating_control_risk || "",
      c.control_narrative_url || "",
      c.upload_document || "0",
      c.control_objective_id || "",
      c.process_phase || "Process - Input",
      c.risk_id || "",
    ]);
    const csv = [CSV_HEADERS.join(","), ...rows.map(r => r.map(escapeCsv).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `control_library_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${libraryControls.length} library controls`);
  };

  return (
    <Card className="border border-slate-200 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <ClipboardCheck className="w-5 h-5 text-emerald-600" />
          Control Library
          <Badge variant="outline" className="text-slate-500 ml-1">
            {isLoading ? "…" : `${libraryControls.length} controls`}
          </Badge>
        </CardTitle>
        <p className="text-sm text-slate-500">
          Download the seeded control library to CSV, or upload to purge-and-replace or append-and-override (matched by ControlRef). The <strong>Framework</strong> column (code or name) is required — rows without a resolvable framework are skipped.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Download */}
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownload}
            disabled={isLoading || libraryControls.length === 0}
          >
            <Download className="w-4 h-4" />
            Download Library ({libraryControls.length})
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => queryClient.invalidateQueries({ queryKey: ["libraryControls"] })}
            disabled={isLoading}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </Button>
        </div>

        {/* Mode selector */}
        <div className="flex items-center gap-2 border-t border-slate-100 pt-3">
          <span className="text-sm font-medium text-slate-600 mr-2">Upload mode:</span>
          <button
            className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
              mode === "append"
                ? "bg-blue-50 border-blue-300 text-blue-700"
                : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
            }`}
            onClick={() => setMode("append")}
          >
            Append / Override
          </button>
          <button
            className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
              mode === "purge"
                ? "bg-red-50 border-red-300 text-red-700"
                : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
            }`}
            onClick={() => setMode("purge")}
          >
            <Trash2 className="w-3.5 h-3.5 inline mr-1" />
            Purge & Replace
          </button>
        </div>
        <p className="text-xs text-slate-400">
          {mode === "append"
            ? "Existing controls with the same ControlRef will be overridden with the uploaded values. New controls will be appended."
            : "⚠ All existing library controls will be permanently deleted before importing the new set from the file."}
        </p>

        {/* Upload */}
        <div
          className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center hover:border-emerald-300 hover:bg-emerald-50/30 transition-colors cursor-pointer"
          onClick={() => fileRef.current?.click()}
        >
          {importMutation.isPending ? (
            <Loader2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 animate-spin" />
          ) : (
            <Upload className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          )}
          <p className="text-sm font-medium text-slate-600">
            {importMutation.isPending ? "Uploading…" : "Click to upload or drag & drop"}
          </p>
          <p className="text-xs text-slate-400 mt-1">Supported: .xlsx, .xls, .csv</p>
          <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFileChange} />
        </div>

        {result && (
          <div className={`p-3 rounded-lg flex items-start gap-2 text-sm ${
            result.success ? "bg-green-50 border border-green-200 text-green-800" : "bg-red-50 border border-red-200 text-red-800"
          }`}>
            {result.success
              ? <CheckCircle className="w-4 h-4 mt-0.5 shrink-0" />
              : <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            }
            <span>{result.message}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}