import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard, Building2, Shield, ClipboardCheck, Server,
  AlertTriangle, Users, AlertCircle, ClipboardList, TriangleAlert,
  Target, FileCheck, Network, GitBranch, Cog, FileText, Star,
  ChevronDown, ChevronRight, BookOpen, Settings, Layers, Globe,
  Activity, X, PlusCircle, Sparkles, Cpu, Search, ShieldCheck, HelpCircle, MessageCircle, SlidersHorizontal, Folder, ShieldAlert, CalendarClock, Gauge, Info,
  Presentation, FileSpreadsheet, Workflow, Palette, Boxes, Database, GitCompare, GitCommitVertical, LayoutTemplate,
  Wrench, FileSearch, FileInput, Download
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useIsAuditRole } from "@/hooks/useIsAuditRole";
import { useIsImplementerRole } from "@/hooks/useIsImplementerRole";
import OverviewIconCustomizer from "@/components/layout/OverviewIconCustomizer";
import ModuleNavigator from "@/components/layout/ModuleNavigator";
import { resolveIcon, buildCustomIconMap, CUSTOM_ICON_PREFIX } from "@/lib/navIconStore";
import { useQuery, useQueryClient } from "@tanstack/react-query";

// ─── Navigation tree definition ──────────────────────────────────────────────
export const NAV_GROUPS = [
  {
    id: "overview",
    label: "Overview",
    icon: LayoutDashboard,
    items: [
      { id: "my_actions", title: "My Actions", url: createPageUrl("MyActions"), icon: CalendarClock },
      { id: "dashboard", title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard },
      { id: "companies", title: "Companies", url: createPageUrl("Companies"), icon: Building2 },
      { id: "business_units", title: "Business Units", url: createPageUrl("BusinessUnits"), icon: Network },
      { id: "knowledge", title: "Knowledge", url: createPageUrl("KnowledgeManagement"), icon: BookOpen },
      { id: "getting_started", title: "Getting Started", url: createPageUrl("GettingStarted"), icon: HelpCircle },
      { id: "help_centre", title: "Help Centre", url: createPageUrl("HelpCentre"), icon: MessageCircle },
      { id: "about", title: "About", url: createPageUrl("About"), icon: Info },
    ],
  },
  {
    id: "governance",
    label: "Governance",
    icon: Shield,
    items: [
      { id: "frameworks", title: "Frameworks", url: createPageUrl("Frameworks"), icon: Shield },
      { id: "controls", title: "Controls", url: createPageUrl("Controls"), icon: Shield },
      { id: "control_objectives", title: "Control Objectives", url: createPageUrl("ControlObjectives"), icon: Target },
      { id: "control_assessment_cycles", title: "Control Assessment Cycles", url: createPageUrl("ControlAssessmentCycles"), icon: ClipboardList },
      { id: "risk_assessment_cycles", title: "Assessment Cycles", url: createPageUrl("RiskAssessmentCycles"), icon: ClipboardList },
      { id: "assessments", title: "Assessments", url: createPageUrl("Assessments"), icon: ClipboardCheck },
      { id: "process_assessments", title: "Process Assessments", url: createPageUrl("ProcessAssessments"), icon: ClipboardCheck },
      { id: "assessment_models", title: "Assessment Models", url: createPageUrl("AssessmentModels"), icon: SlidersHorizontal },
      { id: "framework_mapper", title: "Framework Mapper (AI)", url: createPageUrl("FrameworkControlMapper"), icon: Sparkles },
      { id: "grc_goals", title: "GRC Goals", url: createPageUrl("GRCGoals"), icon: Target },
      { id: "balanced_scorecards", title: "Balanced Scorecards", url: createPageUrl("BalancedScorecards"), icon: Gauge },
      { id: "org_objectives", title: "Org. Objectives", url: createPageUrl("ObjectivesSummary"), icon: Target },
      { id: "root_cause_categories", title: "Root Cause Categories", url: createPageUrl("RootCauseCategories"), icon: AlertCircle },
    ],
  },
  {
    id: "risk",
    label: "Risk Management",
    icon: TriangleAlert,
    items: [
      { id: "risk_register", title: "Risk Register", url: createPageUrl("RiskRegister"), icon: TriangleAlert },
      { id: "risk_engine", title: "Risk Engine", url: createPageUrl("RiskControlEngine"), icon: Cog },
      { id: "raci_matrix", title: "RACI Matrix", url: createPageUrl("RACIMatrix"), icon: Layers },
      { id: "principal_risks", title: "Principal Risks", url: createPageUrl("PrincipalRisksSummary"), icon: ShieldAlert },
      { id: "third_parties", title: "Third Parties", url: createPageUrl("ThirdParties"), icon: Globe },
      { id: "advanced_tprm", title: "Partner by Design (PBD)", url: createPageUrl("PartnerByDesign"), icon: ShieldAlert },
      { id: "issues", title: "Issues", url: createPageUrl("Issues"), icon: AlertCircle },
      { id: "incidents", title: "Incidents", url: createPageUrl("Incidents"), icon: AlertTriangle },
    ],
  },
  {
    id: "compliance",
    label: "Compliance",
    icon: ClipboardCheck,
    items: [
      { id: "surveys", title: "Surveys", url: createPageUrl("Surveys"), icon: ClipboardList },
      { id: "evidence_library", title: "Evidence Library", url: createPageUrl("EvidenceLibrary"), icon: Folder },
    ],
  },
  {
    id: "process",
    label: "Process & Systems",
    icon: Network,
    items: [
      { id: "ihpom", title: "iHPOM Repository", url: createPageUrl("iHPOM"), icon: Network },
      { id: "process_mgmt", title: "Process Management", url: createPageUrl("ProcessManagement"), icon: Network },
      { id: "ict_systems", title: "ICT Systems", url: createPageUrl("ICTSystems"), icon: Server },
      { id: "it_capabilities", title: "IT Capabilities", url: createPageUrl("ITCapabilities"), icon: Cpu },
      { id: "value_chains", title: "Value Chains", url: createPageUrl("ValueChains"), icon: Network },
      { id: "advanced_process_modelling", title: "Operations by Design (OBD)", url: createPageUrl("OperationsByDesign"), icon: Workflow },
      { id: "assets_by_design", title: "Assets by Design (ABD)", url: createPageUrl("AssetsByDesign"), icon: Boxes },
      { id: "cmdb_dashboard", title: "CMDB Dashboard", url: createPageUrl("CMDBDashboard"), icon: LayoutDashboard },
      { id: "cmdb_inventory", title: "CMDB Inventory", url: createPageUrl("CMDBInventory"), icon: Boxes },
      { id: "cmdb_applications", title: "CBD Applications", url: createPageUrl("CMDBApplications"), icon: Layers },
      { id: "process_assignment_gaps", title: "Assignment Gap Finder", url: createPageUrl("StakeholderAssignmentGaps"), icon: ShieldAlert },
      { id: "scenario_planning", title: "Scenario Planning", url: createPageUrl("ScenarioPlanning"), icon: GitCompare },
    ],
  },
  {
    id: "reports_group",
    label: "Reports",
    icon: FileText,
    items: [
      { id: "report_centre", title: "Report Centre", url: createPageUrl("ReportTemplateStudio"), icon: LayoutTemplate },
      { id: "reports_all", title: "All Reports", url: createPageUrl("Reports"), icon: FileText },
      { id: "performance_management", title: "Performance Management", url: createPageUrl("PerformanceManagement"), icon: Presentation },
      { id: "data_libraries", title: "Data Libraries", url: createPageUrl("DataLibraries"), icon: FileSpreadsheet },
      { id: "issue_management", title: "Issue Management", url: createPageUrl("IssueManagement"), icon: AlertCircle },
      { id: "matrices", title: "Matrices", url: createPageUrl("Matrices"), icon: Layers },
      { id: "enterprise_diagnostics", title: "Diagnostics & Opportunities", url: createPageUrl("EnterpriseDiagnostics"), icon: Gauge },
      { id: "technology_intelligence", title: "Technology Intelligence", url: createPageUrl("TechnologyIntelligence"), icon: Cpu },
    ],
  },
  {
    id: "stakeholders",
    label: "Stakeholders",
    icon: Users,
    items: [
      { id: "stakeholders", title: "Stakeholder Management", url: createPageUrl("Stakeholders"), icon: Users },
      { id: "stakeholder_groups", title: "Stakeholder Groups", url: createPageUrl("Stakeholders") + "?tab=groups", icon: Users },
      { id: "stakeholder_hierarchy", title: "Stakeholder Hierarchy", url: createPageUrl("StakeholderHierarchy"), icon: GitBranch },
      { id: "sign_offs", title: "Sign-Offs", url: createPageUrl("SignOffs"), icon: FileCheck },
      { id: "doa", title: "Delegation of Authority", url: createPageUrl("DelegationOfAuthority"), icon: ShieldCheck },
    ],
  },
  {
    id: "admin",
    label: "Administration",
    icon: Settings,
    items: [
      { id: "users", title: "Users", url: createPageUrl("Users"), icon: Users },
      { id: "roles", title: "Roles", url: createPageUrl("Roles"), icon: Layers },
      { id: "audit_logs", title: "Audit Logs", url: createPageUrl("AuditLogs"), icon: Activity },
      { id: "version_history", title: "Version History", url: createPageUrl("VersionHistory"), icon: GitCommitVertical },
    ],
  },
  {
    id: "utilities",
    label: "Utilities",
    icon: Wrench,
    items: [
      { id: "seeded_libraries", title: "Seed Master Libraries", url: createPageUrl("SeedLibraries"), icon: Database },
      { id: "control_expansion_import", title: "Control Expansion Import", url: createPageUrl("ControlExpansionImport"), icon: FileInput },
      { id: "cross_entity_audit", title: "Cross-Entity Audit", url: createPageUrl("CrossEntityAudit"), icon: FileSearch },
      { id: "hierarchy_audit", title: "Hierarchy Audit", url: createPageUrl("HierarchyAudit"), icon: GitBranch },
      { id: "integrity_audit", title: "Integrity Audit", url: createPageUrl("IntegrityAudit"), icon: ShieldAlert },
      { id: "data_export", title: "Data Export Templates", url: createPageUrl("DataExport"), icon: Download },
    ],
  },
  {
    id: "configuration",
    label: "Configuration",
    icon: Cog,
    items: [
      { id: "workflows", title: "Workflows", url: createPageUrl("Workflows"), icon: GitBranch },
      { id: "workflow_visual_map", title: "Workflow Visual Map", url: createPageUrl("WorkflowVisualMap"), icon: Workflow },
      { id: "configuration", title: "Configuration & Imports", url: createPageUrl("Configuration"), icon: Settings },
      { id: "admin_playbooks", title: "Admin Playbooks", url: createPageUrl("AdminPlaybooks"), icon: BookOpen },
    ],
  },
];

// Flatten all items for quick lookup
export const ALL_NAV_ITEMS = NAV_GROUPS.flatMap(g => g.items);

// ─── Storage helpers ─────────────────────────────────────────────────────────
const getFavKey = (userId) => `cbd_favorites_${userId || "guest"}`;

const loadFavorites = (userId) => {
  try {
    return JSON.parse(localStorage.getItem(getFavKey(userId)) || "[]");
  } catch {
    return [];
  }
};

const saveFavorites = (userId, favs) => {
  localStorage.setItem(getFavKey(userId), JSON.stringify(favs));
  // Notify same-tab listeners (storage event only fires in other tabs)
  window.dispatchEvent(new CustomEvent("cbd_favorites_changed", { detail: { userId, favs } }));
};

// ─── Single nav link ──────────────────────────────────────────────────────────
function NavLink({ item, isActive, favorites, onToggleFav, showFavBtn = false, customIcons, customIconMap }) {
  const isFav = favorites.includes(item.id);
  const Icon = resolveIcon(customIcons, item.id, item.icon, customIconMap);
  return (
    <div className="group flex items-center rounded-lg hover:bg-slate-50 transition-colors">
      <Link
        to={item.url}
        className={`flex items-center gap-2.5 px-3 py-2 flex-1 min-w-0 text-sm ${
          isActive ? "text-primary font-semibold" : "text-slate-700"
        }`}
      >
        <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-primary" : "text-slate-500"}`} />
        <span className="truncate">{item.title}</span>
      </Link>
      {showFavBtn && (
        <button
          onClick={(e) => { e.preventDefault(); onToggleFav(item.id); }}
          className={`mr-2 p-1 rounded opacity-0 group-hover:opacity-100 transition-opacity ${
            isFav ? "opacity-100 text-amber-500" : "text-slate-400 hover:text-amber-500"
          }`}
          title={isFav ? "Remove from favourites" : "Add to favourites"}
        >
          <Star className={`w-3.5 h-3.5 ${isFav ? "fill-amber-400" : ""}`} />
        </button>
      )}
    </div>
  );
}

// ─── Collapsible group ────────────────────────────────────────────────────────
const groupColors = {
  overview: "text-secondary font-medium",
  governance: "text-secondary font-medium",
  risk: "text-secondary font-medium",
  compliance: "text-secondary font-medium",
  process: "text-secondary font-medium",
  stakeholders: "text-secondary font-medium",
  admin: "text-secondary font-medium",
  utilities: "text-secondary font-medium",
  configuration: "text-secondary font-medium",
};

function NavGroup({ group, location, favorites, onToggleFav, defaultOpen = false, customIcons, customIconMap, extra }) {
  const [open, setOpen] = useState(defaultOpen);
  const hasActive = group.items.some(i => location.pathname === i.url);

  // Auto-open if any child is active
  useEffect(() => {
    if (hasActive) setOpen(true);
  }, [hasActive]);

  return (
    <div className="mb-1">
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-secondary font-medium uppercase tracking-wider transition-colors hover:bg-slate-100"
      >
        <group.icon className="w-3.5 h-3.5 shrink-0" />
        <span className="flex-1 text-left">{group.label}</span>
        {open ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
      </button>
      {open && (
        <div className="ml-2 mt-0.5 border-l-2 border-slate-200 pl-2 space-y-0.5">
          {group.items.map(item => (
            <NavLink
              key={item.id}
              item={item}
              isActive={location.pathname === item.url}
              favorites={favorites}
              onToggleFav={onToggleFav}
              showFavBtn
              customIcons={customIcons}
              customIconMap={customIconMap}
            />
          ))}
          {extra}
        </div>
      )}
    </div>
  );
}

// ─── Main NavTree ─────────────────────────────────────────────────────────────
export default function NavTree() {
  const location = useLocation();
  const [userId, setUserId] = useState(null);
  const [user, setUser] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [favOpen, setFavOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [iconDialogOpen, setIconDialogOpen] = useState(false);
  const queryClient = useQueryClient();
  const { canImport } = useIsImplementerRole();

  useEffect(() => {
    base44.auth.me().then(u => {
      if (u) {
        setUser(u);
        setUserId(u.id);
        setFavorites(loadFavorites(u.id));
      }
    }).catch(() => {
      setFavorites(loadFavorites(null));
    });
  }, []);

  const { data: metas = [] } = useQuery({
    queryKey: ["appMeta"],
    queryFn: () => base44.entities.AppMeta.list("-updated_date", 1),
  });
  const meta = metas[0];
  const navIcons = meta?.nav_icon_overrides || {};

  const { data: customIconRecords = [] } = useQuery({
    queryKey: ["customIcons"],
    queryFn: () => base44.entities.CustomIcon.list("-updated_date", 200),
  });
  const customIconMap = buildCustomIconMap(customIconRecords);

  // Always read the latest overrides from the query cache so rapid successive
  // edits merge on top of the most recent state (not a stale render snapshot).
  const latestOverrides = () => {
    const cached = queryClient.getQueryData(["appMeta"]);
    const m = Array.isArray(cached) ? cached[0] : cached;
    return m?.nav_icon_overrides || {};
  };

  const persistOverrides = async (next) => {
    const payload = {
      nav_icon_overrides: next,
      last_updated_by: user?.full_name || user?.email || "admin",
    };
    const current = queryClient.getQueryData(["appMeta"]);
    const m = Array.isArray(current) ? current[0] : current;
    if (m) await base44.entities.AppMeta.update(m.id, payload);
    else await base44.entities.AppMeta.create({ app_name: "GRC Platform", ...payload });
    queryClient.invalidateQueries(["appMeta"]);
  };

  const setNavItemIcon = (itemId, name) =>
    persistOverrides({ ...latestOverrides(), [itemId]: name }).catch(() => {});
  const resetNavItemIcon = (itemId) => {
    const next = { ...latestOverrides() };
    delete next[itemId];
    persistOverrides(next).catch(() => {});
  };

  const addCustomIcon = async (name, svg) => {
    const rec = await base44.entities.CustomIcon.create({ name, svg });
    queryClient.invalidateQueries(["customIcons"]);
    return rec;
  };
  const deleteCustomIcon = async (id) => {
    // Clear any nav overrides that reference this custom icon first.
    const overrides = latestOverrides();
    const ref = CUSTOM_ICON_PREFIX + id;
    const next = { ...overrides };
    for (const k of Object.keys(next)) if (next[k] === ref) delete next[k];
    await base44.entities.CustomIcon.delete(id);
    if (JSON.stringify(next) !== JSON.stringify(overrides)) await persistOverrides(next);
    queryClient.invalidateQueries(["customIcons"]);
  };

  const toggleFav = (itemId) => {
    const next = favorites.includes(itemId)
      ? favorites.filter(f => f !== itemId)
      : [...favorites, itemId];
    setFavorites(next);
    saveFavorites(userId, next);
  };

  const favItems = ALL_NAV_ITEMS.filter(i => favorites.includes(i.id));

  const searchResults = searchQuery.trim()
    ? ALL_NAV_ITEMS.filter(i => i.title.toLowerCase().includes(searchQuery.toLowerCase()))
    : null;

  return (
    <div className="space-y-1 py-2">
      {/* Add-on module navigator */}
      <ModuleNavigator />

      <div className="border-t border-slate-200 my-2" />

      {/* Search bar */}
      <div className="px-2 pb-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search menu…"
            className="w-full pl-8 pr-8 py-1.5 text-sm bg-slate-100 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30 focus:bg-white transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Search results */}
      {searchResults && (
        <div className="mb-2">
          <p className="px-3 py-1 text-xs font-semibold uppercase tracking-wider text-slate-400">
            {searchResults.length} result{searchResults.length !== 1 ? "s" : ""}
          </p>
          <div className="ml-2 border-l-2 border-primary/30 pl-2 space-y-0.5">
            {searchResults.length === 0 ? (
              <p className="text-xs text-slate-400 px-3 py-2 italic">No matches found.</p>
            ) : searchResults.map(item => (
              <NavLink
                key={item.id}
                item={item}
                isActive={location.pathname === item.url}
                favorites={favorites}
                onToggleFav={toggleFav}
                showFavBtn
                customIcons={navIcons}
                customIconMap={customIconMap}
              />
            ))}
          </div>
          <div className="border-t border-slate-200 mt-2" />
        </div>
      )}

      {/* Hint */}
      <div className="px-3 py-2 mb-1">
        <p className="text-xs text-slate-400 italic flex items-center gap-1.5">
          <Star className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />
          Star an item to add it to your Quick Actions toolbar on the right.
        </p>
      </div>

      <div className="border-t border-slate-200 my-2" />

      {/* Nav groups — hide when searching */}
      {!searchResults && NAV_GROUPS.filter(g => g.id !== "configuration").map((group, i) => (
        <NavGroup
          key={group.id}
          group={group}
          location={location}
          favorites={favorites}
          onToggleFav={toggleFav}
          defaultOpen={i === 0}
          customIcons={navIcons}
          customIconMap={customIconMap}
        />
      ))}

      {/* Configuration group — restricted to implementers & product owners */}
      {!searchResults && canImport && (() => {
        const cfgGroup = NAV_GROUPS.find(g => g.id === "configuration");
        if (!cfgGroup) return null;
        return (
          <NavGroup
            key={cfgGroup.id}
            group={cfgGroup}
            location={location}
            favorites={favorites}
            onToggleFav={toggleFav}
            customIcons={navIcons}
            customIconMap={customIconMap}
            extra={
              <div className="group flex items-center rounded-lg hover:bg-slate-50 transition-colors">
                <button
                  onClick={() => setIconDialogOpen(true)}
                  className="flex items-center gap-2.5 px-3 py-2 flex-1 min-w-0 text-sm text-slate-700 hover:text-primary"
                >
                  <Palette className="w-4 h-4 shrink-0 text-slate-500" />
                  <span className="truncate">Customise menu icons</span>
                </button>
              </div>
            }
          />
        );
      })()}

      {canImport && (
        <OverviewIconCustomizer
          open={iconDialogOpen}
          onClose={() => setIconDialogOpen(false)}
          groups={NAV_GROUPS}
          customIcons={navIcons}
          customIconRecords={customIconRecords}
          onSetIcon={setNavItemIcon}
          onResetIcon={resetNavItemIcon}
          onAddCustomIcon={addCustomIcon}
          onDeleteCustomIcon={deleteCustomIcon}
        />
      )}
    </div>
  );
}