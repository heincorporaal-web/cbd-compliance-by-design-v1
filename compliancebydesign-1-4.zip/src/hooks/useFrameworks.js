import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

/**
 * Loads all frameworks and returns a deduplicated, alphabetically sorted list.
 * Deduplication is by name (case-insensitive), preferring master frameworks.
 * This ensures dropdowns never show duplicate framework entries.
 */
export function useFrameworks() {
  const query = useQuery({
    queryKey: ['frameworks'],
    queryFn: () => base44.entities.Framework.list('-created_date', 500),
  });

  const frameworks = useMemo(() => {
    const all = query.data || [];
    // Sort: active first, then master frameworks — both preferred during dedup
    const sorted = [...all].sort((a, b) => {
      const aActive = a.status !== "archived" ? 1 : 0;
      const bActive = b.status !== "archived" ? 1 : 0;
      if (aActive !== bActive) return bActive - aActive;
      return (b.is_master ? 1 : 0) - (a.is_master ? 1 : 0);
    });
    const seen = new Map();
    for (const f of sorted) {
      // Dedup by name (case-insensitive)
      const nameKey = (f.name || "").toLowerCase().trim();
      if (nameKey && !seen.has(nameKey)) seen.set(nameKey, f);
    }
    // Second pass: dedup by framework_code (case-insensitive), preferring active
    const byCode = new Map();
    for (const f of seen.values()) {
      const codeKey = (f.framework_code || "").toLowerCase().trim();
      if (codeKey) {
        if (!byCode.has(codeKey)) byCode.set(codeKey, f);
      } else {
        byCode.set(`__nocode_${f.id}`, f);
      }
    }
    return Array.from(byCode.values()).sort((a, b) =>
      (a.name || "").localeCompare(b.name || "")
    );
  }, [query.data]);

  return { ...query, frameworks };
}