import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Plus, Edit2, Trash2, BarChart3, FileText, Settings, ClipboardList, Send, Users, ShieldCheck, Target, CheckCircle2 } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import MaturityScoreChart from "@/components/maturity/MaturityScoreChart";
import MaturityScoreSummary from "@/components/maturity/MaturityScoreSummary";
import MaturityTemplateEditor from "@/components/maturity/MaturityTemplateEditor";
import MaturityAssessmentForm from "@/components/maturity/MaturityAssessmentForm";
import MaturitySurveyTab from "@/components/maturity/MaturitySurveyTab";
import MaturityOwnerRollup from "@/components/maturity/MaturityOwnerRollup";
import ValidationTab from "@/components/maturity/ValidationTab";
import AspirationsTab from "@/components/maturity/AspirationsTab";
import { DEFAULT_MATURITY_TEMPLATE } from "@/lib/defaultMaturityTemplate";
import { DEFAULT_SCORING_CONFIG, buildScoringConfig } from "@/lib/maturityScoring";

export default function CapabilityMaturity() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [companyId] = useCompanyFilter();
  const [capabilities, setCapabilities] = useState([]);
  const [selectedCapId, setSelectedCapId] = useState(searchParams.get("capability_id") || "");
  const linkedProcessAssessmentId = searchParams.get("process_assessment_id") || "";

  useEffect(() => {
    const urlCapId = searchParams.get("capability_id");
    if (urlCapId && urlCapId !== selectedCapId) {
      setSelectedCapId(urlCapId);
    }
  }, [searchParams]);
  const [assessments, setAssessments] = useState([]);
  const [allAssessments, setAllAssessments] = useState([]);
  const [template, setTemplate] = useState(null);
  const [assessmentModels, setAssessmentModels] = useState([]);
  const [linkedModel, setLinkedModel] = useState(null);
  const [view, setView] = useState("list");
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [newAssessmentMeta, setNewAssessmentMeta] = useState({ name: "", date: "", target_score: 3, assessor_ids: [], ope_lead_id: "" });
  const [stakeholders, setStakeholders] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);

  const scoringConfig = useMemo(
    () => (linkedModel ? buildScoringConfig(linkedModel) : DEFAULT_SCORING_CONFIG),
    [linkedModel]
  );

  const loadCapabilities = useCallback(async () => {
    const query = companyId && companyId !== "all" ? { company_id: companyId } : {};
    const res = await base44.entities.ITCapability.filter(query, { sort: "name", limit: 500 });
    setCapabilities(res.items || []);
  }, [companyId]);

  const loadAssessments = useCallback(async (capId) => {
    if (!capId) { setAssessments([]); return; }
    const res = await base44.entities.CapabilityMaturityAssessment.filter(
      { capability_id: capId },
      { sort: "-assessment_date", limit: 100 }
    );
    setAssessments(res.items || []);
  }, []);

  const loadAllAssessments = useCallback(async () => {
    const query = companyId && companyId !== "all" ? { company_id: companyId } : {};
    const res = await base44.entities.CapabilityMaturityAssessment.filter(query, { sort: "-assessment_date", limit: 500 });
    setAllAssessments(res.items || []);
  }, [companyId]);

  const loadTemplate = useCallback(async (cid) => {
    if (!cid || cid === "all") { setTemplate(null); setLinkedModel(null); return; }
    const res = await base44.entities.MaturityAssessmentTemplate.filter(
      { company_id: cid },
      { limit: 10 }
    );
    if (res.items && res.items.length > 0) {
      setTemplate(res.items[0]);
    } else {
      setTemplate(null);
    }
  }, []);

  const loadStakeholders = useCallback(async (cid) => {
    if (!cid || cid === "all") { setStakeholders([]); return; }
    const res = await base44.entities.Stakeholder.filter({ company_id: cid }, { sort: "full_name", limit: 500, fields: ["full_name", "email", "job_title"] });
    setStakeholders(res.items || []);
  }, []);

  const loadAssessmentModels = useCallback(async (cid) => {
    if (!cid || cid === "all") { setAssessmentModels([]); return; }
    const res = await base44.entities.AssessmentModel.filter(
      { $or: [{ company_id: cid }, { is_global: true }] },
      { limit: 200 }
    );
    // Prefer Maturity Assessment models, but include all so users can pick any
    const sorted = (res.items || []).sort((a, b) => {
      const am = a.analysis_type === "Maturity Assessment" ? 0 : 1;
      const bm = b.analysis_type === "Maturity Assessment" ? 0 : 1;
      if (am !== bm) return am - bm;
      return (a.name || "").localeCompare(b.name || "");
    });
    setAssessmentModels(sorted);
  }, []);

  // Load the linked AssessmentModel whenever the template's assessment_model_id changes
  useEffect(() => {
    const modelId = template?.assessment_model_id;
    if (!modelId) { setLinkedModel(null); return; }
    let cancelled = false;
    (async () => {
      try {
        const model = await base44.entities.AssessmentModel.get(modelId);
        if (!cancelled) setLinkedModel(model);
      } catch (e) {
        if (!cancelled) setLinkedModel(null);
      }
    })();
    return () => { cancelled = true; };
  }, [template?.assessment_model_id, template?.id]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await loadCapabilities();
      await loadAllAssessments();
      setLoading(false);
    })();
  }, [loadCapabilities, loadAllAssessments]);

  useEffect(() => {
    if (selectedCapId) {
      setSearchParams({ capability_id: selectedCapId });
      loadAssessments(selectedCapId);
    }
  }, [selectedCapId, loadAssessments, setSearchParams]);

  useEffect(() => {
    loadTemplate(companyId);
    loadAssessmentModels(companyId);
    loadStakeholders(companyId);
  }, [companyId, loadTemplate, loadAssessmentModels, loadStakeholders]);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const handleSaveTemplate = async (draft) => {
    setSaving(true);
    try {
      if (template?.id) {
        await base44.entities.MaturityAssessmentTemplate.update(template.id, { ...draft, company_id: companyId });
        setTemplate({ ...template, ...draft });
      } else {
        const created = await base44.entities.MaturityAssessmentTemplate.create({ ...draft, company_id: companyId });
        setTemplate(created);
      }
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  const handleCreateAssessment = async () => {
    if (!selectedCapId || !template) return;
    setSaving(true);
    try {
      const responses = [];
      for (const dim of template.dimensions || []) {
        for (const q of dim.questions || []) {
          responses.push({
            question_id: q.question_id,
            dimension: dim.name,
            mandatory_artefact: q.mandatory_artefact,
            assessment_question: q.assessment_question,
            weight: q.weight,
            response_level: 0,
            raw_score: 0,
            score_5: 0,
            weighted_score: 0,
            evidence_type: "none",
            evidence_file_uri: "",
            evidence_file_name: "",
            evidence_url: "",
            evidence_reference: "",
            evidence_status: "pending",
            comments: "",
          });
        }
      }
      const assessorNames = (newAssessmentMeta.assessor_ids || [])
        .map((id) => stakeholders.find((s) => s.id === id)?.full_name)
        .filter(Boolean);
      const opeLeadName = stakeholders.find((s) => s.id === newAssessmentMeta.ope_lead_id)?.full_name || "";
      const newAssessment = {
        capability_id: selectedCapId,
        company_id: companyId,
        template_id: template.id,
        assessment_model_id: template.assessment_model_id || null,
        process_assessment_id: linkedProcessAssessmentId || null,
        assessment_name: newAssessmentMeta.name,
        assessment_date: newAssessmentMeta.date,
        status: "draft",
        validation_stage: "not_started",
        assessor_stakeholder_ids: newAssessmentMeta.assessor_ids || [],
        assessor_names: assessorNames,
        ope_lead_stakeholder_id: newAssessmentMeta.ope_lead_id || "",
        ope_lead_name: opeLeadName,
        target_score: newAssessmentMeta.target_score,
        responses,
        dimension_scores: [],
        overall_score: 0,
        question_completion: 0,
        evidence_completion: 0,
      };
      const created = await base44.entities.CapabilityMaturityAssessment.create(newAssessment);
      await loadAssessments(selectedCapId);
      setShowNewDialog(false);
      setNewAssessmentMeta({ name: "", date: "", target_score: scoringConfig.scoreScale * 0.6 });
      setSelectedAssessment(created);
      setView("form");
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  const handleSaveAssessment = async (updated) => {
    setSaving(true);
    try {
      await base44.entities.CapabilityMaturityAssessment.update(updated.id, updated);
      setSelectedAssessment(updated);
      await loadAssessments(selectedCapId);
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  const handleDeleteAssessment = async (id) => {
    if (!confirm("Delete this assessment?")) return;
    await base44.entities.CapabilityMaturityAssessment.delete(id);
    await loadAssessments(selectedCapId);
    if (selectedAssessment?.id === id) { setSelectedAssessment(null); setView("list"); }
  };

  const handleConvertToGoals = async (aspirations) => {
    const cap = capabilities.find((c) => c.id === selectedCapId);
    for (const asp of aspirations) {
      const gap = (asp.aspiration_score_5 || 0) - (asp.current_score_5 || 0);
      if (gap <= 0.01) continue; // only create goals for dimensions with a gap
      const goal = {
        title: `${cap?.name || "Capability"} — ${asp.dimension} maturity improvement`,
        description: `Improve "${asp.dimension}" maturity from ${(asp.current_score_5 || 0).toFixed(2)} to ${(asp.aspiration_score_5 || 0).toFixed(2)} (gap: ${gap.toFixed(2)}). ${asp.notes || ""}`.trim(),
        company_id: companyId,
        category: "operational",
        current_maturity: Math.max(1, Math.round(asp.current_score_5 || 0)),
        target_maturity: Math.min(5, Math.round(asp.aspiration_score_5 || 0)),
        maturity_gap: gap,
        status: "not_started",
        source: "Maturity Assessment",
        owner: cap?.owner || "",
        notes: `Derived from maturity assessment: ${selectedAssessment?.assessment_name || ""}`,
      };
      await base44.entities.GRCGoal.create(goal);
    }
    await base44.entities.CapabilityMaturityAssessment.update(selectedAssessment.id, { goals_created: true });
  };

  const selectedCapability = capabilities.find((c) => c.id === selectedCapId);

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" /></div>;
  }

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-7xl mx-auto">
      <PageHeader icon="BarChart3" title="Capability Maturity Scoring" tagline="Per-capability maturity assessment with customisable dimensions and survey questions" />

      {/* Capability selector */}
      <Card className="border-slate-200">
        <CardContent className="p-3 flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="flex-1 space-y-1">
            <Label className="text-xs text-slate-500">IT Capability</Label>
            <Select value={selectedCapId} onValueChange={setSelectedCapId}>
              <SelectTrigger><SelectValue placeholder="Select a capability..." /></SelectTrigger>
              <SelectContent>
                {capabilities.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {selectedCapability && (
            <Badge variant="outline" className="self-end md:self-center">
              {capabilities.length} capabilities
            </Badge>
          )}
        </CardContent>
      </Card>

      {!selectedCapId ? (
        <Card className="border-dashed">
          <CardContent className="p-8 text-center text-slate-400">
            <ClipboardList className="w-10 h-10 mx-auto mb-2 opacity-40" />
            <p>Select an IT capability to begin maturity scoring.</p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Tab navigation */}
          <div className="flex gap-2 border-b border-slate-200 pb-px">
            {[
              { key: "list", label: "Assessments", icon: FileText },
              { key: "rollup", label: "Roll-up by Owner", icon: Users },
              { key: "surveys", label: "Surveys", icon: Send },
              { key: "template", label: "Template Setup", icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              const active = view === tab.key || (tab.key === "list" && (view === "dashboard" || view === "form"));
              return (
                <button
                  key={tab.key}
                  onClick={() => { setView(tab.key); setSelectedAssessment(null); }}
                  className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium border-b-2 transition-colors ${
                    active ? "border-primary text-primary" : "border-transparent text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <Icon className="w-4 h-4" /> {tab.label}
                </button>
              );
            })}
          </div>

          {/* Template view */}
          {view === "template" && (
            <MaturityTemplateEditor template={template} onSave={handleSaveTemplate} saving={saving} assessmentModels={assessmentModels} />
          )}

          {/* Surveys view */}
          {view === "surveys" && (
            <MaturitySurveyTab
              capability={selectedCapability}
              template={template}
              companyId={companyId}
              onAssessmentCreated={() => loadAssessments(selectedCapId)}
              scoringConfig={scoringConfig}
            />
          )}

          {/* Roll-up by owner view */}
          {view === "rollup" && (
            <MaturityOwnerRollup
              assessments={allAssessments}
              capabilities={capabilities}
              scoringConfig={scoringConfig}
            />
          )}

          {/* List view */}
          {view === "list" && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <p className="text-sm text-slate-600">{assessments.length} assessment(s)</p>
                <Button size="sm" onClick={() => setShowNewDialog(true)} disabled={!template}>
                  <Plus className="w-4 h-4 mr-1" /> New Assessment
                </Button>
              </div>
              {!template && (
                <Card className="border-amber-200 bg-amber-50">
                  <CardContent className="p-3 text-sm text-amber-700">
                    No template found for this company. Go to <strong>Template Setup</strong> to create one (or use the default CMM template).
                  </CardContent>
                </Card>
              )}
              {template && linkedModel && (
                <Card className="border-blue-200 bg-blue-50">
                  <CardContent className="p-3 text-sm text-blue-700">
                    Scoring model: <strong>{linkedModel.name}</strong> — {scoringConfig.responseLevels.length - 1} maturity levels, scored out of {scoringConfig.scoreScale}.
                  </CardContent>
                </Card>
              )}
              {assessments.length === 0 && template ? (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center text-slate-400">
                    <FileText className="w-10 h-10 mx-auto mb-2 opacity-40" />
                    <p>No assessments yet. Click "New Assessment" to begin.</p>
                  </CardContent>
                </Card>
              ) : (
                assessments.map((a) => (
                  <Card key={a.id} className="border-slate-200 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => { setSelectedAssessment(a); setView("dashboard"); }}
                  >
                    <CardContent className="p-3 flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm text-slate-800 truncate">{a.assessment_name || "Untitled assessment"}</p>
                        <p className="text-xs text-slate-500">
                          {a.assessment_date || "No date"} • Score: {(a.overall_score || 0).toFixed(2)}/{scoringConfig.scoreScale} • Questions: {Math.round(a.question_completion || 0)}%
                        </p>
                        {a.validation_stage && a.validation_stage !== "not_started" && (
                          <Badge variant="outline" className="text-[10px] mt-0.5 capitalize" style={{
                            color: a.validation_stage === "completed" ? "#22c55e" : a.validation_stage === "validated" ? "#3b82f6" : "#f59e0b",
                            border: 0,
                          }}>
                            {a.validation_stage.replace(/_/g, " ")}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0" onClick={(e) => e.stopPropagation()}>
                        <Button size="sm" variant="ghost" onClick={() => { setSelectedAssessment(a); setView("form"); }}>
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => handleDeleteAssessment(a.id)}>
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          )}

          {/* Dashboard view */}
          {view === "dashboard" && selectedAssessment && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Button size="sm" variant="ghost" onClick={() => { setView("list"); setSelectedAssessment(null); }}>
                  <ArrowLeft className="w-4 h-4 mr-1" /> Back to list
                </Button>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => setView("form")}>
                    <Edit2 className="w-4 h-4 mr-1" /> Edit Responses
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setView("validation")}>
                    <ShieldCheck className="w-4 h-4 mr-1" /> Validation
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setView("aspirations")} disabled={(selectedAssessment.validation_stage || "not_started") !== "aspirations_pending" && (selectedAssessment.validation_stage || "not_started") !== "completed"}>
                    <Target className="w-4 h-4 mr-1" /> Aspirations
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="lg:col-span-1">
                  <MaturityScoreSummary
                    overallScore={selectedAssessment.overall_score || 0}
                    targetScore={selectedAssessment.target_score || 0}
                    status={selectedAssessment.status}
                    questionCompletion={selectedAssessment.question_completion || 0}
                    evidenceCompletion={selectedAssessment.evidence_completion || 0}
                    scoringConfig={scoringConfig}
                  />
                </div>
                <div className="lg:col-span-2">
                  <Card className="border-slate-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Dimension Scores</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <MaturityScoreChart
                        dimensionScores={selectedAssessment.dimension_scores || []}
                        overallScore={selectedAssessment.overall_score || 0}
                        targetScore={selectedAssessment.target_score || 0}
                        scoringConfig={scoringConfig}
                      />
                    </CardContent>
                  </Card>
                </div>
              </div>
              <Card className="border-slate-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">How the baseline score is calculated</CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-slate-600 space-y-1">
                  <p>
                    Each response receives a raw score from 0 to {scoringConfig.maxRaw} and is converted to a score out of {scoringConfig.scoreScale} (Raw Score ÷ {scoringConfig.maxRaw} × {scoringConfig.scoreScale}). The question score is then multiplied by its assigned weight. All weighted question scores are summed to produce the overall baseline score out of {scoringConfig.scoreScale}.
                  </p>
                  <p className="text-slate-500 italic">This is an initiation baseline, not an effectiveness assessment. A top score means the required artefacts exist, are approved and show evidence of maintenance — it does not prove the capability is operating effectively.</p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Form view */}
          {view === "form" && selectedAssessment && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Button size="sm" variant="ghost" onClick={() => { setView("list"); setSelectedAssessment(null); }}>
                  <ArrowLeft className="w-4 h-4 mr-1" /> Back to list
                </Button>
                <Button size="sm" variant="outline" onClick={() => setView("dashboard")}>
                  <BarChart3 className="w-4 h-4 mr-1" /> View Dashboard
                </Button>
              </div>
              <MaturityAssessmentForm
                assessment={selectedAssessment}
                templateDimensions={template?.dimensions || DEFAULT_MATURITY_TEMPLATE.dimensions}
                onSave={handleSaveAssessment}
                saving={saving}
                scoringConfig={scoringConfig}
                validationStage={selectedAssessment.validation_stage}
              />
            </div>
          )}

          {/* Validation view */}
          {view === "validation" && selectedAssessment && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Button size="sm" variant="ghost" onClick={() => setView("dashboard")}>
                  <ArrowLeft className="w-4 h-4 mr-1" /> Back to dashboard
                </Button>
              </div>
              <ValidationTab
                assessment={selectedAssessment}
                template={template}
                stakeholders={stakeholders}
                scoringConfig={scoringConfig}
                onSave={handleSaveAssessment}
                saving={saving}
                currentUser={currentUser}
              />
            </div>
          )}

          {/* Aspirations view */}
          {view === "aspirations" && selectedAssessment && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Button size="sm" variant="ghost" onClick={() => setView("dashboard")}>
                  <ArrowLeft className="w-4 h-4 mr-1" /> Back to dashboard
                </Button>
              </div>
              <AspirationsTab
                assessment={selectedAssessment}
                scoringConfig={scoringConfig}
                onSave={handleSaveAssessment}
                saving={saving}
                onConvertToGoals={handleConvertToGoals}
              />
            </div>
          )}
        </>
      )}

      {/* New assessment dialog */}
      <Dialog open={showNewDialog} onOpenChange={setShowNewDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New Maturity Assessment</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label>Assessment Name</Label>
              <Input value={newAssessmentMeta.name} onChange={(e) => setNewAssessmentMeta({ ...newAssessmentMeta, name: e.target.value })} placeholder="e.g. 2026 Baseline Assessment" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Assessment Date</Label>
                <Input type="date" value={newAssessmentMeta.date} onChange={(e) => setNewAssessmentMeta({ ...newAssessmentMeta, date: e.target.value })} />
              </div>
              <div className="space-y-1">
                <Label>Target Score /{scoringConfig.scoreScale}</Label>
                <Input type="number" step="0.01" value={newAssessmentMeta.target_score} onChange={(e) => setNewAssessmentMeta({ ...newAssessmentMeta, target_score: Number(e.target.value) })} />
              </div>
            </div>
            {linkedModel && (
              <p className="text-xs text-slate-500">
                Scored using <strong>{linkedModel.name}</strong> — {scoringConfig.responseLevels.length - 1} maturity levels, out of {scoringConfig.scoreScale}.
              </p>
            )}
            {linkedProcessAssessmentId && (
              <p className="text-xs text-blue-600">
                This assessment will be linked to a process assessment.
              </p>
            )}
            <div className="space-y-1">
              <Label>Assessors / Validators (multiple)</Label>
              <div className="max-h-32 overflow-y-auto border border-slate-200 rounded-md p-2 space-y-1">
                {stakeholders.length === 0 && <p className="text-xs text-slate-400">No stakeholders found for this company.</p>}
                {stakeholders.map((s) => (
                  <label key={s.id} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-slate-50 rounded px-1 py-0.5">
                    <input
                      type="checkbox"
                      checked={newAssessmentMeta.assessor_ids?.includes(s.id) || false}
                      onChange={(e) => {
                        const ids = newAssessmentMeta.assessor_ids || [];
                        setNewAssessmentMeta({
                          ...newAssessmentMeta,
                          assessor_ids: e.target.checked ? [...ids, s.id] : ids.filter((id) => id !== s.id),
                        });
                      }}
                      className="rounded"
                    />
                    <span>{s.full_name}</span>
                    {s.job_title && <span className="text-slate-400 text-[10px]">({s.job_title})</span>}
                  </label>
                ))}
              </div>
            </div>
            <div className="space-y-1">
              <Label>OPEX Lead (calibration approver)</Label>
              <Select
                value={newAssessmentMeta.ope_lead_id}
                onValueChange={(v) => setNewAssessmentMeta({ ...newAssessmentMeta, ope_lead_id: v })}
              >
                <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Select OPEX lead..." /></SelectTrigger>
                <SelectContent>
                  {stakeholders.map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewDialog(false)}>Cancel</Button>
            <Button onClick={handleCreateAssessment} disabled={saving || !newAssessmentMeta.name}>
              {saving ? "Creating..." : "Create Assessment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}