import React, { useState, useMemo, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, AlertTriangle, CheckCircle2, XCircle, Link2, Unlink, GitBranch, Users, ShieldAlert, FileSearch, Loader2, Zap, Check, ChevronDown, ChevronRight, ShieldCheck, Eye, Database, Download, UserX, FileCheck2, ClipboardList } from "lucide-react";

const AUDIT_LABELS = {
  value_chain_workstream: "Value Chains → Workstreams",
  workstream_process: "Workstreams → Processes",
  process_stakeholder: "Processes → Stakeholders",
  process_risk: "Processes → Risks",
  risk_control: "Risks → Controls",
};

const FINDING_TYPE_LABELS = {
  missing: "Missing",
  invalid: "Invalid Reference",
  duplicate: "Duplicate",
  semantic_mismatch: "Semantic Advisory",
  orphaned: "Orphaned",
  recommended: "Recommended Match",
  over_assignment: "Over-Assignment",
  proposed_association: "Proposed Association",
  not_applicable: "Not Applicable",
};

const SEVERITY_STYLES = {
  high: "bg-red-100 text-red-700 border-red-300",
  medium: "bg-amber-100 text-amber-700 border-amber-300",
  low: "bg-blue-100 text-blue-700 border-blue-300",
};

const SEVERITY_ICONS = {
  high: <XCircle className="w-4 h-4 text-red-500" />,
  medium: <AlertTriangle className="w-4 h-4 text-amber-500" />,
  low: <CheckCircle2 className="w-4 h-4 text-blue-500" />,
};

const AUDIT_ICONS = {
  value_chain_workstream: <GitBranch className="w-4 h-4" />,
  workstream_process: <GitBranch className="w-4 h-4" />,
  process_stakeholder: <Users className="w-4 h-4" />,
  process_risk: <ShieldAlert className="w-4 h-4" />,
  risk_control: <ShieldAlert className="w-4 h-4" />,
};

const APPLICABILITY_LABELS = {
  mandatory: "Mandatory",
  optional: "Optional",
  not_applicable: "N/A",
};

const APPLICABILITY_STYLES = {
  mandatory: "bg-red-50 text-red-600 border-red-200",
  optional: "bg-blue-50 text-blue-600 border-blue-200",
  not_applicable: "bg-slate-100 text-slate-500 border-slate-200",
};

const CATEGORY_LABELS = {
  technical: "Technical",
  semantic: "Semantic",
};

const CATEGORY_STYLES = {
  technical: "bg-orange-50 text-orange-600 border-orange-200",
  semantic: "bg-purple-50 text-purple-600 border-purple-200",
};

function MetricBar({ label, percentage, total, withRel, icon, excluded }) {
  const color = percentage >= 80 ? "bg-emerald-500" : percentage >= 50 ? "bg-amber-500" : "bg-red-500";
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-sm">
        <span className="flex items-center gap-1.5 text-slate-600 font-medium">{icon} {label}</span>
        <span className="font-semibold text-slate-800">{percentage}% <span className="text-xs text-slate-400 font-normal">({withRel}/{total})</span></span>
      </div>
      <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all duration-500`} style={{ width: `${percentage}%` }} />
      </div>
      {excluded > 0 && (
        <p className="text-xs text-slate-400">{excluded} record(s) excluded as not-applicable</p>
      )}
    </div>
  );
}

function DualMetricBar({ label, techPct, semPct, total, techValid, semValid, icon }) {
  const techColor = techPct >= 80 ? "bg-emerald-500" : techPct >= 50 ? "bg-amber-500" : "bg-red-500";
  const semColor = semPct >= 80 ? "bg-emerald-400" : semPct >= 50 ? "bg-amber-400" : "bg-red-400";
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-sm">
        <span className="flex items-center gap-1.5 text-slate-600 font-medium">{icon} {label}</span>
      </div>
      <div className="space-y-1">
        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center gap-1 text-slate-500"><ShieldCheck className="w-3 h-3 text-orange-500" /> Technical Integrity</span>
          <span className="font-semibold text-slate-700">{techPct}% <span className="text-slate-400 font-normal">({techValid}/{total})</span></span>
        </div>
        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
          <div className={`h-full ${techColor} rounded-full transition-all duration-500`} style={{ width: `${techPct}%` }} />
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center gap-1 text-slate-500"><Eye className="w-3 h-3 text-purple-500" /> Semantic Relevance</span>
          <span className="font-semibold text-slate-700">{semPct}% <span className="text-slate-400 font-normal">({semValid}/{total})</span></span>
        </div>
        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
          <div className={`h-full ${semColor} rounded-full transition-all duration-500`} style={{ width: `${semPct}%` }} />
        </div>
      </div>
    </div>
  );
}

function ProposedAssociationDetail({ assoc }) {
  if (!assoc) return null;
  return (
    <div className="mt-2 p-3 bg-indigo-50/50 border border-indigo-100 rounded-lg space-y-2 text-xs">
      <p className="font-semibold text-indigo-700 flex items-center gap-1.5">
        <FileCheck2 className="w-3.5 h-3.5" /> Proposed Risk–Control Association
      </p>
      <div className="grid grid-cols-1 gap-2">
        <div>
          <span className="text-slate-400 font-medium">Risk scenario:</span>
          <p className="mt-0.5 text-slate-700">{assoc.risk_scenario}</p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <span className="text-slate-400 font-medium">Risk category:</span>
            <span className="ml-1 text-slate-700 capitalize">{assoc.risk_category}</span>
          </div>
          <div>
            <span className="text-slate-400 font-medium">Control mechanism:</span>
            <span className="ml-1 text-slate-700">{assoc.control_mechanism}</span>
          </div>
        </div>
        {assoc.control_governance && (
          <div>
            <Badge variant="outline" className="text-xs bg-purple-50 text-purple-600 border-purple-200">Governance Control</Badge>
          </div>
        )}
        <div>
          <span className="text-slate-400 font-medium">Evidence expectation:</span>
          <p className="mt-0.5 text-slate-600">{assoc.evidence_expectation}</p>
        </div>
        <div>
          <span className="text-slate-400 font-medium">Operational context:</span>
          <p className="mt-0.5 text-slate-600">{assoc.operational_context}</p>
        </div>
        <div>
          <span className="text-slate-400 font-medium">Matching rationale:</span>
          <p className="mt-0.5 text-indigo-600">{assoc.matching_rationale}</p>
        </div>
        {assoc.source && (
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={`text-xs ${assoc.source === 'master_library' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-amber-50 text-amber-600 border-amber-200'}`}>
              {assoc.source === 'master_library' ? 'Existing Master Control' : 'Expansion Library (Draft)'}
            </Badge>
            {assoc.deduplicated && <span className="text-xs text-emerald-600">Deduplicated — no new record needed</span>}
          </div>
        )}
        {assoc.proposals && assoc.proposals.length > 1 && (
          <div className="mt-2 pt-2 border-t border-indigo-100">
            <p className="font-semibold text-indigo-700 mb-1.5">Consolidated Proposals ({assoc.proposals.length})</p>
            <div className="space-y-1.5">
              {assoc.proposals.map((p, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <Badge variant="outline" className={p.source === 'master_library' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-amber-50 text-amber-600 border-amber-200'}>
                    {p.source === 'master_library' ? 'Master' : 'Expansion'}
                  </Badge>
                  <span className="text-slate-700 font-medium truncate max-w-[200px]" title={p.control_title}>{p.control_title}</span>
                  <span className="text-slate-400">({p.control_reference})</span>
                  <span className="font-semibold text-slate-600">{p.score}%</span>
                  {p.deduplicated && <span className="text-emerald-600">✓ dedup</span>}
                </div>
              ))}
            </div>
            {assoc.master_controls_searched != null && (
              <p className="text-xs text-slate-400 mt-1">Searched {assoc.master_controls_searched} master + {assoc.expansion_controls_searched} expansion controls</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ReconciliationReportSection({ report }) {
  if (!report) return null;
  const sections = [
    { key: 'genuine_defects', label: 'Genuine Defects', icon: <XCircle className="w-4 h-4 text-red-500" />, color: 'border-red-200 bg-red-50/50', desc: report.genuine_defects.description, count: report.genuine_defects.count },
    { key: 'false_positives', label: 'False Positives', icon: <AlertTriangle className="w-4 h-4 text-amber-500" />, color: 'border-amber-200 bg-amber-50/50', desc: report.false_positives.description, count: report.false_positives.count },
    { key: 'approved_corrections', label: 'Approved Corrections', icon: <FileCheck2 className="w-4 h-4 text-emerald-500" />, color: 'border-emerald-200 bg-emerald-50/50', desc: report.approved_corrections.description, count: report.approved_corrections.count },
    { key: 'outstanding_decisions', label: 'Outstanding Decisions', icon: <ClipboardList className="w-4 h-4 text-blue-500" />, color: 'border-blue-200 bg-blue-50/50', desc: report.outstanding_decisions.description, count: report.outstanding_decisions.count },
  ];
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <ClipboardList className="w-5 h-5 text-indigo-600" />
          Reconciliation Report
        </CardTitle>
        <p className="text-xs text-slate-400">Revised audit summary — genuine defects, false positives, approved corrections and outstanding decisions. No approved records or historical relationships are silently modified.</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {sections.map(s => (
            <div key={s.key} className={`rounded-lg border p-3 ${s.color}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="flex items-center gap-1.5 text-sm font-semibold text-slate-700">{s.icon} {s.label}</span>
                <span className="text-lg font-bold text-slate-800">{s.count}</span>
              </div>
              <p className="text-xs text-slate-500 leading-snug">{s.desc}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function ValidationDetail({ detail }) {
  if (!detail) return null;
  return (
    <div className="mt-2 space-y-1.5 text-xs">
      <div className="flex items-start gap-2">
        <span className="text-slate-400 font-medium shrink-0">Rule:</span>
        <code className="text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">{detail.rule}</code>
      </div>
      {detail.source_fields && (
        <div>
          <span className="text-slate-400 font-medium">Source fields:</span>
          <pre className="mt-0.5 p-2 bg-slate-100 rounded text-xs overflow-x-auto text-slate-600 max-h-32">{JSON.stringify(detail.source_fields, null, 2)}</pre>
        </div>
      )}
      {detail.target_fields && (
        <div>
          <span className="text-slate-400 font-medium">Target fields:</span>
          <pre className="mt-0.5 p-2 bg-slate-100 rounded text-xs overflow-x-auto text-slate-600 max-h-32">{JSON.stringify(detail.target_fields, null, 2)}</pre>
        </div>
      )}
      <div>
        <span className="text-slate-400 font-medium">Evidence:</span>
        <p className="mt-0.5 text-slate-600">{detail.evidence}</p>
      </div>
      <div>
        <span className="text-slate-400 font-medium">Resolution:</span>
        <p className="mt-0.5 text-emerald-600">{detail.resolution}</p>
      </div>
    </div>
  );
}

function FindingRow({ finding }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="border-b border-slate-100 last:border-b-0">
      <div
        className="flex items-start gap-3 px-4 py-3 cursor-pointer hover:bg-slate-50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="mt-0.5 shrink-0">
          {expanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
        </div>
        <div className="mt-0.5 shrink-0">{SEVERITY_ICONS[finding.severity]}</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className={`text-xs ${SEVERITY_STYLES[finding.severity]}`}>
              {finding.severity}
            </Badge>
            <Badge variant="outline" className={`text-xs ${CATEGORY_STYLES[finding.validation_category] || "bg-slate-50 text-slate-500 border-slate-200"}`}>
              {CATEGORY_LABELS[finding.validation_category] || finding.validation_category}
            </Badge>
            <Badge variant="outline" className={`text-xs ${APPLICABILITY_STYLES[finding.applicability] || "bg-slate-50 text-slate-500 border-slate-200"}`}>
              {APPLICABILITY_LABELS[finding.applicability] || finding.applicability}
            </Badge>
            <Badge variant="outline" className="text-xs text-slate-600">
              {FINDING_TYPE_LABELS[finding.finding_type] || finding.finding_type}
            </Badge>
            <span className="text-xs text-slate-400">{AUDIT_LABELS[finding.audit_type]}</span>
          </div>
          <div className="mt-1 text-sm text-slate-800 font-medium truncate">
            {finding.source_record?.name || finding.source_record?.code || '—'}
            {finding.target_record && (
              <span className="text-slate-400 font-normal"> → {finding.target_record.name || finding.target_record.code}</span>
            )}
          </div>
          <div className="mt-0.5 text-xs text-slate-500 truncate">{finding.existing_relationship}</div>
        </div>
        <div className="shrink-0 text-right">
          <div className="text-xs text-slate-400">Confidence</div>
          <div className="text-sm font-semibold text-slate-700">{finding.confidence_score}%</div>
        </div>
      </div>
      {expanded && (
        <div className="px-4 pb-4 pl-11 space-y-2 bg-slate-50/50">
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-slate-400 font-medium">Source:</span>
              <span className="ml-1 text-slate-700">{finding.source_record?.type} — {finding.source_record?.name || finding.source_record?.code}</span>
              {finding.source_record?.id && (
                <span className="ml-1 text-slate-400 font-mono text-[10px]">({finding.source_record.id.slice(-8)})</span>
              )}
            </div>
            <div>
              <span className="text-slate-400 font-medium">Target:</span>
              <span className="ml-1 text-slate-700">
                {finding.target_record ? `${finding.target_record.type} — ${finding.target_record.name || finding.target_record.code}` : '—'}
              </span>
              {finding.target_record?.id && (
                <span className="ml-1 text-slate-400 font-mono text-[10px]">({finding.target_record.id.slice(-8)})</span>
              )}
            </div>
          </div>
          <div className="text-xs">
            <span className="text-slate-400 font-medium">Existing:</span>
            <span className="ml-1 text-slate-600">{finding.existing_relationship}</span>
          </div>
          {finding.proposed_relationship && (
            <div className="text-xs">
              <span className="text-slate-400 font-medium">Proposed:</span>
              <span className="ml-1 text-indigo-600 font-medium">{finding.proposed_relationship}</span>
            </div>
          )}
          <div className="text-xs">
            <span className="text-slate-400 font-medium">Justification:</span>
            <span className="ml-1 text-slate-600">{finding.justification}</span>
          </div>
          {finding.proposed_association && (
            <ProposedAssociationDetail assoc={finding.proposed_association} />
          )}
          {finding.validation_detail && (
            <div className="mt-2 pt-2 border-t border-slate-200">
              <p className="text-xs font-semibold text-slate-500 mb-1 flex items-center gap-1">
                <Database className="w-3 h-3" /> Drill-down Diagnostics
              </p>
              <ValidationDetail detail={finding.validation_detail} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function CrossEntityAudit() {
  const [companyId, setCompanyId, { locked, assignedCompanyName }] = useCompanyFilter();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [prevResult, setPrevResult] = useState(null);
  const [error, setError] = useState(null);
  const [filterAudit, setFilterAudit] = useState("all");
  const [filterSeverity, setFilterSeverity] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterApplicability, setFilterApplicability] = useState("all");
  const [search, setSearch] = useState("");
  const [companies, setCompanies] = useState([]);
  const [applying, setApplying] = useState(false);
  const [applyResult, setApplyResult] = useState(null);
  const [showApplyConfirm, setShowApplyConfirm] = useState(false);
  const [confidenceThreshold, setConfidenceThreshold] = useState(70);

  useEffect(() => {
    base44.entities.Company.filter({ status: "active" }, { sort: "name", limit: 200 })
      .then(res => setCompanies(res.items || []))
      .catch(() => {});
  }, []);

  // Auto-select EVI Trading if available and no specific company selected
  useEffect(() => {
    if (!locked && (companyId === "all" || !companyId) && companies.length > 0) {
      const evi = companies.find(c => c.name === "EVI Trading");
      if (evi) setCompanyId(evi.id);
    }
  }, [companies, locked]);

  const runAudit = async () => {
    if (!companyId || companyId === "all") {
      setError("Please select a specific company to audit.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("runCrossEntityAudit", { company_id: companyId });
      setPrevResult(result);
      setResult(res.data);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "Audit failed");
    } finally {
      setLoading(false);
    }
  };

  const highConfMatches = useMemo(() => {
    if (!result?.findings) return [];
    return result.findings.filter(
      f => (f.finding_type === "recommended" || f.finding_type === "proposed_association") && f.confidence_score >= confidenceThreshold
    );
  }, [result, confidenceThreshold]);

  const applyMatches = async () => {
    setShowApplyConfirm(false);
    setApplying(true);
    setApplyResult(null);
    try {
      const res = await base44.functions.invoke("applyCrossEntityMatches", {
        findings: result.findings,
        min_confidence: confidenceThreshold,
      });
      setApplyResult(res.data);
      // Re-run the audit to show updated metrics
      const auditRes = await base44.functions.invoke("runCrossEntityAudit", { company_id: companyId });
      setPrevResult(result);
      setResult(auditRes.data);
    } catch (e) {
      setApplyResult({ error: e?.response?.data?.error || e?.message || "Apply failed" });
    } finally {
      setApplying(false);
    }
  };

  const exportCSV = () => {
    if (!filteredFindings.length) return;
    const headers = [
      "Finding ID", "Audit Type", "Finding Type", "Severity",
      "Validation Category", "Applicability", "Confidence %",
      "Source Type", "Source ID", "Source Name", "Source Code",
      "Target Type", "Target ID", "Target Name", "Target Code",
      "Existing Relationship", "Proposed Relationship", "Justification",
      "Validation Rule", "Source Fields (JSON)", "Target Fields (JSON)",
      "Evidence", "Resolution",
    ];
    const esc = (v) => {
      if (v == null) return "";
      const s = typeof v === "object" ? JSON.stringify(v) : String(v);
      if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
      return s;
    };
    const rows = filteredFindings.map(f => [
      f.id,
      AUDIT_LABELS[f.audit_type] || f.audit_type,
      FINDING_TYPE_LABELS[f.finding_type] || f.finding_type,
      f.severity,
      CATEGORY_LABELS[f.validation_category] || f.validation_category || "",
      APPLICABILITY_LABELS[f.applicability] || f.applicability || "",
      f.confidence_score ?? "",
      f.source_record?.type || "",
      f.source_record?.id || "",
      f.source_record?.name || "",
      f.source_record?.code || "",
      f.target_record?.type || "",
      f.target_record?.id || "",
      f.target_record?.name || "",
      f.target_record?.code || "",
      f.existing_relationship || "",
      f.proposed_relationship || "",
      f.justification || "",
      f.validation_detail?.rule || "",
      f.validation_detail?.source_fields ? JSON.stringify(f.validation_detail.source_fields) : "",
      f.validation_detail?.target_fields ? JSON.stringify(f.validation_detail.target_fields) : "",
      f.validation_detail?.evidence || "",
      f.validation_detail?.resolution || "",
    ].map(esc).join(","));
    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cross-entity-audit-findings-${result.company_name || companyId}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredFindings = useMemo(() => {
    if (!result?.findings) return [];
    return result.findings.filter(f => {
      if (filterAudit !== "all" && f.audit_type !== filterAudit) return false;
      if (filterSeverity !== "all" && f.severity !== filterSeverity) return false;
      if (filterCategory !== "all" && f.validation_category !== filterCategory) return false;
      if (filterApplicability !== "all" && f.applicability !== filterApplicability) return false;
      if (search) {
        const q = search.toLowerCase();
        const text = `${f.source_record?.name} ${f.target_record?.name} ${f.existing_relationship} ${f.proposed_relationship} ${f.justification} ${f.validation_detail?.rule || ''} ${f.validation_detail?.evidence || ''}`.toLowerCase();
        if (!text.includes(q)) return false;
      }
      return true;
    });
  }, [result, filterAudit, filterSeverity, filterCategory, filterApplicability, search]);

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <FileSearch className="w-6 h-6 text-indigo-600" />
            Cross-Entity Relationship Audit
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Read-only diagnostic audit of relationship integrity — technical integrity and semantic relevance scored independently.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={companyId}
            onChange={(e) => setCompanyId(e.target.value)}
            disabled={locked}
            className="px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white disabled:bg-slate-50 disabled:text-slate-400 max-w-[200px]"
          >
            {locked ? (
              <option value={companyId}>{assignedCompanyName || "My Company"}</option>
            ) : (
              <>
                <option value="all">All Companies</option>
                {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </>
            )}
          </select>
          <Button onClick={runAudit} disabled={loading} className="gap-2 bg-indigo-600 hover:bg-indigo-700">
            {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Auditing…</> : <><Search className="w-4 h-4" /> Run Audit</>}
          </Button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">
          {error}
        </div>
      )}

      {loading && !result && (
        <Card>
          <CardContent className="py-16 flex flex-col items-center gap-3">
            <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
            <p className="text-sm text-slate-500">Auditing entity relationships…</p>
          </CardContent>
        </Card>
      )}

      {result && (
        <>
          {/* Record counts */}
          <div className="flex items-center gap-2 flex-wrap text-xs text-slate-500">
            <span className="font-medium text-slate-600">Records audited:</span>
            <Badge variant="outline" className="text-xs">{result.record_counts.value_chains} Value Chains</Badge>
            <Badge variant="outline" className="text-xs">{result.record_counts.workstreams} Workstreams</Badge>
            <Badge variant="outline" className="text-xs">{result.record_counts.processes} Processes</Badge>
            <Badge variant="outline" className="text-xs">{result.record_counts.stakeholders} Stakeholders</Badge>
            <Badge variant="outline" className="text-xs">{result.record_counts.risks} Risks</Badge>
            <Badge variant="outline" className="text-xs">{result.record_counts.controls} Controls</Badge>
          </div>

          {/* Before/after comparison banner */}
          {prevResult && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-3 text-sm text-blue-700">
              <span className="font-medium">Before → After:</span>
              <span className="ml-2">Completeness {prevResult.metrics.completeness.overall.percentage}% → {result.metrics.completeness.overall.percentage}%</span>
              <span className="mx-2 text-blue-300">|</span>
              <span className="flex items-center gap-1 inline-flex"><ShieldCheck className="w-3.5 h-3.5" /> Technical {prevResult.metrics.quality.overall.technical_integrity?.percentage ?? prevResult.metrics.quality.overall.percentage}% → {result.metrics.quality.overall.technical_integrity?.percentage ?? result.metrics.quality.overall.percentage}%</span>
              <span className="mx-2 text-blue-300">|</span>
              <span className="flex items-center gap-1 inline-flex"><Eye className="w-3.5 h-3.5" /> Semantic {prevResult.metrics.quality.overall.semantic_relevance?.percentage ?? '—'}% → {result.metrics.quality.overall.semantic_relevance?.percentage ?? '—'}%</span>
            </div>
          )}

          {/* Metrics dashboard */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center justify-between">
                  <span>Relationship Completeness</span>
                  <span className={`text-2xl font-bold ${result.metrics.completeness.overall.percentage >= 80 ? 'text-emerald-600' : result.metrics.completeness.overall.percentage >= 50 ? 'text-amber-600' : 'text-red-600'}`}>
                    {result.metrics.completeness.overall.percentage}%
                  </span>
                </CardTitle>
                <p className="text-xs text-slate-400">Percentage of applicable records that have the expected relationship (not-applicable records excluded from denominator)</p>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(result.metrics.completeness)
                  .filter(([k]) => k !== "overall")
                  .map(([key, m]) => (
                    <MetricBar key={key} label={AUDIT_LABELS[key]} percentage={m.percentage} total={m.total} withRel={m.with_relationship} icon={AUDIT_ICONS[key]} excluded={m.excluded_not_applicable} />
                  ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center justify-between">
                  <span>Relationship Quality</span>
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1 text-sm"><ShieldCheck className="w-4 h-4 text-orange-500" /> <span className={`font-bold ${result.metrics.quality.overall.technical_integrity?.percentage >= 80 ? 'text-emerald-600' : result.metrics.quality.overall.technical_integrity?.percentage >= 50 ? 'text-amber-600' : 'text-red-600'}`}>{result.metrics.quality.overall.technical_integrity?.percentage ?? result.metrics.quality.overall.percentage}%</span></span>
                    <span className="flex items-center gap-1 text-sm"><Eye className="w-4 h-4 text-purple-500" /> <span className={`font-bold ${result.metrics.quality.overall.semantic_relevance?.percentage >= 80 ? 'text-emerald-600' : result.metrics.quality.overall.semantic_relevance?.percentage >= 50 ? 'text-amber-600' : 'text-red-600'}`}>{result.metrics.quality.overall.semantic_relevance?.percentage ?? '—'}%</span></span>
                  </div>
                </CardTitle>
                <p className="text-xs text-slate-400">Technical integrity (target exists, correct company, no duplicates) scored separately from semantic relevance (job title, group membership, text similarity — advisory only)</p>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(result.metrics.quality)
                  .filter(([k]) => k !== "overall")
                  .map(([key, q]) => (
                    <DualMetricBar
                      key={key}
                      label={AUDIT_LABELS[key]}
                      techPct={q.technical_integrity?.percentage ?? q.percentage}
                      semPct={q.semantic_relevance?.percentage ?? 100}
                      total={q.total_relationships}
                      techValid={q.technical_integrity?.valid ?? q.valid}
                      semValid={q.semantic_relevance?.valid ?? q.total_relationships}
                      icon={AUDIT_ICONS[key]}
                    />
                  ))}
              </CardContent>
            </Card>
          </div>

          {/* Reconciliation Report */}
          {result.reconciliation_report && (
            <ReconciliationReportSection report={result.reconciliation_report} />
          )}

          {/* Remediation Cases (Requirement #9: raw finding count vs distinct affected-record count) */}
          {result.remediation_cases && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <ClipboardList className="w-5 h-5 text-blue-600" />
                  Remediation Cases
                  <span className="ml-auto flex items-center gap-2 text-sm">
                    <Badge variant="outline" className="text-xs">{result.remediation_cases.raw_finding_count} raw findings</Badge>
                    <Badge variant="outline" className="text-xs bg-blue-50 text-blue-600 border-blue-200">{result.remediation_cases.distinct_affected_records} distinct records</Badge>
                    <Badge variant="outline" className="text-xs bg-indigo-50 text-indigo-600 border-indigo-200">{result.remediation_cases.cases_with_proposed_changes} with proposed changes</Badge>
                  </span>
                </CardTitle>
                <p className="text-xs text-slate-400">Related findings grouped by affected source record — each case may contain multiple findings for the same record. No approved records are automatically modified.</p>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-slate-500 mb-2">
                  {result.remediation_cases.total_cases} unique remediation cases identified from {result.remediation_cases.raw_finding_count} raw findings.
                  Confirmed defects are reported separately from advisory findings and unverified AI recommendations.
                </div>
              </CardContent>
            </Card>
          )}

          {/* Control Library Breakdown (Requirement #2) */}
          {result.control_library_breakdown && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Database className="w-5 h-5 text-slate-600" />
                  Control Library Access
                </CardTitle>
                <p className="text-xs text-slate-400">Controls searched during risk-control reconciliation — master library, company-specific and expansion controls</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <div className="rounded-lg border border-slate-200 p-3 text-center">
                    <div className="text-2xl font-bold text-slate-700">{result.control_library_breakdown.total_controls}</div>
                    <div className="text-xs text-slate-500">Total Controls</div>
                  </div>
                  <div className="rounded-lg border border-emerald-200 bg-emerald-50/50 p-3 text-center">
                    <div className="text-2xl font-bold text-emerald-700">{result.control_library_breakdown.master_library_controls}</div>
                    <div className="text-xs text-emerald-600">Master Library</div>
                  </div>
                  <div className="rounded-lg border border-blue-200 bg-blue-50/50 p-3 text-center">
                    <div className="text-2xl font-bold text-blue-700">{result.control_library_breakdown.company_controls}</div>
                    <div className="text-xs text-blue-600">Company Controls</div>
                  </div>
                  <div className="rounded-lg border border-amber-200 bg-amber-50/50 p-3 text-center">
                    <div className="text-2xl font-bold text-amber-700">{result.control_library_breakdown.expansion_controls}</div>
                    <div className="text-xs text-amber-600">Expansion (144 Finance/IT)</div>
                  </div>
                  <div className="rounded-lg border border-red-200 bg-red-50/50 p-3 text-center">
                    <div className="text-2xl font-bold text-red-700">{result.control_library_breakdown.invalid_controls_rejected}</div>
                    <div className="text-xs text-red-600">Rejected (blank/zero)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Change Preview (Requirement #10) */}
          {result.change_preview && result.change_preview.total_proposed_changes > 0 && (
            <Card className="border-indigo-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <FileCheck2 className="w-5 h-5 text-indigo-600" />
                  Proposed Changes Preview
                  <span className="ml-auto text-sm text-slate-500">{result.change_preview.total_proposed_changes} proposed</span>
                </CardTitle>
                <p className="text-xs text-slate-400">{result.change_preview.note}</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3 mb-3 text-xs">
                  <Badge variant="outline" className="bg-emerald-50 text-emerald-600 border-emerald-200">High (≥80%): {result.change_preview.by_confidence.high}</Badge>
                  <Badge variant="outline" className="bg-amber-50 text-amber-600 border-amber-200">Medium (60-79%): {result.change_preview.by_confidence.medium}</Badge>
                  <Badge variant="outline" className="bg-slate-50 text-slate-600 border-slate-200">Low (&lt;60%): {result.change_preview.by_confidence.low}</Badge>
                </div>
                <div className="max-h-64 overflow-y-auto border border-slate-100 rounded-lg">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 sticky top-0">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium text-slate-500">Source</th>
                        <th className="text-left px-3 py-2 font-medium text-slate-500">Target</th>
                        <th className="text-left px-3 py-2 font-medium text-slate-500">Existing</th>
                        <th className="text-left px-3 py-2 font-medium text-slate-500">Proposed</th>
                        <th className="text-right px-3 py-2 font-medium text-slate-500">Confidence</th>
                        <th className="text-center px-3 py-2 font-medium text-slate-500">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.change_preview.changes.slice(0, 100).map((c, i) => (
                        <tr key={i} className="border-t border-slate-100 hover:bg-slate-50">
                          <td className="px-3 py-1.5 text-slate-700 truncate max-w-[150px]" title={c.source_record?.name}>{c.source_record?.name || '—'}</td>
                          <td className="px-3 py-1.5 text-slate-700 truncate max-w-[150px]" title={c.target_record?.name}>{c.target_record?.name || '—'}</td>
                          <td className="px-3 py-1.5 text-slate-500 truncate max-w-[120px]" title={c.existing_relationship}>{c.existing_relationship || '—'}</td>
                          <td className="px-3 py-1.5 text-indigo-600 truncate max-w-[180px]" title={c.proposed_relationship}>{c.proposed_relationship || '—'}</td>
                          <td className="px-3 py-1.5 text-right font-semibold text-slate-700">{c.confidence}%</td>
                          <td className="px-3 py-1.5 text-center"><Badge variant="outline" className="text-xs bg-amber-50 text-amber-600 border-amber-200">Pending</Badge></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {result.change_preview.changes.length > 100 && (
                  <p className="text-xs text-slate-400 mt-2">Showing first 100 of {result.change_preview.changes.length} proposed changes. Export CSV for full list.</p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Summary badges */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-medium text-slate-600">Findings:</span>
            <Badge className="bg-red-100 text-red-700 border border-red-300">{result.summary.by_severity.high} High</Badge>
            <Badge className="bg-amber-100 text-amber-700 border border-amber-300">{result.summary.by_severity.medium} Medium</Badge>
            <Badge className="bg-blue-100 text-blue-700 border border-blue-300">{result.summary.by_severity.low} Low</Badge>
            {result.summary.by_validation_category && (
              <>
                <span className="text-slate-300">|</span>
                <Badge variant="outline" className="text-xs text-orange-600 border-orange-200">{result.summary.by_validation_category.technical || 0} Technical</Badge>
                <Badge variant="outline" className="text-xs text-purple-600 border-purple-200">{result.summary.by_validation_category.semantic || 0} Semantic</Badge>
              </>
            )}
            {result.summary.by_applicability && (
              <>
                <span className="text-slate-300">|</span>
                <Badge variant="outline" className="text-xs text-red-600 border-red-200">{result.summary.by_applicability.mandatory || 0} Mandatory</Badge>
                <Badge variant="outline" className="text-xs text-blue-600 border-blue-200">{result.summary.by_applicability.optional || 0} Optional</Badge>
                <Badge variant="outline" className="text-xs text-slate-500 border-slate-200">{result.summary.by_applicability.not_applicable || 0} N/A</Badge>
              </>
            )}
            <span className="text-slate-300">|</span>
            {Object.entries(result.summary.by_finding_type).map(([type, count]) => (
              <Badge key={type} variant="outline" className="text-xs text-slate-600">
                {FINDING_TYPE_LABELS[type] || type}: {count}
              </Badge>
            ))}
          </div>

          {/* Apply high-confidence matches panel */}
          {(highConfMatches.length > 0 || applyResult || applying) && (
            <Card className="border-indigo-200 bg-indigo-50/50">
              <CardContent className="py-4 space-y-3">
                {highConfMatches.length > 0 && (
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-indigo-600" />
                      <div>
                        <p className="text-sm font-semibold text-slate-800">
                          {highConfMatches.length} high-confidence recommended matches ready to apply
                        </p>
                        <p className="text-xs text-slate-500">
                           Applies process owner links, process-risk links, and risk-control links (including mechanism-based proposed associations)
                         </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        <label className="text-xs text-slate-500 font-medium">Min confidence:</label>
                        <input
                          type="number"
                          min={50}
                          max={100}
                          value={confidenceThreshold}
                          onChange={(e) => setConfidenceThreshold(Number(e.target.value))}
                          className="w-16 px-2 py-1 text-sm border border-slate-200 rounded-lg text-center"
                        />
                        <span className="text-xs text-slate-400">%</span>
                      </div>
                      <Button
                        onClick={() => setShowApplyConfirm(true)}
                        disabled={applying}
                        className="gap-2 bg-indigo-600 hover:bg-indigo-700"
                      >
                        <Zap className="w-4 h-4" /> Apply Matches
                      </Button>
                    </div>
                  </div>
                )}

                {showApplyConfirm && (
                  <div className="bg-white border border-indigo-200 rounded-lg p-3 space-y-2">
                    <p className="text-sm text-slate-700 font-medium">
                      Confirm: apply {highConfMatches.length} matches (confidence ≥ {confidenceThreshold}%)?
                    </p>
                    <p className="text-xs text-slate-500">
                      This will update entity records directly. The audit will re-run automatically afterwards to show updated metrics.
                    </p>
                    <div className="flex gap-2">
                      <Button onClick={applyMatches} disabled={applying} className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-sm">
                        {applying ? <><Loader2 className="w-4 h-4 animate-spin" /> Applying…</> : <><Check className="w-4 h-4" /> Confirm & Apply</>}
                      </Button>
                      <Button onClick={() => setShowApplyConfirm(false)} variant="outline" className="text-sm">Cancel</Button>
                    </div>
                  </div>
                )}

                {applying && (
                  <div className="flex items-center gap-2 text-sm text-indigo-600">
                    <Loader2 className="w-4 h-4 animate-spin" /> Applying matches and re-running audit…
                  </div>
                )}

                {applyResult && (
                  <div className={`rounded-lg p-3 text-sm ${applyResult.error ? "bg-red-50 border border-red-200 text-red-700" : "bg-emerald-50 border border-emerald-200 text-emerald-700"}`}>
                    {applyResult.error ? (
                      <span>Error: {applyResult.error}</span>
                    ) : (
                      <div className="space-y-1">
                        <p className="font-medium flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4" /> Applied {applyResult.applied} record updates, skipped {applyResult.skipped} already-linked
                        </p>
                        {applyResult.errors > 0 && <p className="text-red-600">{applyResult.errors} errors occurred</p>}
                        <p className="text-xs text-emerald-600">
                          Breakdown: {applyResult.breakdown.process_stakeholder} owner links, {applyResult.breakdown.process_risk} process-risk links, {applyResult.breakdown.risk_control} risk-control links
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Findings table */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <CardTitle className="text-base">Reconciliation Workbench</CardTitle>
                <div className="flex items-center gap-2 flex-wrap">
                  <Button onClick={exportCSV} disabled={!filteredFindings.length} variant="outline" className="gap-1.5 text-sm h-9">
                    <Download className="w-3.5 h-3.5" /> Export CSV
                  </Button>
                  <input
                    type="text"
                    placeholder="Search findings…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="px-3 py-1.5 text-sm border border-slate-200 rounded-lg w-48"
                  />
                  <select value={filterAudit} onChange={(e) => setFilterAudit(e.target.value)} className="px-2 py-1.5 text-sm border border-slate-200 rounded-lg">
                    <option value="all">All Audits</option>
                    {Object.entries(AUDIT_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                  <select value={filterSeverity} onChange={(e) => setFilterSeverity(e.target.value)} className="px-2 py-1.5 text-sm border border-slate-200 rounded-lg">
                    <option value="all">All Severities</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                  <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="px-2 py-1.5 text-sm border border-slate-200 rounded-lg">
                    <option value="all">All Categories</option>
                    <option value="technical">Technical</option>
                    <option value="semantic">Semantic</option>
                  </select>
                  <select value={filterApplicability} onChange={(e) => setFilterApplicability(e.target.value)} className="px-2 py-1.5 text-sm border border-slate-200 rounded-lg">
                    <option value="all">All Applicability</option>
                    <option value="mandatory">Mandatory</option>
                    <option value="optional">Optional</option>
                    <option value="not_applicable">N/A</option>
                  </select>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 border-b border-slate-100 text-xs font-medium text-slate-500">
                <span className="flex items-center gap-1"><Link2 className="w-3 h-3 text-indigo-500" /> Click any finding to expand drill-down diagnostics — raw source/target values, validation rule, evidence, and resolution</span>
              </div>
              {filteredFindings.length === 0 ? (
                <div className="py-12 text-center text-sm text-slate-400">
                  {result.findings.length === 0 ? "No findings — all relationships are complete and valid." : "No findings match the current filters."}
                </div>
              ) : (
                <div className="max-h-[600px] overflow-y-auto">
                  {filteredFindings.map(f => <FindingRow key={f.id} finding={f} />)}
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {!result && !loading && !error && (
        <Card>
          <CardContent className="py-16 text-center">
            <FileSearch className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-slate-500">Select a company and click "Run Audit" to begin the cross-entity relationship audit.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}