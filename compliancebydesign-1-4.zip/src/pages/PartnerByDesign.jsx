import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import {
  Handshake, ShieldAlert, Network, FileCheck, Globe,
  UserX, AlertTriangle, ShieldX, Link2, CheckCircle2, Activity, Ban,
} from "lucide-react";
import ModuleDashboard from "@/components/branding/ModuleDashboard";
import { BRANDS } from "@/lib/moduleBrands";

const FEATURES = [
  { icon: Globe, title: "Third-party Register", desc: "Centralise suppliers, service providers and sub-contractors with rich legal and relationship data." },
  { icon: ShieldAlert, title: "Inherent & Residual Risk", desc: "Rate inherent and residual risk, and link controls, frameworks and risks from the library." },
  { icon: Network, title: "Linked Operations", desc: "Connect third parties to value chains, workstreams, processes and ICT assets they support." },
  { icon: FileCheck, title: "BCP & Assurance", desc: "Flag business-continuity-critical partners, and track issues, incidents and assurance activity." },
];

export default function PartnerByDesign() {
  const [companyId] = useCompanyFilter();
  const effectiveCompanyId = companyId === "all" ? null : companyId;

  const { data: providers = [], isLoading } = useQuery({
    queryKey: ["tprmProviders", effectiveCompanyId],
    queryFn: () =>
      effectiveCompanyId
        ? base44.entities.ThirdPartyProvider.filter({ company_id: effectiveCompanyId })
        : base44.entities.ThirdPartyProvider.list("-created_date", 500),
  });

  const metrics = [
    { label: "Total Third Parties", value: providers.length, icon: Handshake, link: "/ThirdParties" },
    { label: "Without Owner", value: providers.filter((p) => !p.procurement_owner_id && !p.procurement_owner_name && !p.relationship_owner_id).length, icon: UserX, link: "/ThirdParties", attention: true },
    { label: "Without Risk Rating", value: providers.filter((p) => !p.inherent_risk_rating).length, icon: AlertTriangle, link: "/AdvancedThirdPartyRiskManagement", attention: true },
    { label: "Without Controls", value: providers.filter((p) => !p.linked_control_ids?.length).length, icon: ShieldX, link: "/AdvancedThirdPartyRiskManagement", attention: true },
    { label: "Without Processes", value: providers.filter((p) => !p.linked_process_ids?.length).length, icon: Link2, link: "/AdvancedThirdPartyRiskManagement", attention: true },
    { label: "BCP-Critical", value: providers.filter((p) => p.business_continuity_critical).length, icon: ShieldAlert, link: "/ThirdParties" },
    { label: "Active", value: providers.filter((p) => p.status === "active").length, icon: CheckCircle2, link: "/ThirdParties" },
    { label: "Terminated", value: providers.filter((p) => p.status === "terminated").length, icon: Ban, link: "/ThirdParties" },
  ];

  return (
    <ModuleDashboard
      brand={BRANDS.pbd}
      Icon={Handshake}
      logoUrl={BRANDS.pbd.logoUrl}
      metrics={metrics}
      isLoading={isLoading}
      enterPath={BRANDS.pbd.enterPath}
      enterLabel={BRANDS.pbd.enterLabel}
      features={FEATURES}
      moduleKey="pbd"
    />
  );
}