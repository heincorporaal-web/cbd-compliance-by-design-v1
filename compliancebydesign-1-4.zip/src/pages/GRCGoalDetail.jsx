import React, { useState, useEffect } from "react";
import { useUnsavedChangesGuard } from "@/hooks/useUnsavedChangesGuard";
import UnsavedChangesDialog from "@/components/UnsavedChangesDialog";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Save, Plus, Trash2, Target, TrendingUp, AlertTriangle, Shield, Cpu, Workflow, Info } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import MaturityScale from "../components/grc/MaturityScale";
import MaturityBadge from "../components/grc/MaturityBadge";
import GoalActionPanel from "@/components/goals/GoalActionPanel";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import CompanyField from "@/components/CompanyField";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider } from "@/components/ui/tooltip";
import SearchableSelect from "@/components/ui/SearchableSelect";

export default function GRCGoalDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const goalId = urlParams.get('id');
  const [globalCompany, , { locked }] = useCompanyFilter();

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    company_id: globalCompany && globalCompany !== "all" ? globalCompany : "",
    category: "governance",
    linked_risk_ids: [],
    linked_control_ids: [],
    linked_capability_ids: [],
    linked_process_ids: [],
    linked_objective_ids: [],
    current_maturity: null,
    target_maturity: null,
    maturity_gap: 0,
    status: "not_started",
    source: "Manual",
    owner: "",
    due_date: "",
    notes: "",
    maturity_assessments: []
  });

  const [isCapabilityDialogOpen, setIsCapabilityDialogOpen] = useState(false);
  const [isProcessDialogOpen, setIsProcessDialogOpen] = useState(false);
  const [isAssessmentDialogOpen, setIsAssessmentDialogOpen] = useState(false);
  const [newAssessment, setNewAssessment] = useState({ level: null, notes: "", assessor: "" });
  const [useDecimal, setUseDecimal] = useState(false);
  const [decimalErrors, setDecimalErrors] = useState({ current: "", target: "" });
  const [decimalInputs, setDecimalInputs] = useState({ current: "", target: "" });

  // Parse a comma-decimal string (e.g. "1,5") into a number (1.5).
  // Returns null if the input is empty or not a valid 1-decimal-place value.
  const parseDecimalMaturity = (raw) => {
    if (!raw || !raw.toString().trim()) return null;
    const normalized = raw.toString().replace(",", ".").trim();
    if (!/^\d+(\.\d{1})?$/.test(normalized)) return null;
    return parseFloat(normalized);
  };

  // Validate a decimal maturity value: must be 1.0–5.0 with 1 decimal place.
  // Returns an error string (empty when valid).
  const validateDecimalMaturity = (raw) => {
    if (!raw || !raw.toString().trim()) return "";
    const normalized = raw.toString().replace(",", ".").trim();
    if (!/^\d+([,.]\d{1})?$/.test(raw.toString().trim())) {
      return "Use 1 decimal place (e.g. 1,5). Use a comma, not a period.";
    }
    const val = parseFloat(normalized);
    if (isNaN(val)) return "Invalid number";
    if (val < 1.0) return "Value cannot be below 1,0 (Initial)";
    if (val > 5.0) return "Value cannot exceed 5,0 (Optimized)";
    return "";
  };

  const handleDecimalMaturityChange = (field, raw) => {
    const key = field === "current_maturity" ? "current" : "target";
    const error = validateDecimalMaturity(raw);
    setDecimalErrors(prev => ({ ...prev, [key]: error }));
    setDecimalInputs(prev => ({ ...prev, [key]: raw }));
    if (error) return;
    const parsed = parseDecimalMaturity(raw);
    setFormData(prev => ({ ...prev, [field]: parsed }));
  };

  const formatDecimalForInput = (val) => {
    if (val == null) return "";
    return Number.isInteger(val) ? String(val) : val.toFixed(1).replace(".", ",");
  };
  const { isDirty, checkDirty, initSnapshot, markClean, guardedNavigate, showDialog, confirmDiscard, confirmSave, cancelDialog } = useUnsavedChangesGuard(navigate);

  const { data: existingGoal } = useQuery({
    queryKey: ['grcGoal', goalId],
    queryFn: () => base44.entities.GRCGoal.filter({ id: goalId }),
    enabled: !!goalId,
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list(),
  });

  const { data: risks = [] } = useQuery({
    queryKey: ['risks'],
    queryFn: () => base44.entities.Risk.list(),
  });

  const { data: controlObjectives = [] } = useQuery({
    queryKey: ['controlObjectives'],
    queryFn: () => base44.entities.ControlObjective.list(),
  });

  const { data: capabilities = [] } = useQuery({
    queryKey: ['itCapabilities'],
    queryFn: () => base44.entities.ITCapability.list(),
  });

  const { data: processes = [] } = useQuery({
    queryKey: ['orgProcesses'],
    queryFn: () => base44.entities.OrgProcess.list(),
  });

  useEffect(() => {
    if (existingGoal?.[0]) {
      setFormData(existingGoal[0]);
      initSnapshot(existingGoal[0]);
      setDecimalInputs({
        current: formatDecimalForInput(existingGoal[0].current_maturity),
        target: formatDecimalForInput(existingGoal[0].target_maturity)
      });
    } else if (!goalId) {
      initSnapshot(formData);
    }
  }, [existingGoal]);

  useEffect(() => {
    if (formData.current_maturity != null && formData.target_maturity != null) {
      const gap = Math.max(0, +(formData.target_maturity - formData.current_maturity).toFixed(1));
      setFormData(prev => ({ ...prev, maturity_gap: gap }));
    }
  }, [formData.current_maturity, formData.target_maturity]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.GRCGoal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['grcGoals']);
      navigate(createPageUrl("GRCGoals"));
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.GRCGoal.update(goalId, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['grcGoals']);
      queryClient.invalidateQueries(['grcGoal', goalId]);
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    markClean();
    if (goalId) {
      await updateMutation.mutateAsync(formData);
    } else {
      await createMutation.mutateAsync(formData);
    }
  };

  const addRisk = (riskId) => {
    if (riskId && !formData.linked_risk_ids.includes(riskId)) {
      const updated = [...formData.linked_risk_ids, riskId];
      setFormData({ ...formData, linked_risk_ids: updated });
      if (goalId) updateMutation.mutate({ ...formData, linked_risk_ids: updated });
    }
  };

  const removeRisk = (riskId) => {
    const updated = formData.linked_risk_ids.filter(id => id !== riskId);
    setFormData({ ...formData, linked_risk_ids: updated });
    if (goalId) updateMutation.mutate({ ...formData, linked_risk_ids: updated });
  };

  const addControl = (controlId) => {
    if (controlId && !formData.linked_control_ids.includes(controlId)) {
      const updated = [...formData.linked_control_ids, controlId];
      setFormData({ ...formData, linked_control_ids: updated });
      if (goalId) updateMutation.mutate({ ...formData, linked_control_ids: updated });
    }
  };

  const removeControl = (controlId) => {
    const updated = formData.linked_control_ids.filter(id => id !== controlId);
    setFormData({ ...formData, linked_control_ids: updated });
    if (goalId) updateMutation.mutate({ ...formData, linked_control_ids: updated });
  };

  const addCapability = (capabilityId) => {
    if (!formData.linked_capability_ids.includes(capabilityId)) {
      const updated = [...formData.linked_capability_ids, capabilityId];
      setFormData({ ...formData, linked_capability_ids: updated });
      if (goalId) updateMutation.mutate({ ...formData, linked_capability_ids: updated });
    }
    setIsCapabilityDialogOpen(false);
  };

  const removeCapability = (capabilityId) => {
    const updated = formData.linked_capability_ids.filter(id => id !== capabilityId);
    setFormData({ ...formData, linked_capability_ids: updated });
    if (goalId) updateMutation.mutate({ ...formData, linked_capability_ids: updated });
  };

  const addProcess = (processId) => {
    if (!formData.linked_process_ids.includes(processId)) {
      const updated = [...formData.linked_process_ids, processId];
      setFormData({ ...formData, linked_process_ids: updated });
      if (goalId) updateMutation.mutate({ ...formData, linked_process_ids: updated });
    }
    setIsProcessDialogOpen(false);
  };

  const removeProcess = (processId) => {
    const updated = formData.linked_process_ids.filter(id => id !== processId);
    setFormData({ ...formData, linked_process_ids: updated });
    if (goalId) updateMutation.mutate({ ...formData, linked_process_ids: updated });
  };

  const addMaturityAssessment = () => {
    if (newAssessment.level) {
      const assessment = {
        date: new Date().toISOString().split('T')[0],
        level: newAssessment.level,
        assessor: newAssessment.assessor,
        notes: newAssessment.notes
      };
      const updatedAssessments = [...(formData.maturity_assessments || []), assessment];
      const updatedFormData = {
        ...formData,
        maturity_assessments: updatedAssessments,
        current_maturity: newAssessment.level
      };
      setFormData(updatedFormData);
      if (goalId) updateMutation.mutate(updatedFormData);
      setNewAssessment({ level: null, notes: "", assessor: "" });
      setIsAssessmentDialogOpen(false);
    }
  };

  // Track dirty state
  useEffect(() => { checkDirty(formData); }, [formData]);

  // Only show risks belonging to the selected company (exclude master library risks)
  const companyRisks = risks.filter(r =>
    (!formData.company_id || r.company_id === formData.company_id) &&
    !r.is_library_risk
  );
  const linkedRisks = risks.filter(r => formData.linked_risk_ids?.includes(r.id));
  const linkedControlObjectives = controlObjectives.filter(c => formData.linked_control_ids?.includes(c.id));
  const availableControlObjectives = controlObjectives.filter(c => !formData.linked_control_ids?.includes(c.id));
  const linkedCapabilities = capabilities.filter(c => formData.linked_capability_ids?.includes(c.id));
  const linkedProcesses = processes.filter(p => formData.linked_process_ids?.includes(p.id));
  const company = companies.find(c => c.id === formData.company_id);
  
  const companyObjectives = company?.objectives || [];
  const linkedObjectives = companyObjectives.filter(obj => formData.linked_objective_ids?.includes(obj.id));
  const availableObjectives = companyObjectives.filter(obj => !formData.linked_objective_ids?.includes(obj.id));

  const addObjective = (objectiveId) => {
    const updated = [...(formData.linked_objective_ids || []), objectiveId];
    setFormData({ ...formData, linked_objective_ids: updated });
    if (goalId) updateMutation.mutate({ ...formData, linked_objective_ids: updated });
  };

  const removeObjective = (objectiveId) => {
    const updated = formData.linked_objective_ids.filter(id => id !== objectiveId);
    setFormData({ ...formData, linked_objective_ids: updated });
    if (goalId) updateMutation.mutate({ ...formData, linked_objective_ids: updated });
  };

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => guardedNavigate(createPageUrl("GRCGoals"))}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">
              {goalId ? 'Edit GRC Goal' : 'New GRC Goal'}
            </h1>
            <div className="flex items-center gap-2">
              <p className="text-slate-600">Define goals with maturity assessments</p>
              {goalId && formData.source && (
                <Badge variant="outline" className="bg-slate-100 text-slate-600 border-slate-200">
                  Source: {formData.source}
                </Badge>
              )}
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={() => guardedNavigate(createPageUrl("GRCGoals"))}>Cancel</Button>
          <Button onClick={handleSubmit} className="bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4 mr-2" />
            {goalId ? 'Save Changes' : 'Create Goal'}
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <CardTitle>Goal Details</CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="title">Title *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({...formData, title: e.target.value})}
                      required
                    />
                  </div>
                  <CompanyField value={formData.company_id} onChange={(value) => setFormData({...formData, company_id: value})} companies={companies} />
                  <div className="space-y-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="governance">Governance</SelectItem>
                        <SelectItem value="risk_management">Risk Management</SelectItem>
                        <SelectItem value="compliance">Compliance</SelectItem>
                        <SelectItem value="security">Security</SelectItem>
                        <SelectItem value="operational">Operational</SelectItem>
                        <SelectItem value="strategic">Strategic</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="not_started">Not Started</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="on_track">On Track</SelectItem>
                        <SelectItem value="at_risk">At Risk</SelectItem>
                        <SelectItem value="achieved">Achieved</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="owner">Owner</Label>
                    <Input
                      id="owner"
                      value={formData.owner}
                      onChange={(e) => setFormData({...formData, owner: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="due_date">Due Date</Label>
                    <Input
                      id="due_date"
                      type="date"
                      value={formData.due_date}
                      onChange={(e) => setFormData({...formData, due_date: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      rows={3}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  Strategic Objectives
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                {linkedObjectives.length > 0 ? (
                  <div className="space-y-2">
                    {linkedObjectives.map(obj => (
                      <div key={obj.id} className="flex items-center justify-between p-3 bg-purple-50 rounded-lg border border-purple-200">
                        <div>
                          <p className="font-medium text-slate-900">{obj.title}</p>
                          {obj.description && (
                            <p className="text-sm text-slate-600">{obj.description}</p>
                          )}
                        </div>
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeObjective(obj.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500 text-center py-4">No objectives linked yet</p>
                )}
                
                {availableObjectives.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <Label>Add Strategic Objective</Label>
                    <Select onValueChange={addObjective}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select objective to add" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableObjectives.map(obj => (
                          <SelectItem key={obj.id} value={obj.id}>
                            {obj.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-orange-600" />
                  Linked Entity Risks
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4 space-y-4">
                {linkedRisks.length > 0 ? (
                  <div className="space-y-2">
                    {linkedRisks.map(risk => (
                      <div key={risk.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
                        <div>
                          <p className="font-medium text-slate-900">{risk.title}</p>
                          <p className="text-sm text-slate-600">{risk.category?.replace('_', ' ')}</p>
                        </div>
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeRisk(risk.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500 text-center py-4">No risks linked yet</p>
                )}
                {formData.company_id && companyRisks.filter(r => !formData.linked_risk_ids?.includes(r.id)).length > 0 && (
                  <div className="space-y-2">
                    <Label>Add Risk</Label>
                    <SearchableSelect
                      value=""
                      onValueChange={(id) => id && addRisk(id)}
                      options={companyRisks
                        .filter(r => !formData.linked_risk_ids?.includes(r.id))
                        .map(r => ({ id: r.id, label: r.risk_reference_nr ? `${r.risk_reference_nr} - ${r.title}` : r.title }))}
                      placeholder="Search risks to add…"
                    />
                  </div>
                )}
                {!formData.company_id && (
                  <p className="text-xs text-slate-400">Select a company first to link risks.</p>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-blue-600" />
                  Control Objectives
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4 space-y-4">
                {linkedControlObjectives.length > 0 ? (
                  <div className="space-y-2">
                    {linkedControlObjectives.map(obj => (
                      <div key={obj.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <div>
                          <p className="font-medium text-slate-900">{obj.reference_number ? `${obj.reference_number} - ${obj.title}` : obj.title}</p>
                          {obj.category && <p className="text-sm text-slate-600">{obj.category}</p>}
                        </div>
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeControl(obj.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500 text-center py-4">No control objectives linked yet</p>
                )}
                {availableControlObjectives.length > 0 && (
                  <div className="space-y-2">
                    <Label>Add Control Objective</Label>
                    <SearchableSelect
                      value=""
                      onValueChange={(id) => id && addControl(id)}
                      options={availableControlObjectives.map(o => ({ id: o.id, label: o.reference_number ? `${o.reference_number} - ${o.title}` : o.title }))}
                      placeholder="Search control objectives to add…"
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="w-5 h-5 text-indigo-600" />
                    IT Capabilities
                  </CardTitle>
                  <Dialog open={isCapabilityDialogOpen} onOpenChange={setIsCapabilityDialogOpen}>
                    <DialogTrigger asChild>
                      <Button type="button" variant="outline" size="sm">
                        <Plus className="w-4 h-4 mr-1" /> Add Capability
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Link IT Capability</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {capabilities.filter(c => !formData.linked_capability_ids?.includes(c.id)).map(capability => (
                          <div
                            key={capability.id}
                            className="p-3 border rounded-lg hover:bg-slate-50 cursor-pointer"
                            onClick={() => addCapability(capability.id)}
                          >
                            <p className="font-medium">{capability.name}</p>
                            <p className="text-sm text-slate-600">{capability.category?.replace('_', ' ')}</p>
                          </div>
                        ))}
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                {linkedCapabilities.length > 0 ? (
                  <div className="space-y-2">
                    {linkedCapabilities.map(capability => (
                      <div key={capability.id} className="flex items-center justify-between p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                        <div>
                          <p className="font-medium text-slate-900">{capability.name}</p>
                          <p className="text-sm text-slate-600">{capability.category?.replace('_', ' ')}</p>
                        </div>
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeCapability(capability.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500 text-center py-4">No capabilities linked yet</p>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Workflow className="w-5 h-5 text-teal-600" />
                    Business Processes
                  </CardTitle>
                  <Dialog open={isProcessDialogOpen} onOpenChange={setIsProcessDialogOpen}>
                    <DialogTrigger asChild>
                      <Button type="button" variant="outline" size="sm">
                        <Plus className="w-4 h-4 mr-1" /> Add Process
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Link Business Process</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {processes.filter(p => !formData.linked_process_ids?.includes(p.id)).map(proc => (
                          <div
                            key={proc.id}
                            className="p-3 border rounded-lg hover:bg-slate-50 cursor-pointer"
                            onClick={() => addProcess(proc.id)}
                          >
                            <p className="font-medium">{proc.process_code} - {proc.name}</p>
                            <p className="text-sm text-slate-600">Level {proc.level}</p>
                          </div>
                        ))}
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                {linkedProcesses.length > 0 ? (
                  <div className="space-y-2">
                    {linkedProcesses.map(proc => (
                      <div key={proc.id} className="flex items-center justify-between p-3 bg-teal-50 rounded-lg border border-teal-200">
                        <div>
                          <p className="font-medium text-slate-900">{proc.process_code} - {proc.name}</p>
                          <p className="text-sm text-slate-600">Level {proc.level}</p>
                        </div>
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeProcess(proc.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500 text-center py-4">No processes linked yet</p>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                  Maturity Assessment
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-6">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                  <Checkbox
                    id="use-decimal"
                    checked={useDecimal}
                    onCheckedChange={(checked) => {
                      setUseDecimal(checked === true);
                      setDecimalErrors({ current: "", target: "" });
                      if (checked) {
                        setDecimalInputs({
                          current: formatDecimalForInput(formData.current_maturity),
                          target: formatDecimalForInput(formData.target_maturity)
                        });
                      } else {
                        setDecimalInputs({ current: "", target: "" });
                      }
                    }}
                  />
                  <Label htmlFor="use-decimal" className="text-sm font-medium cursor-pointer flex items-center gap-1">
                    Use decimal for target
                    <TooltipProvider delayDuration={200}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="w-3.5 h-3.5 text-slate-400 cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-[220px]">
                          Use a comma "," as the decimal separator (e.g. 1,5), not a period. Values must be between 1,0 and 5,0 with 1 decimal place. The whole number determines the band — e.g. 1,5 is still "Initial".
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Label>
                </div>

                {useDecimal ? (
                  <>
                    <div className="space-y-2">
                      <Label>Current Maturity (decimal)</Label>
                      <Input
                        type="text"
                        inputMode="decimal"
                        placeholder="e.g. 1,5"
                        value={decimalInputs.current}
                        onChange={(e) => handleDecimalMaturityChange("current_maturity", e.target.value)}
                        className={decimalErrors.current ? "border-red-400" : ""}
                      />
                      {decimalErrors.current && (
                        <p className="text-xs text-red-500">{decimalErrors.current}</p>
                      )}
                      {formData.current_maturity != null && !decimalErrors.current && (
                        <MaturityBadge level={formData.current_maturity} showDescription />
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label>Target Maturity (decimal)</Label>
                      <Input
                        type="text"
                        inputMode="decimal"
                        placeholder="e.g. 3,5"
                        value={decimalInputs.target}
                        onChange={(e) => handleDecimalMaturityChange("target_maturity", e.target.value)}
                        className={decimalErrors.target ? "border-red-400" : ""}
                      />
                      {decimalErrors.target && (
                        <p className="text-xs text-red-500">{decimalErrors.target}</p>
                      )}
                      {formData.target_maturity != null && !decimalErrors.target && (
                        <MaturityBadge level={formData.target_maturity} showDescription />
                      )}
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label>Current Maturity</Label>
                      <MaturityScale
                        value={formData.current_maturity}
                        onChange={(level) => setFormData({...formData, current_maturity: level})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Target Maturity</Label>
                      <MaturityScale
                        value={formData.target_maturity}
                        onChange={(level) => setFormData({...formData, target_maturity: level})}
                      />
                    </div>
                  </>
                )}
                {formData.maturity_gap > 0 && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
                    <p className="text-sm text-red-700">Maturity Gap</p>
                    <p className="text-3xl font-bold text-red-700">{formData.maturity_gap.toFixed(1).replace(".", ",")}</p>
                  </div>
                )}
                {formData.maturity_gap === 0 && formData.current_maturity && formData.target_maturity && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                    <p className="text-sm text-green-700">Target Achieved!</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <div className="flex items-center justify-between">
                  <CardTitle>Assessment History</CardTitle>
                  <Dialog open={isAssessmentDialogOpen} onOpenChange={setIsAssessmentDialogOpen}>
                    <DialogTrigger asChild>
                      <Button type="button" variant="outline" size="sm">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Record Maturity Assessment</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label>Maturity Level</Label>
                          <MaturityScale
                            value={newAssessment.level}
                            onChange={(level) => setNewAssessment({...newAssessment, level})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Assessor</Label>
                          <Input
                            value={newAssessment.assessor}
                            onChange={(e) => setNewAssessment({...newAssessment, assessor: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Notes</Label>
                          <Textarea
                            value={newAssessment.notes}
                            onChange={(e) => setNewAssessment({...newAssessment, notes: e.target.value})}
                            rows={2}
                          />
                        </div>
                        <Button type="button" onClick={addMaturityAssessment} className="w-full">
                          Record Assessment
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                {formData.maturity_assessments?.length > 0 ? (
                  <div className="space-y-2">
                    {[...formData.maturity_assessments].reverse().map((assessment, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                        <div className="flex items-center justify-between mb-1">
                          <MaturityBadge level={assessment.level} />
                          <span className="text-xs text-slate-500">
                            {format(new Date(assessment.date), 'd MMM yyyy')}
                          </span>
                        </div>
                        {assessment.assessor && (
                          <p className="text-xs text-slate-600">By: {assessment.assessor}</p>
                        )}
                        {assessment.notes && (
                          <p className="text-sm text-slate-700 mt-1">{assessment.notes}</p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500 text-center py-4">No assessments recorded</p>
                )}
              </CardContent>
            </Card>

          </div>
        </div>

        {goalId && (
          <div className="mt-6">
            <GoalActionPanel goalId={goalId} companyId={formData.company_id} />
          </div>
        )}
      </form>

      <UnsavedChangesDialog
        open={showDialog}
        onDiscard={confirmDiscard}
        onSave={() => confirmSave(handleSubmit.bind(null, { preventDefault: () => {} }))}
        onClose={cancelDialog}
      />
    </div>
  );
}