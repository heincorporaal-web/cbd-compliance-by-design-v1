import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import {
  Workflow, FileText, GitBranch, ShieldCheck,
  UserX, FileX2, AlertTriangle, ShieldX, CheckCircle2, Activity, Archive,
} from "lucide-react";
import ModuleDashboard from "@/components/branding/ModuleDashboard";
import { BRANDS } from "@/lib/moduleBrands";

const FEATURES = [
  { icon: Workflow, title: "BPMN 2.0 Designer", desc: "Model end-to-end processes with a full BPMN 2.0 canvas, element data pane and SVG snapshots." },
  { icon: FileText, title: "Document Templates", desc: "Compose SOPs and work instructions that merge data fields straight from your process flows." },
  { icon: GitBranch, title: "Process Hierarchy", desc: "Navigate the full process tree, link risks, controls and systems, and keep versions in check." },
  { icon: ShieldCheck, title: "Risk-based Assessment", desc: "Assess process maturity and risk posture, and turn gaps into tracked actions." },
];

export default function OperationsByDesign() {
  const [companyId] = useCompanyFilter();
  const effectiveCompanyId = companyId === "all" ? null : companyId;

  const { data: processes = [], isLoading } = useQuery({
    queryKey: ["orgProcesses", effectiveCompanyId],
    queryFn: () =>
      effectiveCompanyId
        ? base44.entities.OrgProcess.filter({ company_id: effectiveCompanyId })
        : base44.entities.OrgProcess.list("-created_date", 500),
  });

  const { data: diagrams = [] } = useQuery({
    queryKey: ["processDiagrams", effectiveCompanyId],
    queryFn: () =>
      effectiveCompanyId
        ? base44.entities.ProcessDiagram.filter({ company_id: effectiveCompanyId })
        : base44.entities.ProcessDiagram.list("-created_date", 500),
    enabled: !isLoading,
  });

  const processIdsWithDiagrams = new Set(diagrams.map((d) => d.process_id));

  const metrics = [
    { label: "Total Processes", value: processes.length, icon: GitBranch, link: "/ProcessManagement" },
    { label: "Without Owner", value: processes.filter((p) => !p.process_owner && !p.process_owner_stakeholder_id).length, icon: UserX, link: "/ProcessManagement", attention: true },
    { label: "Without Diagram", value: processes.filter((p) => !processIdsWithDiagrams.has(p.id)).length, icon: FileX2, link: "/AdvancedProcessModelling", attention: true },
    { label: "Without Risks", value: processes.filter((p) => !p.linked_risk_ids?.length).length, icon: AlertTriangle, link: "/ProcessManagement", attention: true },
    { label: "Without Controls", value: processes.filter((p) => !p.linked_control_ids?.length).length, icon: ShieldX, link: "/ProcessManagement", attention: true },
    { label: "Active", value: processes.filter((p) => p.status === "active").length, icon: CheckCircle2, link: "/ProcessManagement" },
    { label: "Draft / Review", value: processes.filter((p) => ["draft", "under_review"].includes(p.status)).length, icon: Activity, link: "/ProcessManagement" },
    { label: "Archived", value: processes.filter((p) => p.status === "archived").length, icon: Archive, link: "/ProcessManagement" },
  ];

  return (
    <ModuleDashboard
      brand={BRANDS.obd}
      Icon={Workflow}
      logoUrl={BRANDS.obd.logoUrl}
      metrics={metrics}
      isLoading={isLoading}
      enterPath={BRANDS.obd.enterPath}
      enterLabel={BRANDS.obd.enterLabel}
      features={FEATURES}
      moduleKey="obd"
    />
  );
}