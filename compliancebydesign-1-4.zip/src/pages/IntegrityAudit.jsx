import React, { useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, ShieldCheck, AlertCircle, RefreshCw } from "lucide-react";
import IntegritySummaryCards from "@/components/integrity/IntegritySummaryCards";
import IntegrityFindingsTable from "@/components/integrity/IntegrityFindingsTable";
import ExceptionDialog from "@/components/integrity/ExceptionDialog";
import ExceptionsPanel from "@/components/integrity/ExceptionsPanel";
import PageHeader from "@/components/layout/PageHeader";
import { useToast } from "@/components/ui/use-toast";

export default function IntegrityAudit() {
  const [selectedCompanyId, setSelectedCompanyId] = useCompanyFilter();
  const [running, setRunning] = useState(false);
  const [auditData, setAuditData] = useState(null);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("findings");
  const [exceptionDialogOpen, setExceptionDialogOpen] = useState(false);
  const [selectedFinding, setSelectedFinding] = useState(null);
  const [refreshExceptions, setRefreshExceptions] = useState(0);
  const { toast } = useToast();

  const runAudit = useCallback(async () => {
    if (!selectedCompanyId) return;
    setRunning(true);
    setError(null);
    try {
      const result = await base44.functions.invoke("runIntegrityAudit", {
        company_id: selectedCompanyId,
        include_cross_entity: true,
      });
      const data = result?.data ?? result;
      if (data?.error) {
        throw new Error(data.error);
      }
      setAuditData(data);
      setActiveTab("summary");
    } catch (e) {
      setError(e.message || "Failed to run integrity audit");
    } finally {
      setRunning(false);
    }
  }, [selectedCompanyId]);

  const handleAcceptException = useCallback((finding) => {
    setSelectedFinding(finding);
    setExceptionDialogOpen(true);
  }, []);

  const handleConfirmException = useCallback(
    async (finding, rationale) => {
      try {
        await base44.functions.invoke("manageAuditException", {
          action: "accept",
          company_id: selectedCompanyId,
          finding,
          rationale,
        });
        toast({ title: "Exception accepted", description: "The finding will be suppressed on future audits while conditions remain unchanged." });
        setRefreshExceptions((n) => n + 1);
        // Re-run audit to update the dashboard
        runAudit();
      } catch (e) {
        toast({ variant: "destructive", title: "Failed to accept exception", description: e.message });
      }
    },
    [selectedCompanyId, toast, runAudit]
  );

  const handleInvalidateException = useCallback(
    async (exceptionId) => {
      try {
        await base44.functions.invoke("manageAuditException", {
          action: "invalidate",
          company_id: selectedCompanyId,
          exception_id: exceptionId,
        });
        toast({ title: "Exception invalidated", description: "The finding will reappear on the next audit run." });
        setRefreshExceptions((n) => n + 1);
        runAudit();
      } catch (e) {
        toast({ variant: "destructive", title: "Failed to invalidate exception", description: e.message });
      }
    },
    [selectedCompanyId, toast, runAudit]
  );

  const handleApplyCorrection = useCallback(
    (finding) => {
      // Corrections are applied through the existing CBD update mechanisms
      // Navigate to the relevant entity detail page
      if (finding.entity_type === "OrgProcess") {
        toast({
          title: "Apply correction",
          description: `Navigate to the process detail page to apply: ${finding.proposed_relationship}`,
        });
      } else {
        toast({
          title: "Apply correction",
          description: finding.proposed_relationship,
        });
      }
    },
    [toast]
  );

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <PageHeader
        navItemId="integrity_audit"
        icon={ShieldCheck}
        title="Integrity Audit"
        tagline="Exception-aware data integrity and relationship audit with hierarchy validation."
        gradient="from-purple-600 to-indigo-700"
      />

      {/* Run audit card */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-5 h-5 text-purple-600" />
              <div>
                <p className="font-semibold text-slate-900">Run Integrity Audit</p>
                <p className="text-xs text-slate-500">
                  Detects hierarchy anomalies, relationship inconsistencies, and structural failures.
                  Accepted exceptions are suppressed while their fingerprint remains unchanged.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {auditData && (
                <Button variant="outline" onClick={() => setAuditData(null)} className="gap-2">
                  Reset
                </Button>
              )}
              <Button
                onClick={runAudit}
                disabled={!selectedCompanyId || running}
                className="gap-2 bg-purple-600 hover:bg-purple-700"
              >
                {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                {running ? "Running audit..." : "Run Audit"}
              </Button>
              {!selectedCompanyId && (
                <span className="text-xs text-amber-600">Select a company first</span>
              )}
            </div>
          </div>
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2 mt-3">
              <AlertCircle className="w-4 h-4" /> {error}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {auditData && (
        <>
          <IntegritySummaryCards dashboard={auditData.dashboard} summary={auditData.summary} />

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="summary">Summary</TabsTrigger>
              <TabsTrigger value="findings">
                Findings ({auditData.findings?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="exceptions">
                Exceptions
              </TabsTrigger>
              {auditData.invalidated_exceptions?.length > 0 && (
                <TabsTrigger value="invalidated">
                  Invalidated ({auditData.invalidated_exceptions.length})
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="summary" className="mt-4 space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-xs text-slate-500">Audit Run ID</p>
                      <p className="text-sm font-mono text-slate-900">{auditData.audit_run_id}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Audited At</p>
                      <p className="text-sm text-slate-900">
                        {new Date(auditData.audited_at).toLocaleString("en-GB")}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Processes Checked</p>
                      <p className="text-sm font-semibold text-slate-900">
                        {auditData.record_counts?.processes || 0}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Active Exceptions</p>
                      <p className="text-sm font-semibold text-purple-600">
                        {auditData.exceptions?.active || 0}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Suppressed Findings</p>
                      <p className="text-sm font-semibold text-purple-600">
                        {auditData.summary?.suppressed_count || 0}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Invalidated Exceptions</p>
                      <p className="text-sm font-semibold text-red-600">
                        {auditData.exceptions?.invalidated || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {auditData.invalidated_exceptions?.length > 0 && (
                <Card className="border-red-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-3">
                      <AlertCircle className="w-5 h-5 text-red-600" />
                      <h4 className="font-semibold text-slate-900">
                        {auditData.invalidated_exceptions.length} Exception(s) Invalidated
                      </h4>
                    </div>
                    <p className="text-sm text-slate-500 mb-3">
                      These exceptions were invalidated because the underlying relationship attributes
                      changed. The findings are now actionable and require correction or renewed exception acceptance.
                    </p>
                    <div className="space-y-2">
                      {auditData.invalidated_exceptions.map((inv, i) => (
                        <div key={i} className="text-xs bg-red-50 border border-red-200 rounded-lg p-2">
                          <span className="font-mono text-slate-600">{inv.rule_id}</span> ·{" "}
                          <span className="text-slate-700">{inv.entity_type}:{inv.entity_id}</span>
                          <div className="text-slate-400 mt-1">
                            Fingerprint: {inv.old_fingerprint} → {inv.new_fingerprint}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="findings" className="mt-4">
              <IntegrityFindingsTable
                findings={auditData.findings || []}
                onAcceptException={handleAcceptException}
                onApplyCorrection={handleApplyCorrection}
              />
            </TabsContent>

            <TabsContent value="exceptions" className="mt-4">
              <ExceptionsPanel
                key={refreshExceptions}
                companyId={selectedCompanyId}
                onInvalidate={handleInvalidateException}
              />
            </TabsContent>

            {auditData.invalidated_exceptions?.length > 0 && (
              <TabsContent value="invalidated" className="mt-4">
                <Card>
                  <CardContent className="pt-6 space-y-2">
                    {auditData.invalidated_exceptions.map((inv, i) => (
                      <div key={i} className="text-sm bg-red-50 border border-red-200 rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-xs text-slate-600">{inv.rule_id}</span>
                          <span className="text-xs text-slate-500">{inv.entity_type}</span>
                        </div>
                        <p className="text-slate-700">
                          Fingerprint changed from <span className="font-mono">{inv.old_fingerprint}</span> to{" "}
                          <span className="font-mono">{inv.new_fingerprint}</span>
                        </p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
            )}
          </Tabs>
        </>
      )}

      <ExceptionDialog
        open={exceptionDialogOpen}
        finding={selectedFinding}
        onClose={() => setExceptionDialogOpen(false)}
        onConfirm={handleConfirmException}
      />
    </div>
  );
}