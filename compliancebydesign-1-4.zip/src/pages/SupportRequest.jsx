import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Card, CardHeader, CardTitle, CardDescription, CardContent,
} from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { LifeBuoy, Send, AlertTriangle, HelpCircle, Settings, CheckCircle2, Clock, Loader2 } from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = [
  { value: "system_issue", label: "Report a System Issue", icon: AlertTriangle, hint: "Something isn't working — errors, broken pages, unexpected behaviour." },
  { value: "help_request", label: "Ask for Help", icon: HelpCircle, hint: "Guidance on using a feature or completing a task in the platform." },
  { value: "framework_management", label: "Compliance Framework Management", icon: Settings, hint: "Request changes to frameworks, controls, risks, or assessment cycles." },
];

const URGENCY = [
  { value: "low", label: "Low — General question", color: "bg-slate-100 text-slate-700" },
  { value: "medium", label: "Medium — Affects my work", color: "bg-amber-100 text-amber-800" },
  { value: "high", label: "High — Blocking work", color: "bg-orange-100 text-orange-800" },
  { value: "critical", label: "Critical — System down", color: "bg-red-100 text-red-800" },
];

const STATUS_BADGE = {
  open: { label: "Open", className: "bg-blue-100 text-blue-800" },
  in_progress: { label: "In Progress", className: "bg-amber-100 text-amber-800" },
  resolved: { label: "Resolved", className: "bg-emerald-100 text-emerald-800" },
  closed: { label: "Closed", className: "bg-slate-100 text-slate-600" },
};

export default function SupportRequest() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({
    category: "system_issue",
    urgency: "medium",
    subject: "",
    message: "",
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: myRequests = [], isLoading } = useQuery({
    queryKey: ["mySupportRequests"],
    queryFn: () => base44.entities.ContactRequest.filter(
      { request_type: "support" },
      "-created_date",
      20
    ),
  });

  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    if (!form.subject.trim() || !form.message.trim()) {
      toast.error("Please enter a subject and describe your request.");
      return;
    }
    setSubmitting(true);
    try {
      const categoryLabel = CATEGORIES.find(c => c.value === form.category)?.label || form.category;
      const urgencyLabel = URGENCY.find(u => u.value === form.urgency)?.label || form.urgency;
      const fullMessage = `[${categoryLabel}] [Urgency: ${urgencyLabel}]\n\n${form.message.trim()}`;
      await base44.functions.invoke("submitContactRequest", {
        subject: form.subject.trim(),
        message: fullMessage,
        request_type: "support",
      });
      toast.success("Your support request has been submitted.");
      setForm({ category: "system_issue", urgency: "medium", subject: "", message: "" });
      queryClient.invalidateQueries(["mySupportRequests"]);
    } catch (e) {
      toast.error("Failed to submit request: " + (e?.message || "unknown error"));
    } finally {
      setSubmitting(false);
    }
  };

  const selectedCategory = CATEGORIES.find(c => c.value === form.category);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 p-[2px] bg-gradient-to-br from-slate-700 to-indigo-700 rounded-xl shrink-0">
          <div className="w-full h-full bg-slate-200 rounded-[10px] flex items-center justify-center">
            <LifeBuoy className="w-7 h-7 text-primary" />
          </div>
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Support Request</h1>
          <p className="text-slate-500 text-sm">Submit a request, report a system issue, or ask for help with compliance framework management.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Form */}
        <div className="lg:col-span-3">
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="bg-slate-50 border-b border-slate-100">
              <CardTitle className="text-lg flex items-center gap-2">
                <Send className="w-4 h-4 text-indigo-600" /> New Support Request
              </CardTitle>
              <CardDescription>
                Your name and email are included automatically.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-5 sm:p-6 space-y-4">
              {/* Category */}
              <div>
                <Label className="mb-1.5 block">Request Category</Label>
                <div className="grid grid-cols-1 gap-2">
                  {CATEGORIES.map((cat) => {
                    const Icon = cat.icon;
                    const active = form.category === cat.value;
                    return (
                      <button
                        key={cat.value}
                        type="button"
                        onClick={() => setField("category", cat.value)}
                        className={`flex items-start gap-3 p-3 rounded-lg border text-left transition-colors ${
                          active
                            ? "border-indigo-500 bg-indigo-50 ring-1 ring-indigo-200"
                            : "border-slate-200 bg-white hover:bg-slate-50"
                        }`}
                      >
                        <Icon className={`w-5 h-5 mt-0.5 shrink-0 ${active ? "text-indigo-600" : "text-slate-400"}`} />
                        <div className="min-w-0">
                          <p className={`text-sm font-medium ${active ? "text-indigo-900" : "text-slate-800"}`}>{cat.label}</p>
                          <p className="text-xs text-slate-500 mt-0.5">{cat.hint}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Urgency */}
              <div>
                <Label className="mb-1.5 block">Urgency</Label>
                <Select value={form.urgency} onValueChange={(v) => setField("urgency", v)}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {URGENCY.map(u => (
                      <SelectItem key={u.value} value={u.value}>{u.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Identity (read-only) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label>Your Name</Label>
                  <Input value={user?.full_name || ""} disabled />
                </div>
                <div>
                  <Label>Your Email</Label>
                  <Input value={user?.email || ""} disabled />
                </div>
              </div>

              {/* Subject */}
              <div>
                <Label>Subject <span className="text-destructive">*</span></Label>
                <Input
                  placeholder={selectedCategory ? `e.g. ${selectedCategory.label} — …` : "Brief summary of your request"}
                  value={form.subject}
                  onChange={e => setField("subject", e.target.value)}
                />
              </div>

              {/* Message */}
              <div>
                <Label>Message <span className="text-destructive">*</span></Label>
                <Textarea
                  rows={6}
                  placeholder="Describe the issue or request in detail. Include any relevant page names, framework references, or error messages."
                  value={form.message}
                  onChange={e => setField("message", e.target.value)}
                />
              </div>

              <div className="flex justify-end pt-1">
                <Button onClick={handleSubmit} disabled={submitting} className="gap-2">
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  {submitting ? "Submitting…" : "Submit Request"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* My requests sidebar */}
        <div className="lg:col-span-2">
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="bg-slate-50 border-b border-slate-100">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-600" /> My Recent Requests
              </CardTitle>
              <CardDescription>Track the status of your submitted requests.</CardDescription>
            </CardHeader>
            <CardContent className="p-4 space-y-3 max-h-[520px] overflow-y-auto">
              {isLoading ? (
                <div className="text-center text-slate-400 py-8 text-sm">Loading…</div>
              ) : myRequests.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle2 className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm text-slate-400">No support requests yet.</p>
                </div>
              ) : (
                myRequests.map((req) => {
                  const status = STATUS_BADGE[req.status] || STATUS_BADGE.open;
                  return (
                    <div key={req.id} className="border border-slate-200 rounded-lg p-3 bg-white">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <p className="text-sm font-medium text-slate-800 line-clamp-2">{req.subject}</p>
                        <Badge className={`shrink-0 ${status.className}`}>{status.label}</Badge>
                      </div>
                      <p className="text-xs text-slate-400">
                        {new Date(req.created_date).toLocaleString("en-GB")}
                      </p>
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}