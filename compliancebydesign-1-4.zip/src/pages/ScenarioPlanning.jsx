import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import PageHeader from "@/components/layout/PageHeader";
import ScenarioCard from "@/components/scenarios/ScenarioCard";
import ScenarioFormDialog from "@/components/scenarios/ScenarioFormDialog";
import ScenarioCompare from "@/components/scenarios/ScenarioCompare";
import ScenarioDetail from "@/components/scenarios/ScenarioDetail";
import { GitCompare, Plus, Search, Layers } from "lucide-react";

const STATUS_FILTERS = [
  { value: "all", label: "All Statuses" },
  { value: "draft", label: "Draft" },
  { value: "proposed", label: "Proposed" },
  { value: "under_review", label: "Under Review" },
  { value: "approved", label: "Approved" },
  { value: "rejected", label: "Rejected" },
  { value: "archived", label: "Archived" },
];

export default function ScenarioPlanning() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [companyId] = useCompanyFilter();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedScenario, setSelectedScenario] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editingScenario, setEditingScenario] = useState(null);
  const [compareIds, setCompareIds] = useState([]);
  const [showCompare, setShowCompare] = useState(false);

  const { data: scenariosPage, isLoading } = useQuery({
    queryKey: ["scenarios", companyId],
    queryFn: () =>
      base44.entities.Scenario.filter(
        { company_id: companyId },
        { sort: "-created_date", limit: 200 }
      ),
    enabled: !!companyId,
  });
  const scenarios = scenariosPage?.items || [];

  const filtered = scenarios.filter((s) => {
    if (statusFilter !== "all" && s.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const hay = [s.name, s.description, s.current_state_summary, s.future_state_summary]
        .join(" ")
        .toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  const compareScenarios = scenarios.filter((s) => compareIds.includes(s.id));

  const handleSave = async (payload) => {
    try {
      if (editingScenario) {
        await base44.entities.Scenario.update(editingScenario.id, payload);
        toast({ title: "Scenario updated" });
      } else {
        await base44.entities.Scenario.create(payload);
        toast({ title: "Scenario created" });
      }
      queryClient.invalidateQueries(["scenarios", companyId]);
      setFormOpen(false);
      setEditingScenario(null);
    } catch (err) {
      toast({ title: "Error saving scenario", variant: "destructive" });
    }
  };

  const handleDelete = async () => {
    if (!selectedScenario) return;
    if (!confirm("Delete this scenario? This cannot be undone.")) return;
    try {
      await base44.entities.Scenario.delete(selectedScenario.id);
      queryClient.invalidateQueries(["scenarios", companyId]);
      setSelectedScenario(null);
      toast({ title: "Scenario deleted" });
    } catch (err) {
      toast({ title: "Error deleting scenario", variant: "destructive" });
    }
  };

  const handleUpdate = async (id, patch) => {
    try {
      const updated = await base44.entities.Scenario.update(id, patch);
      queryClient.invalidateQueries(["scenarios", companyId]);
      setSelectedScenario(updated);
    } catch (err) {
      toast({ title: "Error updating scenario", variant: "destructive" });
    }
  };

  const toggleCompare = (id, checked) => {
    if (checked) {
      if (compareIds.length >= 3) {
        toast({ title: "Compare up to 3 scenarios at a time", variant: "destructive" });
        return;
      }
      setCompareIds([...compareIds, id]);
    } else {
      setCompareIds(compareIds.filter((x) => x !== id));
    }
  };

  // Detail view
  if (selectedScenario) {
    return (
      <div className="p-4 md:p-6 max-w-6xl mx-auto">
        <ScenarioDetail
          scenario={selectedScenario}
          companyId={companyId}
          onBack={() => setSelectedScenario(null)}
          onEdit={() => {
            setEditingScenario(selectedScenario);
            setFormOpen(true);
          }}
          onDelete={handleDelete}
          onUpdate={handleUpdate}
        />
        <ScenarioFormDialog
          open={formOpen}
          onClose={() => {
            setFormOpen(false);
            setEditingScenario(null);
          }}
          onSave={handleSave}
          scenario={editingScenario}
          companyId={companyId}
        />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      <PageHeader
        title="Scenario Planning"
        subtitle="Model future-state 'what-if' scenarios and compare alternatives side by side"
        icon={GitCompare}
      />

      <div className="flex items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search scenarios..."
              className="pl-8 h-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {STATUS_FILTERS.map((f) => (
                <SelectItem key={f.value} value={f.value}>
                  {f.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex gap-2">
          {compareIds.length >= 2 && (
            <Button
              variant="outline"
              onClick={() => setShowCompare(true)}
              className="gap-2"
            >
              <Layers className="w-4 h-4" /> Compare ({compareIds.length})
            </Button>
          )}
          <Button onClick={() => { setEditingScenario(null); setFormOpen(true); }} className="gap-2">
            <Plus className="w-4 h-4" /> New Scenario
          </Button>
        </div>
      </div>

      {showCompare && compareScenarios.length >= 2 && (
        <div className="mb-6">
          <ScenarioCompare
            scenarios={compareScenarios}
            onClose={() => setShowCompare(false)}
          />
        </div>
      )}

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <GitCompare className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-slate-700 mb-1">
              {scenarios.length === 0 ? "No scenarios yet" : "No matching scenarios"}
            </h3>
            <p className="text-sm text-slate-500 mb-4">
              {scenarios.length === 0
                ? "Create your first future-state scenario to model 'what-if' changes and compare alternatives."
                : "Try adjusting your search or status filter."}
            </p>
            {scenarios.length === 0 && (
              <Button onClick={() => { setEditingScenario(null); setFormOpen(true); }} className="gap-2">
                <Plus className="w-4 h-4" /> Create First Scenario
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((s) => (
            <ScenarioCard
              key={s.id}
              scenario={s}
              onClick={() => setSelectedScenario(s)}
              selected={compareIds.includes(s.id)}
              onSelect={toggleCompare}
            />
          ))}
        </div>
      )}

      <ScenarioFormDialog
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditingScenario(null); }}
        onSave={handleSave}
        scenario={editingScenario}
        companyId={companyId}
      />
    </div>
  );
}