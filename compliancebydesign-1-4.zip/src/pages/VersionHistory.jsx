import React, { useState, useMemo, useEffect } from "react";
import { VERSIONS, ALL_CHANGES, LATEST_VERSION } from "@/lib/versionHistory";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import PageHeader from "@/components/layout/PageHeader";
import { GitCommitVertical, Plus, ArrowRightLeft, Minus, Wrench, Calendar, Trash2 } from "lucide-react";

const PURGE_MONTHS = 18;
const PURGE_KEY = "versionHistory.autoPurge";

function isOlderThanMonths(dateStr, months) {
  const entryDate = new Date(dateStr);
  if (isNaN(entryDate)) return false;
  const cutoff = new Date();
  cutoff.setMonth(cutoff.getMonth() - months);
  return entryDate < cutoff;
}

const TYPE_CONFIG = {
  added: { icon: Plus, label: "Added", color: "text-emerald-600", bg: "bg-emerald-50", border: "border-emerald-200" },
  changed: { icon: ArrowRightLeft, label: "Changed", color: "text-blue-600", bg: "bg-blue-50", border: "border-blue-200" },
  removed: { icon: Minus, label: "Removed", color: "text-rose-600", bg: "bg-rose-50", border: "border-rose-200" },
  fixed: { icon: Wrench, label: "Fixed", color: "text-amber-600", bg: "bg-amber-50", border: "border-amber-200" },
};

const TYPE_FILTERS = [
  { value: "all", label: "All Changes" },
  { value: "added", label: "Added" },
  { value: "changed", label: "Changed" },
  { value: "removed", label: "Removed" },
  { value: "fixed", label: "Fixed" },
];

export default function VersionHistory() {
  const [typeFilter, setTypeFilter] = useState("all");
  const [versionFilter, setVersionFilter] = useState("all");
  const [aboutVersion, setAboutVersion] = useState(null);
  const [autoPurge, setAutoPurge] = useState(() => localStorage.getItem(PURGE_KEY) === "true");

  // Fetch the current version from the About / AppMeta entity
  useEffect(() => {
    base44.entities.AppMeta.list("-updated_date", 1)
      .then((records) => {
        if (records && records.length > 0) {
          setAboutVersion(records[0].version || null);
        }
      })
      .catch(() => {});
  }, []);

  // Persist the purge toggle
  useEffect(() => {
    localStorage.setItem(PURGE_KEY, String(autoPurge));
  }, [autoPurge]);

  // Versions visible after purge filtering
  const visibleVersions = useMemo(() => {
    if (!autoPurge) return VERSIONS;
    return VERSIONS.filter((v) => !isOlderThanMonths(v.date, PURGE_MONTHS));
  }, [autoPurge]);

  const purgedCount = VERSIONS.length - visibleVersions.length;

  // Flatten visible changes for the filtered list and stats
  const visibleAllChanges = useMemo(() => {
    const visibleIds = new Set(visibleVersions.map((v) => v.build || v.version));
    return ALL_CHANGES.filter((c) => visibleIds.has(c.version));
  }, [visibleVersions]);

  const filtered = useMemo(() => {
    return visibleAllChanges.filter((c) => {
      if (typeFilter !== "all" && c.type !== typeFilter) return false;
      if (versionFilter !== "all" && c.version !== versionFilter) return false;
      return true;
    });
  }, [typeFilter, versionFilter, visibleAllChanges]);

  const stats = useMemo(() => {
    const byType = { added: 0, changed: 0, removed: 0, fixed: 0 };
    visibleAllChanges.forEach((c) => {
      if (byType[c.type] !== undefined) byType[c.type]++;
    });
    return byType;
  }, [visibleAllChanges]);

  // The latest visible version (for the banner)
  const latestVisible = visibleVersions[0] || LATEST_VERSION;

  // Build the display label for the latest banner — shows the About version when available.
  // Strip a leading "v" from the stored value so we don't double up ("vv1.4").
  const normalizedAbout = aboutVersion
    ? aboutVersion.replace(/^v/i, "").trim()
    : null;
  const latestDisplay = normalizedAbout
    ? `v${normalizedAbout} · Build ${latestVisible.build}`
    : latestVisible.build
      ? `Build ${latestVisible.build}`
      : `v${latestVisible.version}`;

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      <PageHeader
        title="Version History"
        subtitle="Chronological log of functionality added, changed, removed, or fixed across the platform"
        icon={GitCommitVertical}
      />

      {/* Latest version banner */}
      <Card className="mb-4 border-primary/20 bg-primary/5">
        <CardContent className="p-4 flex items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-lg font-bold text-primary">{latestDisplay}</span>
              <Badge variant="secondary">{latestVisible.label}</Badge>
            </div>
            <p className="text-sm text-slate-500">
              {latestVisible.changes.length} changes · Released{" "}
              {new Date(latestVisible.date).toLocaleDateString("en-GB", {
                day: "2-digit",
                month: "long",
                year: "numeric",
              })}
            </p>
          </div>
          <div className="hidden md:flex gap-4 text-sm">
            {Object.entries(stats).map(([type, count]) => {
              const cfg = TYPE_CONFIG[type];
              return (
                <div key={type} className="text-center">
                  <div className={`text-xl font-bold ${cfg.color}`}>{count}</div>
                  <div className="text-xs text-slate-400 capitalize">{cfg.label}</div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Purge option */}
      <Card className="mb-4 border-slate-200">
        <CardContent className="p-3 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Trash2 className="w-4 h-4 text-slate-400" />
            <div>
              <p className="text-sm font-medium text-slate-700">
                Auto-purge entries older than {PURGE_MONTHS} months
              </p>
              <p className="text-xs text-slate-400">
                {autoPurge && purgedCount > 0
                  ? `${purgedCount} entr${purgedCount === 1 ? "y" : "ies"} purged from display`
                  : "Permanently hides entries past their retention period"}
              </p>
            </div>
          </div>
          <Switch checked={autoPurge} onCheckedChange={setAutoPurge} />
        </CardContent>
      </Card>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4">
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-40 h-9">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {TYPE_FILTERS.map((f) => (
              <SelectItem key={f.value} value={f.value}>
                {f.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={versionFilter} onValueChange={setVersionFilter}>
          <SelectTrigger className="w-48 h-9">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Versions</SelectItem>
            {visibleVersions.map((v) => (
              <SelectItem key={v.build || v.version} value={v.build || v.version}>
                {v.build ? `Build ${v.build}` : `v${v.version}`} — {v.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span className="text-sm text-slate-400 ml-auto">{filtered.length} changes</span>
      </div>

      {/* Version sections */}
      <div className="space-y-6">
        {visibleVersions.filter((v) => {
          const id = v.build || v.version;
          return versionFilter === "all" || id === versionFilter;
        }).map((v) => {
          const versionChanges = v.changes.filter(
            (c) => typeFilter === "all" || c.type === typeFilter
          );
          if (versionChanges.length === 0) return null;

          return (
            <div key={v.build || v.version}>
              <div className="flex items-center gap-3 mb-3 pb-2 border-b border-slate-200">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <GitCommitVertical className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-900">
                    {v.build ? `Build ${v.build}` : `v${v.version}`}
                  </h2>
                  <p className="text-xs text-slate-500">{v.label}</p>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-400 ml-auto">
                  <Calendar className="w-3.5 h-3.5" />
                  {new Date(v.date).toLocaleDateString("en-GB", {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                  })}
                </div>
              </div>

              <div className="space-y-2 ml-11">
                {versionChanges.map((c, i) => {
                  const cfg = TYPE_CONFIG[c.type];
                  const Icon = cfg.icon;
                  return (
                    <div
                      key={i}
                      className={`flex items-start gap-3 p-3 rounded-lg border ${cfg.bg} ${cfg.border}`}
                    >
                      <div className={`shrink-0 mt-0.5 ${cfg.color}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className={`text-xs font-semibold uppercase tracking-wide ${cfg.color}`}>
                            {cfg.label}
                          </span>
                          <Badge variant="outline" className="text-xs font-normal">
                            {c.category}
                          </Badge>
                        </div>
                        <h3 className="text-sm font-semibold text-slate-800">{c.title}</h3>
                        <p className="text-sm text-slate-600 mt-0.5">{c.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-sm text-slate-400">No changes match the selected filters.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}