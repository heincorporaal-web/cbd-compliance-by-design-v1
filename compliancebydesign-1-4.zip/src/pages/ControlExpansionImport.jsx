import React, { useState, useMemo, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Search, Loader2, Upload, ChevronDown, ChevronRight, Check, X,
  AlertTriangle, CheckCircle2, Copy, FileSearch, Zap, Download,
  ShieldCheck, Eye, Users, Link2, AlertCircle,
} from "lucide-react";

const ACTION_LABELS = {
  create: { label: "Create New", color: "bg-emerald-100 text-emerald-700 border-emerald-300" },
  update_existing: { label: "Update Existing", color: "bg-blue-100 text-blue-700 border-blue-300" },
  skip: { label: "Skip / Review", color: "bg-amber-100 text-amber-700 border-amber-300" },
  reject: { label: "Rejected", color: "bg-red-100 text-red-700 border-red-300" },
};

const OWNER_STATUS = {
  stakeholder: { label: "Resolved", color: "bg-emerald-100 text-emerald-700" },
  group: { label: "Group", color: "bg-blue-100 text-blue-700" },
  ambiguous: { label: "Ambiguous", color: "bg-amber-100 text-amber-700" },
  none: { label: "Unmatched", color: "bg-red-100 text-red-700" },
};

function StagedItemRow({ item, index, onActionChange }) {
  const [expanded, setExpanded] = useState(false);
  const action = item.action || "create";

  return (
    <div className="border-b border-slate-100 last:border-b-0">
      <div
        className="flex items-start gap-3 px-4 py-3 cursor-pointer hover:bg-slate-50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="mt-0.5 shrink-0">
          {expanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <Badge variant="outline" className={`text-xs ${ACTION_LABELS[action]?.color || ""}`}>
              {ACTION_LABELS[action]?.label || action}
            </Badge>
            {item.validation_issues.length > 0 && (
              <Badge variant="outline" className="text-xs bg-orange-50 text-orange-600 border-orange-200">
                <AlertCircle className="w-3 h-3 mr-1" /> {item.validation_issues.length} validation
              </Badge>
            )}
            {item.duplicate_match && (
              <Badge variant="outline" className="text-xs bg-purple-50 text-purple-600 border-purple-200">
                <Copy className="w-3 h-3 mr-1" /> {item.duplicate_match.recommendation.replace(/_/g, " ")} ({item.duplicate_match.similarity}%)
              </Badge>
            )}
            {item.simulation_flag && (
              <Badge variant="outline" className="text-xs bg-slate-100 text-slate-500 border-slate-200">
                Synthetic
              </Badge>
            )}
          </div>
          <div className="text-sm font-medium text-slate-800 truncate">
            <span className="text-slate-400 font-mono text-xs mr-2">{item.control_id}</span>
            {item.title}
          </div>
          <div className="mt-0.5 text-xs text-slate-500 truncate">
            {item.function} · {item.category || item.domain}
          </div>
        </div>
        <div className="shrink-0 flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          <select
            value={action}
            onChange={(e) => onActionChange(index, e.target.value)}
            className="px-2 py-1 text-xs border border-slate-200 rounded-lg bg-white"
          >
            <option value="create">Create New</option>
            <option value="update_existing">Update Existing</option>
            <option value="skip">Skip</option>
            <option value="reject">Reject</option>
          </select>
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-4 pl-11 space-y-3 bg-slate-50/50">
          {/* Validation issues */}
          {item.validation_issues.length > 0 && (
            <div className="space-y-1">
              <p className="text-xs font-semibold text-orange-600 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> Validation Issues
              </p>
              {item.validation_issues.map((v, i) => (
                <div key={i} className="text-xs text-slate-600 ml-4">
                  <span className="font-mono text-slate-500">{v.field}:</span>{" "}
                  <span className="text-red-600">"{v.csv_value}"</span>
                  {" → suggested: "}
                  <span className="text-emerald-600">"{v.suggested}"</span>
                </div>
              ))}
            </div>
          )}

          {/* Duplicate match */}
          {item.duplicate_match && (
            <div className="space-y-1">
              <p className="text-xs font-semibold text-purple-600 flex items-center gap-1">
                <Copy className="w-3 h-3" /> Duplicate Candidate ({item.duplicate_match.similarity}% similarity)
              </p>
              <div className="text-xs text-slate-600 ml-4">
                <span className="font-mono">{item.duplicate_match.existing_control_id}</span>
                {" — "}
                {item.duplicate_match.existing_title}
                <div className="text-slate-400 mt-0.5">
                  Category: {item.duplicate_match.existing_category || "—"} · Owner: {item.duplicate_match.existing_owner || "—"}
                </div>
                <div className="text-slate-500 mt-0.5">
                  Recommendation: {item.duplicate_match.recommendation.replace(/_/g, " ")}
                </div>
              </div>
            </div>
          )}

          {/* Owner resolution */}
          <div className="space-y-1">
            <p className="text-xs font-semibold text-slate-500 flex items-center gap-1">
              <Users className="w-3 h-3" /> Owner Resolution
            </p>
            <div className="text-xs text-slate-600 ml-4">
              <Badge variant="outline" className={`text-xs ${OWNER_STATUS[item.owner_resolution.type]?.color || ""}`}>
                {OWNER_STATUS[item.owner_resolution.type]?.label || item.owner_resolution.type}
              </Badge>
              <span className="ml-2">Role: "{item.owner_resolution.role_text}"</span>
              {item.owner_resolution.matches.length > 0 && (
                <div className="mt-1 space-y-0.5">
                  {item.owner_resolution.matches.map((m, i) => (
                    <div key={i} className="text-slate-500">
                      → {m.name} ({m.job_title || m.name}) — {m.match_type} ({Math.round(m.score * 100)}%)
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Link proposals */}
          <div className="grid grid-cols-3 gap-3 text-xs">
            <div>
              <p className="font-semibold text-slate-500 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> Objective
              </p>
              <div className="mt-0.5">
                {item.objective_link.match ? (
                  <span className="text-emerald-600">{item.objective_link.match.title} ({item.objective_link.score}%)</span>
                ) : (
                  <span className="text-slate-400">Unmatched</span>
                )}
              </div>
            </div>
            <div>
              <p className="font-semibold text-slate-500 flex items-center gap-1">
                <Link2 className="w-3 h-3" /> Process
              </p>
              <div className="mt-0.5">
                {item.process_link.match ? (
                  <span className="text-emerald-600">{item.process_link.match.name} ({item.process_link.score}%)</span>
                ) : (
                  <span className="text-slate-400">Unmatched</span>
                )}
              </div>
            </div>
            <div>
              <p className="font-semibold text-slate-500 flex items-center gap-1">
                <Eye className="w-3 h-3" /> Value Chain
              </p>
              <div className="mt-0.5">
                {item.value_chain_link.match ? (
                  <span className="text-emerald-600">{item.value_chain_link.match.name} ({item.value_chain_link.score}%)</span>
                ) : (
                  <span className="text-slate-400">Unmatched</span>
                )}
              </div>
            </div>
          </div>

          {/* Risk match candidates */}
          {item.risk_match.status === "candidate" && (
            <div className="space-y-1">
              <p className="text-xs font-semibold text-slate-500 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Risk-Control Match Candidates (advisory — no auto-link)
              </p>
              <div className="text-xs text-slate-600 ml-4">
                <div className="text-slate-400 italic mb-1">"{item.risk_match.proposed_statement.substring(0, 120)}…"</div>
                {item.risk_match.candidates.map((r, i) => (
                  <div key={i} className="text-slate-500">
                    {r.ref} — {r.title} ({r.score}%)
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Raw fields preview */}
          <div className="pt-2 border-t border-slate-200">
            <p className="text-xs font-semibold text-slate-400 mb-1">Mapped Control Fields (Draft status, library_status: draft)</p>
            <pre className="p-2 bg-slate-100 rounded text-xs overflow-x-auto text-slate-600 max-h-32">
              {JSON.stringify(item.raw_fields, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}

export default function ControlExpansionImport() {
  const [companyId, setCompanyId, { locked, assignedCompanyName }] = useCompanyFilter();
  const [loading, setLoading] = useState(false);
  const [staging, setStaging] = useState(false);
  const [applying, setApplying] = useState(false);
  const [error, setError] = useState(null);
  const [stagedResult, setStagedResult] = useState(null);
  const [applyResult, setApplyResult] = useState(null);
  const [companies, setCompanies] = useState([]);
  const [fileUrl, setFileUrl] = useState("");
  const [fileName, setFileName] = useState("");
  const [uploading, setUploading] = useState(false);
  const [items, setItems] = useState([]);
  const [filterAction, setFilterAction] = useState("all");
  const [filterOwner, setFilterOwner] = useState("all");
  const [filterDuplicate, setFilterDuplicate] = useState("all");
  const [search, setSearch] = useState("");

  useEffect(() => {
    base44.entities.Company.filter({ status: "active" }, { sort: "name", limit: 200 })
      .then(res => setCompanies(res.items || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!locked && (companyId === "all" || !companyId) && companies.length > 0) {
      const evi = companies.find(c => c.name === "EVI Trading");
      if (evi) setCompanyId(evi.id);
    }
  }, [companies, locked]);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const uploadRes = await base44.integrations.Core.UploadPrivateFile({ file });
      const signedRes = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: uploadRes.file_uri, expires_in: 300 });
      setFileUrl(signedRes.signed_url);
      setFileName(file.name);
    } catch (e) {
      setError("File upload failed: " + (e?.message || "unknown error"));
    } finally {
      setUploading(false);
    }
  };

  const runStaging = async () => {
    if (!fileUrl || !companyId || companyId === "all") {
      setError("Please upload a CSV file and select a company.");
      return;
    }
    setStaging(true);
    setError(null);
    setApplyResult(null);
    try {
      const res = await base44.functions.invoke("stageControlExpansion", { file_url: fileUrl, company_id: companyId });
      setStagedResult(res.data);
      setItems(res.data.items || []);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "Staging failed");
    } finally {
      setStaging(false);
    }
  };

  const handleActionChange = (index, newAction) => {
    setItems(prev => prev.map((item, i) => i === index ? { ...item, action: newAction } : item));
  };

  const bulkAction = (action) => {
    setItems(prev => prev.map(item => ({ ...item, action })));
  };

  const filteredItems = useMemo(() => {
    return items.filter(item => {
      if (filterAction !== "all" && item.action !== filterAction) return false;
      if (filterOwner !== "all" && item.owner_resolution.type !== filterOwner) return false;
      if (filterDuplicate === "has_dup" && !item.duplicate_match) return false;
      if (filterDuplicate === "no_dup" && item.duplicate_match) return false;
      if (search) {
        const q = search.toLowerCase();
        const text = `${item.control_id} ${item.title} ${item.function} ${item.category} ${item.domain}`.toLowerCase();
        if (!text.includes(q)) return false;
      }
      return true;
    });
  }, [items, filterAction, filterOwner, filterDuplicate, search]);

  const applyApproved = async () => {
    setApplying(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("applyControlExpansion", {
        company_id: companyId,
        items: items.filter(i => i.action === "create" || i.action === "update_existing"),
      });
      setApplyResult(res.data);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "Apply failed");
    } finally {
      setApplying(false);
    }
  };

  const exportCSV = () => {
    if (!filteredItems.length) return;
    const headers = [
      "Control ID", "Title", "Function", "Domain", "Category", "Action",
      "Change Type", "Simulation", "Review Required",
      "Validation Issues", "Duplicate Found", "Duplicate Similarity", "Duplicate Existing ID",
      "Owner Role", "Owner Status", "Owner Match",
      "Objective Match", "Objective Score",
      "Process Match", "Process Score",
      "Value Chain Match", "VC Score",
      "Risk Match Status", "Risk Candidates",
      "Framework",
    ];
    const esc = (v) => {
      if (v == null) return "";
      const s = String(v);
      if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
      return s;
    };
    const rows = filteredItems.map(item => [
      item.control_id, item.title, item.function, item.domain, item.category, item.action,
      item.change_type, item.simulation_flag, item.review_required,
      item.validation_issues.map(v => `${v.field}: "${v.csv_value}" → "${v.suggested}"`).join("; "),
      item.duplicate_match ? "Yes" : "No",
      item.duplicate_match?.similarity || "",
      item.duplicate_match?.existing_control_id || "",
      item.owner_resolution.role_text,
      item.owner_resolution.type,
      item.owner_resolution.matches.map(m => `${m.name} (${m.match_type}, ${Math.round(m.score * 100)}%)`).join("; "),
      item.objective_link?.match?.title || "Unmatched",
      item.objective_link?.score || "",
      item.process_link?.match?.name || "Unmatched",
      item.process_link?.score || "",
      item.value_chain_link?.match?.name || "Unmatched",
      item.value_chain_link?.score || "",
      item.risk_match?.status || "none",
      item.risk_match?.candidates?.map(c => `${c.ref} (${c.score}%)`).join("; ") || "",
      item.framework_name || "Unresolved",
    ].map(esc).join(","));
    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `control-expansion-staged-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const summary = stagedResult?.summary;
  const approvedCount = items.filter(i => i.action === "create" || i.action === "update_existing").length;

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
          <FileSearch className="w-6 h-6 text-indigo-600" />
          Control Expansion Package Import
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Staged, synthetic control catalogue import — semantic duplicate detection, enum validation, owner resolution, and link proposals. Nothing is created until you approve.
        </p>
      </div>

      {/* Upload + staging controls */}
      <Card>
        <CardContent className="py-4 space-y-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <label className="px-4 py-2 text-sm bg-indigo-600 text-white rounded-lg cursor-pointer hover:bg-indigo-700 flex items-center gap-2">
                <Upload className="w-4 h-4" /> Upload CSV
                <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} disabled={uploading} />
              </label>
              {uploading && <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />}
              {fileName && <span className="text-sm text-slate-600">{fileName}</span>}
            </div>

            <select
              value={companyId}
              onChange={(e) => setCompanyId(e.target.value)}
              disabled={locked}
              className="px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white disabled:bg-slate-50 max-w-[200px]"
            >
              {locked ? (
                <option value={companyId}>{assignedCompanyName || "My Company"}</option>
              ) : (
                <>
                  <option value="all">Select company…</option>
                  {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </>
              )}
            </select>

            <Button onClick={runStaging} disabled={staging || !fileUrl || !companyId || companyId === "all"} className="gap-2 bg-indigo-600 hover:bg-indigo-700">
              {staging ? <><Loader2 className="w-4 h-4 animate-spin" /> Staging…</> : <><Search className="w-4 h-4" /> Stage Import</>}
            </Button>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">{error}</div>
          )}
        </CardContent>
      </Card>

      {/* Staging summary */}
      {stagedResult && summary && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card><CardContent className="py-3">
              <p className="text-xs text-slate-400">Total Proposals</p>
              <p className="text-2xl font-bold text-slate-800">{summary.total}</p>
            </CardContent></Card>
            <Card><CardContent className="py-3">
              <p className="text-xs text-slate-400">Create New</p>
              <p className="text-2xl font-bold text-emerald-600">{summary.by_action.create}</p>
            </CardContent></Card>
            <Card><CardContent className="py-3">
              <p className="text-xs text-slate-400">Update Existing</p>
              <p className="text-2xl font-bold text-blue-600">{summary.by_action.update_existing}</p>
            </CardContent></Card>
            <Card><CardContent className="py-3">
              <p className="text-xs text-slate-400">Skip / Review</p>
              <p className="text-2xl font-bold text-amber-600">{summary.by_action.skip}</p>
            </CardContent></Card>
          </div>

          <div className="flex items-center gap-2 flex-wrap text-xs">
            <span className="font-medium text-slate-600">Reconciliation:</span>
            <Badge variant="outline" className="text-xs">{summary.duplicates_found} duplicates found</Badge>
            <Badge variant="outline" className="text-xs text-orange-600 border-orange-200">{summary.validation_issues} with validation issues</Badge>
            <Badge variant="outline" className="text-xs text-emerald-600 border-emerald-200">{summary.owners_resolved} owners resolved</Badge>
            <Badge variant="outline" className="text-xs text-amber-600 border-amber-200">{summary.owners_ambiguous} ambiguous owners</Badge>
            <Badge variant="outline" className="text-xs text-red-600 border-red-200">{summary.owners_unmatched} unmatched owners</Badge>
            <span className="text-slate-300">|</span>
            <Badge variant="outline" className="text-xs">{summary.objectives_matched} objectives matched</Badge>
            <Badge variant="outline" className="text-xs">{summary.processes_matched} processes matched</Badge>
            <Badge variant="outline" className="text-xs">{summary.value_chains_matched} value chains matched</Badge>
            <Badge variant="outline" className="text-xs text-purple-600 border-purple-200">{summary.risk_candidates} risk match candidates</Badge>
          </div>

          {/* Reference data counts */}
          <div className="text-xs text-slate-400">
            Reference data: {stagedResult.reference_counts.library_controls} library controls, {stagedResult.reference_counts.company_controls} company controls, {stagedResult.reference_counts.stakeholders} stakeholders, {stagedResult.reference_counts.control_objectives} control objectives, {stagedResult.reference_counts.processes} processes, {stagedResult.reference_counts.value_chains} value chains, {stagedResult.reference_counts.risks} risks
          </div>
        </>
      )}

      {/* Apply result / reconciliation report */}
      {applyResult && (
        <Card className="border-emerald-200 bg-emerald-50/50">
          <CardContent className="py-4 space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <p className="text-sm font-semibold text-slate-800">Reconciliation Report</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
              <div><span className="text-slate-500">New controls created:</span> <span className="font-bold text-emerald-600">{applyResult.report.created}</span></div>
              <div><span className="text-slate-500">Existing controls updated:</span> <span className="font-bold text-blue-600">{applyResult.report.updated}</span></div>
              <div><span className="text-slate-500">Duplicates avoided:</span> <span className="font-bold text-purple-600">{applyResult.reconciliation.duplicates_avoided}</span></div>
              <div><span className="text-slate-500">Skipped:</span> <span className="font-bold text-amber-600">{applyResult.report.skipped}</span></div>
              <div><span className="text-slate-500">Owner links set:</span> <span className="font-bold">{applyResult.report.links.owners}</span></div>
              <div><span className="text-slate-500">Objective links set:</span> <span className="font-bold">{applyResult.report.links.objectives}</span></div>
              <div><span className="text-slate-500">Process links set:</span> <span className="font-bold">{applyResult.report.links.processes}</span></div>
              <div><span className="text-slate-500">Risk-control links created:</span> <span className="font-bold text-red-600">0 (never auto-created)</span></div>
            </div>
            <div className="text-xs text-slate-500">
              Unresolved mappings: {applyResult.reconciliation.unresolved_mappings.owners} owners, {applyResult.reconciliation.unresolved_mappings.objectives} objectives, {applyResult.reconciliation.unresolved_mappings.processes} processes, {applyResult.reconciliation.unresolved_mappings.value_chains} value chains
              {applyResult.report.errors > 0 && <span className="text-red-600 ml-2">· {applyResult.report.errors} errors</span>}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Staged items table */}
      {items.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <CardTitle className="text-base">Staged Proposals ({filteredItems.length} of {items.length})</CardTitle>
              <div className="flex items-center gap-2 flex-wrap">
                <Button onClick={exportCSV} variant="outline" className="gap-1.5 text-sm h-9">
                  <Download className="w-3.5 h-3.5" /> Export CSV
                </Button>
                <Button onClick={() => bulkAction("create")} variant="outline" className="text-xs h-9">All Create</Button>
                <Button onClick={() => bulkAction("update_existing")} variant="outline" className="text-xs h-9">All Update</Button>
                <Button onClick={() => bulkAction("skip")} variant="outline" className="text-xs h-9">All Skip</Button>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap mt-2">
              <input
                type="text" placeholder="Search…" value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="px-3 py-1.5 text-sm border border-slate-200 rounded-lg w-48"
              />
              <select value={filterAction} onChange={(e) => setFilterAction(e.target.value)} className="px-2 py-1.5 text-sm border border-slate-200 rounded-lg">
                <option value="all">All Actions</option>
                <option value="create">Create New</option>
                <option value="update_existing">Update Existing</option>
                <option value="skip">Skip</option>
                <option value="reject">Reject</option>
              </select>
              <select value={filterOwner} onChange={(e) => setFilterOwner(e.target.value)} className="px-2 py-1.5 text-sm border border-slate-200 rounded-lg">
                <option value="all">All Owners</option>
                <option value="stakeholder">Resolved</option>
                <option value="group">Group</option>
                <option value="ambiguous">Ambiguous</option>
                <option value="none">Unmatched</option>
              </select>
              <select value={filterDuplicate} onChange={(e) => setFilterDuplicate(e.target.value)} className="px-2 py-1.5 text-sm border border-slate-200 rounded-lg">
                <option value="all">All Duplicates</option>
                <option value="has_dup">Has Duplicate</option>
                <option value="no_dup">No Duplicate</option>
              </select>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[700px] overflow-y-auto">
              {filteredItems.map((item, idx) => (
                <StagedItemRow
                  key={item.row_index ?? idx}
                  item={item}
                  index={items.indexOf(item)}
                  onActionChange={handleActionChange}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Apply button */}
      {items.length > 0 && (
        <Card className="border-indigo-200 bg-indigo-50/50">
          <CardContent className="py-4 flex items-center justify-between gap-3 flex-wrap">
            <div>
              <p className="text-sm font-semibold text-slate-800">
                {approvedCount} items approved for application
              </p>
              <p className="text-xs text-slate-500">
                Creates new controls in Draft status, updates existing descriptions, and sets objective/process/owner links. Risk-control links are never auto-created.
              </p>
            </div>
            <Button onClick={applyApproved} disabled={applying || approvedCount === 0} className="gap-2 bg-indigo-600 hover:bg-indigo-700">
              {applying ? <><Loader2 className="w-4 h-4 animate-spin" /> Applying…</> : <><Zap className="w-4 h-4" /> Apply Approved Items</>}
            </Button>
          </CardContent>
        </Card>
      )}

      {!stagedResult && !staging && !error && (
        <Card>
          <CardContent className="py-16 text-center">
            <FileSearch className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-slate-500">Upload a CSV file and click "Stage Import" to begin the staged control expansion review.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}