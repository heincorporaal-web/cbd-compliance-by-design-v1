import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GitBranch, Plus, ArrowLeft, Search, Building2, CalendarOff, Save, Trash2, Workflow as WorkflowIcon } from "lucide-react";
import EndDateBadge from "@/components/ui/EndDateBadge";
import { Link } from "react-router-dom";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import PageHeader from "@/components/layout/PageHeader";
import VisualWorkflowCanvas from "@/components/workflows/VisualWorkflowCanvas";
import WorkflowMiniMap from "@/components/workflows/WorkflowMiniMap";

const ENTITY_TYPES = ["Assessment", "ProcessAssessment", "BusinessProcess", "Risk", "Control", "Framework", "Issue", "OrgProcess", "ICTSystem", "Survey", "RiskAssessmentCycle"];

export default function WorkflowVisualMap() {
  const [globalCompany] = useCompanyFilter();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterEntityType, setFilterEntityType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [editingWorkflow, setEditingWorkflow] = useState(null);
  const [isNew, setIsNew] = useState(false);
  const queryClient = useQueryClient();

  const { data: workflows = [], isLoading } = useQuery({
    queryKey: ['workflows'],
    queryFn: () => base44.entities.Workflow.list('-created_date'),
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list(),
  });

  const { data: workflowInstances = [] } = useQuery({
    queryKey: ['workflowInstances'],
    queryFn: () => base44.entities.WorkflowInstance.list('-created_date', 50),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Workflow.create(data),
    onSuccess: () => { queryClient.invalidateQueries(['workflows']); setEditingWorkflow(null); setIsNew(false); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Workflow.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries(['workflows']); setEditingWorkflow(null); setIsNew(false); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Workflow.delete(id),
    onSuccess: () => { queryClient.invalidateQueries(['workflows']); setEditingWorkflow(null); },
  });

  const handleNew = () => {
    setEditingWorkflow({
      name: "",
      description: "",
      company_id: "",
      entity_type: "Assessment",
      trigger_condition: "manual",
      status: "active",
      end_date: "",
      steps: [],
      auto_notify_days_before: 3,
    });
    setIsNew(true);
  };

  const handleSave = () => {
    if (!editingWorkflow.name) return;
    if (isNew) {
      createMutation.mutate(editingWorkflow);
    } else {
      updateMutation.mutate({ id: editingWorkflow.id, data: editingWorkflow });
    }
  };

  const handleDelete = () => {
    if (!editingWorkflow.id) return;
    if (confirm('Are you sure you want to delete this workflow?')) {
      deleteMutation.mutate(editingWorkflow.id);
    }
  };

  const update = (field, value) => setEditingWorkflow(prev => ({ ...prev, [field]: value }));

  const filteredWorkflows = workflows.filter(w => {
    const matchesSearch = !searchTerm || w.name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCompany = globalCompany === "all" || !w.company_id || w.company_id === globalCompany;
    const matchesEntityType = filterEntityType === "all" || w.entity_type === filterEntityType;
    const matchesStatus = filterStatus === "all" || w.status === filterStatus;
    return matchesSearch && matchesCompany && matchesEntityType && matchesStatus;
  });

  // Editor mode
  if (editingWorkflow) {
    return (
      <div className="p-4 lg:p-6 space-y-4">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <Button variant="ghost" size="sm" onClick={() => { setEditingWorkflow(null); setIsNew(false); }}>
            <ArrowLeft className="w-4 h-4 mr-1" /> Back to Gallery
          </Button>
          <div className="flex gap-2">
            {!isNew && (
              <Button variant="outline" size="sm" onClick={handleDelete} className="text-red-600 hover:bg-red-50">
                <Trash2 className="w-4 h-4 mr-1" /> Delete
              </Button>
            )}
            <Button size="sm" onClick={handleSave} className="bg-purple-600 hover:bg-purple-700">
              <Save className="w-4 h-4 mr-1" /> {isNew ? 'Create' : 'Save'}
            </Button>
          </div>
        </div>

        <PageHeader
          icon={WorkflowIcon}
          title={isNew ? "New Workflow" : (editingWorkflow.name || "Untitled Workflow")}
          tagline={isNew ? "Build a new visual workflow" : "Edit workflow details and visual flow"}
          gradient="from-violet-600 to-purple-700"
        />

        {/* Metadata form */}
        <Card className="border-none shadow-lg">
          <CardContent className="pt-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Workflow Name *</Label>
                <Input value={editingWorkflow.name || ""} onChange={(e) => update("name", e.target.value)} placeholder="e.g., Risk Approval Workflow" />
              </div>
              <div className="space-y-2">
                <Label>Applies To *</Label>
                <Select value={editingWorkflow.entity_type} onValueChange={(v) => update("entity_type", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ENTITY_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Company <span className="text-slate-400 font-normal">(optional — leave blank for global)</span></Label>
                <Select value={editingWorkflow.company_id || "global"} onValueChange={(v) => update("company_id", v === "global" ? "" : v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="global">All companies (global)</SelectItem>
                    {companies.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Trigger When</Label>
                <Select value={editingWorkflow.trigger_condition} onValueChange={(v) => update("trigger_condition", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="on_create">On Create</SelectItem>
                    <SelectItem value="on_update">On Update</SelectItem>
                    <SelectItem value="on_status_change">On Status Change</SelectItem>
                    <SelectItem value="manual">Manual Trigger</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={editingWorkflow.status} onValueChange={(v) => update("status", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Auto-Notify Days Before Due</Label>
                <Input type="number" value={editingWorkflow.auto_notify_days_before ?? 3} onChange={(e) => update("auto_notify_days_before", parseInt(e.target.value))} />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><CalendarOff className="w-3.5 h-3.5 text-slate-400" /> End Date</Label>
                <Input type="date" value={editingWorkflow.end_date || ""} onChange={(e) => update("end_date", e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={editingWorkflow.description || ""} onChange={(e) => update("description", e.target.value)} rows={2} />
            </div>
          </CardContent>
        </Card>

        {/* Visual Canvas */}
        <Card className="border-none shadow-lg">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="text-base flex items-center gap-2">
              <WorkflowIcon className="w-4 h-4 text-purple-600" />
              Visual Workflow Designer
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <VisualWorkflowCanvas
              steps={editingWorkflow.steps || []}
              onChange={(steps) => update("steps", steps)}
              entityType={editingWorkflow.entity_type}
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  // Gallery mode
  const activeCount = workflows.filter(w => w.status === 'active').length;
  const inactiveCount = workflows.filter(w => w.status === 'inactive').length;

  return (
    <div className="p-4 lg:p-6 lg:p-8 space-y-6">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <PageHeader
          icon={WorkflowIcon}
          title="Workflow Visual Map"
          tagline="Central hub for all approval workflows — visualise, build, and manage"
          gradient="from-violet-600 to-purple-700"
        />
        <Button className="bg-purple-600 hover:bg-purple-700" onClick={handleNew}>
          <Plus className="w-4 h-4 mr-2" /> New Workflow
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-none shadow-lg">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center justify-between">
              <div><p className="text-xs text-slate-600 mb-1">Total Workflows</p><p className="text-2xl font-bold text-slate-900">{workflows.length}</p></div>
              <GitBranch className="w-7 h-7 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-lg">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center justify-between">
              <div><p className="text-xs text-slate-600 mb-1">Active</p><p className="text-2xl font-bold text-green-600">{activeCount}</p></div>
              <div className="w-3 h-3 rounded-full bg-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-lg">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center justify-between">
              <div><p className="text-xs text-slate-600 mb-1">Inactive</p><p className="text-2xl font-bold text-slate-500">{inactiveCount}</p></div>
              <div className="w-3 h-3 rounded-full bg-slate-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-lg">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center justify-between">
              <div><p className="text-xs text-slate-600 mb-1">Active Instances</p><p className="text-2xl font-bold text-blue-600">{workflowInstances.filter(wi => wi.status === 'in_progress' || wi.status === 'pending').length}</p></div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-none shadow-lg">
        <CardContent className="pt-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input placeholder="Search workflows..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
            </div>
            <Select value={filterEntityType} onValueChange={setFilterEntityType}>
              <SelectTrigger className="w-full md:w-48"><SelectValue placeholder="Entity Type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Entity Types</SelectItem>
                {ENTITY_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-36"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Gallery grid */}
      {isLoading ? (
        <div className="text-center py-12 text-slate-500">Loading workflows...</div>
      ) : filteredWorkflows.length === 0 ? (
        <Card className="border-none shadow-lg">
          <CardContent className="py-16 text-center">
            <WorkflowIcon className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 mb-4">No workflows found</p>
            <Button onClick={handleNew} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" /> Create Your First Workflow
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredWorkflows.map(workflow => {
            const instances = workflowInstances.filter(wi => wi.workflow_id === workflow.id);
            const activeInstances = instances.filter(wi => wi.status === 'in_progress' || wi.status === 'pending').length;
            const companyName = companies.find(c => c.id === workflow.company_id)?.name;
            return (
              <Card
                key={workflow.id}
                className="border-none shadow-lg hover:shadow-xl transition-all cursor-pointer"
                onClick={() => { setEditingWorkflow(workflow); setIsNew(false); }}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-semibold text-slate-900 text-sm truncate">{workflow.name}</h3>
                      <div className="flex items-center gap-1 flex-wrap mt-1">
                        <Badge variant="outline" className={`text-[10px] ${workflow.status === 'active' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-slate-50 text-slate-500 border-slate-200'}`}>
                          {workflow.status}
                        </Badge>
                        <Badge variant="outline" className="text-[10px] bg-blue-50 text-blue-700 border-blue-200">{workflow.entity_type}</Badge>
                        {workflow.company_id ? (
                          <Badge variant="outline" className="text-[10px] bg-purple-50 text-purple-700 border-purple-200 flex items-center gap-0.5">
                            <Building2 className="w-2.5 h-2.5" />{companyName || 'Company'}
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-[10px] bg-slate-50 text-slate-500 border-slate-200">Global</Badge>
                        )}
                      </div>
                    </div>
                    <EndDateBadge endDate={workflow.end_date} />
                  </div>
                </CardHeader>
                <CardContent className="pt-2">
                  {workflow.description && (
                    <p className="text-xs text-slate-500 mb-3 line-clamp-2">{workflow.description}</p>
                  )}
                  {/* Mini map */}
                  <div className="bg-slate-50 rounded-lg border border-slate-100 p-2 mb-2">
                    <WorkflowMiniMap steps={workflow.steps || []} />
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{workflow.steps?.length || 0} steps • {workflow.trigger_condition?.replace('_', ' ')}</span>
                    {activeInstances > 0 && <span className="text-blue-600 font-medium">{activeInstances} active</span>}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Link to classic workflows page */}
      <div className="text-center pt-2">
        <Link to="/Workflows" className="text-xs text-slate-500 hover:text-purple-600 hover:underline">
          Go to classic Workflow Automation page →
        </Link>
      </div>
    </div>
  );
}