import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { FileText, Database, Palette, CheckCircle2, ClipboardCheck, RefreshCw, HelpCircle } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import TemplatesTab from "@/components/reportstudio/TemplatesTab";
import FieldRegistryTab from "@/components/reportstudio/FieldRegistryTab";
import BrandingTab from "@/components/reportstudio/BrandingTab";
import ReadinessTab from "@/components/reportstudio/ReadinessTab";
import QATestTab from "@/components/reportstudio/QATestTab";
import ReportStudioHelp from "@/components/reportstudio/ReportStudioHelp";
import { useToast } from "@/components/ui/use-toast";

export default function ReportTemplateStudio() {
  const { toast } = useToast();
  const [canEdit, setCanEdit] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    base44.auth.me().then((u) => setCanEdit(u?.role === "admin")).catch(() => setCanEdit(false));
  }, []);

  const reseed = async () => {
    setSeeding(true);
    try {
      await base44.functions.invoke("seedReportTemplateStudio", {});
      toast({ title: "Re-seeded from config pack", description: "All studio records refreshed from the starter pack." });
      setReloadKey((k) => k + 1);
    } catch (e) {
      toast({ title: "Re-seed failed", description: e.message, variant: "destructive" });
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <PageHeader icon={FileText} gradient="from-slate-700 to-slate-900" title="Report Centre" tagline="Author and govern report templates, field bindings, branding and readiness" />
        {canEdit && (
          <Button variant="outline" size="sm" onClick={reseed} disabled={seeding}>
            <RefreshCw className={`w-4 h-4 mr-2 ${seeding ? "animate-spin" : ""}`} />
            {seeding ? "Re-seeding…" : "Re-seed from config pack"}
          </Button>
        )}
      </div>

      <Tabs defaultValue="templates" className="w-full">
        <TabsList className="w-full justify-start flex-wrap h-auto">
          <TabsTrigger value="templates" className="gap-1.5"><FileText className="w-4 h-4" /> Templates</TabsTrigger>
          <TabsTrigger value="fields" className="gap-1.5"><Database className="w-4 h-4" /> Field Registry</TabsTrigger>
          <TabsTrigger value="branding" className="gap-1.5"><Palette className="w-4 h-4" /> Branding</TabsTrigger>
          <TabsTrigger value="readiness" className="gap-1.5"><CheckCircle2 className="w-4 h-4" /> Readiness</TabsTrigger>
          <TabsTrigger value="qa" className="gap-1.5"><ClipboardCheck className="w-4 h-4" /> QA</TabsTrigger>
          <TabsTrigger value="help" className="gap-1.5"><HelpCircle className="w-4 h-4" /> Help</TabsTrigger>
        </TabsList>
        <TabsContent value="templates"><TemplatesTab canEdit={canEdit} reloadKey={reloadKey} /></TabsContent>
        <TabsContent value="fields"><FieldRegistryTab canEdit={canEdit} reloadKey={reloadKey} /></TabsContent>
        <TabsContent value="branding"><BrandingTab canEdit={canEdit} reloadKey={reloadKey} /></TabsContent>
        <TabsContent value="readiness"><ReadinessTab canEdit={canEdit} reloadKey={reloadKey} /></TabsContent>
        <TabsContent value="qa"><QATestTab canEdit={canEdit} reloadKey={reloadKey} /></TabsContent>
        <TabsContent value="help"><ReportStudioHelp /></TabsContent>
      </Tabs>
    </div>
  );
}