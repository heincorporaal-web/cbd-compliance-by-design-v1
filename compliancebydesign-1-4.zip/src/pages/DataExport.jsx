import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/layout/PageHeader";
import { Download, FileSpreadsheet, Loader2, Database, Table } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const COMPANY_ID = "69e85cf90d020bae2aa07c10";

// CSV helper
function csvEscape(val) {
  if (val === null || val === undefined) return "";
  let s = String(val);
  if (s.includes(",") || s.includes('"') || s.includes("\n") || s.includes("\r")) {
    s = '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}
function arrayToCsv(arr) {
  if (!arr || !Array.isArray(arr)) return "";
  return arr.join("; ");
}
function buildRow(fields, obj) {
  return fields
    .map((f) => {
      const v = obj[f];
      if (Array.isArray(v)) return csvEscape(arrayToCsv(v));
      if (v && typeof v === "object") return csvEscape(JSON.stringify(v));
      return csvEscape(v);
    })
    .join(",");
}
function toCsv(headers, rows) {
  return [headers.join(","), ...rows].join("\n");
}

function downloadCsv(filename, csvContent) {
  const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Entity configurations: key fields for ChatGPT to populate
const ENTITY_CONFIGS = [
  {
    key: "Risk",
    label: "Risks",
    icon: "shield-alert",
    filename: "EVI_Risks.csv",
    description: "Risk register entries with likelihood, impact, owner, and mitigation",
    fields: [
      "title", "description", "category", "risk_type", "likelihood", "impact",
      "inherent_risk_score", "status", "owner", "risk_reference_nr", "risk_statement",
      "root_cause", "mitigation_plan", "review_date", "identified_date",
      "value_chain", "sub_process", "process_activity", "control_ids", "framework_ids",
    ],
    fieldHints: {
      category: "operational|financial|strategic|compliance|cyber_security|third_party|reputational|technology",
      risk_type: "Financial|Operational|Strategic|Governance & Compliance|Governance|Unspecified",
      likelihood: "very_low|low|medium|high|very_high",
      impact: "very_low|low|medium|high|very_high",
      status: "draft|identified|pending_review|approved|assessed|mitigated|accepted|closed",
    },
  },
  {
    key: "Control",
    label: "Controls",
    icon: "shield-check",
    filename: "EVI_Controls.csv",
    description: "Control register with type, frequency, owner, and execution method",
    fields: [
      "control_id", "title", "description", "category", "priority", "status",
      "control_criticality", "control_owner", "key_control", "control_execution_type",
      "control_type", "control_frequency", "process_phase", "framework_id",
      "control_objective_id",
    ],
    fieldHints: {
      priority: "critical|high|medium|low",
      status: "draft|pending_review|approved|active|archived",
      control_criticality: "Must Have|Should Have|Nice to Have",
      control_execution_type: "Manual|Automated|Semi-Automated",
      control_type: "Preventive|Detective|Corrective",
      control_frequency: "Daily|Weekly|Monthly|Quarterly|Annually|Continuous|Ad-hoc",
      process_phase: "Pre-Input|Process - Input|Process - Output|Post-Output",
    },
  },
  {
    key: "ICTSystem",
    label: "ICT Systems",
    icon: "server",
    filename: "EVI_ICTSystems.csv",
    description: "ICT system register with criticality, vendor, hosting, and recovery objectives",
    fields: [
      "name", "system_type", "system_type_custom", "criticality", "description",
      "vendor", "hosting_type", "recovery_time_objective", "recovery_point_objective",
      "status", "data_classification", "last_assessment_date", "next_assessment_date",
      "dependencies", "it_capability_ids",
    ],
    fieldHints: {
      system_type: "core_banking|payment_processing|trading_platform|risk_management|customer_relationship|data_analytics|infrastructure|security|other|custom",
      criticality: "critical|important|supporting",
      hosting_type: "on_premise|cloud|hybrid|managed_service",
      status: "active|decommissioned|planned|under_review|discovered",
      data_classification: "public|internal|confidential|highly_confidential",
    },
  },
  {
    key: "Incident",
    label: "Incidents",
    icon: "alert-triangle",
    filename: "EVI_Incidents.csv",
    description: "Incident log with type, severity, dates, impact, and root cause",
    fields: [
      "incident_reference", "title", "incident_type", "category", "subcategory",
      "severity", "priority", "status", "major_incident", "security_incident",
      "data_breach", "detected_date", "reported_date", "resolved_date",
      "service_restored_date", "detection_source", "reporter", "affected_service",
      "description", "impact", "users_affected", "estimated_financial_impact",
      "incident_owner", "assignment_group", "technical_lead", "business_owner",
      "root_cause",
    ],
    fieldHints: {
      incident_type: "cyber_attack|system_outage|data_breach|operational_disruption|third_party_failure|natural_disaster|human_error|security_incident|other",
      severity: "critical|major|moderate|minor",
      priority: "P1|P2|P3|P4",
      status: "detected|logged|classified|assessed|assigned|investigating|mitigating|service_restored|resolved|pir_rca|closed",
      detection_source: "monitoring_alert|service_desk|user_report|email|api_ingestion|third_party_notification|manual|other",
    },
  },
  {
    key: "Stakeholder",
    label: "Stakeholders",
    icon: "users",
    filename: "EVI_Stakeholders.csv",
    description: "People directory with job titles, departments, and reporting lines",
    fields: [
      "employee_number", "full_name", "email", "job_title", "department",
      "phone", "status", "manager_id", "group_ids", "end_date", "notes",
    ],
    fieldHints: {
      status: "active|inactive",
    },
  },
  {
    key: "ValueChain",
    label: "Value Chains",
    icon: "network",
    filename: "EVI_ValueChains.csv",
    description: "Organisational value chains grouped by management domain, with owners and descriptions",
    fields: [
      "value_chain_code", "name", "management_chain", "owner", "description",
      "badge_color", "sort_order", "status", "is_active", "end_date", "company_id",
    ],
    fieldHints: {
      management_chain: "Enterprise Asset Management|Strategy & Governance|Finance & Risk|Customer & Revenue|Supply Chain|People & Culture|Technology & Digital",
      status: "active|inactive|archived",
      is_active: "true|false",
    },
  },
  {
    key: "Workstream",
    label: "Workstreams",
    icon: "layers",
    filename: "EVI_Workstreams.csv",
    description: "Workstreams within value chains, with domain codes, E2E codes, and owners",
    fields: [
      "workstream_code", "name", "full_label", "description", "value_chain_id",
      "owner", "domain_code", "e2e_code", "sort_order", "status", "is_active",
      "end_date", "company_id",
    ],
    fieldHints: {
      domain_code: "SCM|EIT|GRC|HCM|FIN|EPM",
      e2e_code: "O2C|P2P|H2R|R2C|L2C|P2A",
      status: "active|inactive|archived",
      is_active: "true|false",
    },
  },
  {
    key: "OrgProcess",
    label: "Processes",
    icon: "git-branch",
    filename: "EVI_OrgProcesses.csv",
    description: "Business process hierarchy with owners, value chains, and linkages",
    fields: [
      "process_code", "name", "description", "level", "parent_id", "value_chain",
      "workstream", "process_owner", "deputy_owner", "global_control_owner",
      "status", "linked_system_ids", "linked_risk_ids", "linked_control_ids",
      "linked_goal_ids",
    ],
    fieldHints: {
      level: "0|1|2|3|4|5|6",
      status: "active|draft|archived|under_review",
    },
  },
  {
    key: "Issue",
    label: "Issues & Findings",
    icon: "flag",
    filename: "EVI_Issues.csv",
    description: "Issues and assessment findings with action items and RACI data",
    fields: [
      "title", "description", "issue_type", "status", "priority",
      "linked_entity_type", "linked_entity_name", "assigned_to", "due_date",
      "action_item_count", "action_items_summary",
    ],
    fieldHints: {
      issue_type: "action_item|fyi|risk|finding|recommendation",
      status: "open|in_progress|resolved|closed",
      priority: "low|medium|high|critical",
      linked_entity_type: "Company|ThirdPartyProvider|Assessment|ICTSystem|Framework|Incident|Control|Risk|OrgProcess",
    },
  },
  {
    key: "GRCGoal",
    label: "GRC Goals",
    icon: "target",
    filename: "EVI_GRCGoals.csv",
    description: "Governance, risk, and compliance goals with maturity targets and linkages",
    fields: [
      "title", "description", "category", "status", "owner", "due_date",
      "current_maturity", "target_maturity", "maturity_gap", "source",
      "linked_risk_ids", "linked_control_ids", "linked_capability_ids",
      "linked_process_ids", "notes",
    ],
    fieldHints: {
      category: "governance|risk_management|compliance|security|operational|strategic",
      status: "not_started|in_progress|on_track|at_risk|achieved",
      source: "Manual|Risk Assessment|Process Assessment|Maturity Assessment",
    },
  },
  {
    key: "DelegationOfAuthority",
    label: "Delegation of Authority",
    icon: "scale",
    filename: "EVI_DelegationOfAuthority.csv",
    description: "Delegation of Authority records with owner, business unit, validity dates, and review cadence",
    fields: [
      "title", "business_unit", "business_unit_id", "owner_name",
      "owner_stakeholder_id", "review_frequency", "reminder_date",
      "valid_from", "valid_to", "scope_notes", "status", "company_id",
    ],
    fieldHints: {
      review_frequency: "Weekly|Monthly|Quarterly|Bi-Annually|Annually|Ad-hoc",
      status: "draft|active|archived",
    },
  },
  {
    key: "Assessment",
    label: "Assessments",
    icon: "clipboard-check",
    filename: "EVI_Assessments.csv",
    description: "Assessment records with assessor, reviewer, status, and linked risks",
    fields: [
      "name", "status", "assessment_date", "due_date", "completion_date",
      "assessor", "assessor_email", "reviewer", "reviewer_email", "approver",
      "framework_id", "assessment_model_name", "assessment_model_id",
      "linked_to_cycle", "assessment_cycle_name", "linked_risk_ids", "notes",
    ],
    fieldHints: {
      status: "draft|in_progress|pending_review|returned|approved|completed|overdue|archived",
    },
  },
  {
    key: "ThirdPartyProvider",
    label: "Third Parties",
    icon: "building-2",
    filename: "EVI_ThirdParties.csv",
    description: "Third-party vendor register with criticality, contracts, and risk ratings",
    fields: [
      "name", "legal_name", "trading_name", "service_type", "criticality",
      "risk_rating", "status", "contract_start_date", "contract_end_date",
      "contact_name", "contact_email", "last_audit_date", "next_audit_date",
      "certifications", "country_of_registration", "third_party_reference", "notes",
    ],
    fieldHints: {
      service_type: "cloud_hosting|software_as_service|managed_security|data_center|payment_processing|it_support|consulting|other",
      criticality: "critical|important|supporting",
      risk_rating: "low|medium|high|critical",
      status: "active|under_review|terminated|onboarding",
    },
  },
  {
    key: "ConfigurationItem",
    label: "Configuration Items",
    icon: "box",
    filename: "EVI_ConfigurationItems.csv",
    description: "CMDB configuration items with class, environment, and ownership",
    fields: [
      "name", "description", "ci_class", "ci_subclass", "environment",
      "lifecycle_status", "business_owner", "technical_owner", "criticality",
      "parent_ci_id", "related_ict_system_id",
    ],
    fieldHints: {
      environment: "Production|Test|Development|Staging|DR",
      lifecycle_status: "In Service|Retired|In Maintenance|Planned",
      criticality: "critical|important|supporting",
    },
  },
  {
    key: "CapabilityMaturityAssessment",
    label: "Capability Maturity",
    icon: "gauge",
    filename: "EVI_CapabilityMaturity.csv",
    description: "Maturity assessments with scores, bands, and validation status",
    fields: [
      "assessment_name", "assessment_date", "status", "validation_stage",
      "overall_score", "final_score", "target_score", "maturity_band",
      "question_completion", "evidence_completion", "assessor_names", "notes",
    ],
    fieldHints: {
      status: "draft|in_progress|provisional|final",
      validation_stage: "not_started|in_validation|reassess_pending|calibration_pending|validated|aspirations_pending|completed",
    },
  },
  {
    key: "ProcessAssessment",
    label: "Process Assessments",
    icon: "clipboard-list",
    filename: "EVI_ProcessAssessments.csv",
    description: "Process assessments with maturity/risk scores and RACI action items",
    fields: [
      "process_id", "assessment_date", "assessor", "assessment_type", "scope",
      "findings", "outcomes", "overall_rating", "maturity_score", "risk_score",
      "status", "next_assessment_date", "notes", "actions_summary",
    ],
    fieldHints: {
      assessment_type: "initial|annual|ad_hoc|remediation|maturity",
      overall_rating: "excellent|satisfactory|needs_improvement|unsatisfactory",
      status: "draft|completed|approved",
    },
  },
];

export default function DataExport() {
  const [loading, setLoading] = useState(true);
  const [dataMap, setDataMap] = useState({});
  const [downloading, setDownloading] = useState(null);

  useEffect(() => {
    loadAllData();
  }, []);

  async function loadAllData() {
    setLoading(true);
    const results = {};
    for (const config of ENTITY_CONFIGS) {
      try {
        const page = await base44.entities[config.key].filter(
          { company_id: COMPANY_ID },
          { limit: 200, fields: config.fields }
        );
        results[config.key] = page.items || [];
      } catch (e) {
        results[config.key] = [];
      }
    }
    setDataMap(results);
    setLoading(false);
  }

  function generateCsv(config) {
    const records = dataMap[config.key] || [];
    const rows = records.map((r) => {
      if (config.key === "Issue") {
        const ais = r.action_items || [];
        const summary = ais
          .map(
            (ai) =>
              `[${ai.reference_number || ""}] ${ai.title || ""} | Assigned: ${ai.assigned_to || ""} | Due: ${ai.due_date || ""} | Status: ${ai.status || ""} | Desc: ${ai.description || ""}`
          )
          .join(" || ");
        return buildRow(config.fields, { ...r, action_item_count: ais.length, action_items_summary: summary });
      }
      if (config.key === "ProcessAssessment") {
        const acts = r.actions || [];
        const summary = acts
          .map(
            (a) =>
              `[${a.id || ""}] ${a.description || ""} | Priority: ${a.priority || ""} | Due: ${a.due_date || ""} | Status: ${a.status || ""} | R: ${a.responsible || ""} | A: ${a.accountable || ""} | C: ${a.consulted || ""} | I: ${a.informed || ""}`
          )
          .join(" || ");
        return buildRow(config.fields, { ...r, actions_summary: summary });
      }
      return buildRow(config.fields, r);
    });

    // Build hint comment block at the TOP (before header) so ChatGPT sees valid values first
    const hintLines = config.fields
      .map((f) => {
        const hint = config.fieldHints?.[f];
        return hint ? `# ${f}: ${hint}` : "";
      })
      .filter(Boolean);

    let csv = "";
    if (hintLines.length > 0) {
      csv += hintLines.join("\n") + "\n";
    }
    csv += config.fields.join(",");
    if (rows.length > 0) {
      csv += "\n" + rows.join("\n");
    }
    // Add 10 blank rows for ChatGPT to fill
    for (let i = 0; i < 10; i++) {
      csv += "\n" + config.fields.map(() => "").join(",");
    }
    return csv;
  }

  function handleDownload(config) {
    setDownloading(config.key);
    const csv = generateCsv(config);
    downloadCsv(config.filename, csv);
    setTimeout(() => setDownloading(null), 1000);
  }

  function handleDownloadAll() {
    ENTITY_CONFIGS.forEach((config, idx) => {
      setTimeout(() => handleDownload(config), idx * 500);
    });
  }

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-5xl mx-auto">
      <PageHeader
        icon={Database}
        title="Data Export for AI Population"
        tagline="CSV templates with existing EVI Trading data — download and give to ChatGPT to populate meaningful demo data"
      />

      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Database className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div className="text-sm text-blue-900 space-y-1">
              <p className="font-semibold">How to use these files</p>
              <p>
                Each CSV contains the field headers, enum value hints (as comments), existing data rows
                from EVI Trading, and 5 blank rows at the bottom. Download a file, give it to ChatGPT,
                and ask it to populate the blank rows with realistic trading firm data following the
                same patterns as the existing rows.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-600">
          {loading ? "Loading data..." : `${ENTITY_CONFIGS.length} entity templates available`}
        </p>
        {!loading && (
          <Button onClick={handleDownloadAll} variant="default" size="sm">
            <Download className="w-4 h-4" />
            Download All
          </Button>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ENTITY_CONFIGS.map((config) => {
            const count = dataMap[config.key]?.length || 0;
            return (
              <Card key={config.key} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Table className="w-4 h-4 text-slate-500" />
                      <CardTitle className="text-base">{config.label}</CardTitle>
                    </div>
                    <Badge variant={count > 0 ? "default" : "secondary"}>
                      {count} records
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-slate-600">{config.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {config.fields.slice(0, 6).map((f) => (
                      <span key={f} className="text-xs bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">
                        {f}
                      </span>
                    ))}
                    {config.fields.length > 6 && (
                      <span className="text-xs text-slate-400 px-1.5 py-0.5">
                        +{config.fields.length - 6} more
                      </span>
                    )}
                  </div>
                  <Button
                    onClick={() => handleDownload(config)}
                    disabled={downloading === config.key}
                    size="sm"
                    variant="outline"
                    className="w-full"
                  >
                    {downloading === config.key ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <FileSpreadsheet className="w-4 h-4" />
                    )}
                    Download {config.filename}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}