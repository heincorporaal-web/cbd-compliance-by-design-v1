import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Workflow, Globe, Lock, GitBranch, FileText, Save, Upload, Wand2, Download,
} from "lucide-react";
import { downloadBpmnMetadataSchema } from "@/lib/bpmnSchemaExport";
import { toast } from "sonner";
import BpmnDesigner from "@/components/processmodelling/BpmnDesigner";
import ProcessDiagramList from "@/components/processmodelling/ProcessDiagramList";
import ProcessDocumentTemplates from "@/components/processmodelling/ProcessDocumentTemplates";
import GenerateDocumentDialog from "@/components/processmodelling/GenerateDocumentDialog";
import BpmnImportWizard from "@/components/processmodelling/BpmnImportWizard";
import BpmnGenerateDialog from "@/components/processmodelling/BpmnGenerateDialog";
import ModuleToggleStrip from "@/components/branding/ModuleToggleStrip";
import ModuleRibbon from "@/components/branding/ModuleRibbon";
import { BRANDS } from "@/lib/moduleBrands";

export default function AdvancedProcessModelling() {
  const [companyId] = useCompanyFilter();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedProcess, setSelectedProcess] = useState(null);
  const [viewMode, setViewMode] = useState("edit");
  const [activeTab, setActiveTab] = useState("diagrams");
  const [showDocDialog, setShowDocDialog] = useState(false);
  const [showImportWizard, setShowImportWizard] = useState(false);
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);
  const [saveTrigger, setSaveTrigger] = useState(0);

  const effectiveCompanyId = companyId === "all" ? null : companyId;

  // Product owner = platform admin or a role flagged is_product_owner
  const { data: roles = [] } = useQuery({
    queryKey: ["userRoles"],
    queryFn: () => base44.entities.UserRole.list("-created_date", 2000),
    enabled: !!user?.custom_role_id,
  });
  const myRole = roles.find((r) => r.id === user?.custom_role_id);
  const isProductOwner = user?.role === "admin" || !!myRole?.is_product_owner;

  // Company preferences (module on/off flag)
  const { data: prefs = [] } = useQuery({
    queryKey: ["companyPrefs", effectiveCompanyId],
    queryFn: () => base44.entities.CompanyPreference.filter({ company_id: effectiveCompanyId }),
    enabled: !!effectiveCompanyId,
  });
  const pref = prefs[0];
  const moduleEnabled = !!pref?.enable_advanced_process_modelling;

  const enableModuleMutation = useMutation({
    mutationFn: async (enable) => {
      if (pref) {
        return base44.entities.CompanyPreference.update(pref.id, { enable_advanced_process_modelling: enable });
      }
      return base44.entities.CompanyPreference.create({
        company_id: effectiveCompanyId,
        enable_advanced_process_modelling: enable,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["companyPrefs", effectiveCompanyId]);
      toast.success(`Advanced Process Modelling ${moduleEnabled ? "disabled" : "enabled"}`);
    },
  });

  const { data: processes = [], isLoading } = useQuery({
    queryKey: ["orgProcesses", effectiveCompanyId],
    queryFn: () =>
      effectiveCompanyId
        ? base44.entities.OrgProcess.filter({ company_id: effectiveCompanyId })
        : base44.entities.OrgProcess.list("process_code", 500),
    enabled: !!effectiveCompanyId,
  });

  // All diagrams for this company — used to flag processes that have a diagram
  const { data: companyDiagrams = [] } = useQuery({
    queryKey: ["companyProcessDiagrams", effectiveCompanyId],
    queryFn: () => base44.entities.ProcessDiagram.filter({ company_id: effectiveCompanyId }),
    enabled: !!effectiveCompanyId && moduleEnabled,
  });
  const diagramProcessIds = useMemo(
    () => new Set(companyDiagrams.map((d) => d.process_id)),
    [companyDiagrams]
  );

  // Saved diagram for the selected process
  const { data: diagrams = [] } = useQuery({
    queryKey: ["processDiagram", selectedProcess?.id],
    queryFn: () => base44.entities.ProcessDiagram.filter({ process_id: selectedProcess.id }),
    enabled: !!selectedProcess,
  });
  const diagram = diagrams[0];

  const saveMutation = useMutation({
    mutationFn: async ({ xml, svg, canvasMeta, elementMeta }) => {
      const chosenId = canvasMeta?.diagram_process_id;
      let proc = selectedProcess;
      if (chosenId && chosenId !== selectedProcess.id) {
        proc = await base44.entities.OrgProcess.get(chosenId);
      }
      const overriddenName = canvasMeta?.process_name || proc.name;
      const payload = {
        process_id: proc.id,
        process_code: proc.process_code,
        process_name: overriddenName,
        company_id: proc.company_id,
        bpmn_xml: xml,
        svg_snapshot: svg,
        canvas_meta: canvasMeta || {},
        element_meta: elementMeta || {},
      };
      if (diagram) return base44.entities.ProcessDiagram.update(diagram.id, payload);
      return base44.entities.ProcessDiagram.create({ ...payload, status: "draft" });
    },
    onSuccess: (_data, variables) => {
      const chosenId = variables?.canvasMeta?.diagram_process_id;
      queryClient.invalidateQueries(["processDiagram", selectedProcess.id]);
      if (chosenId) queryClient.invalidateQueries(["processDiagram", chosenId]);
      queryClient.invalidateQueries(["companyProcessDiagrams", effectiveCompanyId]);
      queryClient.invalidateQueries(["orgProcesses", effectiveCompanyId]);
      if (chosenId && chosenId !== selectedProcess.id) {
        base44.entities.OrgProcess.get(chosenId)
          .then((p) => { if (p) setSelectedProcess(p); })
          .catch(() => {});
      }
      toast.success("Process diagram saved");
    },
    onError: (e) => toast.error("Save failed: " + (e?.message || e)),
  });

  // No company selected (admin "all")
  if (!effectiveCompanyId) {
    return (
      <div>
        <ModuleRibbon moduleKey="obd" />
        <div className="p-6 lg:p-8 space-y-4">
          <Card className="p-10 text-center text-slate-500">
            <Globe className="w-10 h-10 mx-auto mb-3 text-slate-300" />
            <p className="font-medium">Select a specific company to manage Advanced Process Modelling.</p>
            <p className="text-sm text-slate-400 mt-1">The add-on is switched on per company.</p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div>
      <ModuleRibbon moduleKey="obd" />
      <div className="p-4 lg:p-6 space-y-4">
      {/* Module toggle strip — product owner only, collapsed by default */}
      {isProductOwner && (
        <ModuleToggleStrip
          brand={BRANDS.obd}
          moduleName="Advanced Process Modelling"
          moduleEnabled={moduleEnabled}
          onToggle={(v) => enableModuleMutation.mutate(v)}
          enabledLabel="Switched on — model processes using BPMN 2.0 diagrams, document them, and assess risk posture."
          disabledLabel="Switched off — enable the add-on to access the BPMN 2.0 process diagram designer."
        />
      )}

      {!moduleEnabled ? (
        <Card className="p-10 text-center text-slate-500">
          {isProductOwner ? (
            <>
              <Workflow className="w-10 h-10 mx-auto mb-3 text-slate-300" />
              <p className="font-medium">Advanced Process Modelling is switched off.</p>
              <p className="text-sm text-slate-400 mt-1">Enable the add-on above to access the BPMN 2.0 diagram designer.</p>
              <Link to="/ProcessManagement" className="inline-flex items-center gap-1.5 mt-3 text-sm text-indigo-600 font-medium hover:underline">
                <GitBranch className="w-4 h-4" /> Go to Process Management
              </Link>
            </>
          ) : (
            <>
              <Lock className="w-10 h-10 mx-auto mb-3 text-slate-300" />
              <p className="font-medium">Advanced Process Modelling is not enabled for your company.</p>
              <p className="text-sm text-slate-400 mt-1">
                Request activation using the Contact form in the{" "}
                <Link to="/about" className="text-indigo-600 font-medium hover:underline">About section</Link>.
              </p>
              <Link to="/ProcessManagement" className="inline-flex items-center gap-1.5 mt-3 text-sm text-indigo-600 font-medium hover:underline">
                <GitBranch className="w-4 h-4" /> Go to Process Management
              </Link>
            </>
          )}
        </Card>
      ) : (
        <>
          {!selectedProcess && (
            <div className="flex items-center justify-between gap-2 border-b border-slate-200">
              <div className="flex items-center gap-1">
                <TabButton active={activeTab === "diagrams"} onClick={() => setActiveTab("diagrams")}>Process Diagrams</TabButton>
                <TabButton active={activeTab === "templates"} onClick={() => setActiveTab("templates")}>Document Templates</TabButton>
              </div>
              {activeTab === "diagrams" && (
                <div className="flex items-center gap-2">
                  <Button size="sm" onClick={() => downloadBpmnMetadataSchema()} variant="outline" className="gap-1.5">
                    <Download className="w-4 h-4" /> Export Schema
                  </Button>
                  <Button size="sm" onClick={() => setShowGenerateDialog(true)} className="gap-1.5 bg-violet-600 hover:bg-violet-700">
                    <Wand2 className="w-4 h-4" /> Generate with AI
                  </Button>
                  <Button size="sm" onClick={() => setShowImportWizard(true)} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                    <Upload className="w-4 h-4" /> Import BPMN
                  </Button>
                </div>
              )}
            </div>
          )}
          {activeTab === "templates" ? (
            <ProcessDocumentTemplates companyId={effectiveCompanyId} user={user} />
          ) : selectedProcess ? (
            <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <span className="font-mono">{selectedProcess.process_code}</span>
              <span className="text-slate-300">/</span>
              <span className="font-medium text-slate-700">{selectedProcess.name}</span>
              <Badge variant="outline" className="ml-2">L{selectedProcess.level}</Badge>
            </div>
            <div className="flex items-center gap-2">
              {viewMode === "edit" && (
                <Button size="sm" onClick={() => setSaveTrigger((v) => v + 1)} disabled={saveMutation.isPending} className="gap-1.5 bg-indigo-600 hover:bg-indigo-700">
                  <Save className="w-4 h-4" /> {saveMutation.isPending ? "Saving…" : "Save"}
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={() => setShowDocDialog(true)} className="gap-1.5">
                <FileText className="w-4 h-4" /> Generate Document
              </Button>
            </div>
          </div>
          <BpmnDesigner
            key={`${selectedProcess.id}-${viewMode}`}
            initialXml={diagram?.bpmn_xml}
            initialCanvasMeta={diagram?.canvas_meta}
            initialElementMeta={diagram?.element_meta}
            readOnly={viewMode === "view"}
            saveTrigger={saveTrigger}
            currentProcess={selectedProcess}
            onSave={(xml, svg, canvasMeta, elementMeta) =>
              saveMutation.mutate({ xml, svg, canvasMeta, elementMeta })
            }
            saving={saveMutation.isPending}
            onBack={() => setSelectedProcess(null)}
            processLabel={`${selectedProcess.process_code || ""} ${diagram?.canvas_meta?.process_name || selectedProcess.name || ""}`.trim()}
            companyId={selectedProcess.company_id}
          />
          <GenerateDocumentDialog
            open={showDocDialog}
            onClose={() => setShowDocDialog(false)}
            process={selectedProcess}
            diagram={diagram}
            companyId={selectedProcess.company_id}
          />
        </div>
      ) : (
        <ProcessDiagramList
          processes={processes}
          isLoading={isLoading}
          diagramProcessIds={diagramProcessIds}
          onView={(p) => { setViewMode("view"); setSelectedProcess(p); }}
          onEdit={(p) => { setViewMode("edit"); setSelectedProcess(p); }}
        />
      )}
        </>
      )}
      <BpmnImportWizard
        open={showImportWizard}
        onClose={setShowImportWizard}
        companyId={effectiveCompanyId}
        processes={processes}
        onImported={() => {
          queryClient.invalidateQueries(["companyProcessDiagrams", effectiveCompanyId]);
          queryClient.invalidateQueries(["orgProcesses", effectiveCompanyId]);
        }}
      />
      <BpmnGenerateDialog
        open={showGenerateDialog}
        onClose={setShowGenerateDialog}
        companyId={effectiveCompanyId}
        processes={processes}
        onOpenInDesigner={(proc) => {
          queryClient.invalidateQueries(["companyProcessDiagrams", effectiveCompanyId]);
          queryClient.invalidateQueries(["processDiagram", proc.id]);
          setViewMode("edit");
          setSelectedProcess(proc);
        }}
      />
      </div>
    </div>
  );
}

function TabButton({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors ${active ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500 hover:text-slate-700"}`}
    >
      {children}
    </button>
  );
}