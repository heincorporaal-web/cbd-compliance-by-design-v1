import React, { useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Upload, GitBranch, CheckCircle2, AlertCircle, Download, FileSearch } from "lucide-react";
import HierarchySummaryCards from "@/components/hierarchyaudit/HierarchySummaryCards";
import HierarchyBeforeAfter from "@/components/hierarchyaudit/HierarchyBeforeAfter";
import HierarchyFindingsTable from "@/components/hierarchyaudit/HierarchyFindingsTable";
import HierarchyTreeView from "@/components/hierarchyaudit/HierarchyTreeView";
import PageHeader from "@/components/layout/PageHeader";

export default function HierarchyAudit() {
  const [selectedCompanyId, setSelectedCompanyId] = useCompanyFilter();
  const [staging, setStaging] = useState(false);
  const [stagedData, setStagedData] = useState(null);
  const [applying, setApplying] = useState(false);
  const [applyResult, setApplyResult] = useState(null);
  const [error, setError] = useState(null);
  const [actions, setActions] = useState({});
  const [activeTab, setActiveTab] = useState("findings");

  const handleUpload = useCallback(async (file) => {
    if (!file || !selectedCompanyId) return;
    setStaging(true);
    setError(null);
    setApplyResult(null);
    setActions({});
    try {
      // Upload CSV (stored publicly — anyone with the link can open them)
      const uploadRes = await base44.integrations.Core.UploadPublicFile({ file });
      const fileUrl = uploadRes.file_url;

      // Stage the audit
      const result = await base44.functions.invoke("stageHierarchyAudit", {
        file_url: fileUrl,
        company_id: selectedCompanyId,
      });
      setStagedData(result);
      setActiveTab("summary");
    } catch (e) {
      setError(e.message || "Failed to stage audit");
    } finally {
      setStaging(false);
    }
  }, [selectedCompanyId]);

  const handleActionChange = useCallback((rowIndex, action) => {
    setActions((prev) => {
      const next = { ...prev };
      if (action === null) delete next[rowIndex];
      else next[rowIndex] = action;
      return next;
    });
  }, []);

  const handleApply = useCallback(async () => {
    if (!stagedData || !selectedCompanyId) return;
    const approvedItems = stagedData.items
      .filter((item) => actions[item.row_index] === "approve" && item.has_changes && item.process_found)
      .map((item) => ({ ...item }));
    if (approvedItems.length === 0) {
      setError("No approved items with changes to apply.");
      return;
    }
    setApplying(true);
    setError(null);
    try {
      const result = await base44.functions.invoke("applyHierarchyCorrections", {
        company_id: selectedCompanyId,
        items: approvedItems,
      });
      setApplyResult(result);
      setActiveTab("apply");
    } catch (e) {
      setError(e.message || "Failed to apply corrections");
    } finally {
      setApplying(false);
    }
  }, [stagedData, selectedCompanyId, actions]);

  const exportRemediationCSV = useCallback(() => {
    if (!stagedData?.items) return;
    const headers = ["process_id", "name", "current_code", "current_level", "current_parent_id", "proposed_code", "proposed_level", "proposed_parent_id", "target_value_chain_code", "suggested_workstream_code", "target_action", "issue_flags", "has_changes", "action"];
    const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const lines = [headers.map(esc).join(",")];
    for (const item of stagedData.items) {
      lines.push([
        item.process_id,
        item.process_name,
        item.current_code,
        item.current_level,
        item.current_parent_id,
        item.proposed_code,
        item.proposed_level ?? "",
        item.proposed_parent_id,
        item.target_value_chain_code,
        item.suggested_workstream_code,
        item.target_action,
        item.issue_flags.join(";"),
        item.has_changes ? "YES" : "NO",
        actions[item.row_index] || "pending",
      ].map(esc).join(","));
    }
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hierarchy_audit_remediation_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }, [stagedData, actions]);

  const approvedCount = Object.values(actions).filter((a) => a === "approve").length;
  const approvedWithChanges = stagedData?.items
    ? stagedData.items.filter((item) => actions[item.row_index] === "approve" && item.has_changes && item.process_found).length
    : 0;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <PageHeader
        navItemId="hierarchy_audit"
        icon={GitBranch}
        title="Hierarchy Audit"
        tagline="Hierarchical process numbering and parent–child integrity validation."
        gradient="from-indigo-600 to-blue-700"
      />

      {/* Upload section */}
      <Card>
        <CardContent className="pt-6">
          {!stagedData ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <FileSearch className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-slate-900">Import Hierarchy Audit CSV</h3>
              </div>
              <p className="text-sm text-slate-500">
                Upload a Full Hierarchy Audit CSV (with code proposals) to stage findings for review.
                The audit validates parent–child integrity, hierarchical numbering, value-chain alignment,
                and workstream associations across the complete process population.
              </p>
              <div className="flex items-center gap-3">
                <label className="cursor-pointer">
                  <input
                    type="file"
                    accept=".csv"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleUpload(file);
                    }}
                    disabled={!selectedCompanyId || staging}
                  />
                  <div className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                    !selectedCompanyId
                      ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                      : "bg-primary text-white hover:bg-primary/90"
                  }`}>
                    {staging ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    {staging ? "Staging…" : "Upload Audit CSV"}
                  </div>
                </label>
                {!selectedCompanyId && (
                  <span className="text-xs text-amber-600">Select a company first</span>
                )}
              </div>
              {error && (
                <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                  <AlertCircle className="w-4 h-4" /> {error}
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-semibold text-slate-900">Audit Staged Successfully</p>
                  <p className="text-xs text-slate-500">
                    {stagedData.total_rows} rows · {stagedData.summary.process_found} found in DB ·{" "}
                    {stagedData.summary.changes.no_change} no change ·{" "}
                    {stagedData.total - stagedData.summary.changes.no_change} with changes
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" onClick={exportRemediationCSV} className="gap-2">
                  <Download className="w-4 h-4" /> Export Remediation CSV
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setStagedData(null);
                    setApplyResult(null);
                    setActions({});
                    setError(null);
                  }}
                >
                  Reset
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {stagedData && (
        <>
          <HierarchySummaryCards summary={stagedData.summary} />
          <HierarchyBeforeAfter beforeAfter={stagedData.before_after} />

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="findings">
                Findings ({stagedData.items.length})
              </TabsTrigger>
              <TabsTrigger value="tree">
                Hierarchy Tree
              </TabsTrigger>
              <TabsTrigger value="apply">
                Apply ({approvedWithChanges})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="findings" className="mt-4">
              <HierarchyFindingsTable
                items={stagedData.items}
                groups={stagedData.groups}
                summary={stagedData.summary}
                onActionChange={handleActionChange}
                actions={actions}
              />
            </TabsContent>

            <TabsContent value="tree" className="mt-4">
              <HierarchyTreeView items={stagedData.items} />
            </TabsContent>

            <TabsContent value="apply" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Apply Approved Corrections</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4 text-sm">
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
                      {approvedCount} approved
                    </Badge>
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
                      {approvedWithChanges} with changes & in DB
                    </Badge>
                    <span className="text-slate-500">
                      Only approved items with actual changes and valid DB records will be updated.
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <Button
                      onClick={handleApply}
                      disabled={applying || approvedWithChanges === 0}
                      className="gap-2 bg-primary hover:bg-primary/90"
                    >
                      {applying ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                      {applying ? "Applying…" : `Apply ${approvedWithChanges} Corrections`}
                    </Button>
                    {error && (
                      <span className="text-sm text-red-600 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" /> {error}
                      </span>
                    )}
                  </div>

                  {applyResult && (
                    <div className="space-y-3 pt-3 border-t">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                        <h4 className="font-semibold text-slate-900">Application Report</h4>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="bg-slate-50 rounded-lg p-3">
                          <p className="text-xs text-slate-500">Updated</p>
                          <p className="text-xl font-bold text-green-600">{applyResult.report.updated}</p>
                        </div>
                        <div className="bg-slate-50 rounded-lg p-3">
                          <p className="text-xs text-slate-500">Skipped</p>
                          <p className="text-xl font-bold text-slate-600">{applyResult.report.skipped}</p>
                        </div>
                        <div className="bg-slate-50 rounded-lg p-3">
                          <p className="text-xs text-slate-500">Aliases Created</p>
                          <p className="text-xl font-bold text-blue-600">{applyResult.report.aliases_created}</p>
                        </div>
                        <div className="bg-slate-50 rounded-lg p-3">
                          <p className="text-xs text-slate-500">Diagrams Updated</p>
                          <p className="text-xl font-bold text-purple-600">{applyResult.report.diagrams_updated}</p>
                        </div>
                      </div>
                      {applyResult.report.errors > 0 && (
                        <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                          <AlertCircle className="w-4 h-4" /> {applyResult.report.errors} errors occurred during application.
                        </div>
                      )}
                      <details className="text-sm">
                        <summary className="cursor-pointer text-slate-500 hover:text-slate-700">
                          View {applyResult.report.details.length} detail entries
                        </summary>
                        <div className="mt-2 max-h-64 overflow-y-auto border border-slate-200 rounded-lg">
                          <table className="w-full text-xs">
                            <thead className="bg-slate-50 sticky top-0">
                              <tr>
                                <th className="text-left p-2">Process ID</th>
                                <th className="text-left p-2">Old Code</th>
                                <th className="text-left p-2">New Code</th>
                                <th className="text-left p-2">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {applyResult.report.details.map((d, i) => (
                                <tr key={i} className="border-t border-slate-100">
                                  <td className="p-2 font-mono text-slate-500 truncate max-w-[120px]">{d.process_id}</td>
                                  <td className="p-2 font-mono text-slate-600">{d.old_code || '—'}</td>
                                  <td className="p-2 font-mono text-slate-700">{d.new_code || '—'}</td>
                                  <td className="p-2 text-slate-500">{d.action}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </details>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}