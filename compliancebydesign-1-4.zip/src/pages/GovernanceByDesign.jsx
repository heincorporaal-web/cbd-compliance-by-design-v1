import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import { differenceInDays, parseISO } from "date-fns";
import {
  BookOpen, GitBranch, ClipboardCheck, BarChart3,
  UserX, AlertTriangle, Clock, CheckCircle2, FileText, Archive,
} from "lucide-react";
import ModuleDashboard from "@/components/branding/ModuleDashboard";
import { BRANDS } from "@/lib/moduleBrands";

const FEATURES = [
  { icon: BookOpen, title: "Governance Library", desc: "Central searchable catalogue of policies, standards, procedures and guidelines with full metadata, versioning and lifecycle tracking." },
  { icon: GitBranch, title: "Policy Lifecycle", desc: "Draft, review, approve, publish and retire governance artefacts with structured workflows, version history and approval records." },
  { icon: ClipboardCheck, title: "Review Management", desc: "Structured periodic and event-driven reviews with questionnaires, outcomes and automated due-date tracking." },
  { icon: BarChart3, title: "Governance Traceability", desc: "Link policies to existing CBD risks, controls, frameworks and processes — trace governance intent through to operational evidence." },
];

export default function GovernanceByDesign() {
  const [companyId] = useCompanyFilter();
  const effectiveCompanyId = companyId === "all" ? null : companyId;

  const { data: docs = [], isLoading } = useQuery({
    queryKey: ["governanceDocs", effectiveCompanyId],
    queryFn: () =>
      effectiveCompanyId
        ? base44.entities.GovernanceDocument.filter({ company_id: effectiveCompanyId })
        : base44.entities.GovernanceDocument.list("-created_date", 500),
  });

  const now = new Date();
  const metrics = [
    { label: "Total Documents", value: docs.length, icon: FileText, link: "/GovernanceByDesignModule" },
    { label: "Without Owner", value: docs.filter((d) => !d.owner_name && !d.owner_stakeholder_id).length, icon: UserX, link: "/GovernanceByDesignModule", attention: true },
    { label: "Without Approver", value: docs.filter((d) => !d.approver_name && !d.approver_stakeholder_id).length, icon: AlertTriangle, link: "/GovernanceByDesignModule", attention: true },
    { label: "Overdue Reviews", value: docs.filter((d) => d.next_review_date && differenceInDays(parseISO(d.next_review_date), now) < 0).length, icon: Clock, link: "/GovernanceByDesignModule", attention: true },
    { label: "Published", value: docs.filter((d) => d.status === "published").length, icon: CheckCircle2, link: "/GovernanceByDesignModule" },
    { label: "In Draft / Review", value: docs.filter((d) => ["draft", "internal_review", "awaiting_approval", "under_review"].includes(d.status)).length, icon: BookOpen, link: "/GovernanceByDesignModule" },
    { label: "Approved", value: docs.filter((d) => d.status === "approved").length, icon: CheckCircle2, link: "/GovernanceByDesignModule" },
    { label: "Retired / Expired", value: docs.filter((d) => ["retired", "expired"].includes(d.status)).length, icon: Archive, link: "/GovernanceByDesignModule" },
  ];

  return (
    <ModuleDashboard
      brand={BRANDS.gbd}
      Icon={BookOpen}
      logoUrl={BRANDS.gbd.logoUrl}
      metrics={metrics}
      isLoading={isLoading}
      enterPath={BRANDS.gbd.enterPath}
      enterLabel={BRANDS.gbd.enterLabel}
      features={FEATURES}
      moduleKey="gbd"
    />
  );
}