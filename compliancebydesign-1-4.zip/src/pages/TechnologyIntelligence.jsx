import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import { useToast } from "@/components/ui/use-toast";
import PageHeader from "@/components/layout/PageHeader";
import TechReadinessPanel from "@/components/tech/TechReadinessPanel";
import TechPortfolioAnalytics from "@/components/tech/TechPortfolioAnalytics";
import TechHealthExposure from "@/components/tech/TechHealthExposure";
import TechOpportunities from "@/components/tech/TechOpportunities";
import TechSystemsTable from "@/components/tech/TechSystemsTable";
import TechDecisionDialog from "@/components/tech/TechDecisionDialog";
import { Cpu, Play, Loader2 } from "lucide-react";

export default function TechnologyIntelligence() {
  const { toast } = useToast();
  const [companyId] = useCompanyFilter();
  const [result, setResult] = useState(null);
  const [running, setRunning] = useState(false);
  const [dialog, setDialog] = useState(null); // { opportunity, existing }

  const hasCompany = companyId && companyId !== "all";
  const { data: decisions = [] } = useQuery({
    queryKey: ["tech-decisions", companyId],
    enabled: hasCompany,
    queryFn: async () =>
      (await base44.entities.TechnologyDecision.filter({ company_id: companyId }, { sort: "-created_date", limit: 500 })).items,
  });

  const decisionIds = decisions.map((d) => d.id);
  const { data: workflowInstances = [] } = useQuery({
    queryKey: ["tech-decision-workflow-instances", companyId, decisionIds.join(",")],
    enabled: hasCompany && decisionIds.length > 0,
    queryFn: async () =>
      await base44.entities.WorkflowInstance.filter({
        entity_type: "TechnologyDecision",
        entity_id: { $in: decisionIds },
      }),
  });
  const workflowStatusByDecision = React.useMemo(() => {
    const map = {};
    (workflowInstances || []).forEach((i) => {
      map[i.entity_id] = i.status;
    });
    return map;
  }, [workflowInstances]);

  const run = async () => {
    setRunning(true);
    try {
      const res = await base44.functions.invoke("runTechnologyIntelligence", { company_id: companyId });
      setResult(res.data);
      toast({ title: "Technology intelligence calculated" });
    } catch (e) {
      toast({ title: "Could not run analysis", description: e.message, variant: "destructive" });
    }
    setRunning(false);
  };

  const openDecision = (opportunity) => {
    const existing = decisions.find((d) => d.asset_id === opportunity.asset_id && d.asset_type === opportunity.asset_type);
    setDialog({ opportunity, existing });
  };

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <PageHeader icon={Cpu} title="Technology Intelligence" tagline="Risk-based technology portfolio intelligence and strategic decision support" />
        <Button onClick={run} disabled={!hasCompany || running}>
          {running ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Play className="w-4 h-4 mr-1" />} Run analysis
        </Button>
      </div>

      {!hasCompany ? (
        <Card><CardContent className="p-6 text-slate-600">Select a single company in the company filter to run technology intelligence.</CardContent></Card>
      ) : !result ? (
        <Card><CardContent className="p-6 text-slate-600">Run the analysis to assess technology health, strategic value and improvement opportunities. Nothing in your source records is changed.</CardContent></Card>
      ) : (
        <>
          <div className="flex flex-wrap gap-2 text-xs text-slate-500">
            {Object.entries(result.source_counts).map(([k, v]) => (
              <Badge key={k} variant="outline" className="capitalize">{k.replace(/_/g, " ")}: {v}</Badge>
            ))}
          </div>
          <TechReadinessPanel readiness={result.readiness} />
          <TechPortfolioAnalytics analytics={result.portfolio_analytics} decisions={decisions} workflowStatusByDecision={workflowStatusByDecision} />
          <TechHealthExposure health={result.health_exposure} decisions={decisions} workflowStatusByDecision={workflowStatusByDecision} />
          <TechOpportunities opportunities={result.opportunities} decisions={decisions} workflowStatusByDecision={workflowStatusByDecision} onDecide={openDecision} />
          <TechSystemsTable systems={result.systems} decisions={decisions} workflowStatusByDecision={workflowStatusByDecision} onDecide={openDecision} />
        </>
      )}

      <TechDecisionDialog
        open={!!dialog}
        opportunity={dialog?.opportunity}
        existing={dialog?.existing}
        companyId={companyId}
        onClose={() => setDialog(null)}
      />
    </div>
  );
}