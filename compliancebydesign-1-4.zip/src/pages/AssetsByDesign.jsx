import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import {
  Boxes, Radar, Link2, Activity,
  UserX, Unlink, AlertTriangle, ShieldOff, CheckCircle2, Server, Ban,
} from "lucide-react";
import ModuleDashboard from "@/components/branding/ModuleDashboard";
import { BRANDS } from "@/lib/moduleBrands";

const FEATURES = [
  { icon: Boxes, title: "Configuration Items", desc: "Central CMDB of all infrastructure configuration items — servers, VMs, network devices, cloud resources — with unique CI IDs, classes and lifecycle tracking." },
  { icon: Radar, title: "Microsoft Discovery", desc: "Ingest from Defender for Endpoint, Intune, Entra ID and Azure Resource Graph through a staging and reconciliation pipeline — never write raw data straight to CIs." },
  { icon: Link2, title: "Relationship Mapping", desc: "Map CI-to-CI dependencies and link CBD applications to their supporting infrastructure — relationships live only in the CMDB, CBD stays read-only." },
  { icon: Activity, title: "Lifecycle & Audit", desc: "Track each CI from discovered through retired, with change detection, audit history and data quality scoring for full traceability." },
];

export default function AssetsByDesign() {
  const [companyId] = useCompanyFilter();
  const effectiveCompanyId = companyId === "all" ? null : companyId;

  const { data: cis = [], isLoading: cisLoading } = useQuery({
    queryKey: ["configurationItems", effectiveCompanyId],
    queryFn: () =>
      effectiveCompanyId
        ? base44.entities.ConfigurationItem.filter({ company_id: effectiveCompanyId })
        : base44.entities.ConfigurationItem.list("-created_date", 500),
  });

  const { data: assets = [] } = useQuery({
    queryKey: ["discoveredAssets", effectiveCompanyId],
    queryFn: () =>
      effectiveCompanyId
        ? base44.entities.DiscoveredAsset.filter({ company_id: effectiveCompanyId })
        : base44.entities.DiscoveredAsset.list("-created_date", 500),
    enabled: !!effectiveCompanyId,
  });

  const { data: systems = [] } = useQuery({
    queryKey: ["ictSystems", effectiveCompanyId],
    queryFn: () =>
      effectiveCompanyId
        ? base44.entities.ICTSystem.filter({ company_id: effectiveCompanyId })
        : base44.entities.ICTSystem.list("-created_date", 500),
  });

  const isLoading = cisLoading;

  const metrics = [
    { label: "Total CIs", value: cis.length, icon: Boxes, link: "/CMDBInventory" },
    { label: "Without Owner", value: cis.filter((c) => !c.technical_owner && !c.business_owner).length, icon: UserX, link: "/CMDBInventory", attention: true },
    { label: "Unmanaged", value: cis.filter((c) => c.managed_unmanaged === "unmanaged").length, icon: ShieldOff, link: "/CMDBInventory", attention: true },
    { label: "Stale", value: cis.filter((c) => c.stale_status === "stale" || c.stale_status === "retirement_candidate").length, icon: AlertTriangle, link: "/CMDBInventory", attention: true },
    { label: "Discovered (Unlinked)", value: assets.filter((a) => a.status === "discovered").length, icon: Unlink, link: "/AdvancedAssetManagement", attention: true },
    { label: "In Service", value: cis.filter((c) => c.lifecycle_status === "In Service").length, icon: CheckCircle2, link: "/CMDBInventory" },
    { label: "ICT Systems", value: systems.length, icon: Server, link: "/ICTSystems" },
    { label: "Retired", value: cis.filter((c) => c.lifecycle_status === "Retired").length, icon: Ban, link: "/CMDBInventory" },
  ];

  return (
    <ModuleDashboard
      brand={BRANDS.abd}
      Icon={Boxes}
      logoUrl={BRANDS.abd.logoUrl}
      metrics={metrics}
      isLoading={isLoading}
      enterPath={BRANDS.abd.enterPath}
      enterLabel={BRANDS.abd.enterLabel}
      features={FEATURES}
      moduleKey="abd"
    />
  );
}