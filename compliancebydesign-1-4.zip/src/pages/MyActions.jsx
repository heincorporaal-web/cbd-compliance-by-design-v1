import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import {
  CalendarClock, CheckCircle2, ChevronRight,
  ShieldAlert, Target, Shield, Scale, TriangleAlert, X
} from "lucide-react";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import CompanyFilterBar from "@/components/CompanyFilterBar";
import PageHeader from "@/components/layout/PageHeader";
import ActionSummaryWidget from "@/components/actions/ActionSummaryWidget";
import { differenceInDays, parseISO, isValid, addDays, addWeeks, addMonths, addYears } from "date-fns";

const TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

const WINDOW_DAYS = 180; // show items due within 6 months

function parseDate(val) {
  if (!val) return null;
  const d = typeof val === "string" ? parseISO(val.split("T")[0]) : new Date(val);
  return isValid(d) ? d : null;
}

function getDaysUntil(dateVal) {
  const d = parseDate(dateVal);
  if (!d) return null;
  return differenceInDays(d, TODAY);
}

// Estimate next review date from last approval + frequency
function estimateNextReview(approvalDate, frequency) {
  const base = parseDate(approvalDate);
  if (!base) return null;
  switch (frequency) {
    case "Daily": return addDays(base, 1);
    case "Weekly": return addWeeks(base, 1);
    case "Monthly": return addMonths(base, 1);
    case "Quarterly": return addMonths(base, 3);
    case "Annually": return addYears(base, 1);
    default: return null;
  }
}

function StatusBadge({ days }) {
  if (days === null) return null;
  if (days < 0) return <Badge className="bg-red-100 text-red-700 border-red-200">Overdue {Math.abs(days)}d</Badge>;
  if (days === 0) return <Badge className="bg-red-100 text-red-700 border-red-200">Due Today</Badge>;
  if (days <= 7)  return <Badge className="bg-red-50 text-red-600 border-red-100">In {days}d</Badge>;
  if (days <= 14) return <Badge className="bg-orange-100 text-orange-700 border-orange-200">In {days}d</Badge>;
  if (days <= 30) return <Badge className="bg-amber-100 text-amber-700 border-amber-200">In {days}d</Badge>;
  if (days <= 90) return <Badge className="bg-yellow-50 text-yellow-700 border-yellow-100">In {days}d</Badge>;
  return <Badge className="bg-slate-100 text-slate-500 border-slate-200">In {days}d</Badge>;
}

const TYPE_META = {
  principal_risk: { label: "Principal Risk",  icon: ShieldAlert,   color: "text-red-600",    tint: "from-red-50 to-orange-50",    url: "/PrincipalRisks"      },
  risk:           { label: "Risk",             icon: TriangleAlert, color: "text-orange-600", tint: "from-orange-50 to-amber-50",  url: "/RiskRegister"         },
  objective:      { label: "Objective",        icon: Target,        color: "text-purple-600", tint: "from-purple-50 to-indigo-50", url: "/ObjectivesSummary"    },
  control:        { label: "Control",          icon: Shield,        color: "text-indigo-600", tint: "from-indigo-50 to-blue-50",    url: "/Controls"            },
  framework:      { label: "Framework",        icon: Shield,        color: "text-blue-600",   tint: "from-blue-50 to-sky-50",      url: "/Frameworks"          },
  doa:            { label: "DOA",              icon: Scale,         color: "text-teal-600",   tint: "from-teal-50 to-cyan-50",    url: "/DelegationOfAuthority"},
};

const TYPE_FILTERS = [
  { id: "all",           label: "All Types" },
  { id: "principal_risk",label: "Principal Risks" },
  { id: "risk",          label: "Risks" },
  { id: "objective",     label: "Objectives" },
  { id: "control",       label: "Controls" },
  { id: "framework",     label: "Frameworks" },
  { id: "doa",           label: "DOA" },
];

const URGENCY_FILTERS = [
  { id: "all",     label: "All" },
  { id: "overdue", label: "Overdue" },
  { id: "soon",    label: "Due ≤ 14d" },
  { id: "upcoming",label: "Due ≤ 90d" },
];

function ActionRow({ item }) {
  const meta = TYPE_META[item.type];
  const Icon = meta.icon;
  return (
    <Link to={meta.url} className="flex items-center gap-3 p-3.5 border-b last:border-0 hover:bg-slate-50 transition-colors group">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-gradient-to-br ${meta.tint}`}>
        <Icon className={`w-4 h-4 ${meta.color}`} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-slate-900 text-sm truncate">{item.title}</p>
        <p className="text-xs text-slate-500 truncate">{item.subtitle}</p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <Badge variant="outline" className={`text-xs hidden sm:inline-flex ${meta.color} border-current/20`}>{meta.label}</Badge>
        <StatusBadge days={item.days} />
        <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 transition-colors" />
      </div>
    </Link>
  );
}

export default function MyActions() {
  const [globalCompany] = useCompanyFilter();
  const gc = globalCompany;
  const [typeFilter, setTypeFilter] = useState("all");
  const [urgencyFilter, setUrgencyFilter] = useState("all");

  const { data: principalRisks = [] } = useQuery({ queryKey: ["principalRisks"],  queryFn: () => base44.entities.PrincipalRisk.list() });
  const { data: risks = [] }           = useQuery({ queryKey: ["risks"],            queryFn: () => base44.entities.Risk.list() });
  const { data: objectives = [] }      = useQuery({ queryKey: ["orgObjectives"],    queryFn: () => base44.entities.OrgObjective.list() });
  const { data: controls = [] }        = useQuery({ queryKey: ["controls"],         queryFn: () => base44.entities.Control.list() });
  const { data: frameworks = [] }      = useQuery({ queryKey: ["frameworks"],       queryFn: () => base44.entities.Framework.list() });
  const { data: doaList = [] }         = useQuery({ queryKey: ["doa"],              queryFn: () => base44.entities.DelegationOfAuthority.list() });
  const { data: companies = [] }       = useQuery({ queryKey: ["companies"],        queryFn: () => base44.entities.Company.list() });

  const cname = (id) => companies.find(c => c.id === id)?.name || "";
  const byCompany = (arr) => gc && gc !== "all" ? arr.filter(r => r.company_id === gc) : arr;

  const allItems = useMemo(() => {
    const items = [];

    // Principal Risks — next_review_date
    byCompany(principalRisks)
      .filter(r => r.next_review_date && r.status !== "Retired")
      .forEach(r => {
        const days = getDaysUntil(r.next_review_date);
        if (days !== null && days <= WINDOW_DAYS) {
          items.push({
            type: "principal_risk",
            days,
            title: `${r.risk_reference ? `[${r.risk_reference}] ` : ""}${r.risk_title}`,
            subtitle: `Next Review · ${cname(r.company_id)} · ${r.risk_category}`,
            dateLabel: r.next_review_date,
          });
        }
      });

    // Risks — review_date
    byCompany(risks)
      .filter(r => r.review_date && r.status !== "closed" && r.status !== "mitigated")
      .forEach(r => {
        const days = getDaysUntil(r.review_date);
        if (days !== null && days <= WINDOW_DAYS) {
          items.push({
            type: "risk",
            days,
            title: `${r.risk_reference_nr ? `[${r.risk_reference_nr}] ` : ""}${r.title}`,
            subtitle: `Review Date · ${cname(r.company_id)} · ${r.category?.replace(/_/g, " ")}`,
            dateLabel: r.review_date,
          });
        }
      });

    // Objectives — next_review_date
    byCompany(objectives)
      .filter(o => o.next_review_date && o.status !== "Retired")
      .forEach(o => {
        const days = getDaysUntil(o.next_review_date);
        if (days !== null && days <= WINDOW_DAYS) {
          items.push({
            type: "objective",
            days,
            title: `${o.reference_number ? `[${o.reference_number}] ` : ""}${o.title}`,
            subtitle: `Next Review · ${cname(o.company_id)} · ${o.category}`,
            dateLabel: o.next_review_date,
          });
        }
      });

    // Controls — estimate from approval_date + control_frequency
    controls
      .filter(c => c.status === "active" || c.status === "approved")
      .forEach(c => {
        const nextDate = estimateNextReview(c.approval_date, c.control_frequency);
        if (!nextDate) return;
        const days = differenceInDays(nextDate, TODAY);
        if (days !== null && days <= WINDOW_DAYS) {
          items.push({
            type: "control",
            days,
            title: `${c.control_id ? `[${c.control_id}] ` : ""}${c.title}`,
            subtitle: `${c.control_frequency} Review · ${c.control_type || "Control"} · ${c.category || ""}`,
            dateLabel: nextDate.toISOString().split("T")[0],
          });
        }
      });

    // Frameworks — end_date
    frameworks
      .filter(f => f.end_date && f.status !== "archived")
      .forEach(f => {
        const days = getDaysUntil(f.end_date);
        if (days !== null && days <= WINDOW_DAYS) {
          items.push({
            type: "framework",
            days,
            title: f.name,
            subtitle: `End Date · ${f.framework_code || f.category}`,
            dateLabel: f.end_date,
          });
        }
      });

    // DOA — reminder_date
    byCompany(doaList)
      .filter(d => d.reminder_date && d.status !== "archived")
      .forEach(d => {
        const days = getDaysUntil(d.reminder_date);
        if (days !== null && days <= WINDOW_DAYS) {
          items.push({
            type: "doa",
            days,
            title: d.title,
            subtitle: `Review Reminder · ${cname(d.company_id)}`,
            dateLabel: d.reminder_date,
          });
        }
      });

    return items.sort((a, b) => a.days - b.days);
  }, [principalRisks, risks, objectives, controls, frameworks, doaList, gc, companies]);

  const filtered = useMemo(() => {
    let result = allItems;
    if (typeFilter !== "all") result = result.filter(i => i.type === typeFilter);
    if (urgencyFilter === "overdue")  result = result.filter(i => i.days < 0);
    if (urgencyFilter === "soon")     result = result.filter(i => i.days >= 0 && i.days <= 14);
    if (urgencyFilter === "upcoming") result = result.filter(i => i.days >= 0 && i.days <= 90);
    return result;
  }, [allItems, typeFilter, urgencyFilter]);

  const totalOverdue  = allItems.filter(i => i.days < 0).length;
  const totalSoon     = allItems.filter(i => i.days >= 0 && i.days <= 14).length;
  const totalUpcoming = allItems.filter(i => i.days >= 0 && i.days <= 90).length;

  const typeCounts = useMemo(() => {
    const counts = {};
    allItems.forEach(i => { counts[i.type] = (counts[i.type] || 0) + 1; });
    return counts;
  }, [allItems]);

  // Per-type urgency breakdown for the summary widgets
  const typeMetrics = useMemo(() => {
    const metrics = {};
    Object.keys(TYPE_META).forEach(t => {
      metrics[t] = { total: 0, overdue: 0, soon: 0, upcoming: 0 };
    });
    allItems.forEach(i => {
      const m = metrics[i.type];
      if (!m) return;
      m.total++;
      if (i.days < 0) m.overdue++;
      else if (i.days <= 14) m.soon++;
      else if (i.days <= 90) m.upcoming++;
    });
    return metrics;
  }, [allItems]);

  return (
    <div className="p-4 lg:p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <PageHeader
          navItemId="my_actions"
          icon={CalendarClock}
          title="My Actions"
          tagline="Upcoming review dates across risks, controls, objectives and more"
          gradient="from-amber-500 to-orange-600"
        />
        <CompanyFilterBar />
      </div>

      {/* Summary widgets — per-type breakdown matching the dashboard widget style */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {Object.entries(TYPE_META).map(([key, meta]) => {
          const m = typeMetrics[key] || { total: 0, overdue: 0, soon: 0, upcoming: 0 };
          return (
            <ActionSummaryWidget
              key={key}
              icon={meta.icon}
              title={meta.label}
              rows={[
                { label: "Total Due", value: m.total },
                { label: "Overdue", value: m.overdue, highlight: m.overdue > 0 },
                { label: "Due ≤ 14d", value: m.soon },
                { label: "Due ≤ 90d", value: m.upcoming },
              ]}
            />
          );
        })}
      </div>

      {/* Type filter pills — matching the dashboard category pills */}
      <div className="flex items-center gap-2 flex-wrap">
        {TYPE_FILTERS.map(f => (
          <button
            key={f.id}
            onClick={() => setTypeFilter(f.id)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all border ${
              typeFilter === f.id
                ? "bg-primary text-white border-primary shadow-sm"
                : "bg-white text-slate-600 border-slate-200 hover:border-primary/50 hover:text-primary"
            }`}
          >
            {f.label}{f.id !== "all" && typeCounts[f.id] ? ` (${typeCounts[f.id]})` : ""}
          </button>
        ))}
        {(typeFilter !== "all" || urgencyFilter !== "all") && (
          <button
            onClick={() => { setTypeFilter("all"); setUrgencyFilter("all"); }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-medium bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 transition-colors"
          >
            <X className="w-3.5 h-3.5" /> Clear
          </button>
        )}
      </div>

      {/* Action list — dark header bar matching the dashboard card style */}
      <Card className="border border-slate-200 shadow-sm overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground">
          <CalendarClock className="w-4 h-4 shrink-0" />
          <h2 className="text-sm font-semibold tracking-wide truncate">Action Items</h2>
          <Badge variant="outline" className="ml-auto font-normal border-primary-foreground/30 text-primary-foreground">{filtered.length} items</Badge>
        </div>
        <div className="max-h-[600px] overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="py-12 text-center">
              <CheckCircle2 className="w-10 h-10 text-green-400 mx-auto mb-3" />
              <p className="text-slate-500 font-medium">All clear!</p>
              <p className="text-sm text-slate-400 mt-1">No items match the selected filters.</p>
            </div>
          ) : (
            filtered.map((item, i) => <ActionRow key={i} item={item} />)
          )}
        </div>
      </Card>
    </div>
  );
}