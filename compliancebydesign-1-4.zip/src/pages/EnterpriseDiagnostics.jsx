import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { useCompanyFilter } from "@/hooks/useCompanyFilter";
import PageHeader from "@/components/layout/PageHeader";
import CycleFormDialog from "@/components/diagnostics/CycleFormDialog";
import RuleCoverageCard from "@/components/diagnostics/RuleCoverageCard";
import RuleDrilldownDialog from "@/components/diagnostics/RuleDrilldownDialog";
import ReconciliationPanel from "@/components/diagnostics/ReconciliationPanel";
import ImportanceEffectivenessMatrix from "@/components/diagnostics/ImportanceEffectivenessMatrix";
import AreaScorecards from "@/components/diagnostics/AreaScorecards";
import FindingsPanel from "@/components/diagnostics/FindingsPanel";
import { ExportResultsButton, ExportFindingsButton } from "@/components/diagnostics/ExportButtons";
import TrendChart from "@/components/diagnostics/TrendChart";
import BaselineDelta from "@/components/diagnostics/BaselineDelta";
import { Link } from "react-router-dom";
import { Gauge, Plus, Play, Loader2, Cpu } from "lucide-react";

const LOCKED = ["approved", "published", "archived"];

export default function EnterpriseDiagnostics() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [companyId] = useCompanyFilter();
  const [cycleId, setCycleId] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [running, setRunning] = useState(false);
  const [live, setLive] = useState(null);
  const [drill, setDrill] = useState(null);

  const hasCompany = companyId && companyId !== "all";
  const { data: cycles = [] } = useQuery({
    queryKey: ["diagnostic-cycles", companyId],
    enabled: hasCompany,
    queryFn: async () =>
      (await base44.entities.DiagnosticCycle.filter({ company_id: companyId }, { sort: "-created_date", limit: 50 })).items,
  });

  const cycle = cycles.find((c) => c.id === cycleId);
  const result = live?.company_id === companyId ? live : cycle?.results ? { ...cycle.results, stored: true } : null;
  const locked = cycle && LOCKED.includes(cycle.status);

  const run = async () => {
    setRunning(true);
    const res = await base44.functions.invoke("runDiagnosticCoverage", { company_id: companyId });
    const data = res.data;
    setLive(data);
    if (cycle && !locked) {
      const stored = {
        ...data,
        rules: data.rules.map(({ uncovered_items, ...r }) => r),
      };
      await base44.entities.DiagnosticCycle.update(cycle.id, { results: stored, last_run_at: data.generated_at });
      queryClient.invalidateQueries({ queryKey: ["diagnostic-cycles", companyId] });
    }
    setRunning(false);
    toast({ title: "Coverage calculated", description: cycle && !locked ? "Snapshot saved to the cycle." : "Preview only, nothing was saved." });
  };

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <PageHeader icon={Gauge} title="Diagnostics & Opportunities" tagline="Read-only coverage diagnostics with full source drill-down" />
        <div className="flex items-center gap-2">
          <Button disabled={!hasCompany} onClick={() => setFormOpen(true)}><Plus className="w-4 h-4 mr-1" /> Create cycle</Button>
          <Button asChild variant="outline" size="sm"><Link to="/TechnologyIntelligence"><Cpu className="w-4 h-4 mr-1" /> Technology intelligence</Link></Button>
        </div>
      </div>

      {!hasCompany ? (
        <Card><CardContent className="p-6 text-slate-600">Select a single company in the company filter to run diagnostics. Cycles never combine data from several companies.</CardContent></Card>
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-3">
            <Select value={cycleId || "none"} onValueChange={(v) => { setCycleId(v === "none" ? null : v); setLive(null); }}>
              <SelectTrigger className="w-72"><SelectValue placeholder="Diagnostic cycle" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No cycle (preview only)</SelectItem>
                {cycles.map((c) => <SelectItem key={c.id} value={c.id}>{c.name} · {c.status.replace("_", " ")}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button onClick={run} disabled={running}>
              {running ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Play className="w-4 h-4 mr-1" />} Run coverage diagnostic
            </Button>
            <Badge variant="outline" className="border-amber-500 text-amber-700">PRELIMINARY</Badge>
            {locked && <Badge variant="secondary">Cycle is {cycle.status}: results are locked</Badge>}
            {result && (
              <div className="flex items-center gap-2 ml-auto">
                <ExportResultsButton result={result} cycleName={cycle?.name} />
                <ExportFindingsButton cycleId={cycle?.id} cycleName={cycle?.name} />
              </div>
            )}
          </div>

          {cycle && (
            <p className="text-sm text-slate-600">
              Cut-off {cycle.cutoff_date || "not set"} · Mode {cycle.assessment_mode} · Template v{cycle.template_version}
              {cycle.last_run_at ? ` · Last run ${new Date(cycle.last_run_at).toLocaleString("en-GB")}` : ""}
            </p>
          )}

          {!result ? (
            <Card><CardContent className="p-6 text-slate-600">Run the coverage diagnostic to see results. Nothing in your source records is changed.</CardContent></Card>
          ) : (
            <>
              {result.stored && <p className="text-xs text-slate-500">Showing the stored snapshot. Run again to enable gap drill-down.</p>}
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {result.rules.map((r) => (
                  <RuleCoverageCard key={r.rule_id} rule={r} generatedAt={result.generated_at}
                    onDrill={(rule) => rule.uncovered_items && setDrill(rule)} />
                ))}
              </div>
              <Card><CardContent className="p-4 space-y-4">
                <AreaScorecards rules={result.rules} />
                <ImportanceEffectivenessMatrix rules={result.rules} />
              </CardContent></Card>
              <ReconciliationPanel checks={result.reconciliation} />
              <FindingsPanel cycleId={cycle?.id} companyId={companyId} />
            </>
          )}
        </>
      )}

      {hasCompany && <TrendChart companyId={companyId} />}
      {cycle?.baseline_cycle_id && <BaselineDelta cycle={cycle} />}
      <CycleFormDialog open={formOpen} onOpenChange={setFormOpen} companyId={companyId}
        onCreated={(c) => { setFormOpen(false); setCycleId(c.id); queryClient.invalidateQueries({ queryKey: ["diagnostic-cycles", companyId] }); }} />
      <RuleDrilldownDialog rule={drill} filters={live?.filters} companyId={companyId} cycleId={cycle?.id} onClose={() => setDrill(null)} />
    </div>
  );
}