import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Target, Plus, Search, Trash2, Pencil } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { useFrameworks } from "@/hooks/useFrameworks";
import { toast } from "sonner";
import ObjectiveMappingMatrix from "@/components/objectives/ObjectiveMappingMatrix";

const STATUS_COLORS = {
  draft: "bg-slate-100 text-slate-600",
  active: "bg-green-100 text-green-700",
  archived: "bg-red-100 text-red-700",
};

const TYPE_COLORS = {
  Preventive: "bg-blue-100 text-blue-700",
  Detective: "bg-amber-100 text-amber-700",
  Corrective: "bg-orange-100 text-orange-700",
  Compensating: "bg-purple-100 text-purple-700",
};

const EMPTY_FORM = {
  reference_number: "",
  title: "",
  control_statement: "",
  rationale: "",
  description: "",
  framework_id: "",
  category: "",
  objective_type: "Preventive",
  status: "active",
  is_library: false,
  notes: "",
  mappings: [],
};

export default function ControlObjectives() {
  const queryClient = useQueryClient();
  const { frameworks } = useFrameworks();
  const [search, setSearch] = useState("");
  const [frameworkFilter, setFrameworkFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editObj, setEditObj] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  const { data: objectives = [], isLoading } = useQuery({
    queryKey: ["controlObjectives"],
    queryFn: () => base44.entities.ControlObjective.list("-created_date", 500),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ControlObjective.create(data),
    onSuccess: () => { queryClient.invalidateQueries(["controlObjectives"]); toast.success("Control objective created"); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ControlObjective.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries(["controlObjectives"]); toast.success("Control objective updated"); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ControlObjective.delete(id),
    onSuccess: () => { queryClient.invalidateQueries(["controlObjectives"]); toast.success("Control objective deleted"); },
  });

  const openCreate = () => { setEditObj(null); setDialogOpen(true); };
  const openEdit = (obj) => { setEditObj(obj); setDialogOpen(true); };
  const closeDialog = () => { setDialogOpen(false); setEditObj(null); };

  const filtered = objectives.filter(o => {
    const matchSearch = !search ||
      o.title?.toLowerCase().includes(search.toLowerCase()) ||
      o.reference_number?.toLowerCase().includes(search.toLowerCase());
    const matchFramework = frameworkFilter === "all" || o.framework_id === frameworkFilter;
    const matchStatus = statusFilter === "all" || o.status === statusFilter;
    return matchSearch && matchFramework && matchStatus;
  });

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-xl flex items-center justify-center shadow-lg">
            <Target className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Control Objectives</h1>
            <p className="text-slate-600">Maintain control objectives that controls link to within each framework</p>
          </div>
        </div>
        <Button onClick={openCreate} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
          <Plus className="w-4 h-4" /> New Control Objective
        </Button>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Search by title or reference…" value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Select value={frameworkFilter} onValueChange={setFrameworkFilter}>
          <SelectTrigger className="w-56"><SelectValue placeholder="All Frameworks" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Frameworks</SelectItem>
            {frameworks.map(f => (
              <SelectItem key={f.id} value={f.id}>{f.framework_code ? `${f.framework_code} — ${f.name}` : f.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="text-center py-16 text-slate-500">Loading…</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Target className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 mb-4">No control objectives found</p>
          <Button onClick={openCreate}>Create First Control Objective</Button>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(obj => {
            const fw = frameworks.find(f => f.id === obj.framework_id);
            return (
              <Card key={obj.id} className="border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0 cursor-pointer" onClick={() => openEdit(obj)}>
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        {obj.reference_number && <span className="font-mono text-xs text-primary">{obj.reference_number}</span>}
                        <h3 className="font-semibold text-slate-900">{obj.title}</h3>
                        <Badge className={STATUS_COLORS[obj.status] || "bg-slate-100 text-slate-600"}>{obj.status}</Badge>
                        {obj.objective_type && <Badge className={TYPE_COLORS[obj.objective_type] || ""}>{obj.objective_type}</Badge>}
                        {obj.mappings?.length > 0 && <Badge className="bg-emerald-100 text-emerald-700">{obj.mappings.length} link{obj.mappings.length > 1 ? "s" : ""}</Badge>}
                      </div>
                      {obj.description && <p className="text-sm text-slate-500 mb-2 line-clamp-2">{obj.description}</p>}
                      <div className="flex items-center gap-4 text-xs text-slate-500 flex-wrap">
                        {fw && <span>{fw.framework_code ? `${fw.framework_code} — ${fw.name}` : fw.name}</span>}
                        {obj.category && <span>{obj.category}</span>}
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(obj)}>
                        <Pencil className="w-4 h-4 text-slate-500" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-red-400 hover:text-red-600" onClick={() => setConfirmDeleteId(obj.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <ControlObjectiveDialog
        open={dialogOpen}
        onClose={closeDialog}
        editObj={editObj}
        frameworks={frameworks}
        onCreate={createMutation.mutate}
        onUpdate={updateMutation.mutate}
        isPending={createMutation.isPending || updateMutation.isPending}
      />

      <Dialog open={!!confirmDeleteId} onOpenChange={v => { if (!v) setConfirmDeleteId(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete Control Objective?</DialogTitle>
            <DialogDescription>This action cannot be undone. Controls linked to this objective will lose their reference.</DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setConfirmDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { deleteMutation.mutate(confirmDeleteId); setConfirmDeleteId(null); }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ControlObjectiveDialog({ open, onClose, editObj, frameworks, onCreate, onUpdate, isPending }) {
  const [form, setForm] = useState(EMPTY_FORM);

  React.useEffect(() => {
    if (open) {
      if (editObj) {
        setForm({
          reference_number: editObj.reference_number || "",
          title: editObj.title || "",
          control_statement: editObj.control_statement || "",
          rationale: editObj.rationale || "",
          description: editObj.description || "",
          framework_id: editObj.framework_id || "",
          category: editObj.category || "",
          objective_type: editObj.objective_type || "Preventive",
          status: editObj.status || "active",
          is_library: editObj.is_library ?? false,
          notes: editObj.notes || "",
          mappings: editObj.mappings || [],
        });
      } else {
        setForm(EMPTY_FORM);
      }
    }
  }, [open, editObj]);

  const handleSubmit = () => {
    if (!form.title.trim()) { toast.error("Title is required"); return; }
    if (editObj) {
      onUpdate({ id: editObj.id, data: form });
    } else {
      onCreate(form);
    }
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={v => { if (!v) onClose(); }}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editObj ? "Edit Control Objective" : "New Control Objective"}</DialogTitle>
          <DialogDescription>
            {editObj ? "Update the control objective details and mappings." : "Create a control objective that controls can link to."}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="details">
          <TabsList>
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="mappings">Mappings{form.mappings?.length > 0 ? ` (${form.mappings.length})` : ""}</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Reference Number</Label>
                <Input
                  value={form.reference_number}
                  onChange={e => setForm({ ...form, reference_number: e.target.value })}
                  placeholder="e.g. CO-001, A.5.1-Obj"
                />
              </div>
              <div className="space-y-2">
                <Label>Framework</Label>
                <Select value={form.framework_id || "none"} onValueChange={v => setForm({ ...form, framework_id: v === "none" ? "" : v })}>
                  <SelectTrigger><SelectValue placeholder="Select framework" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— None —</SelectItem>
                    {frameworks.map(f => (
                      <SelectItem key={f.id} value={f.id}>{f.framework_code ? `${f.framework_code} — ${f.name}` : f.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Title *</Label>
              <Input
                value={form.title}
                onChange={e => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. Ensure access to information is restricted to authorized users"
              />
            </div>

            <div className="space-y-2">
              <Label>Control Statement</Label>
              <Textarea
                value={form.control_statement}
                onChange={e => setForm({ ...form, control_statement: e.target.value })}
                placeholder="Formal control statement describing the control requirement…"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label>Rationale</Label>
              <Textarea
                value={form.rationale}
                onChange={e => setForm({ ...form, rationale: e.target.value })}
                placeholder="Why does this control objective exist? What is its purpose?"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
                placeholder="Detailed description of what this control objective aims to achieve…"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Category</Label>
                <Input
                  value={form.category}
                  onChange={e => setForm({ ...form, category: e.target.value })}
                  placeholder="e.g. Access Control"
                />
              </div>
              <div className="space-y-2">
                <Label>Objective Type</Label>
                <Select value={form.objective_type} onValueChange={v => setForm({ ...form, objective_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Preventive">Preventive</SelectItem>
                    <SelectItem value="Detective">Detective</SelectItem>
                    <SelectItem value="Corrective">Corrective</SelectItem>
                    <SelectItem value="Compensating">Compensating</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={form.notes}
                onChange={e => setForm({ ...form, notes: e.target.value })}
                placeholder="Additional notes…"
                rows={2}
              />
            </div>

            <div className="flex items-center gap-2">
              <Label className="flex items-center gap-2">
                <input type="checkbox" checked={form.is_library} onChange={e => setForm({ ...form, is_library: e.target.checked })} className="rounded border-slate-300" />
                Master Library Objective (not company-specific)
              </Label>
            </div>
          </TabsContent>

          <TabsContent value="mappings" className="mt-4">
            {editObj ? (
              <ObjectiveMappingMatrix
                mappings={form.mappings}
                onChange={(mappings) => setForm({ ...form, mappings })}
              />
            ) : (
              <div className="text-center py-12 text-slate-500">
                <Target className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <p>Save the control objective first, then return to add mappings.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={isPending} className="bg-emerald-600 hover:bg-emerald-700">
            {editObj ? "Save Changes" : "Create"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}