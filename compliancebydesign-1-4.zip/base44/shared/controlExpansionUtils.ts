// Shared utilities for the Control Expansion Package import (stage + apply functions).

// --- Text normalization & similarity ---

export function normalizeText(text) {
  if (!text) return "";
  return String(text)
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function tokenize(text) {
  return normalizeText(text).split(" ").filter((t) => t.length > 2);
}

export function jaccardSimilarity(a, b) {
  const ta = new Set(tokenize(a));
  const tb = new Set(tokenize(b));
  if (ta.size === 0 || tb.size === 0) return 0;
  let intersection = 0;
  for (const t of ta) if (tb.has(t)) intersection++;
  return intersection / (ta.size + tb.size - intersection);
}

export function bestMatch(query, candidates, threshold = 0.3) {
  let best = null;
  let bestScore = 0;
  for (const c of candidates) {
    const score = jaccardSimilarity(query, c.text);
    if (score > bestScore) {
      bestScore = score;
      best = { ...c, score };
    }
  }
  if (bestScore < threshold) return null;
  return best;
}

// --- Enum validation ---

export const CONTROL_ENUMS = {
  control_execution_type: ["Manual", "Automated", "Semi-Automated"],
  control_frequency: ["Daily", "Weekly", "Monthly", "Quarterly", "Annually", "Continuous", "Ad-hoc"],
  control_type: ["Preventive", "Detective", "Corrective"],
  process_phase: ["Pre-Input", "Process - Input", "Process - Output", "Post-Output"],
  control_criticality: ["Must Have", "Should Have", "Nice to Have"],
  priority: ["critical", "high", "medium", "low"],
  status: ["draft", "pending_review", "returned", "approved", "active", "archived"],
  library_status: ["active", "retired", "draft"],
};

// Maps non-standard CSV values to the closest valid enum value.
export const ENUM_MAPPINGS = {
  control_execution_type: {
    hybrid: "Semi-Automated",
    "semi-automated": "Semi-Automated",
    "semi automated": "Semi-Automated",
    it: "Automated",
    "it-dependent": "Automated",
    automatic: "Automated",
  },
  control_frequency: {
    "per transaction": "Continuous",
    "per supplier change": "Ad-hoc",
    "per event": "Ad-hoc",
    "real-time": "Continuous",
    realtime: "Continuous",
    "as needed": "Ad-hoc",
    "on-demand": "Ad-hoc",
    annually: "Annually",
    "fiscal year": "Annually",
  },
  process_phase: {
    "process - execution": "Process - Output",
    "process execution": "Process - Output",
    execution: "Process - Output",
    "in-process": "Process - Output",
    "process - monitoring": "Process - Output",
    monitoring: "Process - Output",
  },
};

export function validateEnum(field, value) {
  const validValues = CONTROL_ENUMS[field];
  if (!validValues) return { valid: true, value, mapped: false };
  if (!value) return { valid: true, value: validValues[0], mapped: false, wasEmpty: true };
  const lower = String(value).toLowerCase().trim();
  // Exact match (case-insensitive)
  const exact = validValues.find((v) => v.toLowerCase() === lower);
  if (exact) return { valid: true, value: exact, mapped: false };
  // Try mapping table
  const mapping = ENUM_MAPPINGS[field]?.[lower];
  if (mapping) return { valid: true, value: mapping, mapped: true, originalValue: value };
  // No match — invalid
  return { valid: false, value, mapped: false, suggestedValue: validValues[0] };
}

// --- CSV parsing ---

export function parseCSV(text) {
  // Single-pass CSV parser: handles quoted fields, escaped quotes, and newlines inside quotes.
  const rows = [];
  let row = [];
  let field = "";
  let inQuotes = false;
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i++;
        continue;
      }
      field += ch;
      i++;
      continue;
    }
    // Not in quotes
    if (ch === '"') {
      inQuotes = true;
      i++;
      continue;
    }
    if (ch === ",") {
      row.push(field);
      field = "";
      i++;
      continue;
    }
    if (ch === "\n" || ch === "\r") {
      row.push(field);
      field = "";
      if (row.length > 1 || row[0]) rows.push(row);
      row = [];
      // skip \r\n
      if (ch === "\r" && text[i + 1] === "\n") i += 2;
      else i++;
      continue;
    }
    field += ch;
    i++;
  }
  // last field
  if (field || row.length > 0) {
    row.push(field);
    if (row.length > 1 || row[0]) rows.push(row);
  }
  if (rows.length < 2) return [];
  const headers = rows[0].map((h) => h.trim());
  const result = [];
  for (let r = 1; r < rows.length; r++) {
    const values = rows[r];
    const obj = {};
    headers.forEach((h, idx) => {
      obj[h] = (values[idx] || "").trim();
    });
    result.push(obj);
  }
  return result;
}

// --- Owner role resolution ---

export function resolveOwnerRole(roleText, stakeholders, stakeholderGroups) {
  if (!roleText) return { matched: false, matches: [], type: "none" };
  const normalized = normalizeText(roleText);
  const matches = [];

  // 1. Exact job title match
  for (const s of stakeholders) {
    if (!s.job_title) continue;
    if (normalizeText(s.job_title) === normalized) {
      matches.push({ stakeholder_id: s.id, name: s.full_name, job_title: s.job_title, match_type: "exact_title", score: 1.0 });
    }
  }
  if (matches.length === 1) return { matched: true, matches, type: "stakeholder" };

  // 2. Job title contains / contained-by
  const partialTitleMatches = [];
  for (const s of stakeholders) {
    if (!s.job_title) continue;
    const titleNorm = normalizeText(s.job_title);
    if (titleNorm.includes(normalized) || normalized.includes(titleNorm)) {
      partialTitleMatches.push({ stakeholder_id: s.id, name: s.full_name, job_title: s.job_title, match_type: "partial_title", score: 0.7 });
    }
  }
  if (partialTitleMatches.length > 0 && matches.length === 0) {
    matches.push(...partialTitleMatches);
  }

  // 3. Stakeholder group name match
  const groupMatches = [];
  for (const g of stakeholderGroups) {
    const gNorm = normalizeText(g.name);
    if (gNorm === normalized || gNorm.includes(normalized) || normalized.includes(gNorm)) {
      groupMatches.push({ group_id: g.id, name: g.name, match_type: "group", score: 0.6 });
    }
  }
  if (groupMatches.length > 0 && matches.length === 0) {
    return { matched: true, matches: groupMatches, type: "group" };
  }

  // 4. Fuzzy title match
  if (matches.length === 0) {
    let bestScore = 0;
    let bestMatch = null;
    for (const s of stakeholders) {
      if (!s.job_title) continue;
      const score = jaccardSimilarity(roleText, s.job_title);
      if (score > bestScore) {
        bestScore = score;
        bestMatch = { stakeholder_id: s.id, name: s.full_name, job_title: s.job_title, match_type: "fuzzy_title", score };
      }
    }
    if (bestMatch && bestScore >= 0.4) {
      matches.push(bestMatch);
    }
  }

  if (matches.length === 0) return { matched: false, matches: [], type: "none" };
  if (matches.length > 1) return { matched: true, matches, type: "ambiguous" };
  return { matched: true, matches, type: matches[0].match_type.includes("group") ? "group" : "stakeholder" };
}