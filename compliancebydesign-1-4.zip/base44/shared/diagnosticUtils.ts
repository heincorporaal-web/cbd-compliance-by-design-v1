// Shared helpers for diagnostic / intelligence backend functions.
// Plain module — no Deno.serve. Import from "../../shared/diagnosticUtils.ts".

export async function fetchAll(entity, query, fields) {
  const out = [];
  let cursor;
  for (let i = 0; i < 100; i++) {
    const opts = { limit: 1000 };
    if (cursor) opts.cursor = cursor;
    if (fields) opts.fields = fields;
    const page = await entity.filter(query, opts);
    out.push(...page.items);
    if (!page.has_more || !page.next_cursor) break;
    cursor = page.next_cursor;
  }
  return out;
}

export const hasItems = (a) => Array.isArray(a) && a.length > 0;
export const hasText = (s) => typeof s === "string" && s.trim().length > 0;