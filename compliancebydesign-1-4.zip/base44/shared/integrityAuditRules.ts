// Integrity audit rules: process hierarchy checks, fingerprint computation,
// and exception suppression logic. Shared between runIntegrityAudit and
// manageAuditException backend functions.

// ── Fingerprint computation ─────────────────────────────────────────────────
// Creates a stable hash of the relationship attributes relevant to a finding.
// If the fingerprint changes between audit runs, the exception is invalidated.

export function computeFingerprint(attributes: Record<string, any>): string {
  const keys = Object.keys(attributes).sort();
  const parts = keys.map(k => {
    const v = attributes[k];
    if (v == null) return `${k}=`;
    if (Array.isArray(v)) return `${k}=[${v.slice().sort().join(',')}]`;
    if (typeof v === 'object') return `${k}=${JSON.stringify(v, Object.keys(v).sort())}`;
    return `${k}=${String(v)}`;
  });
  const str = parts.join('|');
  // Simple hash (djb2) — stable across runs, no crypto needed
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash + str.charCodeAt(i)) & 0x7fffffff;
  }
  return String(hash);
}

// ── Finding key generation ───────────────────────────────────────────────────
// Stable deduplication key for matching findings across audit runs.

export function makeFindingKey(ruleId: string, entityType: string, entityId: string, relatedEntityId: string = ''): string {
  return `${ruleId}|${entityType}|${entityId}|${relatedEntityId}`;
}

// ── Non-negotiable integrity rules ───────────────────────────────────────────
// These finding types CANNOT be excepted — they represent fundamental database
// integrity constraints that must be fixed, not accepted.

const NON_EXCEPTIONABLE_RULES = new Set([
  'process_parent_id_must_resolve',    // invalid parent reference
  'process_code_must_be_unique',        // duplicate primary key
  'process_owner_stakeholder_id_must_resolve', // invalid stakeholder reference
  'process_workstream_id_must_resolve',  // invalid workstream reference
  'process_linked_risk_id_must_resolve', // invalid risk reference
  'risk_control_id_must_resolve',        // invalid control reference
  'workstream_value_chain_id_must_resolve',
  'process_level_must_be_valid',        // level outside 0-6 range
]);

export function isExceptionable(ruleId: string, validationCategory: string, findingType: string): boolean {
  if (validationCategory === 'technical' && (findingType === 'invalid' || findingType === 'duplicate')) {
    return !NON_EXCEPTIONABLE_RULES.has(ruleId);
  }
  return true;
}

// ── Process hierarchy audit rules ────────────────────────────────────────────
// Each rule has: id, version, audit_type, severity, validation_category,
// applicability, and a check function that returns findings.

export const HIERARCHY_RULE_VERSION = '1.0';

type Process = {
  id: string;
  process_code?: string;
  name?: string;
  level?: number;
  parent_id?: string;
  value_chain_id?: string;
  value_chain?: string;
  workstream_id?: string;
  workstream?: string;
  status?: string;
};

type Finding = {
  rule_id: string;
  rule_version: string;
  audit_type: string;
  finding_type: string;
  severity: string;
  validation_category: string;
  applicability: string;
  is_exceptionable: boolean;
  entity_type: string;
  entity_id: string;
  entity_name: string;
  entity_code: string;
  related_entity_type: string;
  related_entity_id: string;
  related_entity_name: string;
  existing_relationship: string;
  proposed_relationship: string;
  justification: string;
  confidence_score: number;
  validation_detail: any;
  relationship_fingerprint: string;
};

function makeHierarchyFinding(
  ruleId: string, findingType: string, severity: string,
  process: Process, existing: string, proposed: string, justification: string,
  fingerprintAttrs: Record<string, any>,
  options: { relatedEntity?: any, relatedEntityType?: string, confidence?: number, validationCategory?: string, applicability?: string, validationDetail?: any } = {}
): Finding {
  const validationCategory = options.validationCategory || 'technical';
  const applicability = options.applicability || 'mandatory';
  const exceptionable = isExceptionable(ruleId, validationCategory, findingType);
  return {
    rule_id: ruleId,
    rule_version: HIERARCHY_RULE_VERSION,
    audit_type: 'process_hierarchy',
    finding_type: findingType,
    severity,
    validation_category: validationCategory,
    applicability,
    is_exceptionable: exceptionable,
    entity_type: 'OrgProcess',
    entity_id: process.id,
    entity_name: process.name || '',
    entity_code: process.process_code || '',
    related_entity_type: options.relatedEntityType || '',
    related_entity_id: options.relatedEntity?.id || '',
    related_entity_name: options.relatedEntity?.name || options.relatedEntity?.process_code || '',
    existing_relationship: existing,
    proposed_relationship: proposed,
    justification,
    confidence_score: options.confidence ?? 95,
    validation_detail: options.validationDetail || {
      rule: ruleId,
      source_value: process.id,
      target_value: options.relatedEntity?.id || null,
      resolution: proposed,
    },
    relationship_fingerprint: computeFingerprint(fingerprintAttrs),
  };
}

// HIER-001: Process level inconsistent with parent (child level must be parent level + 1)
export function auditHierarchyLevelConsistency(processes: Process[]): Finding[] {
  const findings: Finding[] = [];
  const processMap = new Map(processes.map(p => [p.id, p]));

  for (const p of processes) {
    if (!p.parent_id) continue;
    const parent = processMap.get(p.parent_id);
    if (!parent) continue; // handled by HIER-005
    if (p.level == null || parent.level == null) continue;
    if (p.level !== parent.level + 1) {
      findings.push(makeHierarchyFinding(
        'HIER-001', 'invalid', 'high', p,
        `Level L${p.level} but parent "${parent.name}" is L${parent.level} (expected L${parent.level + 1})`,
        `Set level to L${parent.level + 1}`,
        `Process "${p.name}" (${p.process_code}) has level L${p.level} but its parent is L${parent.level}. A child process must be exactly one level below its parent.`,
        { level: p.level, parent_id: p.parent_id, parent_level: parent.level, process_code: p.process_code },
        { relatedEntity: parent, relatedEntityType: 'OrgProcess', confidence: 98 }
      ));
    }
  }
  return findings;
}

// HIER-002: Process code doesn't follow parent code hierarchy
// (child code should start with parent code as prefix, e.g. P1.1.2 → parent P1.1)
export function auditHierarchyCodeConsistency(processes: Process[]): Finding[] {
  const findings: Finding[] = [];
  const processMap = new Map(processes.map(p => [p.id, p]));

  for (const p of processes) {
    if (!p.parent_id || !p.process_code) continue;
    const parent = processMap.get(p.parent_id);
    if (!parent || !parent.process_code) continue;
    // Check if child code starts with parent code
    const parentCode = parent.process_code;
    const childCode = p.process_code;
    // Allow both dot-separated (P1.1 → P1.1.2) and dash-separated (VC-WS-001) patterns
    if (!childCode.startsWith(parentCode)) {
      findings.push(makeHierarchyFinding(
        'HIER-002', 'semantic_mismatch', 'medium', p,
        `Code "${childCode}" does not extend parent code "${parentCode}"`,
        `Rename to start with "${parentCode}" (e.g. ${parentCode}.X) or correct the parent assignment`,
        `Process "${p.name}" has code "${childCode}" but its parent has code "${parentCode}". Child process codes should extend the parent code to maintain hierarchical numbering.`,
        { process_code: childCode, parent_id: p.parent_id, parent_code: parentCode },
        { relatedEntity: parent, relatedEntityType: 'OrgProcess', confidence: 80, validationCategory: 'semantic' }
      ));
    }
  }
  return findings;
}

// HIER-003: L1 process has a parent (should be root)
export function auditHierarchyRootParent(processes: Process[]): Finding[] {
  const findings: Finding[] = [];
  for (const p of processes) {
    if (p.level === 1 && p.parent_id) {
      findings.push(makeHierarchyFinding(
        'HIER-003', 'invalid', 'high', p,
        `L1 process has parent "${p.parent_id}" but L1 should be a root`,
        `Remove parent_id (set to null) or correct the level`,
        `Process "${p.name}" (${p.process_code}) is level L1 but has a parent. L1 processes are roots and should not have a parent.`,
        { level: p.level, parent_id: p.parent_id, process_code: p.process_code },
        { confidence: 95 }
      ));
    }
  }
  return findings;
}

// HIER-004: L2+ process has no parent (orphaned)
export function auditHierarchyOrphanedProcess(processes: Process[]): Finding[] {
  const findings: Finding[] = [];
  for (const p of processes) {
    if (p.level && p.level >= 2 && !p.parent_id && p.status !== 'archived') {
      findings.push(makeHierarchyFinding(
        'HIER-004', 'missing', 'high', p,
        `L${p.level} process has no parent`,
        `Assign a parent process at level L${p.level - 1}`,
        `Process "${p.name}" (${p.process_code}) is level L${p.level} but has no parent. Processes at L2+ must have a parent at the level above.`,
        { level: p.level, parent_id: '', process_code: p.process_code },
        { confidence: 90 }
      ));
    }
  }
  return findings;
}

// HIER-005: Parent doesn't exist (invalid parent_id)
export function auditHierarchyInvalidParent(processes: Process[]): Finding[] {
  const findings: Finding[] = [];
  const processIds = new Set(processes.map(p => p.id));
  for (const p of processes) {
    if (p.parent_id && !processIds.has(p.parent_id)) {
      findings.push(makeHierarchyFinding(
        'HIER-005', 'invalid', 'high', p,
        `References parent ID "${p.parent_id}" which does not exist`,
        `Set parent_id to an existing process, or remove if this is a root`,
        `Process "${p.name}" (${p.process_code}) references a parent that has been deleted or does not exist.`,
        { level: p.level, parent_id: p.parent_id, process_code: p.process_code },
        { confidence: 98 }
      ));
    }
  }
  return findings;
}

// HIER-006: Duplicate process codes
export function auditHierarchyDuplicateCodes(processes: Process[]): Finding[] {
  const findings: Finding[] = [];
  const codeMap: Record<string, Process[]> = {};
  for (const p of processes) {
    if (!p.process_code) continue;
    const key = p.process_code;
    if (!codeMap[key]) codeMap[key] = [];
    codeMap[key].push(p);
  }
  for (const [code, dups] of Object.entries(codeMap)) {
    if (dups.length > 1) {
      for (const p of dups) {
        findings.push(makeHierarchyFinding(
          'HIER-006', 'duplicate', 'high', p,
          `Duplicate process code "${code}" (${dups.length} occurrences)`,
          `Rename to ensure unique code, or merge duplicate processes`,
          `Process "${p.name}" shares code "${code}" with ${dups.length - 1} other process(es). Process codes must be unique.`,
          { process_code: code, level: p.level, parent_id: p.parent_id },
          { confidence: 98 }
        ));
      }
    }
  }
  return findings;
}

// HIER-007: Value chain mismatch between parent and child
export function auditHierarchyValueChainInheritance(processes: Process[]): Finding[] {
  const findings: Finding[] = [];
  const processMap = new Map(processes.map(p => [p.id, p]));
  for (const p of processes) {
    if (!p.parent_id) continue;
    const parent = processMap.get(p.parent_id);
    if (!parent) continue;
    if (p.value_chain_id && parent.value_chain_id && p.value_chain_id !== parent.value_chain_id) {
      findings.push(makeHierarchyFinding(
        'HIER-007', 'semantic_mismatch', 'medium', p,
        `Value chain differs from parent (process: ${p.value_chain_id}, parent: ${parent.value_chain_id})`,
        `Align value_chain_id with parent's value chain (${parent.value_chain_id}) or reassign parent`,
        `Process "${p.name}" (${p.process_code}) has a different value chain from its parent "${parent.name}". Child processes should inherit the parent's value chain unless a documented exception applies.`,
        { value_chain_id: p.value_chain_id, parent_id: p.parent_id, parent_value_chain_id: parent.value_chain_id, process_code: p.process_code },
        { relatedEntity: parent, relatedEntityType: 'OrgProcess', confidence: 75, validationCategory: 'semantic' }
      ));
    }
  }
  return findings;
}

// HIER-008: Process level out of valid range (0-6)
export function auditHierarchyLevelRange(processes: Process[]): Finding[] {
  const findings: Finding[] = [];
  for (const p of processes) {
    if (p.level != null && (p.level < 0 || p.level > 6)) {
      findings.push(makeHierarchyFinding(
        'HIER-008', 'invalid', 'high', p,
        `Level L${p.level} is outside valid range (0-6)`,
        `Set level to a value between 0 and 6`,
        `Process "${p.name}" (${p.process_code}) has level L${p.level} which is outside the valid range of 0-6.`,
        { level: p.level, process_code: p.process_code },
        { confidence: 98 }
      ));
    }
  }
  return findings;
}

// ── Run all hierarchy checks ─────────────────────────────────────────────────

export function runHierarchyChecks(processes: Process[]): Finding[] {
  return [
    ...auditHierarchyLevelConsistency(processes),
    ...auditHierarchyCodeConsistency(processes),
    ...auditHierarchyRootParent(processes),
    ...auditHierarchyOrphanedProcess(processes),
    ...auditHierarchyInvalidParent(processes),
    ...auditHierarchyDuplicateCodes(processes),
    ...auditHierarchyValueChainInheritance(processes),
    ...auditHierarchyLevelRange(processes),
  ];
}

// ── Convert cross-entity audit findings to integrity findings ───────────────
// Maps the finding format from runCrossEntityAudit to the IntegrityFinding format.

export function convertCrossEntityFinding(f: any, companyId: string): Finding {
  const ruleId = f.validation_detail?.rule || f.audit_type + '_' + f.finding_type;
  const entityType = f.source_record?.type || 'OrgProcess';
  const entityId = f.source_record?.id || '';
  const relatedEntityType = f.target_record?.type || '';
  const relatedEntityId = f.target_record?.id || '';

  // Build fingerprint from validation detail source/target values
  const fpAttrs: Record<string, any> = {};
  if (f.validation_detail?.source_fields) {
    for (const [k, v] of Object.entries(f.validation_detail.source_fields)) {
      // Only include relationship-relevant fields, not display-only fields
      if (k.includes('id') || k.includes('code') || k === 'level' || k === 'status') {
        fpAttrs[k] = v;
      }
    }
  }
  if (f.validation_detail?.target_fields) {
    for (const [k, v] of Object.entries(f.validation_detail.target_fields)) {
      if (k.includes('id') || k.includes('code') || k === 'level' || k === 'status') {
        fpAttrs[`target_${k}`] = v;
      }
    }
  }

  return {
    rule_id: ruleId,
    rule_version: '1.0',
    audit_type: f.audit_type,
    finding_type: f.finding_type,
    severity: f.severity,
    validation_category: f.validation_category || 'technical',
    applicability: f.applicability || 'mandatory',
    is_exceptionable: isExceptionable(ruleId, f.validation_category || 'technical', f.finding_type),
    entity_type: entityType,
    entity_id: entityId,
    entity_name: f.source_record?.name || '',
    entity_code: f.source_record?.code || '',
    related_entity_type: relatedEntityType,
    related_entity_id: relatedEntityId,
    related_entity_name: f.target_record?.name || '',
    existing_relationship: f.existing_relationship || '',
    proposed_relationship: f.proposed_relationship || '',
    justification: f.justification || '',
    confidence_score: f.confidence_score || 0,
    validation_detail: f.validation_detail || null,
    relationship_fingerprint: computeFingerprint(fpAttrs),
  };
}

// ── Exception suppression logic ─────────────────────────────────────────────
// Given current findings and existing exceptions, determine which findings
// should be suppressed (exception active) or flagged (exception invalidated).

export function suppressWithExceptions(
  findings: Finding[],
  exceptions: any[]
): {
  actionable: Finding[];
  suppressed: Finding[];
  invalidated_exceptions: any[];
} {
  const activeExceptions = exceptions.filter(e => e.status === 'active');
  const exceptionMap = new Map<string, any>();
  for (const ex of activeExceptions) {
    const key = `${ex.rule_id}|${ex.entity_type}|${ex.entity_id}`;
    if (!exceptionMap.has(key)) exceptionMap.set(key, ex);
  }

  const actionable: Finding[] = [];
  const suppressed: Finding[] = [];
  const invalidated_exceptions: any[] = [];

  for (const f of findings) {
    const key = `${f.rule_id}|${f.entity_type}|${f.entity_id}`;
    const ex = exceptionMap.get(key);
    if (ex && f.is_exceptionable) {
      // Compare fingerprint
      if (ex.relationship_fingerprint === f.relationship_fingerprint) {
        // Fingerprint unchanged — suppress this finding
        suppressed.push({ ...f, exception_id: ex.id });
      } else {
        // Fingerprint changed — invalidate the exception, finding is actionable
        invalidated_exceptions.push({
          exception: ex,
          new_fingerprint: f.relationship_fingerprint,
          old_fingerprint: ex.relationship_fingerprint,
        });
        actionable.push({ ...f, status: 'exception_invalidated' as any, exception_id: ex.id });
      }
    } else {
      actionable.push(f);
    }
  }

  // Also check for exceptions whose entities no longer have findings (resolved)
  const findingKeys = new Set(findings.map(f => `${f.rule_id}|${f.entity_type}|${f.entity_id}`));
  for (const ex of activeExceptions) {
    const key = `${ex.rule_id}|${ex.entity_type}|${ex.entity_id}`;
    if (!findingKeys.has(key)) {
      // The anomaly is gone — the exception can remain but the finding is resolved
      // Don't invalidate the exception — it's just no longer needed
    }
  }

  return { actionable, suppressed, invalidated_exceptions };
}

// ── Dashboard classification ─────────────────────────────────────────────────
// Classify findings into dashboard categories, avoiding double-counting.

export function classifyFindings(
  currentFindings: Finding[],
  previousFindings: any[],
  exceptions: any[]
): {
  new_findings: Finding[];
  existing_unresolved: Finding[];
  resolved: any[];
  accepted_exceptions: any[];
  invalidated_exceptions: any[];
  recurring: Finding[];
  recommended_corrections: Finding[];
  confirmed_structural_failures: Finding[];
  distinct_affected_records: number;
  raw_finding_count: number;
} {
  const previousKeys = new Set(previousFindings.map((f: any) => f.finding_key));
  const previousResolvedKeys = new Set(
    previousFindings.filter((f: any) => f.status === 'resolved').map((f: any) => f.finding_key)
  );

  const activeExceptionKeys = new Set(
    exceptions.filter((e: any) => e.status === 'active').map((e: any) => `${e.rule_id}|${e.entity_type}|${e.entity_id}`)
  );

  const new_findings: Finding[] = [];
  const existing_unresolved: Finding[] = [];
  const recurring: Finding[] = [];
  const recommended_corrections: Finding[] = [];
  const confirmed_structural_failures: Finding[] = [];

  for (const f of currentFindings) {
    const key = makeFindingKey(f.rule_id, f.entity_type, f.entity_id, f.related_entity_id);

    // Skip suppressed (exception active) findings
    if (activeExceptionKeys.has(`${f.rule_id}|${f.entity_type}|${f.entity_id}`)) continue;

    if (!previousKeys.has(key)) {
      new_findings.push(f);
    } else if (previousResolvedKeys.has(key)) {
      recurring.push(f);
    } else {
      existing_unresolved.push(f);
    }

    if (f.finding_type === 'recommended' || f.finding_type === 'proposed_association') {
      recommended_corrections.push(f);
    }
    if (f.validation_category === 'technical' && (f.finding_type === 'invalid' || f.finding_type === 'duplicate')) {
      confirmed_structural_failures.push(f);
    }
  }

  const currentKeys = new Set(currentFindings.map(f => makeFindingKey(f.rule_id, f.entity_type, f.entity_id, f.related_entity_id)));
  const resolved = previousFindings.filter((f: any) =>
    f.status !== 'resolved' && !currentKeys.has(f.finding_key)
  );

  const accepted_exceptions = exceptions.filter((e: any) => e.status === 'active');
  const invalidated_exceptions = exceptions.filter((e: any) => e.status === 'invalidated');

  // Distinct affected records (avoid double-counting)
  const affectedRecordKeys = new Set<string>();
  for (const f of currentFindings) {
    affectedRecordKeys.add(`${f.entity_type}|${f.entity_id}`);
  }

  return {
    new_findings,
    existing_unresolved,
    resolved,
    accepted_exceptions,
    invalidated_exceptions,
    recurring,
    recommended_corrections,
    confirmed_structural_failures,
    distinct_affected_records: affectedRecordKeys.size,
    raw_finding_count: currentFindings.length,
  };
}