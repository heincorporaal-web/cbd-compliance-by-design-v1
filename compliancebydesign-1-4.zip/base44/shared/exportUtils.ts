// Shared export utilities for backend functions

export async function fetchAll(base44, entityName, query, fields) {
  const all = [];
  let cursor = undefined;
  for (;;) {
    const opts = { limit: 500 };
    if (fields) opts.fields = fields;
    if (cursor) opts.cursor = cursor;
    const page = await base44.entities[entityName].filter(query, opts);
    all.push(...page.items);
    if (!page.has_more) break;
    cursor = page.next_cursor;
  }
  return all;
}

export function buildLookup(records, idField = 'id', valueField = 'name') {
  const map = {};
  for (const r of records) {
    map[r[idField]] = r[valueField];
  }
  return map;
}