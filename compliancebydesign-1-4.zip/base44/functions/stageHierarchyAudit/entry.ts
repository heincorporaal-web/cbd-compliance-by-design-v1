import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { parseCSV } from "../../shared/controlExpansionUtils.ts";

function parseLevel(levelStr: string): number | null {
  if (!levelStr) return null;
  const m = levelStr.match(/^L(\d)/i);
  if (m) return parseInt(m[1]);
  const n = parseInt(levelStr);
  return isNaN(n) ? null : n;
}

function parseBool(v: string): boolean {
  return String(v).toLowerCase() === 'true';
}

export default async function(req: any) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { file_url, company_id } = await req.json();
    if (!file_url || !company_id) {
      return Response.json({ error: 'file_url and company_id required' }, { status: 400 });
    }

    // 1. Fetch and parse CSV
    const fileRes = await fetch(file_url, { signal: AbortSignal.timeout(15000) });
    if (!fileRes.ok) return Response.json({ error: 'Failed to fetch CSV file' }, { status: 400 });
    const csvText = await fileRes.text();
    const rows = parseCSV(csvText);
    console.log(`Parsed ${rows.length} CSV rows`);

    if (rows.length === 0) {
      return Response.json({ error: 'No rows found in CSV' }, { status: 400 });
    }

    // 2. Load all OrgProcess records (paginated, full population)
    let allProcesses: any[] = [];
    let cursor: string | undefined = undefined;
    let page: any = null;
    do {
      page = await base44.asServiceRole.entities.OrgProcess.filter(
        { company_id },
        { limit: 500, fields: ['id', 'process_code', 'name', 'level', 'parent_id', 'value_chain', 'value_chain_id', 'workstream', 'workstream_id', 'status', 'linked_risk_ids', 'linked_control_ids'], cursor }
      );
      allProcesses = allProcesses.concat(page.items || []);
      cursor = page.next_cursor;
    } while (cursor && page.has_more);
    console.log(`Loaded ${allProcesses.length} OrgProcess records`);

    const processMap = new Map(allProcesses.map((p: any) => [p.id, p]));

    // 3. Load value chains and workstreams
    const [valueChainsRes, workstreamsRes] = await Promise.all([
      base44.asServiceRole.entities.ValueChain.filter(
        { company_id },
        { limit: 200, fields: ['id', 'value_chain_code', 'name', 'management_chain'] }
      ),
      base44.asServiceRole.entities.Workstream.filter(
        { company_id },
        { limit: 500, fields: ['id', 'workstream_code', 'name', 'value_chain_id'] }
      ),
    ]);

    const vcList = valueChainsRes.items || [];
    const wsList = workstreamsRes.items || [];
    const vcByCode = new Map(vcList.map((vc: any) => [vc.value_chain_code, vc]));
    const vcById = new Map(vcList.map((vc: any) => [vc.id, vc]));
    const wsByCode = new Map(wsList.map((ws: any) => [ws.workstream_code, ws]));

    // 4. Process each CSV row
    const items: any[] = [];
    for (const row of rows) {
      const processId = (row.immutable_process_id || '').trim();
      const currentProcess = processMap.get(processId);

      const currentCode = (row.current_code || '').trim();
      const currentLevel = parseInt(row.current_level) || (currentProcess?.level ?? 0);
      const currentParentId = (row.current_parent_id || '').trim();

      const proposedCode = (row.proposed_code || '').trim();
      const proposedLevel = parseLevel(row.proposed_level);
      const proposedParentId = (row.proposed_parent_id || '').trim();
      const proposedStatus = (row.proposed_status || '').trim();

      const targetAction = (row.target_action || '').trim();
      const issueFlags = (row.issue_flags || '').split(';').map((f: string) => f.trim()).filter(Boolean);

      const targetVcCode = (row.target_value_chain_code || '').trim();
      const targetVcIdFromCsv = (row.target_value_chain_id || '').trim();
      const suggestedWsCode = (row.suggested_workstream_code || '').trim();

      // Resolve value chain
      let resolvedVcId = targetVcIdFromCsv;
      let resolvedVcName = '';
      let resolvedVcChain = '';
      if (!resolvedVcId && targetVcCode) {
        const vc = vcByCode.get(targetVcCode);
        if (vc) { resolvedVcId = vc.id; resolvedVcName = vc.name; resolvedVcChain = vc.management_chain || ''; }
      } else if (resolvedVcId) {
        const vc = vcById.get(resolvedVcId);
        if (vc) { resolvedVcName = vc.name; resolvedVcChain = vc.management_chain || ''; }
      }

      // Resolve workstream
      let resolvedWsId = '';
      let resolvedWsName = '';
      if (suggestedWsCode) {
        const ws = wsByCode.get(suggestedWsCode);
        if (ws) { resolvedWsId = ws.id; resolvedWsName = ws.name; }
      }

      // Determine changes
      const dbCode = currentProcess?.process_code || currentCode;
      const dbLevel = currentProcess?.level ?? currentLevel;
      const dbParentId = currentProcess?.parent_id || '';
      const dbVcId = currentProcess?.value_chain_id || '';
      const dbWsId = currentProcess?.workstream_id || '';
      const dbStatus = currentProcess?.status || row.existing_status || '';

      const changes = {
        code: proposedCode && proposedCode !== dbCode,
        level: proposedLevel !== null && proposedLevel !== dbLevel,
        parent: proposedParentId && proposedParentId !== dbParentId,
        value_chain: resolvedVcId && resolvedVcId !== dbVcId,
        workstream: resolvedWsId && resolvedWsId !== dbWsId,
        status: proposedStatus && proposedStatus !== dbStatus,
      };
      const hasChanges = Object.values(changes).some(Boolean);

      // Downstream impacts
      const linkedRiskCount = currentProcess?.linked_risk_ids?.length || parseInt(row.linked_risk_count_reported) || 0;
      const linkedControlCount = currentProcess?.linked_control_ids?.length || parseInt(row.linked_control_count_reported) || 0;

      items.push({
        row_index: items.length,
        process_id: processId,
        process_name: (row.name || '').trim(),
        current_code: currentCode,
        current_level: currentLevel,
        current_parent_id: currentParentId,
        current_parent_code: (row.current_parent_code || '').trim(),
        current_parent_level: row.current_parent_level ? parseInt(row.current_parent_level) : null,
        existing_status: (row.existing_status || '').trim(),
        target_value_chain_code: targetVcCode,
        target_value_chain_id: resolvedVcId,
        target_value_chain_name: resolvedVcName,
        target_management_chain: resolvedVcChain,
        suggested_workstream_code: suggestedWsCode,
        resolved_workstream_id: resolvedWsId,
        resolved_workstream_name: resolvedWsName,
        proposed_code: proposedCode,
        proposed_level: proposedLevel,
        proposed_parent_id: proposedParentId,
        proposed_parent_code: (row.proposed_parent_code || '').trim(),
        proposed_status: proposedStatus,
        target_action: targetAction,
        issue_flags: issueFlags,
        legacy_code_duplicate_count: parseInt(row.legacy_code_duplicate_count) || 0,
        source_parent_level_consistent: parseBool(row.source_parent_level_consistent),
        target_parent_value_chain_consistent: parseBool(row.target_parent_value_chain_consistent),
        parent_in_export: parseBool(row.parent_in_export),
        linked_risk_count: linkedRiskCount,
        linked_control_count: linkedControlCount,
        migration_status: (row.migration_status || '').trim(),
        changes,
        has_changes: hasChanges,
        process_found: !!currentProcess,
        db_current: currentProcess ? {
          process_code: currentProcess.process_code,
          level: currentProcess.level,
          parent_id: currentProcess.parent_id || '',
          value_chain_id: currentProcess.value_chain_id || '',
          workstream_id: currentProcess.workstream_id || '',
          status: currentProcess.status || '',
        } : null,
      });
    }

    // 5. Group findings by primary issue flag (root cause)
    const groups: Record<string, any[]> = {};
    for (const item of items) {
      const key = item.issue_flags[0] || 'NO_ISSUE';
      if (!groups[key]) groups[key] = [];
      groups[key].push(item);
    }

    // 6. Build summary
    const summary: any = {
      total: items.length,
      process_found: items.filter(i => i.process_found).length,
      process_not_found: items.filter(i => !i.process_found).length,
      by_issue: {} as Record<string, number>,
      by_action: {} as Record<string, number>,
      by_value_chain: {} as Record<string, number>,
      by_level: {} as Record<number, number>,
      changes: {
        code: items.filter(i => i.changes.code).length,
        level: items.filter(i => i.changes.level).length,
        parent: items.filter(i => i.changes.parent).length,
        value_chain: items.filter(i => i.changes.value_chain).length,
        workstream: items.filter(i => i.changes.workstream).length,
        status: items.filter(i => i.changes.status).length,
        no_change: items.filter(i => !i.has_changes).length,
      },
      downstream: {
        linked_risks: items.reduce((s, i) => s + i.linked_risk_count, 0),
        linked_controls: items.reduce((s, i) => s + i.linked_control_count, 0),
      },
    };

    for (const item of items) {
      const flag = item.issue_flags[0] || 'NO_ISSUE';
      summary.by_issue[flag] = (summary.by_issue[flag] || 0) + 1;
      summary.by_action[item.target_action] = (summary.by_action[item.target_action] || 0) + 1;
      const vc = item.target_value_chain_code || 'UNASSIGNED';
      summary.by_value_chain[vc] = (summary.by_value_chain[vc] || 0) + 1;
      const lvl = item.current_level;
      summary.by_level[lvl] = (summary.by_level[lvl] || 0) + 1;
    }

    // 7. Before/after structural audit
    const beforeAfter = {
      before: { by_level: {} as Record<number, number>, by_value_chain: {} as Record<string, number> },
      after: { by_level: {} as Record<number, number>, by_value_chain: {} as Record<string, number> },
    };
    for (const item of items) {
      const bLevel = item.current_level;
      const bVc = item.current_code ? item.current_code.split('-')[0] : 'UNKNOWN';
      beforeAfter.before.by_level[bLevel] = (beforeAfter.before.by_level[bLevel] || 0) + 1;
      beforeAfter.before.by_value_chain[bVc] = (beforeAfter.before.by_value_chain[bVc] || 0) + 1;

      const aLevel = item.proposed_level ?? item.current_level;
      const aVc = item.target_value_chain_code || bVc;
      beforeAfter.after.by_level[aLevel] = (beforeAfter.after.by_level[aLevel] || 0) + 1;
      beforeAfter.after.by_value_chain[aVc] = (beforeAfter.after.by_value_chain[aVc] || 0) + 1;
    }

    return Response.json({
      company_id,
      staged_at: new Date().toISOString(),
      total_rows: rows.length,
      items,
      groups,
      summary,
      before_after: beforeAfter,
      reference_counts: {
        processes: allProcesses.length,
        value_chains: vcList.length,
        workstreams: wsList.length,
      },
    });
  } catch (error: any) {
    console.error('Stage hierarchy audit error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}