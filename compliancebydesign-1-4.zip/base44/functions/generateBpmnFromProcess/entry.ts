import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

const escapeXml = (s) =>
  String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");

const ELEMENT_SIZES: Record<string, { w: number; h: number }> = {
  startEvent: { w: 36, h: 36 },
  endEvent: { w: 36, h: 36 },
  task: { w: 100, h: 80 },
  userTask: { w: 100, h: 80 },
  serviceTask: { w: 100, h: 80 },
  exclusiveGateway: { w: 50, h: 50 },
  parallelGateway: { w: 50, h: 50 },
  inclusiveGateway: { w: 50, h: 50 },
};

const BPMN_TAG: Record<string, string> = {
  startEvent: "startEvent",
  endEvent: "endEvent",
  task: "task",
  userTask: "userTask",
  serviceTask: "serviceTask",
  exclusiveGateway: "exclusiveGateway",
  parallelGateway: "parallelGateway",
  inclusiveGateway: "inclusiveGateway",
};

const VALID_TYPES = new Set(Object.keys(BPMN_TAG));

function buildPrompt(proc: any, valueChain: any, stakeholders: any[], risks: any[], instructions?: string): string {
  const parts: string[] = [];

  parts.push("You are a BPMN 2.0 process modelling expert. Generate a complete, well-structured BPMN process diagram for the business process described below.");
  parts.push("");
  parts.push("PROCESS INFORMATION:");
  parts.push(`- Name: ${proc.name || "Unnamed Process"}`);
  parts.push(`- Code: ${proc.process_code || "N/A"}`);
  parts.push(`- Level: L${proc.level ?? 3}`);
  if (proc.description) parts.push(`- Description: ${proc.description}`);
  if (proc.criticality) parts.push(`- Criticality: ${proc.criticality}`);
  if (proc.process_owner) parts.push(`- Process Owner: ${proc.process_owner}`);

  if (valueChain) {
    parts.push("");
    parts.push(`VALUE CHAIN: ${valueChain.name || "N/A"}`);
    if (valueChain.description) parts.push(`Value Chain Description: ${valueChain.description}`);
  }

  if (stakeholders.length > 0) {
    parts.push("");
    parts.push("STAKEHOLDERS (use these as swimlanes — select the 2-5 most relevant):");
    for (const s of stakeholders.slice(0, 20)) {
      parts.push(`- ${s.full_name || "Unknown"}${s.job_title ? ` — ${s.job_title}` : ""}`);
    }
  }

  if (risks.length > 0) {
    parts.push("");
    parts.push("RELATED RISKS (model control or verification steps that address these):");
    for (const r of risks.slice(0, 10)) {
      parts.push(`- ${r.title || "Unnamed Risk"}: ${r.likelihood || "?"} × ${r.impact || "?"} (${r.category || "general"})`);
    }
  }

  if (instructions) {
    parts.push("");
    parts.push("ADDITIONAL INSTRUCTIONS FROM THE USER:");
    parts.push(instructions);
  }

  parts.push("");
  parts.push("GENERATION RULES:");
  parts.push("1. Create a BPMN process with swimlanes based on the stakeholders above (2-5 lanes).");
  parts.push("2. Use action-oriented task names (verb + object, e.g., \"Validate Trade Details\").");
  parts.push("3. Include exclusiveGateway elements where the process branches on a decision.");
  parts.push("4. Start with exactly one startEvent and end with at least one endEvent.");
  parts.push("5. Connect ALL elements with sequence flows — every element must be reachable from the start event.");
  parts.push("6. Keep the process clear and readable: 5-15 tasks, 1-3 gateways, 1-2 end events.");
  parts.push("7. Assign each element to the most appropriate swimlane (stakeholder).");
  parts.push("8. Use \"userTask\" for manual/human activities, \"serviceTask\" for automated/system activities, \"task\" for generic tasks.");
  parts.push("9. Element IDs must be unique and simple (e.g., \"start_1\", \"task_1\", \"gw_1\", \"end_1\").");
  parts.push("10. Every flow must reference existing element IDs in its \"from\" and \"to\" fields.");
  parts.push("");
  parts.push("Return a JSON object with the process structure containing: process_summary (string), lanes (array of {name, role_hint}), elements (array of {id, type, name, lane, description}), flows (array of {from, to, name}).");

  return parts.join("\n");
}

function validateAndNormalize(llmResult: any, proc: any) {
  const raw = typeof llmResult === "string" ? JSON.parse(llmResult) : llmResult;
  const lanes = Array.isArray(raw.lanes) ? raw.lanes.filter((l: any) => l && l.name) : [];
  const elements = Array.isArray(raw.elements) ? raw.elements.filter((e: any) => e && e.id && VALID_TYPES.has(e.type)) : [];
  const flows = Array.isArray(raw.flows) ? raw.flows.filter((f: any) => f && f.from && f.to) : [];

  // Ensure at least one lane
  if (lanes.length === 0) {
    lanes.push({ name: proc.process_owner || "Process Owner", role_hint: "" });
  }

  // Build lane name map (case-insensitive)
  const laneNames = new Map<string, string>();
  for (const l of lanes) {
    laneNames.set(String(l.name).toLowerCase(), l.name);
  }

  // Fix element lane assignments
  for (const el of elements) {
    if (!el.lane || !laneNames.has(String(el.lane).toLowerCase())) {
      el.lane = lanes[0].name;
    } else {
      el.lane = laneNames.get(String(el.lane).toLowerCase())!;
    }
  }

  // Filter flows to only those referencing existing elements
  const elementIds = new Set(elements.map((e: any) => e.id));
  const validFlows = flows.filter((f: any) => elementIds.has(f.from) && elementIds.has(f.to));

  // Ensure at least one start and one end event
  const hasStart = elements.some((e: any) => e.type === "startEvent");
  const hasEnd = elements.some((e: any) => e.type === "endEvent");
  if (!hasStart) {
    elements.unshift({ id: "start_1", type: "startEvent", name: "Start", lane: lanes[0].name });
  }
  if (!hasEnd) {
    elements.push({ id: "end_1", type: "endEvent", name: "Complete", lane: lanes[0].name });
  }

  // Ensure start event has an outgoing flow
  const startEl = elements.find((e: any) => e.type === "startEvent");
  if (startEl && !validFlows.some((f: any) => f.from === startEl.id)) {
    const firstTask = elements.find((e: any) => e.type !== "startEvent" && e.type !== "endEvent");
    if (firstTask) {
      validFlows.unshift({ from: startEl.id, to: firstTask.id });
    }
  }

  // Ensure end event has an incoming flow
  const endEl = elements.find((e: any) => e.type === "endEvent");
  if (endEl && !validFlows.some((f: any) => f.to === endEl.id)) {
    const lastTask = [...elements].reverse().find((e: any) => e.type !== "startEvent" && e.type !== "endEvent");
    if (lastTask) {
      validFlows.push({ from: lastTask.id, to: endEl.id });
    }
  }

  return {
    process: { name: proc.name },
    process_summary: raw.process_summary || "",
    lanes,
    elements,
    flows: validFlows,
  };
}

function buildBpmnXml(diagram: any): string {
  const { lanes, elements, flows } = diagram;

  const laneMap = new Map<string, number>();
  lanes.forEach((l: any, i: number) => laneMap.set(l.name, i));

  // Assign x positions sequentially
  const xMap = new Map<string, number>();
  let xPos = 200;
  for (const el of elements) {
    xMap.set(el.id, xPos);
    xPos += 140;
  }

  const laneHeight = 120;
  const poolWidth = Math.max(xPos + 100, 800);
  const poolHeight = lanes.length * laneHeight;
  const poolX = 100;
  const poolY = 80;
  const laneX = poolX + 30;
  const laneWidth = poolWidth - 30;

  const lines: string[] = [];
  lines.push(`<?xml version="1.0" encoding="UTF-8"?>`);
  lines.push(`<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="Definitions_AI" targetNamespace="http://bpmn.io/schema/bpmn">`);

  // Collaboration
  lines.push(`  <bpmn:collaboration id="Collaboration_1">`);
  lines.push(`    <bpmn:participant id="Participant_1" name="${escapeXml(diagram.process?.name || "Process")}" processRef="Process_1" />`);
  lines.push(`  </bpmn:collaboration>`);

  // Process
  lines.push(`  <bpmn:process id="Process_1" name="${escapeXml(diagram.process?.name || "Process")}" isExecutable="false">`);

  // LaneSet
  lines.push(`    <bpmn:laneSet id="LaneSet_1">`);
  for (let i = 0; i < lanes.length; i++) {
    const lane = lanes[i];
    const laneId = `Lane_${i + 1}`;
    lines.push(`      <bpmn:lane id="${laneId}" name="${escapeXml(lane.name)}">`);
    for (const el of elements) {
      if (laneMap.get(el.lane) === i) {
        lines.push(`        <bpmn:flowNodeRef>${escapeXml(el.id)}</bpmn:flowNodeRef>`);
      }
    }
    lines.push(`      </bpmn:lane>`);
  }
  lines.push(`    </bpmn:laneSet>`);

  // Flow elements
  for (const el of elements) {
    const tag = BPMN_TAG[el.type] || "task";
    lines.push(`    <bpmn:${tag} id="${escapeXml(el.id)}" name="${escapeXml(el.name || "")}" />`);
  }

  // Sequence flows
  for (let i = 0; i < flows.length; i++) {
    const f = flows[i];
    const flowId = `Flow_${i + 1}`;
    const nameAttr = f.name ? ` name="${escapeXml(f.name)}"` : "";
    lines.push(`    <bpmn:sequenceFlow id="${flowId}" sourceRef="${escapeXml(f.from)}" targetRef="${escapeXml(f.to)}"${nameAttr} />`);
  }

  lines.push(`  </bpmn:process>`);

  // DI
  lines.push(`  <bpmndi:BPMNDiagram id="BPMNDiagram_1">`);
  lines.push(`    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1">`);

  // Participant shape
  lines.push(`      <bpmndi:BPMNShape id="Participant_1_di" bpmnElement="Participant_1" isHorizontal="true">`);
  lines.push(`        <dc:Bounds x="${poolX}" y="${poolY}" width="${poolWidth}" height="${poolHeight}" />`);
  lines.push(`      </bpmndi:BPMNShape>`);

  // Lane shapes
  for (let i = 0; i < lanes.length; i++) {
    const laneId = `Lane_${i + 1}`;
    lines.push(`      <bpmndi:BPMNShape id="${laneId}_di" bpmnElement="${laneId}" isHorizontal="true">`);
    lines.push(`        <dc:Bounds x="${laneX}" y="${poolY + i * laneHeight}" width="${laneWidth}" height="${laneHeight}" />`);
    lines.push(`      </bpmndi:BPMNShape>`);
  }

  // Element shapes
  for (const el of elements) {
    const size = ELEMENT_SIZES[el.type] || ELEMENT_SIZES.task;
    const laneIdx = laneMap.get(el.lane) || 0;
    const x = xMap.get(el.id) || 200;
    const y = poolY + laneIdx * laneHeight + (laneHeight - size.h) / 2;
    lines.push(`      <bpmndi:BPMNShape id="${escapeXml(el.id)}_di" bpmnElement="${escapeXml(el.id)}">`);
    lines.push(`        <dc:Bounds x="${x}" y="${Math.round(y)}" width="${size.w}" height="${size.h}" />`);
    lines.push(`      </bpmndi:BPMNShape>`);
  }

  // Edge shapes
  for (let i = 0; i < flows.length; i++) {
    const f = flows[i];
    const flowId = `Flow_${i + 1}`;
    const srcEl = elements.find((e: any) => e.id === f.from);
    const tgtEl = elements.find((e: any) => e.id === f.to);
    if (!srcEl || !tgtEl) continue;
    const srcSize = ELEMENT_SIZES[srcEl.type] || ELEMENT_SIZES.task;
    const srcX = (xMap.get(f.from) || 200) + srcSize.w;
    const srcLaneIdx = laneMap.get(srcEl.lane) || 0;
    const srcY = poolY + srcLaneIdx * laneHeight + laneHeight / 2;
    const tgtX = xMap.get(f.to) || 200;
    const tgtLaneIdx = laneMap.get(tgtEl.lane) || 0;
    const tgtY = poolY + tgtLaneIdx * laneHeight + laneHeight / 2;
    lines.push(`      <bpmndi:BPMNEdge id="${flowId}_di" bpmnElement="${flowId}">`);
    lines.push(`        <di:waypoint x="${srcX}" y="${Math.round(srcY)}" />`);
    lines.push(`        <di:waypoint x="${tgtX}" y="${Math.round(tgtY)}" />`);
    lines.push(`      </bpmndi:BPMNEdge>`);
  }

  lines.push(`    </bpmndi:BPMNPlane>`);
  lines.push(`  </bpmndi:BPMNDiagram>`);
  lines.push(`</bpmn:definitions>`);

  return lines.join("\n");
}

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const { process_id, instructions } = await req.json();
    if (!process_id) return Response.json({ error: "process_id is required" }, { status: 400 });

    const db = base44.asServiceRole.entities;

    // Load process
    const proc = await db.OrgProcess.get(process_id);
    if (!proc) return Response.json({ error: "Process not found" }, { status: 404 });

    // Load context in parallel
    const [valueChainRes, stakeholdersRes, risksRes] = await Promise.allSettled([
      proc.value_chain_id ? db.ValueChain.get(proc.value_chain_id) : Promise.resolve(null),
      db.Stakeholder.filter({ company_id: proc.company_id }, { limit: 50, fields: ["full_name", "job_title", "email"] }),
      proc.linked_risk_ids?.length
        ? db.Risk.filter({ id: { $in: proc.linked_risk_ids } }, { limit: 20, fields: ["title", "category", "likelihood", "impact", "status"] })
        : Promise.resolve([]),
    ]);

    const valueChain = valueChainRes.status === "fulfilled" ? valueChainRes.value : null;
    const stakeholdersRaw = stakeholdersRes.status === "fulfilled" ? stakeholdersRes.value : [];
    const stakeholders = Array.isArray(stakeholdersRaw) ? stakeholdersRaw : (stakeholdersRaw as any)?.items || [];
    const risksRaw = risksRes.status === "fulfilled" ? risksRes.value : [];
    const risks = Array.isArray(risksRaw) ? risksRaw : (risksRaw as any)?.items || [];

    // Build prompt
    const prompt = buildPrompt(proc, valueChain, stakeholders, risks, instructions);

    // Call InvokeLLM
    const llmResult = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          process_summary: { type: "string" },
          lanes: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                role_hint: { type: "string" },
              },
              required: ["name"],
            },
          },
          elements: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: { type: "string" },
                type: { type: "string", enum: ["startEvent", "endEvent", "task", "userTask", "serviceTask", "exclusiveGateway", "parallelGateway", "inclusiveGateway"] },
                name: { type: "string" },
                lane: { type: "string" },
                description: { type: "string" },
              },
              required: ["id", "type", "name"],
            },
          },
          flows: {
            type: "array",
            items: {
              type: "object",
              properties: {
                from: { type: "string" },
                to: { type: "string" },
                name: { type: "string" },
              },
              required: ["from", "to"],
            },
          },
        },
        required: ["lanes", "elements", "flows"],
      },
    });

    // Validate and build BPMN XML
    const diagram = validateAndNormalize(llmResult, proc);
    const bpmnXml = buildBpmnXml(diagram);

    return Response.json({
      bpmn_xml: bpmnXml,
      process_summary: diagram.process_summary,
      stats: {
        lanes: diagram.lanes.length,
        elements: diagram.elements.length,
        flows: diagram.flows.length,
        tasks: diagram.elements.filter((e: any) => ["task", "userTask", "serviceTask"].includes(e.type)).length,
        gateways: diagram.elements.filter((e: any) => e.type.includes("Gateway")).length,
        events: diagram.elements.filter((e: any) => e.type.includes("Event")).length,
      },
      context: {
        process_name: proc.name,
        process_code: proc.process_code,
        value_chain: valueChain?.name || "",
        stakeholders_available: stakeholders.length,
        stakeholders_used: diagram.lanes.length,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}