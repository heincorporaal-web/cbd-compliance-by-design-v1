import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// ── Apply high-confidence recommended matches from the cross-entity audit ─────
//
// Accepts the audit findings (from runCrossEntityAudit) and applies only the
// `recommended` findings whose confidence_score >= min_confidence.
//
// Supported match types:
//   process_stakeholder  → sets OrgProcess.process_owner_stakeholder_id
//   process_risk         → adds Risk ID to OrgProcess.linked_risk_ids
//   risk_control         → adds Control ID to Risk.control_ids

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Admin access required to apply matches' }, { status: 403 });

    const body = await req.json();
    const { findings, min_confidence = 70 } = body;

    if (!findings || !Array.isArray(findings)) {
      return Response.json({ error: 'findings array is required' }, { status: 400 });
    }

    // Filter for high-confidence recommended matches AND proposed associations with valid IDs
    const recommended = findings.filter(f =>
      (f.finding_type === 'recommended' || f.finding_type === 'proposed_association') &&
      f.confidence_score >= min_confidence &&
      f.source_record?.id &&
      f.target_record?.id
    );

    // Group updates by entity record
    // processUpdates[processId] = { set_owner_stakeholder_id?: string, add_risk_ids: string[] }
    // riskUpdates[riskId] = { add_control_ids: string[] }
    const processUpdates = {};
    const riskUpdates = {};

    for (const f of recommended) {
      const src = f.source_record;
      const tgt = f.target_record;

      if (src.type === 'OrgProcess' && tgt.type === 'Stakeholder') {
        if (!processUpdates[src.id]) processUpdates[src.id] = { add_risk_ids: [] };
        processUpdates[src.id].set_owner_stakeholder_id = tgt.id;
      } else if (src.type === 'Risk' && tgt.type === 'OrgProcess') {
        if (!processUpdates[tgt.id]) processUpdates[tgt.id] = { add_risk_ids: [] };
        processUpdates[tgt.id].add_risk_ids.push(src.id);
      } else if (src.type === 'OrgProcess' && tgt.type === 'Risk') {
        if (!processUpdates[src.id]) processUpdates[src.id] = { add_risk_ids: [] };
        processUpdates[src.id].add_risk_ids.push(tgt.id);
      } else if (src.type === 'Risk' && tgt.type === 'Control') {
        if (!riskUpdates[src.id]) riskUpdates[src.id] = { add_control_ids: [] };
        riskUpdates[src.id].add_control_ids.push(tgt.id);
      }
    }

    let applied = 0, skipped = 0, errors = 0;
    const errorDetails = [];
    const appliedBreakdown = { process_stakeholder: 0, process_risk: 0, risk_control: 0 };

    // ── Apply process updates ──────────────────────────────────────────────────
    const processIds = Object.keys(processUpdates);
    if (processIds.length > 0) {
      // Load current process records in batches of 500
      for (let i = 0; i < processIds.length; i += 500) {
        const batch = processIds.slice(i, i + 500);
        const page = await base44.asServiceRole.entities.OrgProcess.filter(
          { id: { $in: batch } },
          { limit: 500 }
        );
        const procMap = {};
        for (const p of page.items || []) procMap[p.id] = p;

        const updates = [];
        for (const pid of batch) {
          const upd = processUpdates[pid];
          const proc = procMap[pid];
          if (!proc) { skipped++; continue; }

          const newFields = {};
          let changed = false;

          if (upd.set_owner_stakeholder_id) {
            if (proc.process_owner_stakeholder_id === upd.set_owner_stakeholder_id) {
              skipped++;
              continue;
            }
            newFields.process_owner_stakeholder_id = upd.set_owner_stakeholder_id;
            appliedBreakdown.process_stakeholder++;
            changed = true;
          }

          if (upd.add_risk_ids.length > 0) {
            const existing = new Set(proc.linked_risk_ids || []);
            const toAdd = upd.add_risk_ids.filter(rid => !existing.has(rid));
            if (toAdd.length === 0 && !changed) { skipped++; continue; }
            if (toAdd.length > 0) {
              newFields.linked_risk_ids = [...(proc.linked_risk_ids || []), ...toAdd];
              appliedBreakdown.process_risk += toAdd.length;
              changed = true;
            }
          }

          if (changed) updates.push({ id: pid, ...newFields });
        }

        if (updates.length > 0) {
          try {
            await base44.asServiceRole.entities.OrgProcess.bulkUpdate(updates);
            applied += updates.length;
          } catch (e) {
            errors += updates.length;
            errorDetails.push(`Process bulkUpdate batch ${i}: ${e.message}`);
          }
        }
      }
    }

    // ── Apply risk updates ─────────────────────────────────────────────────────
    const riskIds = Object.keys(riskUpdates);
    if (riskIds.length > 0) {
      for (let i = 0; i < riskIds.length; i += 500) {
        const batch = riskIds.slice(i, i + 500);
        const page = await base44.asServiceRole.entities.Risk.filter(
          { id: { $in: batch } },
          { limit: 500 }
        );
        const riskMap = {};
        for (const r of page.items || []) riskMap[r.id] = r;

        const updates = [];
        for (const rid of batch) {
          const upd = riskUpdates[rid];
          const risk = riskMap[rid];
          if (!risk) { skipped++; continue; }

          const existing = new Set(risk.control_ids || []);
          const toAdd = upd.add_control_ids.filter(cid => !existing.has(cid));
          if (toAdd.length === 0) { skipped++; continue; }

          updates.push({ id: rid, control_ids: [...(risk.control_ids || []), ...toAdd] });
          appliedBreakdown.risk_control += toAdd.length;
        }

        if (updates.length > 0) {
          try {
            await base44.asServiceRole.entities.Risk.bulkUpdate(updates);
            applied += updates.length;
          } catch (e) {
            errors += updates.length;
            errorDetails.push(`Risk bulkUpdate batch ${i}: ${e.message}`);
          }
        }
      }
    }

    return Response.json({
      applied,
      skipped,
      errors,
      error_details: errorDetails,
      total_recommended: recommended.length,
      breakdown: appliedBreakdown,
      min_confidence,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}