import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import * as XLSX from 'npm:xlsx@0.18.5';

const FILE_URL = "https://media.base44.com/files/public/6975dcbcbc9efd8b47128ae3/3dd0e73ec_CBD_Report_Template_Studio_Starter_Configuration_Pack_v1_1.xlsx";

const splitList = (v) => (v ? String(v).split(/[;\n]/).map((s) => s.trim()).filter(Boolean) : []);
const toBool = (v) => v != null && (String(v).toLowerCase() === "yes" || v === true);
const toNum = (v) => (v === null || v === undefined || v === "") ? null : Number(v);
const str = (v) => (v === null || v === undefined) ? null : String(v).trim();

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    if (user.role !== "admin") return Response.json({ error: "Forbidden: admin only" }, { status: 403 });

    const resp = await fetch(FILE_URL, { signal: AbortSignal.timeout(20000) });
    if (!resp.ok) return Response.json({ error: "Failed to fetch config pack: " + resp.status }, { status: 502 });
    const buf = await resp.arrayBuffer();
    const wb = XLSX.read(new Uint8Array(buf), { type: "array" });
    const sheet = (name) => XLSX.utils.sheet_to_json(wb.Sheets[name], { defval: null });

    // Brand policy per template (Template_Brand_Policy)
    const brandPolicyByTemplate = {};
    for (const r of sheet("Template_Brand_Policy")) {
      const tid = str(r.TemplateID);
      if (!tid) continue;
      brandPolicyByTemplate[tid] = {
        default_brand_profile_id: str(r.DefaultBrandProfileID),
        use_company_defaults: str(r.UseCompanyDefaults),
        company_brand_source: str(r.CompanyBrandSource),
        allowed_override: str(r.AllowedOverride),
        protected_tokens: str(r.ProtectedTokens),
        multi_company_rule: str(r.MultiCompanyRule),
        status: str(r.Status),
      };
    }

    // Bindings per section (Binding_Definitions)
    const bindingsBySection = {};
    for (const r of sheet("Binding_Definitions")) {
      const sid = str(r.SectionID);
      if (!sid) continue;
      if (!bindingsBySection[sid]) bindingsBySection[sid] = [];
      bindingsBySection[sid].push({
        field_id: str(r.FieldID),
        context_filter_template: str(r.ContextFilterTemplate),
        state_filter: str(r.StateFilter),
        aggregate_rule: str(r.AggregateRule),
        formatting: str(r.Formatting),
        approved_scope: str(r.ApprovedScope),
        validation_rule: str(r.ValidationRule),
        actual_cbd_query: str(r.ActualCBDQuery),
      });
    }

    const templates = sheet("Template_Catalog").map((r) => ({
      template_id: str(r.TemplateID),
      name: str(r.TemplateName),
      category: str(r.Category),
      source_modules: splitList(r.SourceModules),
      audience: str(r.Audience),
      status: str(r.Status) || "Draft",
      classification: str(r.Classification) || "Internal",
      output_formats: splitList(r.OutputFormats),
      summary: str(r.Summary),
      scope_parameters: str(r.ScopeParameters),
      import_status: str(r.ImportStatus),
      brand_policy: brandPolicyByTemplate[str(r.TemplateID)] || null,
    })).filter((t) => t.template_id);

    const sections = sheet("Template_Sections").map((r) => ({
      section_id: str(r.SectionID),
      template_id: str(r.TemplateID),
      order: toNum(r.Order),
      section_title: str(r.SectionTitle),
      block_type: str(r.BlockType),
      primary_field_id: str(r.PrimaryFieldID),
      optional: toBool(r.Optional),
      visibility_rule: str(r.VisibilityRule),
      state: str(r.State) || "Draft",
      source_contract: str(r.SourceContract),
      bindings: bindingsBySection[str(r.SectionID)] || [],
    })).filter((s) => s.section_id);

    const fields = sheet("Field_Registry").map((r) => ({
      field_id: str(r.FieldID),
      friendly_name: str(r.FriendlyName),
      source_module: str(r.SourceModule),
      data_type: str(r.DataType),
      source_alias: str(r.SourceAlias),
      allowed_scope: str(r.AllowedScope),
      requirement: str(r.Requirement),
      null_policy: str(r.NullPolicy),
      current_mapping_status: str(r.CurrentMappingStatus),
      actual_cbd_field_or_api: str(r.ActualCBDFieldOrAPI),
      role_restriction: str(r.RoleRestriction),
    })).filter((f) => f.field_id);

    const profiles = sheet("Branding_Profiles").map((r) => ({
      brand_id: str(r.BrandID),
      brand_name: str(r.BrandName),
      company_scope: str(r.CompanyScope),
      brand_source: str(r.BrandSource),
      inherit_company_defaults: toBool(r.InheritCompanyDefaults),
      override_policy: str(r.OverridePolicy),
      presentation_rules: str(r.PresentationRules),
      state: str(r.State) || "Draft",
      schema_mapping: str(r.SchemaMapping),
    })).filter((p) => p.brand_id);

    const tokens = sheet("Company_Brand_Sources").map((r) => ({
      token_id: str(r.TokenID),
      description: str(r.Description),
      data_type: str(r.DataType),
      existing_source: str(r.ExistingSource),
      illustrative_source_alias: str(r.IllustrativeSourceAlias),
      presentation_mapping: str(r.PresentationMapping),
      obligation: str(r.Obligation),
      authority: str(r.Authority),
      missing_value_handling: str(r.MissingValueHandling),
      actual_field_mapping: str(r.ActualFieldMapping),
    })).filter((t) => t.token_id);

    const gates = sheet("Readiness_Gates").map((r) => ({
      gate_id: str(r.GateID),
      stage: str(r.Stage),
      criterion: str(r.Criterion),
      weight: toNum(r.Weight),
      gate_type: str(r.GateType) || "Mandatory",
      status: str(r.Status) || "Not Started",
      owner: str(r.Owner),
      due_date: str(r.DueDate),
      evidence_link: str(r.EvidenceLink),
    })).filter((g) => g.gate_id);

    const tests = sheet("QA_Test_Catalogue").map((r) => ({
      test_id: str(r.TestID),
      category: str(r.Category),
      scenario: str(r.Scenario),
      expected_output: str(r.ExpectedOutput),
      criticality: str(r.Criticality) || "Mandatory",
    })).filter((t) => t.test_id);

    const svc = base44.asServiceRole.entities;
    const [tplRes, secRes, fldRes, profRes, tokRes, gateRes, testRes] = await Promise.all([
      svc.ReportTemplate.upsert(templates, { key: "template_id" }),
      svc.TemplateSection.upsert(sections, { key: "section_id" }),
      svc.ReportField.upsert(fields, { key: "field_id" }),
      svc.BrandingProfile.upsert(profiles, { key: "brand_id" }),
      svc.BrandToken.upsert(tokens, { key: "token_id" }),
      svc.ReadinessGate.upsert(gates, { key: "gate_id" }),
      svc.QATest.upsert(tests, { key: "test_id" }),
    ]);

    return Response.json({
      seeded: {
        templates: { count: templates.length, created: tplRes.created, updated: tplRes.updated },
        sections: { count: sections.length, created: secRes.created, updated: secRes.updated },
        fields: { count: fields.length, created: fldRes.created, updated: fldRes.updated },
        branding_profiles: { count: profiles.length, created: profRes.created, updated: profRes.updated },
        brand_tokens: { count: tokens.length, created: tokRes.created, updated: tokRes.updated },
        readiness_gates: { count: gates.length, created: gateRes.created, updated: gateRes.updated },
        qa_tests: { count: tests.length, created: testRes.created, updated: testRes.updated },
      },
    });
  } catch (error) {
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
}