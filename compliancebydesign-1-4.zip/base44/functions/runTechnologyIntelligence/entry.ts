import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { fetchAll, hasItems, hasText } from "../../shared/diagnosticUtils.ts";

const CALC_VERSION = "tech-intel-1.0";
const CRITICALITY_RANK = { critical: 4, important: 3, supporting: 2 };
const RISK_LEVEL_RANK = { very_low: 1, low: 2, medium: 3, high: 4, very_high: 5 };

function riskLevel(likelihood, impact) {
  const l = RISK_LEVEL_RANK[likelihood] || 3;
  const i = RISK_LEVEL_RANK[impact] || 3;
  const score = l * i;
  if (score >= 16) return "very_high";
  if (score >= 10) return "high";
  if (score >= 6) return "medium";
  if (score >= 3) return "low";
  return "very_low";
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const { company_id } = await req.json();
    if (!company_id) return Response.json({ error: "company_id is required" }, { status: 400 });
    if (user.role !== "admin" && user.assigned_company_id !== company_id) {
      return Response.json({ error: "Forbidden: company scope" }, { status: 403 });
    }

    const db = base44.asServiceRole.entities;
    const [systems, cis, capabilities, processes, objectives, goals, risks] = await Promise.all([
      fetchAll(db.ICTSystem, { company_id }, [
        "name", "system_type", "system_type_custom", "criticality", "status", "owner_stakeholder_id",
        "vendor", "hosting_type", "data_classification", "it_capability_ids", "value_chain_id",
        "last_assessment_date", "next_assessment_date", "dependencies",
      ]),
      fetchAll(db.ConfigurationItem, { company_id }, [
        "ci_name", "ci_class_name", "lifecycle_status", "environment", "stale_status", "os_platform", "os_version",
        "exposure_level", "security_status", "vulnerability_info", "managed_unmanaged", "intrinsic_criticality",
        "technical_owner", "business_owner", "status",
      ]),
      fetchAll(db.ITCapability, { company_id }, [
        "name", "category", "maturity_level", "target_maturity_level", "strategic_importance", "status", "owner", "stakeholder_ids",
      ]),
      fetchAll(db.OrgProcess, { company_id }, [
        "name", "status", "linked_system_ids", "linked_it_capability_ids", "linked_risk_ids", "value_chain_id",
      ]),
      fetchAll(db.OrgObjective, { company_id }, ["title", "status", "linked_capability_ids"]),
      fetchAll(db.GRCGoal, { company_id }, ["title", "status", "category", "linked_capability_ids"]),
      fetchAll(db.Risk, { company_id }, ["title", "category", "likelihood", "impact", "status"]),
    ]);

    // Indexes
    const activeProcesses = processes.filter((p) => p.status === "active");
    const processBySystem = new Map(); // systemId -> [process names]
    const risksByProcess = new Map(); // processId -> [risk records]
    for (const p of activeProcesses) {
      if (hasItems(p.linked_system_ids)) {
        for (const sid of p.linked_system_ids) {
          if (!processBySystem.has(sid)) processBySystem.set(sid, []);
          processBySystem.get(sid).push(p);
        }
      }
    }
    const techRisks = risks.filter((r) => ["technology", "cyber_security"].includes(r.category));
    const objectiveCapabilityIds = new Set(objectives.filter((o) => ["Active", "Approved"].includes(o.status)).flatMap((o) => o.linked_capability_ids || []));
    const goalCapabilityIds = new Set(goals.flatMap((g) => g.linked_capability_ids || []));

    // --- Per-system analysis ---
    const eolCiNames = new Set();
    const systemRows = systems.map((s) => {
      const owner = hasText(s.owner_stakeholder_id);
      const classification = hasText(s.data_classification);
      const lifecycle = s.status && s.status !== "discovered";
      const linkedProcesses = processBySystem.get(s.id) || [];
      const processRiskIds = linkedProcesses.flatMap((p) => p.linked_risk_ids || []);
      const riskLinked = processRiskIds.length > 0;
      const dependency = hasItems(s.dependencies) || hasItems(s.it_capability_ids) || linkedProcesses.length > 0;
      const strategicAlignment = hasText(s.value_chain_id) || hasItems(s.it_capability_ids);

      // Strategic value score (0-100)
      const critScore = { critical: 30, important: 20, supporting: 10 }[s.criticality] || 10;
      const alignScore = (hasText(s.value_chain_id) ? 20 : 0) + (hasItems(s.it_capability_ids) ? 15 : 0);
      const capScore = Math.min(hasItems(s.it_capability_ids) ? s.it_capability_ids.length * 5 : 0, 15);
      const procScore = Math.min(linkedProcesses.length * 7, 20);
      const strategicValue = critScore + alignScore + capScore + procScore;

      // Health flags
      const healthFlags = [];
      if (s.status === "decommissioned") healthFlags.push("decommissioned");
      if (hasText(s.next_assessment_date) && new Date(s.next_assessment_date) < new Date()) healthFlags.push("assessment_overdue");
      if (!owner) healthFlags.push("no_owner");
      if (!classification) healthFlags.push("no_classification");

      // Risk exposure from linked process risks
      const linkedRiskRecords = risks.filter((r) => processRiskIds.includes(r.id) && r.status !== "closed");
      const maxRisk = linkedRiskRecords.reduce((m, r) => Math.max(m, RISK_LEVEL_RANK[riskLevel(r.likelihood, r.impact)] || 0), 0);

      // Recommended decision
      let recommended = "optimize";
      let priority = "medium";
      if (s.status === "decommissioned") { recommended = "retire"; priority = "medium"; }
      else if (healthFlags.includes("assessment_overdue") && (s.criticality === "critical" || s.criticality === "important")) { recommended = "replace"; priority = s.criticality === "critical" ? "critical" : "high"; }
      else if (healthFlags.includes("assessment_overdue")) { recommended = "modernize"; priority = "medium"; }
      else if (strategicValue >= 65) { recommended = "retain"; priority = "low"; }

      return {
        id: s.id,
        name: s.name,
        system_type: s.system_type === "custom" ? (s.system_type_custom || "custom") : s.system_type,
        criticality: s.criticality || "supporting",
        status: s.status || "active",
        owner: owner,
        classification: classification,
        strategic_value: strategicValue,
        strategic_alignment: strategicAlignment,
        risk_exposure: maxRisk >= 4 ? "high" : maxRisk >= 3 ? "medium" : maxRisk > 0 ? "low" : "none",
        process_count: linkedProcesses.length,
        capability_count: hasItems(s.it_capability_ids) ? s.it_capability_ids.length : 0,
        health_flags: healthFlags,
        recommended_decision: recommended,
        priority,
      };
    });

    // --- Readiness ---
    const dims = [
      { key: "ownership", label: "Ownership", ok: (s) => hasText(s.owner_stakeholder_id) },
      { key: "classification", label: "Classification", ok: (s) => hasText(s.data_classification) },
      { key: "lifecycle", label: "Lifecycle", ok: (s) => hasText(s.status) && s.status !== "discovered" },
      { key: "risk", label: "Risk linkage", ok: (s) => (processBySystem.get(s.id) || []).some((p) => hasItems(p.linked_risk_ids)) },
      { key: "dependency", label: "Dependency", ok: (s) => hasItems(s.dependencies) || hasItems(s.it_capability_ids) || (processBySystem.get(s.id) || []).length > 0 },
      { key: "strategic_alignment", label: "Strategic alignment", ok: (s) => hasText(s.value_chain_id) || hasItems(s.it_capability_ids) },
    ];
    const readiness = {
      overall_pct: systems.length ? Math.round(systems.filter((s) => dims.every((d) => d.ok(s))).length / systems.length * 1000) / 10 : null,
      dimensions: dims.map((d) => {
        const missing = systems.filter((s) => !d.ok(s)).length;
        return { key: d.key, label: d.label, missing_count: missing, pct: systems.length ? Math.round((systems.length - missing) / systems.length * 1000) / 10 : null };
      }),
    };

    // --- Health & exposure ---
    const eolUnsupported = [];
    const obsolescence = [];
    const securityExposure = [];
    const ownershipGaps = [];
    const inventoryGaps = [];
    for (const ci of cis) {
      if (ci.status === "archived") continue;
      const lc = ci.lifecycle_status || "";
      const stale = ci.stale_status || "";
      if (["Retiring", "Retired"].includes(lc) || stale === "retirement_candidate") {
        eolUnsupported.push({ id: ci.id, name: ci.ci_name, reason: lc ? `Lifecycle: ${lc}` : "Retirement candidate" });
      }
      if (stale === "stale" || stale === "retirement_candidate") {
        obsolescence.push({ id: ci.id, name: ci.ci_name, reason: `Stale status: ${stale}` });
      }
      if (hasText(ci.exposure_level) || hasText(ci.vulnerability_info) || (hasText(ci.security_status) && /exposed|vulnerable|at.?risk/i.test(ci.security_status))) {
        securityExposure.push({ id: ci.id, name: ci.ci_name, reason: ci.vulnerability_info || ci.exposure_level || ci.security_status });
      }
      if (!hasText(ci.technical_owner) && !hasText(ci.business_owner)) {
        ownershipGaps.push({ id: ci.id, name: ci.ci_name, type: "ConfigurationItem", reason: "No technical or business owner" });
      }
      if (ci.managed_unmanaged === "unmanaged" || ci.managed_unmanaged === "unknown") {
        inventoryGaps.push({ id: ci.id, name: ci.ci_name, reason: `Managed status: ${ci.managed_unmanaged}` });
      }
    }
    for (const s of systems) {
      if (s.status === "decommissioned") eolUnsupported.push({ id: s.id, name: s.name, reason: "System decommissioned" });
      if (!hasText(s.owner_stakeholder_id)) ownershipGaps.push({ id: s.id, name: s.name, type: "ICTSystem", reason: "No system owner" });
    }

    // Concentration
    const vendorCounts = {};
    const hostingCounts = {};
    for (const s of systems) {
      if (hasText(s.vendor)) vendorCounts[s.vendor] = (vendorCounts[s.vendor] || 0) + 1;
      if (hasText(s.hosting_type)) hostingCounts[s.hosting_type] = (hostingCounts[s.hosting_type] || 0) + 1;
    }
    const total = systems.length || 1;
    const vendorConcentration = Object.entries(vendorCounts).map(([vendor, count]) => ({ vendor, count, pct: Math.round(count / total * 1000) / 10 })).filter((v) => v.pct >= 25).sort((a, b) => b.count - a.count);
    const hostingConcentration = Object.entries(hostingCounts).map(([hosting_type, count]) => ({ hosting_type, count, pct: Math.round(count / total * 1000) / 10 })).sort((a, b) => b.count - a.count);

    // --- Portfolio analytics ---
    const countBy = (arr, field, mapFn) => {
      const counts = {};
      for (const x of arr) { const k = mapFn ? mapFn(x) : x[field]; if (hasText(k)) counts[k] = (counts[k] || 0) + 1; }
      return Object.entries(counts).map(([key, count]) => ({ key, count })).sort((a, b) => b.count - a.count);
    };
    const byCategory = countBy(systems, "system_type", (s) => s.system_type === "custom" ? (s.system_type_custom || "custom") : s.system_type);
    const byStatus = countBy(systems, "status");
    const byCriticality = countBy(systems, "criticality");
    const capabilityMaturity = countBy(capabilities, "maturity_level");

    // Risk exposure heatmap: criticality × risk_exposure
    const riskLevels = ["none", "low", "medium", "high"];
    const critLevels = ["critical", "important", "supporting"];
    const riskExposureHeatmap = [];
    for (const c of critLevels) {
      for (const r of riskLevels) {
        riskExposureHeatmap.push({ criticality: c, risk_level: r, count: systemRows.filter((s) => s.criticality === c && s.risk_exposure === r).length });
      }
    }
    // Strategic alignment matrix: criticality × aligned (true/false)
    const strategicAlignmentMatrix = [];
    for (const c of critLevels) {
      for (const aligned of [true, false]) {
        strategicAlignmentMatrix.push({ criticality: c, aligned, count: systems.filter((s) => (s.criticality || "supporting") === c && aligned === (hasText(s.value_chain_id) || hasItems(s.it_capability_ids))).length });
      }
    }

    // --- Opportunities ---
    const opportunities = [];
    let oppSeq = 1;
    for (const s of systemRows) {
      if (s.recommended_decision === "retire") {
        opportunities.push({ id: `OPP-${String(oppSeq++).padStart(3, "0")}`, asset_name: s.name, asset_id: s.id, asset_type: "ICTSystem", opportunity_type: "retire", rationale: "System is decommissioned and should be formally retired from the portfolio.", priority: s.priority });
      } else if (s.recommended_decision === "replace") {
        opportunities.push({ id: `OPP-${String(oppSeq++).padStart(3, "0")}`, asset_name: s.name, asset_id: s.id, asset_type: "ICTSystem", opportunity_type: "replace", rationale: `${s.criticality} criticality system with overdue assessment and health flags: ${s.health_flags.join(", ")}.`, priority: s.priority });
      } else if (s.recommended_decision === "modernize") {
        opportunities.push({ id: `OPP-${String(oppSeq++).padStart(3, "0")}`, asset_name: s.name, asset_id: s.id, asset_type: "ICTSystem", opportunity_type: "modernize", rationale: "Assessment overdue; modernize to restore currency and reduce lifecycle risk.", priority: s.priority });
      }
    }
    // Consolidation opportunities from vendor concentration
    for (const v of vendorConcentration) {
      if (v.count >= 3) {
        opportunities.push({ id: `OPP-${String(oppSeq++).padStart(3, "0")}`, asset_name: v.vendor, asset_id: "", asset_type: "Vendor", opportunity_type: "consolidate", rationale: `${v.count} systems (${v.pct}% of portfolio) from vendor "${v.vendor}". Review for consolidation.`, priority: v.pct >= 50 ? "high" : "medium" });
      }
    }
    // Retain opportunities (high strategic value, good health)
    for (const s of systemRows) {
      if (s.recommended_decision === "retain") {
        opportunities.push({ id: `OPP-${String(oppSeq++).padStart(3, "0")}`, asset_name: s.name, asset_id: s.id, asset_type: "ICTSystem", opportunity_type: "retain", rationale: `High strategic value (${s.strategic_value}/100) with no health flags. Retain and leverage.`, priority: "low" });
      }
    }
    const oppPriorityRank = { critical: 4, high: 3, medium: 2, low: 1 };
    opportunities.sort((a, b) => oppPriorityRank[b.priority] - oppPriorityRank[a.priority]);

    return Response.json({
      calc_version: CALC_VERSION,
      generated_at: new Date().toISOString(),
      company_id,
      mode: "read_only",
      source_counts: {
        ict_systems: systems.length, configuration_items: cis.length, it_capabilities: capabilities.length,
        processes: activeProcesses.length, objectives: objectives.length, goals: goals.length, technology_risks: techRisks.length,
      },
      readiness,
      health_exposure: {
        eol_unsupported: eolUnsupported,
        obsolescence,
        security_exposure: securityExposure,
        concentration: { vendor_concentration: vendorConcentration, hosting_concentration: hostingConcentration },
        ownership_gaps: ownershipGaps,
        inventory_gaps: inventoryGaps,
      },
      portfolio_analytics: {
        by_category: byCategory, by_status: byStatus, by_criticality: byCriticality,
        capability_maturity: capabilityMaturity, risk_exposure_heatmap: riskExposureHeatmap,
        strategic_alignment_matrix: strategicAlignmentMatrix,
      },
      opportunities,
      systems: systemRows,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}