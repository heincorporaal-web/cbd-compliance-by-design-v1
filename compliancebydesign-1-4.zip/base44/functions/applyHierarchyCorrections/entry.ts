import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req: any) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { company_id, items } = await req.json();
    if (!company_id || !Array.isArray(items) || items.length === 0) {
      return Response.json({ error: 'company_id and non-empty items array required' }, { status: 400 });
    }

    const report: any = {
      updated: 0,
      skipped: 0,
      errors: 0,
      aliases_created: 0,
      diagrams_updated: 0,
      details: [],
    };

    for (const item of items) {
      try {
        if (!item.process_id || !item.process_found) {
          report.skipped++;
          report.details.push({ process_id: item.process_id || '', action: 'skipped_not_found' });
          continue;
        }
        if (!item.has_changes) {
          report.skipped++;
          report.details.push({ process_id: item.process_id, action: 'skipped_no_change' });
          continue;
        }

        // Get current process from DB
        const current = await base44.asServiceRole.entities.OrgProcess.get(item.process_id);
        if (!current) {
          report.skipped++;
          report.details.push({ process_id: item.process_id, action: 'skipped_not_found_in_db' });
          continue;
        }

        // Create alias record for traceability (whenever code or level or parent changes)
        if (item.changes.code || item.changes.level || item.changes.parent) {
          try {
            await base44.asServiceRole.entities.ProcessCodeAlias.create({
              company_id,
              process_id: item.process_id,
              old_code: current.process_code,
              new_code: item.proposed_code || current.process_code,
              old_level: current.level,
              new_level: item.proposed_level ?? current.level,
              old_parent_id: current.parent_id || '',
              new_parent_id: item.proposed_parent_id || current.parent_id || '',
              old_value_chain_id: current.value_chain_id || '',
              new_value_chain_id: item.target_value_chain_id || current.value_chain_id || '',
              corrected_at: new Date().toISOString(),
              corrected_by: user.email,
              rationale: item.target_action || '',
              issue_flags: (item.issue_flags || []).join(';'),
              target_action: item.target_action || '',
            });
            report.aliases_created++;
          } catch (e: any) {
            console.log(`Alias creation failed for ${item.process_id}: ${e.message}`);
          }
        }

        // Build update payload
        const update: any = {};
        if (item.changes.code && item.proposed_code) update.process_code = item.proposed_code;
        if (item.changes.level && item.proposed_level !== null) update.level = item.proposed_level;
        if (item.changes.parent && item.proposed_parent_id) update.parent_id = item.proposed_parent_id;
        if (item.changes.value_chain && item.target_value_chain_id) {
          update.value_chain_id = item.target_value_chain_id;
          update.value_chain = item.target_value_chain_name || '';
        }
        if (item.changes.workstream && item.resolved_workstream_id) {
          update.workstream_id = item.resolved_workstream_id;
          update.workstream = item.resolved_workstream_name || '';
        }
        if (item.changes.status && item.proposed_status) update.status = item.proposed_status;

        await base44.asServiceRole.entities.OrgProcess.update(item.process_id, update);
        report.updated++;

        // Update denormalized process_code in ProcessDiagram records
        if (item.changes.code && item.proposed_code) {
          try {
            const diagrams = await base44.asServiceRole.entities.ProcessDiagram.filter(
              { process_id: item.process_id },
              { limit: 50, fields: ['id', 'process_code'] }
            );
            for (const diag of (diagrams.items || [])) {
              if (diag.process_code !== item.proposed_code) {
                await base44.asServiceRole.entities.ProcessDiagram.update(diag.id, { process_code: item.proposed_code });
                report.diagrams_updated++;
              }
            }
          } catch (e: any) {
            console.log(`Diagram update failed for ${item.process_id}: ${e.message}`);
          }
        }

        report.details.push({
          process_id: item.process_id,
          old_code: current.process_code,
          new_code: item.proposed_code || current.process_code,
          action: 'updated',
          changes: item.changes,
        });
      } catch (e: any) {
        report.errors++;
        report.details.push({ process_id: item.process_id || '', action: 'error', error: e.message });
      }
    }

    return Response.json({
      success: true,
      company_id,
      applied_at: new Date().toISOString(),
      report,
    });
  } catch (error: any) {
    console.error('Apply hierarchy corrections error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}