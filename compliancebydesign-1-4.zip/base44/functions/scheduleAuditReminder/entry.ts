import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Format a date string (YYYY-MM-DD or ISO) as YYYY-MM-DD for all-day calendar events
function toAllDayDate(d) {
  if (!d) return null;
  return new Date(d).toISOString().split('T')[0];
}

// Add one day to a YYYY-MM-DD date string (Google all-day end dates are exclusive)
function addOneDay(dateStr) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + 1);
  return d.toISOString().split('T')[0];
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    const { event, data, args = {} } = payload;

    // Only act on create events
    if (event?.type !== "create") {
      return Response.json({ skipped: true, reason: "not_a_create_event" });
    }

    const entityType = args.entity_type || event?.entity_name;
    if (!data) {
      return Response.json({ skipped: true, reason: "no_data" });
    }

    // Build event details based on entity type
    let summary, description, startDate, endDate;
    const attendees = [];

    if (entityType === "Assessment") {
      const refDate = data.due_date || data.assessment_date;
      if (!refDate) {
        return Response.json({ skipped: true, reason: "no_due_date" });
      }
      summary = `Compliance Audit Reminder: ${data.name || "Assessment"}`;
      description = data.notes || `Compliance assessment — reminder for the audit team.`;
      startDate = refDate;
      endDate = refDate;
      if (data.assessor_email) attendees.push(data.assessor_email);
      if (data.reviewer_email) attendees.push(data.reviewer_email);
    } else if (entityType === "RiskAssessmentCycle") {
      if (!data.start_date && !data.end_date) {
        return Response.json({ skipped: true, reason: "no_cycle_dates" });
      }
      summary = `Risk Assessment Cycle: ${data.name || ""}`.trim();
      description = data.description || `Risk assessment cycle${data.cycle_year ? " " + data.cycle_year : ""}.`.trim();
      startDate = data.start_date || data.end_date;
      endDate = data.end_date || data.start_date;
    } else if (entityType === "ControlAssessmentCycle") {
      if (!data.start_date && !data.end_date) {
        return Response.json({ skipped: true, reason: "no_cycle_dates" });
      }
      summary = `Control Assessment Cycle: ${data.name || ""}`.trim();
      description = data.description || `Control assessment cycle${data.cycle_year ? " " + data.cycle_year : ""}.`.trim();
      startDate = data.start_date || data.end_date;
      endDate = data.end_date || data.start_date;
      if (data.reviewer_email) attendees.push(data.reviewer_email);
    } else {
      return Response.json({ skipped: true, reason: "unsupported_entity_type" });
    }

    const startStr = toAllDayDate(startDate);
    let endStr = toAllDayDate(endDate);
    // All-day end dates are exclusive in Google Calendar
    if (startStr === endStr) {
      endStr = addOneDay(endStr);
    }

    const body = {
      summary,
      description,
      start: { date: startStr, timeZone: 'UTC' },
      end: { date: endStr, timeZone: 'UTC' },
      attendees: attendees.length > 0 ? attendees.map(email => ({ email })) : undefined,
      reminders: {
        useDefault: false,
        overrides: [
          { method: 'email', minutes: 1440 },  // 1 day before
          { method: 'popup', minutes: 60 },     // 1 hour before
        ],
      },
    };

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('googlecalendar');

    const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?sendUpdates=all', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    const text = await res.text();
    if (!res.ok) {
      return Response.json({ error: `Google Calendar error: ${text}` }, { status: 400 });
    }
    const calEvent = JSON.parse(text);

    return Response.json({ success: true, google_event_id: calEvent.id, summary, attendees });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});