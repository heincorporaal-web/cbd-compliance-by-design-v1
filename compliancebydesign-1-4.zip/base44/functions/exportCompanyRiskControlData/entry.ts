import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { fetchAll, buildLookup } from '../../shared/exportUtils.ts';

const RISK_FIELDS = [
  'risk_reference_nr', 'title', 'risk_statement', 'category', 'risk_type',
  'likelihood', 'impact', 'inherent_risk_score', 'status', 'owner',
  'owner_stakeholder_name', 'root_cause', 'root_cause_type', 'root_cause_category_name',
  'value_chain', 'sub_process', 'workstream', 'process_activity', 'framework_reference',
  'linked_controls', 'linked_frameworks', 'linked_objectives', 'test_plans',
];

const CONTROL_FIELDS = [
  'control_id', 'title', 'description', 'category', 'priority', 'status',
  'control_criticality', 'control_owner', 'owner_stakeholder_name', 'key_control',
  'control_execution_type', 'control_type', 'control_frequency', 'process_phase',
  'framework_name', 'control_objective_name', 'linked_risk_title',
  'linked_objectives', 'compensating_controls', 'test_plan_names', 'test_plan_count',
];

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const companyId = body?.company_id;
    const library = body?.library; // 'risks', 'controls', or 'both'

    // Fetch company risks and controls
    const [risks, controls] = await Promise.all([
      library === 'controls' ? Promise.resolve([]) : fetchAll(base44, 'Risk',
        { company_id: companyId, is_library_risk: { $ne: true } },
        ['risk_reference_nr', 'title', 'risk_statement', 'category', 'risk_type', 'likelihood',
         'impact', 'inherent_risk_score', 'status', 'owner', 'owner_stakeholder_id', 'root_cause',
         'root_cause_type', 'root_cause_category_id', 'value_chain', 'sub_process', 'workstream',
         'process_activity', 'framework_reference', 'control_ids', 'framework_ids',
         'linked_objective_ids']),
      library === 'risks' ? Promise.resolve([]) : fetchAll(base44, 'Control',
        { is_library_control: { $ne: true } },
        ['control_id', 'title', 'description', 'category', 'priority', 'status',
         'control_criticality', 'control_owner', 'owner_stakeholder_id', 'key_control',
         'control_execution_type', 'control_type', 'control_frequency', 'process_phase',
         'framework_id', 'control_objective_id', 'risk_id', 'linked_objective_ids',
         'compensating_control_ids']),
    ]);

    // Fetch lookup entities in parallel (fetch all, build maps, filter in memory)
    const [frameworks, controlObjectives, orgObjectives, stakeholders, rootCauseCategories,
           allControls, allRisks, testPlans] = await Promise.all([
      fetchAll(base44, 'Framework', { is_master: { $ne: false } }, ['name', 'framework_code']),
      fetchAll(base44, 'ControlObjective', {}, ['title', 'reference_number']),
      fetchAll(base44, 'OrgObjective', { company_id: companyId }, ['title', 'reference_number']),
      fetchAll(base44, 'Stakeholder', { company_id: companyId }, ['full_name']),
      fetchAll(base44, 'RootCauseCategory', {}, ['name']),
      fetchAll(base44, 'Control', {}, ['control_id', 'title']),
      fetchAll(base44, 'Risk', { company_id: companyId }, ['risk_reference_nr', 'title']),
      fetchAll(base44, 'ControlTestPlan', {}, ['control_id', 'name', 'status']),
    ]);

    // Build lookup maps
    const frameworkMap = {};
    for (const f of frameworks) frameworkMap[f.id] = f.framework_code ? `${f.framework_code} — ${f.name}` : f.name;
    const controlObjMap = buildLookup([...controlObjectives, ...orgObjectives], 'id', 'title');
    const stakeholderMap = buildLookup(stakeholders, 'id', 'full_name');
    const rootCauseMap = buildLookup(rootCauseCategories, 'id', 'name');
    const controlMap = {};
    for (const c of allControls) controlMap[c.id] = c.control_id ? `${c.control_id} — ${c.title}` : c.title;
    const riskMap = {};
    for (const r of allRisks) riskMap[r.id] = r.risk_reference_nr ? `${r.risk_reference_nr} — ${r.title}` : r.title;

    // Build test plan lookup (grouped by control_id)
    const testPlanMap = {};
    for (const tp of testPlans) {
      if (!testPlanMap[tp.control_id]) testPlanMap[tp.control_id] = [];
      testPlanMap[tp.control_id].push(tp.name || 'Unnamed');
    }

    // Enrich risks
    const enrichedRisks = risks.map(r => ({
      risk_reference_nr: r.risk_reference_nr,
      title: r.title,
      risk_statement: r.risk_statement,
      category: r.category,
      risk_type: r.risk_type,
      likelihood: r.likelihood,
      impact: r.impact,
      inherent_risk_score: r.inherent_risk_score,
      status: r.status,
      owner: r.owner,
      owner_stakeholder_name: stakeholderMap[r.owner_stakeholder_id] || '',
      root_cause: r.root_cause,
      root_cause_type: r.root_cause_type,
      root_cause_category_name: rootCauseMap[r.root_cause_category_id] || '',
      value_chain: r.value_chain,
      sub_process: r.sub_process,
      workstream: r.workstream,
      process_activity: r.process_activity,
      framework_reference: r.framework_reference,
      linked_controls: (r.control_ids || []).map(id => controlMap[id]).filter(Boolean).join('; '),
      linked_frameworks: (r.framework_ids || []).map(id => frameworkMap[id]).filter(Boolean).join('; '),
      linked_objectives: (r.linked_objective_ids || []).map(id => controlObjMap[id]).filter(Boolean).join('; '),
      test_plans: (r.control_ids || []).flatMap(id => testPlanMap[id] || []).join('; '),
    }));

    // Enrich controls
    const enrichedControls = controls.map(c => ({
      control_id: c.control_id,
      title: c.title,
      description: c.description,
      category: c.category,
      priority: c.priority,
      status: c.status,
      control_criticality: c.control_criticality,
      control_owner: c.control_owner,
      owner_stakeholder_name: stakeholderMap[c.owner_stakeholder_id] || '',
      key_control: c.key_control,
      control_execution_type: c.control_execution_type,
      control_type: c.control_type,
      control_frequency: c.control_frequency,
      process_phase: c.process_phase,
      framework_name: frameworkMap[c.framework_id] || '',
      control_objective_name: controlObjMap[c.control_objective_id] || '',
      linked_risk_title: riskMap[c.risk_id] || '',
      linked_objectives: (c.linked_objective_ids || []).map(id => controlObjMap[id]).filter(Boolean).join('; '),
      compensating_controls: (c.compensating_control_ids || []).map(id => controlMap[id]).filter(Boolean).join('; '),
      test_plan_names: (testPlanMap[c.id] || []).join('; '),
      test_plan_count: (testPlanMap[c.id] || []).length,
    }));

    return Response.json({
      status: 'success',
      riskFields: RISK_FIELDS,
      controlFields: CONTROL_FIELDS,
      riskCount: enrichedRisks.length,
      controlCount: enrichedControls.length,
      risks: library === 'controls' ? undefined : enrichedRisks,
      controls: library === 'risks' ? undefined : enrichedControls,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}