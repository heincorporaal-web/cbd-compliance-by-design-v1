import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { fetchAll, hasItems, hasText } from "../../shared/diagnosticUtils.ts";

const CALC_VERSION = "coverage-1.0";

function buildRule(def, eligible, isCovered, brief, extra = {}) {
  const covered = eligible.filter(isCovered);
  const uncovered = eligible.filter((x) => !isCovered(x));
  return {
    ...def,
    state: eligible.length === 0 ? "not_applicable" : "assessed",
    eligible_count: eligible.length,
    covered_count: covered.length,
    uncovered_count: uncovered.length,
    coverage_pct: eligible.length ? Math.round((covered.length / eligible.length) * 1000) / 10 : null,
    uncovered_items: uncovered.slice(0, 500).map(brief),
    uncovered_truncated: uncovered.length > 500,
    ...extra,
  };
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const { company_id } = await req.json();
    if (!company_id) return Response.json({ error: "company_id is required" }, { status: 400 });
    if (user.role !== "admin" && user.assigned_company_id !== company_id) {
      return Response.json({ error: "Forbidden: company scope" }, { status: 403 });
    }

    const db = base44.asServiceRole.entities;
    const [processes, diagrams, objectives] = await Promise.all([
      fetchAll(db.OrgProcess, { company_id }, [
        "process_code", "name", "status", "process_owner_stakeholder_id", "linked_risk_ids", "linked_control_ids",
      ]),
      fetchAll(db.ProcessDiagram, { company_id }, ["process_id", "status"]),
      fetchAll(db.OrgObjective, { company_id }, [
        "reference_number", "title", "status", "objective_owner", "kpis",
      ]),
    ]);

    // Eligible population: active processes only (draft / under_review / archived are excluded and reported)
    const eligibleP = processes.filter((p) => p.status === "active");
    const excludedP = processes.filter((p) => p.status !== "active");
    const eligibleIds = new Set(eligibleP.map((p) => p.id));

    const assessments = eligibleIds.size
      ? (await fetchAll(db.ProcessAssessment, { status: "approved" }, ["process_id", "status"])).filter((a) =>
          eligibleIds.has(a.process_id))
      : [];

    const diagramProcIds = new Set(diagrams.filter((d) => d.status !== "archived").map((d) => d.process_id));
    const assessedProcIds = new Set(assessments.map((a) => a.process_id));

    const pBrief = (p) => ({ id: p.id, code: p.process_code || "", name: p.name || p.id });
    const eligibleO = objectives.filter((o) => ["Active", "Approved"].includes(o.status));
    const excludedO = objectives.filter((o) => !["Active", "Approved"].includes(o.status));

    const sumLen = (arr, f) => arr.reduce((n, x) => n + (hasItems(x[f]) ? x[f].length : 0), 0);
    const distinct = (arr, f) => new Set(arr.flatMap((x) => (hasItems(x[f]) ? x[f] : []))).size;

    const rules = [
      buildRule(
        { rule_id: "COV-001", name: "Process ownership", entity: "OrgProcess",
          definition: "Active processes with an accountable process owner (stakeholder) assigned, divided by all active processes." },
        eligibleP, (p) => hasText(p.process_owner_stakeholder_id), pBrief),
      buildRule(
        { rule_id: "COV-002", name: "Process diagram", entity: "OrgProcess",
          definition: "Active processes with at least one non-archived process diagram, divided by all active processes." },
        eligibleP, (p) => diagramProcIds.has(p.id), pBrief),
      buildRule(
        { rule_id: "COV-003", name: "Process-risk mapping", entity: "OrgProcess",
          definition: "Active processes with at least one linked risk, divided by all active processes. A missing link is a data-coverage finding, not proof that no risk exists." },
        eligibleP, (p) => hasItems(p.linked_risk_ids), pBrief,
        { associations: sumLen(eligibleP, "linked_risk_ids"), distinct_targets: distinct(eligibleP, "linked_risk_ids") }),
      buildRule(
        { rule_id: "COV-004", name: "Process-control mapping", entity: "OrgProcess",
          definition: "Active processes with at least one directly linked control, divided by all active processes. Inherited mappings are not counted in this release." },
        eligibleP, (p) => hasItems(p.linked_control_ids), pBrief,
        { associations: sumLen(eligibleP, "linked_control_ids"), distinct_targets: distinct(eligibleP, "linked_control_ids") }),
      buildRule(
        { rule_id: "COV-005", name: "Assessment coverage", entity: "OrgProcess",
          definition: "Active processes with at least one approved process assessment, divided by all active processes. Draft and completed-but-unapproved assessments are not counted." },
        eligibleP, (p) => assessedProcIds.has(p.id), pBrief),
      buildRule(
        { rule_id: "COV-006", name: "Strategy KPI and owner linkage", entity: "OrgObjective",
          definition: "Active or approved strategic objectives with both a named objective owner and at least one KPI, divided by all active or approved objectives." },
        eligibleO, (o) => hasText(o.objective_owner) && hasItems(o.kpis),
        (o) => ({ id: o.id, code: o.reference_number || "", name: o.title || o.id })),
    ];

    rules[5].excluded_count = excludedO.length;
    for (const r of rules.slice(0, 5)) r.excluded_count = excludedP.length;

    const reconciliation = [
      {
        id: "REC-001",
        label: "Distinct processes = eligible + excluded",
        pass: processes.length === eligibleP.length + excludedP.length,
        detail: `${processes.length} total = ${eligibleP.length} eligible + ${excludedP.length} excluded (non-active)`,
      },
      {
        id: "REC-002",
        label: "Objectives = eligible + excluded",
        pass: objectives.length === eligibleO.length + excludedO.length,
        detail: `${objectives.length} total = ${eligibleO.length} eligible + ${excludedO.length} excluded`,
      },
      ...rules.map((r) => ({
        id: `REC-${r.rule_id}`,
        label: `${r.rule_id}: covered + uncovered = eligible`,
        pass: r.covered_count + r.uncovered_count === r.eligible_count,
        detail: `${r.covered_count} + ${r.uncovered_count} = ${r.eligible_count}`,
      })),
    ];

    return Response.json({
      calc_version: CALC_VERSION,
      generated_at: new Date().toISOString(),
      company_id,
      mode: "read_only",
      filters: {
        process_eligibility: "OrgProcess.status = active",
        objective_eligibility: "OrgObjective.status in (Active, Approved)",
        assessment_eligibility: "ProcessAssessment.status = approved",
      },
      source_counts: {
        processes: processes.length, diagrams: diagrams.length,
        objectives: objectives.length, approved_assessments: assessments.length,
      },
      rules,
      reconciliation,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}