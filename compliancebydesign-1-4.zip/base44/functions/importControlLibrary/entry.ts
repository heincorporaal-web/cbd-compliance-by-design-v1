import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import * as XLSX from 'npm:xlsx@0.18.5';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { file_url, mode = 'append' } = body;
    if (!file_url) return Response.json({ error: 'file_url required' }, { status: 400 });

    if (!['purge', 'append'].includes(mode)) {
      return Response.json({ error: 'mode must be "purge" or "append"' }, { status: 400 });
    }

    // Fetch the Excel file as ArrayBuffer
    const fileRes = await fetch(file_url);
    if (!fileRes.ok) return Response.json({ error: 'Failed to fetch file' }, { status: 400 });

    const arrayBuffer = await fileRes.arrayBuffer();
    const data = new Uint8Array(arrayBuffer);

    // Parse with xlsx
    const workbook = XLSX.read(data, { type: 'array' });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });

    console.log(`Parsed ${rows.length} rows. Mode: ${mode}. Sample keys:`, Object.keys(rows[0] || {}));

    // Get master frameworks to map framework code to framework_id
    const frameworks = await base44.asServiceRole.entities.Framework.filter({ is_master: true });
    const frameworkMap = new Map();
    frameworks.forEach(fw => {
      const code = (fw.framework_code || '').toLowerCase().trim();
      const name = (fw.name || '').toLowerCase().trim();
      if (code) frameworkMap.set(code, fw.id);
      if (name) frameworkMap.set(name, fw.id);
      if (code === 'ctcm') frameworkMap.set('ctcm', fw.id);
      if (code === 'ifrs icfr') frameworkMap.set('ifrs icfr', fw.id);
    });

    // Helper to safely convert Excel values
    const safeStr = (val, defaultVal = '') => {
      if (val === null || val === undefined || val === '' || val === 0) return defaultVal;
      return String(val).trim();
    };

    // Map rows to Control entity schema
    const skippedNoFramework = [];
    const controls = rows.map((row) => {
      const controlRef = safeStr(row['ControlRef']);
      const controlTitle = safeStr(row['ControlTitle']);
      const controlDesc = safeStr(row['ControlDesc']);
      const category = safeStr(row['Category']);
      const frameworkColVal = safeStr(row['Framework']).toLowerCase().trim();

      // Resolve framework_id: try explicit Framework column first, then ControlRef prefix
      let framework_id = '';
      if (frameworkColVal && frameworkMap.has(frameworkColVal)) {
        framework_id = frameworkMap.get(frameworkColVal);
      } else {
        const frameworkCode = controlRef.split('.')[0]?.toLowerCase().trim();
        if (frameworkCode && frameworkMap.has(frameworkCode)) {
          framework_id = frameworkMap.get(frameworkCode);
        } else if (frameworkColVal) {
          // Try partial match on Framework column value
          for (const [key, value] of frameworkMap.entries()) {
            if (key.includes(frameworkColVal) || frameworkColVal.includes(key)) {
              framework_id = value;
              break;
            }
          }
        } else if (frameworkCode) {
          // Try partial match on ControlRef prefix
          for (const [key, value] of frameworkMap.entries()) {
            if (key.includes(frameworkCode) || frameworkCode.includes(key)) {
              framework_id = value;
              break;
            }
          }
        }
      }

      if (!framework_id) {
        skippedNoFramework.push(controlRef);
        return null;
      }

      // Use explicit title if provided, otherwise derive from description
      const title = controlTitle || controlDesc.substring(0, 500);

      return {
        framework_id: framework_id,
        control_id: controlRef,
        title: title,
        description: controlDesc,
        category: category,
        is_library_control: true,
        global: row['Global'] === true || row['Global'] === 'true' || row['Global'] === 1,
        control_ccm: row['ControlCCM'] === true || row['ControlCCM'] === 'true' || row['ControlCCM'] === 1,
        self_assessment: row['SelfAssessment'] === true || row['SelfAssessment'] === 'true' || row['SelfAssessment'] === 1,
        control_criticality: safeStr(row['ControlCriticality'], 'Should Have'),
        control_owner: safeStr(row['ControlOwner']),
        key_control: row['KeyControl'] === true || row['KeyControl'] === 'true' || row['KeyControl'] === 1,
        control_execution_type: safeStr(row['ControlExecutionType'], 'Manual'),
        control_type: safeStr(row['ControlType'], 'Preventive'),
        finance_control_consideration: row['FinanceControlConsideration'] === true || row['FinanceControlConsideration'] === 'true' || row['FinanceControlConsideration'] === 1,
        control_frequency: safeStr(row['ControlFrequency'], 'Monthly'),
        compensating_control: row['CompensatingControl'] === true || row['CompensatingControl'] === 'true' || row['CompensatingControl'] === 1,
        compensating_control_risk: safeStr(row['CompensatingControlRisk']),
        control_narrative_url: safeStr(row['ControlNarrativeURL']),
        upload_document: safeStr(row['Upload Document'], '0'),
        control_objective_id: safeStr(row['ControlObjectiveID']),
        process_phase: safeStr(row['ProcessPhase'], 'Process - Input'),
        risk_id: safeStr(row['RiskID']),
        status: 'active',
      };
    }).filter(c => c !== null); // skip rows that failed framework resolution

    let purged = 0;
    let updated = 0;
    let created = 0;

    // PURGE MODE: delete all existing library controls first
    if (mode === 'purge') {
      const existing = await base44.asServiceRole.entities.Control.filter({ is_library_control: true }, '-created_date', 10000);
      purged = existing.length;
      if (purged > 0) {
        await base44.asServiceRole.entities.Control.deleteMany({ is_library_control: true });
        console.log(`Purged ${purged} existing library controls`);
      }
    }

    // APPEND MODE: match by control_id, override existing or create new
    if (mode === 'append') {
      const existing = await base44.asServiceRole.entities.Control.filter({ is_library_control: true }, '-created_date', 10000);
      const existingMap = new Map();
      existing.forEach(c => {
        if (c.control_id) existingMap.set(c.control_id, c);
      });

      const toUpdate = [];
      const toCreate = [];

      for (const ctrl of controls) {
        const match = existingMap.get(ctrl.control_id);
        if (match) {
          toUpdate.push({
            id: match.id,
            framework_id: ctrl.framework_id,
            title: ctrl.title,
            description: ctrl.description,
            category: ctrl.category,
            is_library_control: true,
            global: ctrl.global,
            control_ccm: ctrl.control_ccm,
            self_assessment: ctrl.self_assessment,
            control_criticality: ctrl.control_criticality,
            control_owner: ctrl.control_owner,
            key_control: ctrl.key_control,
            control_execution_type: ctrl.control_execution_type,
            control_type: ctrl.control_type,
            finance_control_consideration: ctrl.finance_control_consideration,
            control_frequency: ctrl.control_frequency,
            compensating_control: ctrl.compensating_control,
            compensating_control_risk: ctrl.compensating_control_risk,
            control_narrative_url: ctrl.control_narrative_url,
            upload_document: ctrl.upload_document,
            control_objective_id: ctrl.control_objective_id,
            process_phase: ctrl.process_phase,
            risk_id: ctrl.risk_id,
            status: ctrl.status,
          });
        } else {
          toCreate.push(ctrl);
        }
      }

      // Bulk update in batches of 100
      const BATCH = 100;
      for (let i = 0; i < toUpdate.length; i += BATCH) {
        const batch = toUpdate.slice(i, i + BATCH);
        await base44.asServiceRole.entities.Control.bulkUpdate(batch);
        updated += batch.length;
        console.log(`Updated ${updated}/${toUpdate.length}`);
      }

      // Bulk create new controls
      for (let i = 0; i < toCreate.length; i += BATCH) {
        const batch = toCreate.slice(i, i + BATCH);
        await base44.asServiceRole.entities.Control.bulkCreate(batch);
        created += batch.length;
        console.log(`Created ${created}/${toCreate.length}`);
      }

      return Response.json({
        success: true,
        mode,
        total: controls.length,
        updated,
        created,
        purged: 0,
        skipped: skippedNoFramework.length,
        skippedRefs: skippedNoFramework.slice(0, 20),
      });
    }

    // PURGE MODE: bulk create all controls
    const BATCH = 100;
    for (let i = 0; i < controls.length; i += BATCH) {
      const batch = controls.slice(i, i + BATCH);
      await base44.asServiceRole.entities.Control.bulkCreate(batch);
      created += batch.length;
      console.log(`Created ${created}/${controls.length}`);
    }

    return Response.json({
      success: true,
      mode,
      total: controls.length,
      updated: 0,
      created,
      purged,
      skipped: skippedNoFramework.length,
      skippedRefs: skippedNoFramework.slice(0, 20),
    });
  } catch (error) {
    console.error('Import error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});