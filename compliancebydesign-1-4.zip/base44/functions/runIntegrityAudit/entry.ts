import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import {
  runHierarchyChecks,
  convertCrossEntityFinding,
  suppressWithExceptions,
  classifyFindings,
  makeFindingKey,
  computeFingerprint,
  isExceptionable,
} from "../../shared/integrityAuditRules.ts";

async function fetchAll(entity, query, options = {}) {
  const limit = options.limit || 500;
  let allItems = [];
  let cursor = undefined;
  while (true) {
    const page = await entity.filter(query, { ...options, limit, cursor });
    allItems = allItems.concat(page.items || []);
    cursor = page.next_cursor;
    if (!cursor || !page.has_more) break;
  }
  return allItems;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { company_id, include_cross_entity = true } = await req.json();
    if (!company_id) {
      return Response.json({ error: 'company_id is required' }, { status: 400 });
    }

    const auditRunId = `AUD-${Date.now()}`;
    const now = new Date().toISOString();

    // 1. Load all OrgProcess records for hierarchy checks
    const processes = await fetchAll(
      base44.asServiceRole.entities.OrgProcess,
      { company_id },
      { limit: 500, fields: ['id', 'process_code', 'name', 'level', 'parent_id', 'value_chain_id', 'value_chain', 'workstream_id', 'workstream', 'status'] }
    );

    // 2. Run hierarchy checks
    const hierarchyFindings = runHierarchyChecks(processes);

    // 3. Run cross-entity audit (reuse existing function)
    let crossEntityFindings = [];
    if (include_cross_entity) {
      try {
        const ceResult = await base44.functions.invoke('runCrossEntityAudit', { company_id });
        if (ceResult?.findings) {
          crossEntityFindings = ceResult.findings.map(f => convertCrossEntityFinding(f, company_id));
        }
      } catch (e) {
        console.log('Cross-entity audit failed, continuing with hierarchy only:', e.message);
      }
    }

    // 4. Merge all findings
    const allFindings = [...hierarchyFindings, ...crossEntityFindings];

    // 5. Load existing exceptions
    const exceptions = await fetchAll(
      base44.asServiceRole.entities.AuditException,
      { company_id, status: 'active' },
      { limit: 500, fields: ['id', 'rule_id', 'entity_type', 'entity_id', 'relationship_fingerprint', 'status', 'rationale', 'accepted_at', 'accepted_by', 'finding_summary'] }
    );

    // 6. Suppress findings with active exceptions (fingerprint comparison)
    const { actionable, suppressed, invalidated_exceptions } = suppressWithExceptions(allFindings, exceptions);

    // 7. Load previous findings for change detection
    const previousFindings = await fetchAll(
      base44.asServiceRole.entities.IntegrityFinding,
      { company_id, status: { $in: ['new', 'existing', 'recurring', 'exception_invalidated'] } },
      { limit: 1000, fields: ['id', 'finding_key', 'rule_id', 'entity_type', 'entity_id', 'status', 'first_detected_at', 'last_detected_at'] }
    );

    // 8. Classify findings (new, existing, resolved, recurring)
    const classification = classifyFindings(actionable, previousFindings, exceptions);

    // 9. Persist findings (upsert by finding_key)
    const previousByKey = new Map(previousFindings.map(f => [f.finding_key, f]));
    const findingsToUpsert = [];

    for (const f of actionable) {
      const key = makeFindingKey(f.rule_id, f.entity_type, f.entity_id, f.related_entity_id);
      const prev = previousByKey.get(key);
      const status = prev ? (prev.status === 'resolved' ? 'recurring' : 'existing') : 'new';

      findingsToUpsert.push({
        company_id,
        finding_key: key,
        rule_id: f.rule_id,
        rule_version: f.rule_version,
        audit_type: f.audit_type,
        finding_type: f.finding_type,
        severity: f.severity,
        validation_category: f.validation_category,
        applicability: f.applicability,
        is_exceptionable: f.is_exceptionable,
        entity_type: f.entity_type,
        entity_id: f.entity_id,
        entity_name: f.entity_name,
        entity_code: f.entity_code,
        related_entity_type: f.related_entity_type,
        related_entity_id: f.related_entity_id,
        related_entity_name: f.related_entity_name,
        existing_relationship: f.existing_relationship,
        proposed_relationship: f.proposed_relationship,
        justification: f.justification,
        confidence_score: f.confidence_score,
        validation_detail: f.validation_detail,
        relationship_fingerprint: f.relationship_fingerprint,
        status,
        first_detected_at: prev?.first_detected_at || now,
        last_detected_at: now,
        audit_run_id: auditRunId,
      });
    }

    // Mark suppressed findings as exception_active
    for (const f of suppressed) {
      const key = makeFindingKey(f.rule_id, f.entity_type, f.entity_id, f.related_entity_id);
      const prev = previousByKey.get(key);
      findingsToUpsert.push({
        company_id,
        finding_key: key,
        rule_id: f.rule_id,
        rule_version: f.rule_version,
        audit_type: f.audit_type,
        finding_type: f.finding_type,
        severity: f.severity,
        validation_category: f.validation_category,
        applicability: f.applicability,
        is_exceptionable: f.is_exceptionable,
        entity_type: f.entity_type,
        entity_id: f.entity_id,
        entity_name: f.entity_name,
        entity_code: f.entity_code,
        related_entity_type: f.related_entity_type,
        related_entity_id: f.related_entity_id,
        related_entity_name: f.related_entity_name,
        existing_relationship: f.existing_relationship,
        proposed_relationship: f.proposed_relationship,
        justification: f.justification,
        confidence_score: f.confidence_score,
        validation_detail: f.validation_detail,
        relationship_fingerprint: f.relationship_fingerprint,
        status: 'exception_active',
        exception_id: f.exception_id,
        first_detected_at: prev?.first_detected_at || now,
        last_detected_at: now,
        audit_run_id: auditRunId,
      });
    }

    // Mark resolved findings (previously detected, not in current run)
    const currentKeys = new Set(findingsToUpsert.map(f => f.finding_key));
    const resolvedUpdates = [];
    for (const prev of previousFindings) {
      if (!currentKeys.has(prev.finding_key) && prev.status !== 'resolved' && prev.status !== 'exception_active') {
        resolvedUpdates.push({
          id: prev.id,
          status: 'resolved',
          resolved_at: now,
        });
      }
    }

    // Invalidate exceptions whose fingerprints changed
    const exceptionInvalidations = [];
    for (const inv of invalidated_exceptions) {
      exceptionInvalidations.push({
        id: inv.exception.id,
        status: 'invalidated',
        invalidated_at: now,
        invalidated_reason: `Relationship fingerprint changed: ${inv.old_fingerprint} → ${inv.new_fingerprint}`,
      });
    }

    // Batch upsert findings (upsert by finding_key)
    if (findingsToUpsert.length > 0) {
      try {
        await base44.asServiceRole.entities.IntegrityFinding.upsert(findingsToUpsert, { key: 'finding_key' });
      } catch (e) {
        console.log('Finding upsert failed, trying individual creates:', e.message);
      }
    }

    // Update resolved findings
    if (resolvedUpdates.length > 0) {
      try {
        await base44.asServiceRole.entities.IntegrityFinding.bulkUpdate(resolvedUpdates);
      } catch (e) {
        console.log('Resolved update failed:', e.message);
      }
    }

    // Invalidate changed exceptions
    if (exceptionInvalidations.length > 0) {
      try {
        await base44.asServiceRole.entities.AuditException.bulkUpdate(exceptionInvalidations);
      } catch (e) {
        console.log('Exception invalidation failed:', e.message);
      }
    }

    // 10. Build dashboard summary
    const bySeverity = { high: 0, medium: 0, low: 0 };
    const byStatus = { new: 0, existing: 0, resolved: 0, exception_active: 0, exception_invalidated: 0, recurring: 0 };
    const byValidationCategory = { technical: 0, semantic: 0 };
    const byAuditType = {};

    for (const f of actionable) {
      bySeverity[f.severity]++;
      byValidationCategory[f.validation_category]++;
      byAuditType[f.audit_type] = (byAuditType[f.audit_type] || 0) + 1;
    }
    for (const item of findingsToUpsert) {
      if (byStatus[item.status] !== undefined) byStatus[item.status]++;
    }

    return Response.json({
      success: true,
      company_id,
      audit_run_id: auditRunId,
      audited_at: now,
      record_counts: {
        processes: processes.length,
      },
      summary: {
        raw_finding_count: allFindings.length,
        actionable_count: actionable.length,
        suppressed_count: suppressed.length,
        distinct_affected_records: classification.distinct_affected_records,
        by_severity: bySeverity,
        by_status: byStatus,
        by_validation_category: byValidationCategory,
        by_audit_type: byAuditType,
      },
      dashboard: {
        new_findings: classification.new_findings.length,
        existing_unresolved: classification.existing_unresolved.length,
        resolved: classification.resolved.length,
        accepted_exceptions: classification.accepted_exceptions.length,
        invalidated_exceptions: classification.invalidated_exceptions.length,
        recurring: classification.recurring.length,
        recommended_corrections: classification.recommended_corrections.length,
        confirmed_structural_failures: classification.confirmed_structural_failures.length,
      },
      findings: actionable,
      suppressed,
      invalidated_exceptions: invalidated_exceptions.map(inv => ({
        exception_id: inv.exception.id,
        rule_id: inv.exception.rule_id,
        entity_type: inv.exception.entity_type,
        entity_id: inv.exception.entity_id,
        old_fingerprint: inv.old_fingerprint,
        new_fingerprint: inv.new_fingerprint,
      })),
      exceptions: {
        active: exceptions.filter(e => e.status === 'active').length,
        invalidated: exceptions.filter(e => e.status === 'invalidated').length + invalidated_exceptions.length,
      },
    });
  } catch (error) {
    console.error('Integrity audit error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}