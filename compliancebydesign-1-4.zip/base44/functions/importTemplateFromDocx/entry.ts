import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import mammoth from 'npm:mammoth@1.8.0';

function stripTags(html) {
  return String(html)
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function detectBlockType(body) {
  if (/<table[\s>]/i.test(body)) return "table";
  if (/<img[\s>]/i.test(body)) return "image";
  if (/<ul[\s>]|<ol[\s>]/i.test(body)) return "list";
  return "narrative";
}

function parseHtml(html, filename) {
  const headingRe = /<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi;
  const matches = [];
  let m;
  while ((m = headingRe.exec(html)) !== null) {
    matches.push({ level: Number(m[1]), text: stripTags(m[2]), start: m.index, end: m.index + m[0].length });
  }
  if (matches.length === 0) {
    return {
      templateName: filename ? filename.replace(/\.docx$/i, "") : "Imported Template",
      sections: [{ order: 1, section_title: "Imported content", block_type: detectBlockType(html), content_preview: stripTags(html).slice(0, 300) }],
    };
  }
  const sections = matches.map((h, i) => {
    const bodyEnd = i + 1 < matches.length ? matches[i + 1].start : html.length;
    const body = html.slice(h.end, bodyEnd);
    return { level: h.level, text: h.text, body };
  });
  const titleIdx = sections.findIndex((s) => s.level === 1);
  let templateName;
  let sectionList;
  if (titleIdx >= 0) {
    templateName = sections[titleIdx].text || (filename ? filename.replace(/\.docx$/i, "") : "Imported Template");
    sectionList = sections.filter((_, i) => i !== titleIdx);
  } else {
    templateName = (filename ? filename.replace(/\.docx$/i, "") : "") || sections[0].text || "Imported Template";
    sectionList = sections;
  }
  const parsed = sectionList.map((s, i) => ({
    order: i + 1,
    section_title: s.text || `Section ${i + 1}`,
    block_type: detectBlockType(s.body),
    content_preview: stripTags(s.body).slice(0, 300),
  }));
  return { templateName, sections: parsed };
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    if (user.role !== "admin") return Response.json({ error: "Forbidden: admin only" }, { status: 403 });

    const body = await req.json();
    const fileUri = body.file_uri;
    if (!fileUri) return Response.json({ error: "file_uri is required" }, { status: 400 });
    const filename = body.filename || "Imported Template";

    const signed = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({ file_uri: fileUri });
    const signedUrl = signed.signed_url || signed.file_url;
    const resp = await fetch(signedUrl, { signal: AbortSignal.timeout(20000) });
    if (!resp.ok) return Response.json({ error: "Failed to fetch uploaded file: " + resp.status }, { status: 502 });
    const ab = await resp.arrayBuffer();
    const result = await mammoth.convertToHtml({ buffer: new Uint8Array(ab) });
    const parsed = parseHtml(result.value, filename);
    return Response.json({ parsed, warningCount: (result.messages || []).length });
  } catch (error) {
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
}