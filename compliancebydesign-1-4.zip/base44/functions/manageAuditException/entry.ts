import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { computeFingerprint, makeFindingKey, isExceptionable } from "../../shared/integrityAuditRules.ts";

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { action, company_id, finding, exception_id, rationale } = await req.json();
    if (!company_id) return Response.json({ error: 'company_id is required' }, { status: 400 });

    const now = new Date().toISOString();

    if (action === 'accept') {
      // Accept a finding as an exception
      if (!finding || !rationale) {
        return Response.json({ error: 'finding and rationale are required to accept an exception' }, { status: 400 });
      }

      // Check if the finding is exceptionable
      if (!isExceptionable(finding.rule_id, finding.validation_category, finding.finding_type)) {
        return Response.json({
          error: 'This finding represents a non-negotiable integrity constraint and cannot be accepted as an exception. Fix the underlying data issue instead.',
        }, { status: 400 });
      }

      // Build hierarchy attributes for the fingerprint
      const hierarchyAttrs: Record<string, any> = {};
      if (finding.validation_detail?.source_fields) {
        for (const [k, v] of Object.entries(finding.validation_detail.source_fields)) {
          if (k.includes('id') || k.includes('code') || k === 'level' || k === 'status') {
            hierarchyAttrs[k] = v;
          }
        }
      }
      if (finding.validation_detail?.target_fields) {
        for (const [k, v] of Object.entries(finding.validation_detail.target_fields)) {
          if (k.includes('id') || k.includes('code') || k === 'level' || k === 'status') {
            hierarchyAttrs[`target_${k}`] = v;
          }
        }
      }

      const fingerprint = finding.relationship_fingerprint || computeFingerprint(hierarchyAttrs);

      // Check if an active exception already exists for this finding
      const existing = await base44.asServiceRole.entities.AuditException.filter(
        { company_id, entity_type: finding.entity_type, entity_id: finding.entity_id, rule_id: finding.rule_id, status: 'active' },
        { limit: 1 }
      );

      if (existing.items && existing.items.length > 0) {
        // Update existing exception with new rationale
        const ex = existing.items[0];
        await base44.asServiceRole.entities.AuditException.update(ex.id, {
          rationale,
          relationship_fingerprint: fingerprint,
          hierarchy_attributes: hierarchyAttrs,
          last_verified_at: now,
          accepted_by: user.email,
          accepted_at: now,
        });
        return Response.json({ success: true, exception_id: ex.id, action: 'updated' });
      }

      // Create new exception
      const exception = await base44.asServiceRole.entities.AuditException.create({
        company_id,
        entity_type: finding.entity_type,
        entity_id: finding.entity_id,
        entity_name: finding.entity_name,
        entity_code: finding.entity_code,
        rule_id: finding.rule_id,
        rule_version: finding.rule_version || '1.0',
        audit_type: finding.audit_type,
        finding_type: finding.finding_type,
        finding_severity: finding.severity,
        finding_summary: finding.existing_relationship,
        related_entity_ids: finding.related_entity_id ? [finding.related_entity_id] : [],
        hierarchy_attributes: hierarchyAttrs,
        relationship_fingerprint: fingerprint,
        rationale,
        accepted_at: now,
        accepted_by: user.email,
        status: 'active',
        last_verified_at: now,
      });

      // Update the corresponding IntegrityFinding to exception_active
      const findingKey = makeFindingKey(finding.rule_id, finding.entity_type, finding.entity_id, finding.related_entity_id);
      const findings = await base44.asServiceRole.entities.IntegrityFinding.filter(
        { company_id, finding_key: findingKey },
        { limit: 1 }
      );
      if (findings.items && findings.items.length > 0) {
        await base44.asServiceRole.entities.IntegrityFinding.update(findings.items[0].id, {
          status: 'exception_active',
          exception_id: exception.id,
        });
      }

      return Response.json({ success: true, exception_id: exception.id, action: 'created' });
    }

    if (action === 'invalidate') {
      // Manually invalidate an exception
      if (!exception_id) {
        return Response.json({ error: 'exception_id is required to invalidate' }, { status: 400 });
      }
      await base44.asServiceRole.entities.AuditException.update(exception_id, {
        status: 'invalidated',
        invalidated_at: now,
        invalidated_reason: rationale || 'Manually invalidated by admin',
      });

      // Update corresponding finding back to existing
      const ex = await base44.asServiceRole.entities.AuditException.get(exception_id);
      if (ex) {
        const findingKey = makeFindingKey(ex.rule_id, ex.entity_type, ex.entity_id, '');
        const findings = await base44.asServiceRole.entities.IntegrityFinding.filter(
          { company_id, finding_key: findingKey },
          { limit: 1 }
        );
        if (findings.items && findings.items.length > 0) {
          await base44.asServiceRole.entities.IntegrityFinding.update(findings.items[0].id, {
            status: 'existing',
            exception_id: '',
          });
        }
      }

      return Response.json({ success: true, action: 'invalidated' });
    }

    if (action === 'list') {
      // List all exceptions for the company
      const exceptions = await base44.asServiceRole.entities.AuditException.filter(
        { company_id },
        { sort: '-accepted_at', limit: 500 }
      );
      return Response.json({ exceptions: exceptions.items || [] });
    }

    return Response.json({ error: 'Unknown action. Use accept, invalidate, or list.' }, { status: 400 });
  } catch (error) {
    console.error('Manage audit exception error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}