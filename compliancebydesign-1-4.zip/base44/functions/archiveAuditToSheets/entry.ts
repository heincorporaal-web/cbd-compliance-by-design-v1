import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const SPREADSHEET_TITLE = "CBD Audit Master Ledger";
const SHEET_NAME = "Audit Ledger";

const HEADERS = [
  "Timestamp",
  "Audit Log ID",
  "User Email",
  "User Name",
  "Action",
  "Event Type",
  "Entity Type",
  "Entity ID",
  "Entity Name",
  "Company ID",
  "Changed Fields",
  "Before",
  "After",
  "IP Address",
];

// Truncate long JSON to keep cells readable
function trunc(obj, max = 500) {
  if (!obj) return "";
  const s = typeof obj === "string" ? obj : JSON.stringify(obj);
  return s.length > max ? s.slice(0, max) + "…" : s;
}

// Build a row array from an AuditLog record
function buildRow(record) {
  const changes = record.changes || {};
  return [
    record.created_date || new Date().toISOString(),
    record.id || "",
    record.user_email || "",
    record.user_name || "",
    record.action || "",
    record.event_type || "",
    record.entity_type || "",
    record.entity_id || "",
    record.entity_name || "",
    record.company_id || "",
    trunc(changes.changed_fields),
    trunc(changes.before),
    trunc(changes.after),
    record.ip_address || "",
  ];
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    const { event, data, args = {} } = payload;

    // Only archive on create events (AuditLog records are created, not updated)
    if (event?.type !== "create") {
      return Response.json({ skipped: true, reason: "not_a_create_event" });
    }
    if (!data) {
      return Response.json({ skipped: true, reason: "no_data" });
    }

    const { accessToken } = await base44.asServiceRole.connectors.getConnection("googlesheets");
    const authHeader = { "Authorization": `Bearer ${accessToken}`, "Content-Type": "application/json" };

    let spreadsheetId = process.env.AUDIT_LEDGER_SPREADSHEET_ID;

    // If no spreadsheet ID configured, create a new master ledger spreadsheet
    if (!spreadsheetId) {
      const createRes = await fetch("https://sheets.googleapis.com/v4/spreadsheets", {
        method: "POST",
        headers: authHeader,
        body: JSON.stringify({
          properties: { title: SPREADSHEET_TITLE },
          sheets: [{ properties: { title: SHEET_NAME } }],
        }),
      });
      const createText = await createRes.text();
      if (!createRes.ok) {
        return Response.json({ error: `Failed to create spreadsheet: ${createText}` }, { status: 400 });
      }
      const created = JSON.parse(createText);
      spreadsheetId = created.spreadsheetId;

      // Write header row
      await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(SHEET_NAME)}!A1:N1?valueInputOption=RAW`, {
        method: "PUT",
        headers: authHeader,
        body: JSON.stringify({ values: [HEADERS] }),
      });

      // Bold + freeze the header row for readability
      await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
        method: "POST",
        headers: authHeader,
        body: JSON.stringify({
          requests: [
            {
              repeatCell: {
                range: { sheetId: 0, startRowIndex: 0, endRowIndex: 1 },
                cellFormat: { textFormat: { bold: true } },
              },
            },
            {
              updateSheetProperties: {
                properties: { sheetId: 0, gridProperties: { frozenRowCount: 1 } },
                fields: "gridProperties.frozenRowCount",
              },
            },
          ],
        }),
      });
    }

    // Append the audit log entry as a new row
    const row = buildRow(data);
    const appendRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(SHEET_NAME)}!A:N:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
      {
        method: "POST",
        headers: authHeader,
        body: JSON.stringify({ values: [row] }),
      }
    );
    const appendText = await appendRes.text();
    if (!appendRes.ok) {
      return Response.json({ error: `Failed to append row: ${appendText}` }, { status: 400 });
    }

    const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

    return Response.json({
      success: true,
      spreadsheet_id: spreadsheetId,
      spreadsheet_url: spreadsheetUrl,
      archived_entity: data.entity_name || data.entity_type,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});