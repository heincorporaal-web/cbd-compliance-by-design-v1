import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

const RISK_FIELDS = [
  'risk_reference_nr', 'title', 'risk_statement', 'description', 'category',
  'risk_type', 'likelihood', 'impact', 'inherent_risk_score', 'root_cause',
  'root_cause_type', 'value_chain', 'sub_process', 'workstream', 'process_activity',
  'framework_reference', 'library_status', 'library_end_date',
];

const CONTROL_FIELDS = [
  'control_id', 'title', 'description', 'category', 'priority', 'status',
  'control_criticality', 'control_owner', 'key_control', 'control_execution_type',
  'control_type', 'control_frequency', 'process_phase', 'framework_id',
  'control_objective_id', 'library_status', 'library_end_date',
];

async function fetchAll(base44, entityName, query, fields) {
  const all = [];
  let cursor = undefined;
  for (;;) {
    const opts = { limit: 500, fields };
    if (cursor) opts.cursor = cursor;
    const page = await base44.entities[entityName].filter(query, opts);
    all.push(...page.items);
    if (!page.has_more) break;
    cursor = page.next_cursor;
  }
  return all;
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const library = body?.library;

    const result = {};

    if (!library || library === 'risk_library' || library === 'both') {
      result.risks = await fetchAll(base44, 'Risk', { is_library_risk: true }, RISK_FIELDS);
    }
    if (!library || library === 'control_library' || library === 'both') {
      result.controls = await fetchAll(base44, 'Control', { is_library_control: true }, CONTROL_FIELDS);
    }

    return Response.json({
      status: 'success',
      riskFields: RISK_FIELDS,
      controlFields: CONTROL_FIELDS,
      riskCount: result.risks?.length ?? 0,
      controlCount: result.controls?.length ?? 0,
      ...result,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}