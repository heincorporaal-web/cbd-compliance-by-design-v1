import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden — admin only' }, { status: 403 });

    const body = await req.json();
    const companyId = body?.company_id;
    if (!companyId) return Response.json({ error: 'company_id is required' }, { status: 400 });

    // ── Read the retention period from CompanyPreference ──────────────────
    const prefsResult = await base44.asServiceRole.entities.CompanyPreference.filter({ company_id: companyId });
    const prefs = Array.isArray(prefsResult) ? prefsResult : (prefsResult.items || []);
    const retentionMonths = (prefs[0] && prefs[0].stakeholder_retention_months) || 84;

    // ── Calculate the cutoff date (today minus retention months) ─────────
    const cutoff = new Date();
    cutoff.setMonth(cutoff.getMonth() - retentionMonths);
    const cutoffStr = cutoff.toISOString().split('T')[0]; // YYYY-MM-DD

    // ── Find terminated stakeholders past the retention period ───────────
    const purgeFilter = {
      company_id: companyId,
      end_date: { $lt: cutoffStr },
    };

    const stakeholderResult = await base44.asServiceRole.entities.Stakeholder.filter(purgeFilter);
    const stakeholders = Array.isArray(stakeholderResult) ? stakeholderResult : (stakeholderResult.items || []);

    if (stakeholders.length === 0) {
      return Response.json({
        purged_count: 0,
        history_count: 0,
        retention_months: retentionMonths,
        cutoff_date: cutoffStr,
        message: 'No terminated stakeholders past the retention period.',
      });
    }

    const stakeholderIds = stakeholders.map((s) => s.id);

    // ── Delete related StakeholderHistory records ────────────────────────
    let historyCount = 0;
    try {
      const histResult = await base44.asServiceRole.entities.StakeholderHistory.deleteMany({
        stakeholder_id: { $in: stakeholderIds },
      });
      historyCount = histResult?.deleted_count || histResult?.count || 0;
    } catch (e) {
      // Continue even if history deletion fails — stakeholders are the priority
    }

    // ── Delete the stakeholders ──────────────────────────────────────────
    let purgedCount = 0;
    try {
      const delResult = await base44.asServiceRole.entities.Stakeholder.deleteMany(purgeFilter);
      purgedCount = delResult?.deleted_count || delResult?.count || stakeholders.length;
    } catch (e) {
      // Fallback: delete individually
      for (const s of stakeholders) {
        try {
          await base44.asServiceRole.entities.Stakeholder.delete(s.id);
          purgedCount++;
        } catch (e2) {
          // Continue on individual errors
        }
      }
    }

    return Response.json({
      purged_count: purgedCount,
      history_count: historyCount,
      retention_months: retentionMonths,
      cutoff_date: cutoffStr,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}