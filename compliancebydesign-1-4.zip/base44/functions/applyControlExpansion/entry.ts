import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { company_id, items } = await req.json();
    if (!company_id || !Array.isArray(items) || items.length === 0) {
      return Response.json({ error: 'company_id and non-empty items array required' }, { status: 400 });
    }

    // Only process items with action "create" or "update_existing"
    const toCreate = items.filter(i => i.action === 'create');
    const toUpdate = items.filter(i => i.action === 'update_existing');
    const skipped = items.filter(i => i.action === 'skip' || i.action === 'reject');

    const report = {
      created: 0,
      updated: 0,
      skipped: skipped.length,
      errors: 0,
      links: { objectives: 0, processes: 0, value_chains: 0, owners: 0 },
      risk_links_created: 0, // always 0 — risk links are never auto-created
      details: [],
    };

    // --- Create new controls ---
    const createdControls = [];
    for (const item of toCreate) {
      try {
        const raw = { ...item.raw_fields };
        // Set owner stakeholder if resolved
        if (item.owner_resolution?.type === 'stakeholder' && item.owner_resolution.matches?.length === 1) {
          raw.owner_stakeholder_id = item.owner_resolution.matches[0].stakeholder_id;
        }
        // Set control objective if matched
        if (item.objective_link?.match?.id) {
          raw.control_objective_id = item.objective_link.match.id;
        }

        const created = await base44.asServiceRole.entities.Control.create(raw);
        createdControls.push({ item, control: created });
        report.created++;
        report.details.push({
          control_id: raw.control_id,
          action: 'created',
          control_db_id: created.id,
          owner_set: !!raw.owner_stakeholder_id,
          objective_set: !!raw.control_objective_id,
        });

        if (raw.owner_stakeholder_id) report.links.owners++;
        if (raw.control_objective_id) report.links.objectives++;
      } catch (e) {
        report.errors++;
        report.details.push({ control_id: item.control_id, action: 'create_error', error: e.message });
      }
    }

    // --- Update existing controls (improve description only) ---
    for (const item of toUpdate) {
      try {
        if (!item.duplicate_match?.existing_id) {
          report.skipped++;
          report.details.push({ control_id: item.control_id, action: 'skipped_no_existing_id' });
          continue;
        }
        const update = {
          id: item.duplicate_match.existing_id,
          description: item.raw_fields.description, // improved description
        };
        await base44.asServiceRole.entities.Control.update(item.duplicate_match.existing_id, update);
        report.updated++;
        report.details.push({
          control_id: item.control_id,
          action: 'updated_existing',
          existing_id: item.duplicate_match.existing_id,
          existing_control_id: item.duplicate_match.existing_control_id,
        });
      } catch (e) {
        report.errors++;
        report.details.push({ control_id: item.control_id, action: 'update_error', error: e.message });
      }
    }

    // --- Link controls to org processes ---
    for (const { item, control } of createdControls) {
      if (item.process_link?.match?.id) {
        try {
          const proc = await base44.asServiceRole.entities.OrgProcess.get(item.process_link.match.id);
          if (proc) {
            const existingLinks = proc.linked_control_ids || [];
            if (!existingLinks.includes(control.id)) {
              existingLinks.push(control.id);
              await base44.asServiceRole.entities.OrgProcess.update(proc.id, { linked_control_ids: existingLinks });
              report.links.processes++;
            }
          }
        } catch (e) {
          // non-fatal
          console.log(`Process link error for ${item.control_id}: ${e.message}`);
        }
      }
    }

    // --- Note value chain links (indirect through process) ---
    for (const { item } of createdControls) {
      if (item.value_chain_link?.match?.id) {
        report.links.value_chains++;
      }
    }

    // --- Risk-control links: NOT created (per requirement) ---
    // report.risk_links_created stays 0

    return Response.json({
      success: true,
      company_id,
      applied_at: new Date().toISOString(),
      report,
      reconciliation: {
        existing_controls_reused: report.updated,
        new_controls_created: report.created,
        duplicates_avoided: toUpdate.length,
        relationships_approved: {
          objectives: report.links.objectives,
          processes: report.links.processes,
          value_chains: report.links.value_chains,
          owners: report.links.owners,
        },
        risk_control_links_created: 0,
        risk_control_links_skipped: toCreate.filter(i => i.risk_match?.status === 'candidate').length,
        unresolved_mappings: {
          owners: toCreate.filter(i => i.owner_resolution?.type === 'none' || i.owner_resolution?.type === 'ambiguous').length,
          objectives: toCreate.filter(i => !i.objective_link?.match).length,
          processes: toCreate.filter(i => !i.process_link?.match).length,
          value_chains: toCreate.filter(i => !i.value_chain_link?.match).length,
        },
        skipped: report.skipped,
        errors: report.errors,
      },
    });
  } catch (error) {
    console.error('Apply error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}