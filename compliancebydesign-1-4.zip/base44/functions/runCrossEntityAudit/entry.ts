import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// ── Pagination helper ─────────────────────────────────────────────────────────
// Corrective Action #1: Ensures the audit retrieves the full company population
// through cursor-based pagination, not just the first 1,000 records.

async function fetchAll(entity, query, options = {}) {
  const limit = options.limit || 500;
  let allItems = [];
  let cursor = undefined;
  while (true) {
    const page = await entity.filter(query, { ...options, limit, cursor });
    const items = page.items || [];
    allItems = allItems.concat(items);
    cursor = page.next_cursor;
    if (!cursor || !page.has_more) break;
  }
  return allItems;
}

// ── Text similarity helpers (advisory only — not sole validation basis) ───────

const STOP_WORDS = new Set([
  'the','a','an','and','or','but','of','to','in','for','on','at','by','with','from',
  'is','are','was','were','be','been','being','this','that','these','those','it',
  'as','if','then','than','so','no','not','can','will','just','should','now',
  'process','management','ensure','via','using','through','which','their',
  'such','also','each','all','any','may','might','must','shall','do','does','did',
]);

function tokenize(text) {
  if (!text) return [];
  return String(text)
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !STOP_WORDS.has(w));
}

function jaccard(a, b) {
  const sa = new Set(a), sb = new Set(b);
  if (sa.size === 0 || sb.size === 0) return 0;
  let inter = 0;
  for (const w of sa) if (sb.has(w)) inter++;
  return inter / (sa.size + sb.size - inter);
}

function similarity(textA, textB) {
  return Math.round(jaccard(tokenize(textA), tokenize(textB)) * 100);
}

function rec(id, name, code, type) {
  return { id: id || '', name: name || '', code: code || '', type };
}

// ── Invalid control reference rejection (Requirement #3) ────────────────────
// Reject any matching recommendation whose target control title or reference
// is "0", blank, or unresolved.

function isControlReferenceValid(control) {
  if (!control) return false;
  const title = String(control.title || '').trim();
  const ref = String(control.control_id || '').trim();
  const invalidValues = ['', '0', '—', '-', 'null', 'undefined', 'n/a', 'na', 'none', 'unresolved'];
  if (invalidValues.includes(title.toLowerCase())) return false;
  if (invalidValues.includes(ref.toLowerCase())) return false;
  return true;
}

// ── Inappropriate role exclusion for Trading/Settlement (Requirement #6) ────
// Stop proposing HR, privacy or unrelated Finance roles for Trading and
// Settlement processes unless documented accountability justifies them.

const INAPPROPRIATE_TRADING_ROLE_KEYWORDS = [
  'hr', 'human resources', 'payroll', 'recruitment', 'talent',
  'privacy', 'dpo', 'data protection',
  'marketing', 'communications', 'brand',
  'facilities', 'property', 'real estate',
];

function isInappropriateTradingRole(stakeholder) {
  const title = (stakeholder.job_title || '').toLowerCase();
  const dept = (stakeholder.department || '').toLowerCase();
  return INAPPROPRIATE_TRADING_ROLE_KEYWORDS.some(kw =>
    title.includes(kw) || dept.includes(kw)
  );
}

// ── Manufacturing/procurement/supply-chain detection for processes (Req #8) ──

function isManufacturingProcess(p) {
  const text = `${p.name || ''} ${p.description || ''} ${p.process_code || ''}`.toLowerCase();
  return MANUFACTURING_KEYWORDS.some(k => text.includes(k));
}

let findingCounter = 0;

function makeFinding(auditType, findingType, severity, source, target, existing, proposed, justification, confidence, options = {}) {
  findingCounter++;
  return {
    id: `F${String(findingCounter).padStart(4, '0')}`,
    audit_type: auditType,
    finding_type: findingType,
    validation_category: options.category || 'technical',
    applicability: options.applicability || 'mandatory',
    severity,
    source_record: source,
    target_record: target,
    existing_relationship: existing,
    proposed_relationship: proposed,
    justification,
    confidence_score: Math.max(0, Math.min(100, Math.round(confidence))),
    validation_detail: options.validation_detail || null,
    // Corrective Action #11: Proposed risk-control association context
    proposed_association: options.proposed_association || null,
  };
}

// ── Mechanism-based control assessment (Corrective Actions #8, #9) ─────────────
// Replaces text-similarity-only validation with a mechanism-based assessment
// of preventive, detective, corrective and governance controls.

function classifyControlMechanism(control) {
  const title = (control.title || '').toLowerCase();
  const desc = (control.description || '').toLowerCase();
  const text = `${title} ${desc}`;
  const isGovernance = /board|committee|govern|policy approval|oversight|directive|mandate|tone at top/.test(text);
  return {
    mechanism_type: control.control_type || 'Preventive',
    is_governance: isGovernance,
    execution: control.control_execution_type || 'Manual',
    frequency: control.control_frequency || 'Monthly',
    phase: control.process_phase || 'Process - Input',
  };
}

function riskCategoryMechanisms(riskCategory) {
  const cat = (riskCategory || 'operational').toLowerCase();
  const mechanisms = {
    financial: ['Preventive', 'Detective', 'Corrective'],
    operational: ['Preventive', 'Detective', 'Corrective'],
    strategic: ['Preventive', 'Detective'],
    compliance: ['Preventive', 'Detective'],
    cyber_security: ['Preventive', 'Detective', 'Corrective'],
    third_party: ['Preventive', 'Detective'],
    reputational: ['Preventive', 'Detective'],
    technology: ['Preventive', 'Detective', 'Corrective'],
  };
  return mechanisms[cat] || ['Preventive', 'Detective', 'Corrective'];
}

function isMechanismAppropriate(risk, control) {
  const ctrlMechanism = classifyControlMechanism(control);
  const appropriate = riskCategoryMechanisms(risk.category);
  return appropriate.includes(ctrlMechanism.mechanism_type);
}

// Check functional domain overlap between risk and control.
// Corrective Action #9: Do not reject existing market-risk, trading or
// reconciliation controls because of low title similarity.
function domainOverlap(risk, control) {
  const riskDomain = `${risk.value_chain || ''} ${risk.workstream || ''} ${risk.sub_process || ''} ${risk.process_activity || ''}`.toLowerCase();
  const ctrlDomain = `${control.category || ''} ${control.title || ''}`.toLowerCase();

  // If either side has no domain info, can't determine — don't reject
  if (!riskDomain.trim() || !ctrlDomain.trim()) return { overlap: true, score: 50, reason: 'Insufficient domain data — cannot rule out relevance' };

  const riskTokens = tokenize(riskDomain);
  const ctrlTokens = tokenize(ctrlDomain);
  if (riskTokens.length === 0 || ctrlTokens.length === 0) return { overlap: true, score: 50, reason: 'Insufficient domain tokens' };

  let shared = 0;
  for (const t of riskTokens) if (ctrlTokens.includes(t)) shared++;

  // Domain-specific keyword matching for investment-bank controls
  const domainKeywords = {
    'trading': ['trade', 'trading', 'front office', 'desk', 'position', 'market risk', 'var'],
    'reconciliation': ['reconcil', 'break', 'match', 'nomatch', 'exception'],
    'settlement': ['settle', 'settlement', 'clearing', 'custody', 'depositary'],
    'confirmation': ['confirm', 'affirm', 'match'],
    'finance': ['financial', 'ledger', 'close', 'journal', 'reporting', 'ifrs'],
    'it': ['access', 'system', 'data', 'change', 'cyber', 'security', 'infrastructure'],
    'compliance': ['compliance', 'regulatory', 'aml', 'kyc', 'sanction'],
  };

  for (const [domain, keywords] of Object.entries(domainKeywords)) {
    const riskHasDomain = keywords.some(k => riskDomain.includes(k));
    const ctrlHasDomain = keywords.some(k => ctrlDomain.includes(k));
    if (riskHasDomain && ctrlHasDomain) {
      return { overlap: true, score: 80, reason: `Shared domain: ${domain}` };
    }
  }

  if (shared > 0) return { overlap: true, score: 50 + shared * 10, reason: `${shared} shared domain token(s)` };
  return { overlap: false, score: 0, reason: 'No domain overlap between risk and control' };
}

// ── Applicability helpers ─────────────────────────────────────────────────────

function processOwnerApplicability(p) {
  if (p.status === 'archived') return 'not_applicable';
  if (p.level != null && p.level <= 2) return 'optional';
  return 'mandatory';
}

function processRiskApplicability(p) {
  if (p.status === 'archived') return 'not_applicable';
  if (p.level != null && p.level <= 2) return 'optional';
  return 'mandatory';
}

function workstreamProcessApplicability(ws) {
  if (ws.status === 'archived' || ws.is_active === false) return 'not_applicable';
  return 'mandatory';
}

function valueChainWorkstreamApplicability(vc) {
  if (vc.status === 'archived' || vc.is_active === false) return 'not_applicable';
  return 'mandatory';
}

function riskControlApplicability(r) {
  if (r.status === 'draft' || r.is_library_risk) return 'optional';
  return 'mandatory';
}

// Corrective Action #4: Flag manufacturing and physical supply-chain workstreams
// that are not applicable to EVI Trading's investment-bank operating model.
const MANUFACTURING_KEYWORDS = ['manufacturing', 'production', 'assembly line', 'factory', 'warehouse', 'physical supply chain', 'raw material', 'inventory management', 'procurement of goods', 'shipping', 'freight', 'logistics'];

function isManufacturingWorkstream(ws) {
  const text = `${ws.name || ''} ${ws.description || ''} ${ws.full_label || ''}`.toLowerCase();
  return MANUFACTURING_KEYWORDS.some(k => text.includes(k));
}

// Corrective Action #5: Workstreams that must have unique codes
const SECRETARIAT_WORKSTREAM_NAMES = ['company secretariat', 'board secretariat', 'executive management office', 'exec office', 'emo'];

function isSecretariatWorkstream(ws) {
  const name = (ws.name || '').toLowerCase();
  return SECRETARIAT_WORKSTREAM_NAMES.some(s => name.includes(s));
}

// Corrective Action #7: Trading subprocesses requiring functional owner roles
const TRADING_SUBPROCESS_KEYWORDS = ['trading', 'confirmation', 'settlement', 'custody', 'clearing', 'trade execution', 'trade capture'];

function isTradingSubprocess(p) {
  const text = `${p.name || ''} ${p.process_code || ''}`.toLowerCase();
  return TRADING_SUBPROCESS_KEYWORDS.some(k => text.includes(k));
}

// ── Audit 1: Value Chains → Workstreams ──────────────────────────────────────

function auditValueChainWorkstream(valueChains, workstreams, company) {
  const findings = [];
  const wsByVC = {};
  for (const ws of workstreams) {
    const key = ws.value_chain_id || '';
    if (!wsByVC[key]) wsByVC[key] = [];
    wsByVC[key].push(ws);
  }

  for (const vc of valueChains) {
    const wsList = wsByVC[vc.id] || [];
    const appl = valueChainWorkstreamApplicability(vc);
    if (wsList.length === 0 && appl !== 'not_applicable') {
      findings.push(makeFinding(
        'value_chain_workstream', 'missing', appl === 'optional' ? 'low' : 'high',
        rec(vc.id, vc.name, vc.value_chain_code, 'ValueChain'),
        null,
        'No workstreams assigned',
        null,
        `Value chain "${vc.name}" has no workstreams. Every value chain should be decomposed into at least one workstream.`,
        100,
        {
          applicability: appl,
          validation_detail: {
            rule: 'value_chain_must_have_workstream',
            source_value: vc.id,
            target_value: null,
            source_fields: { name: vc.name, value_chain_code: vc.value_chain_code, status: vc.status, is_active: vc.is_active },
            target_fields: null,
            evidence: `Workstream lookup by value_chain_id="${vc.id}" returned 0 results out of ${workstreams.length} total workstreams.`,
            resolution: 'Create at least one workstream and assign it to this value chain.',
          },
        }
      ));
    }
  }

  // Workstreams assigned to non-existent value chains (TECHNICAL INVALID)
  // Corrective Action #4: Flag manufacturing/physical supply-chain as not applicable
  const vcIds = new Set(valueChains.map(vc => vc.id));
  for (const ws of workstreams) {
    if (ws.value_chain_id && !vcIds.has(ws.value_chain_id)) {
      const isMfg = isManufacturingWorkstream(ws);
      findings.push(makeFinding(
        'value_chain_workstream', 'invalid', isMfg ? 'medium' : 'high',
        rec(ws.id, ws.name, ws.workstream_code, 'Workstream'),
        null,
        `References value chain ID "${ws.value_chain_id}" which does not exist`,
        isMfg
          ? 'Flag as not applicable — manufacturing/physical supply-chain is outside the investment-bank operating model'
          : 'Reassign to a valid value chain or remove the orphaned workstream',
        isMfg
          ? `Workstream "${ws.name}" references a non-existent value chain and appears to be a manufacturing/physical supply-chain workstream not applicable to EVI Trading's investment-bank operating model.`
          : `Workstream "${ws.name}" references a value chain that has been deleted or does not exist.`,
        isMfg ? 85 : 95,
        {
          category: isMfg ? 'semantic' : 'technical',
          applicability: isMfg ? 'not_applicable' : 'mandatory',
          validation_detail: {
            rule: isMfg ? 'workstream_not_applicable_manufacturing' : 'workstream_value_chain_id_must_resolve',
            source_value: ws.value_chain_id,
            target_value: null,
            source_fields: { name: ws.name, workstream_code: ws.workstream_code, value_chain_id: ws.value_chain_id },
            target_fields: null,
            evidence: isMfg
              ? `value_chain_id "${ws.value_chain_id}" not found. Workstream name/description matches manufacturing/physical supply-chain keywords.`
              : `value_chain_id "${ws.value_chain_id}" not found in set of ${vcIds.size} value chain IDs.`,
            resolution: isMfg
              ? 'Flag this workstream as not applicable to the investment-bank operating model. Do not attempt to reassign to a manufacturing value chain.'
              : 'Set value_chain_id to an existing ValueChain record ID, or null if unassigned.',
          },
        }
      ));
    }
  }

  // Duplicate workstream codes (TECHNICAL)
  // Corrective Action #5: Assign unique codes to Company Secretariat, Board
  // Secretariat and Executive Management Office without merging responsibilities.
  const codeMap = {};
  for (const ws of workstreams) {
    const key = `${ws.value_chain_id}::${ws.workstream_code}`;
    if (!codeMap[key]) codeMap[key] = [];
    codeMap[key].push(ws);
  }
  for (const [key, wsList] of Object.entries(codeMap)) {
    if (wsList.length > 1) {
      const hasSecretariat = wsList.some(ws => isSecretariatWorkstream(ws));
      for (const ws of wsList) {
        findings.push(makeFinding(
          'value_chain_workstream', 'duplicate', 'medium',
          rec(ws.id, ws.name, ws.workstream_code, 'Workstream'),
          rec(ws.value_chain_id, '', '', 'ValueChain'),
          `Duplicate workstream code "${ws.workstream_code}" within the same value chain (${wsList.length} occurrences)`,
          hasSecretariat
            ? `Assign unique code to "${ws.name}" (e.g. ${ws.name.toLowerCase().includes('board') ? 'BRD-SEC' : ws.name.toLowerCase().includes('company') ? 'COMP-SEC' : 'EMO'} — do not merge distinct responsibilities)`
            : 'Deduplicate or rename to ensure unique codes',
          hasSecretariat
            ? `Workstream "${ws.name}" shares code "${ws.workstream_code}" with other secretariat/governance workstreams. Each must have a unique code reflecting its distinct responsibilities.`
            : `Workstream code "${ws.workstream_code}" appears ${wsList.length} times within the same value chain.`,
          hasSecretariat ? 92 : 90,
          {
            category: 'technical',
            validation_detail: {
              rule: hasSecretariat ? 'secretariat_workstream_unique_code' : 'workstream_code_unique_within_value_chain',
              source_value: ws.workstream_code,
              target_value: ws.value_chain_id,
              source_fields: { name: ws.name, workstream_code: ws.workstream_code, value_chain_id: ws.value_chain_id },
              target_fields: null,
              evidence: hasSecretariat
                ? `Code "${ws.workstream_code}" shared by ${wsList.length} workstreams including secretariat/governance functions: ${wsList.map(w => w.name).join(', ')}.`
                : `Code "${ws.workstream_code}" found on ${wsList.length} workstreams: ${wsList.map(w => w.id).join(', ')}.`,
              resolution: hasSecretariat
                ? `Assign a unique code to "${ws.name}" that reflects its distinct governance role. Do not merge Company Secretariat, Board Secretariat and Executive Management Office.`
                : 'Rename one of the duplicate workstreams to have a unique code.',
            },
          }
        ));
      }
    }
  }

  return findings;
}

// ── Audit 2: Workstreams → Organisational Processes ───────────────────────────

function auditWorkstreamProcess(workstreams, processes) {
  const findings = [];
  const procByWs = {};
  for (const p of processes) {
    const key = p.workstream_id || '';
    if (!procByWs[key]) procByWs[key] = [];
    procByWs[key].push(p);
  }

  // Corrective Action #6: Reconcile workstreams without process assignments
  // against the complete organisational process hierarchy. Do not archive
  // workstreams solely because no process is presently associated.
  for (const ws of workstreams) {
    const procList = procByWs[ws.id] || [];
    const appl = workstreamProcessApplicability(ws);
    if (procList.length === 0 && appl !== 'not_applicable') {
      findings.push(makeFinding(
        'workstream_process', 'missing', appl === 'optional' ? 'low' : 'medium',
        rec(ws.id, ws.name, ws.workstream_code, 'Workstream'),
        null,
        'No processes assigned',
        null,
        `Workstream "${ws.name}" has no organisational processes. Reconcile against the complete process hierarchy — do not archive solely because no process is presently associated.`,
        90,
        {
          applicability: appl,
          validation_detail: {
            rule: 'workstream_reconcile_processes',
            source_value: ws.id,
            target_value: null,
            source_fields: { name: ws.name, workstream_code: ws.workstream_code, status: ws.status, is_active: ws.is_active },
            target_fields: null,
            evidence: `Process lookup by workstream_id="${ws.id}" returned 0 results out of ${processes.length} total processes.`,
            resolution: 'Reconcile this workstream against the complete organisational process hierarchy. Assign L3+ processes if applicable, or confirm the workstream is a governance/administrative function that operates without formal processes. Do not archive solely due to missing process assignments.',
          },
        }
      ));
    }
  }

  // Processes without workstream assignment
  for (const p of processes) {
    const hasFk = !!p.workstream_id;
    const hasLegacyText = !!p.workstream;
    if (!hasFk && !hasLegacyText) {
      findings.push(makeFinding(
        'workstream_process', 'missing', 'medium',
        rec(p.id, p.name, p.process_code, 'OrgProcess'),
        null,
        'No workstream assigned',
        'Assign to the appropriate workstream based on process domain',
        `Process "${p.name}" (${p.process_code}) has no workstream assignment (neither workstream_id FK nor workstream text field).`,
        85,
        {
          validation_detail: {
            rule: 'process_must_have_workstream',
            source_value: p.id,
            target_value: null,
            source_fields: { name: p.name, process_code: p.process_code, level: p.level, status: p.status, workstream_id: p.workstream_id, workstream: p.workstream },
            target_fields: null,
            evidence: 'Both workstream_id (FK) and workstream (legacy text) are empty.',
            resolution: 'Set workstream_id to an existing Workstream record, or populate the workstream text field.',
          },
        }
      ));
    } else if (!hasFk && hasLegacyText) {
      let bestMatch = null;
      let bestScore = 0;
      for (const ws of workstreams) {
        if (ws.name && ws.name.toLowerCase() === p.workstream.toLowerCase()) {
          bestMatch = ws; bestScore = 100; break;
        }
        const sim = similarity(p.workstream, ws.name);
        if (sim > bestScore) { bestScore = sim; bestMatch = ws; }
      }
      if (bestMatch && bestScore >= 60) {
        findings.push(makeFinding(
          'workstream_process', 'recommended', 'medium',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          rec(bestMatch.id, bestMatch.name, bestMatch.workstream_code, 'Workstream'),
          `Legacy text field "workstream" = "${p.workstream}" but no FK set`,
          `Link workstream_id to "${bestMatch.name}" (${bestMatch.id})`,
          `Process has a legacy workstream text reference but no formal FK. Best match (${bestScore}%): "${bestMatch.name}".`,
          70 + bestScore / 4,
          {
            validation_detail: {
              rule: 'process_workstream_fk_missing_legacy_exists',
              source_value: p.workstream,
              target_value: bestMatch.id,
              source_fields: { name: p.name, process_code: p.process_code, workstream: p.workstream, workstream_id: p.workstream_id },
              target_fields: { name: bestMatch.name, workstream_code: bestMatch.workstream_code, id: bestMatch.id },
              evidence: `Legacy text "${p.workstream}" matches workstream "${bestMatch.name}" at ${bestScore}% similarity.`,
              resolution: `Set workstream_id = "${bestMatch.id}".`,
            },
          }
        ));
      }
    }
  }

  // Processes with invalid workstream_id (TECHNICAL INVALID)
  const wsIds = new Set(workstreams.map(ws => ws.id));
  for (const p of processes) {
    if (p.workstream_id && !wsIds.has(p.workstream_id)) {
      findings.push(makeFinding(
        'workstream_process', 'invalid', 'high',
        rec(p.id, p.name, p.process_code, 'OrgProcess'),
        null,
        `References workstream ID "${p.workstream_id}" which does not exist`,
        'Reassign to a valid workstream',
        `Process "${p.name}" references a workstream that has been deleted or does not exist.`,
        95,
        {
          category: 'technical',
          validation_detail: {
            rule: 'process_workstream_id_must_resolve',
            source_value: p.workstream_id,
            target_value: null,
            source_fields: { name: p.name, process_code: p.process_code, workstream_id: p.workstream_id },
            target_fields: null,
            evidence: `workstream_id "${p.workstream_id}" not found in set of ${wsIds.size} workstream IDs.`,
            resolution: 'Set workstream_id to an existing Workstream record ID.',
          },
        }
      ));
    }
  }

  // Cross-chain mismatch
  const wsMap = {};
  for (const ws of workstreams) wsMap[ws.id] = ws;
  for (const p of processes) {
    if (p.workstream_id && wsMap[p.workstream_id]) {
      const ws = wsMap[p.workstream_id];
      if (p.value_chain_id && ws.value_chain_id && p.value_chain_id !== ws.value_chain_id) {
        findings.push(makeFinding(
          'workstream_process', 'semantic_mismatch', 'medium',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          rec(ws.id, ws.name, ws.workstream_code, 'Workstream'),
          `Process value chain differs from workstream value chain`,
          `Align process value_chain_id with workstream's value chain (${ws.value_chain_id})`,
          `Process "${p.name}" is assigned to workstream "${ws.name}" but their value chain references differ. Process VC: ${p.value_chain_id}, Workstream VC: ${ws.value_chain_id}.`,
          80,
          {
            category: 'semantic',
            validation_detail: {
              rule: 'process_value_chain_must_match_workstream_value_chain',
              source_value: p.value_chain_id,
              target_value: ws.value_chain_id,
              source_fields: { name: p.name, process_code: p.process_code, value_chain_id: p.value_chain_id, workstream_id: p.workstream_id },
              target_fields: { name: ws.name, workstream_code: ws.workstream_code, value_chain_id: ws.value_chain_id, id: ws.id },
              evidence: `Process value_chain_id="${p.value_chain_id}" ≠ Workstream value_chain_id="${ws.value_chain_id}".`,
              resolution: `Set process value_chain_id to "${ws.value_chain_id}" to match the workstream, or reassign the process to a workstream in the same value chain.`,
            },
          }
        ));
      }
    }
  }

  // Requirement #8: Identify legacy manufacturing, procurement and physical
  // supply-chain process content and propose reclassification or exclusion
  // from the investment-bank operating model.
  for (const p of processes) {
    if (isManufacturingProcess(p)) {
      findings.push(makeFinding(
        'workstream_process', 'not_applicable', 'medium',
        rec(p.id, p.name, p.process_code, 'OrgProcess'),
        null,
        'Legacy manufacturing/procurement/supply-chain process content',
        'Reclassify as not applicable to the investment-bank operating model or exclude from the active process hierarchy',
        `Process "${p.name}" (${p.process_code}) appears to be a legacy manufacturing, procurement or physical supply-chain process. This is not applicable to EVI Trading's investment-bank operating model.`,
        85,
        {
          category: 'semantic',
          applicability: 'not_applicable',
          validation_detail: {
            rule: 'process_manufacturing_not_applicable',
            source_value: p.id,
            target_value: null,
            source_fields: { name: p.name, process_code: p.process_code, level: p.level, status: p.status, description: p.description?.slice(0, 200) },
            target_fields: null,
            evidence: `Process name/description matches manufacturing/procurement/supply-chain keywords: ${MANUFACTURING_KEYWORDS.filter(k => `${p.name} ${p.description || ''}`.toLowerCase().includes(k)).join(', ')}.`,
            resolution: 'Reclassify this process as not applicable to the investment-bank operating model, or exclude it from the active process hierarchy. Do not attempt to map it to investment-bank controls.',
          },
        }
      ));
    }
  }

  return findings;
}

// ── Audit 3: Processes → Stakeholders ─────────────────────────────────────────
// Corrective Action #2: Do not require membership of a group literally named
// "Process Owners" as the sole evidence of ownership. Validate organisational
// function, job title, stakeholder status and explicit accountability instead.

function auditProcessStakeholder(processes, stakeholders, stakeholderGroups, valueChains) {
  const findings = [];
  const stMap = {};
  for (const s of stakeholders) stMap[s.id] = s;

  // Build value chain lookup for domain alignment
  const vcMap = {};
  for (const vc of valueChains) vcMap[vc.id] = vc;

  // Build group membership lookup (for advisory use only — not sole validation)
  const groupMap = {};
  for (const g of stakeholderGroups) groupMap[g.id] = g;

  for (const p of processes) {
    const appl = processOwnerApplicability(p);
    const hasFk = !!p.process_owner_stakeholder_id;
    const hasLegacyName = !!p.process_owner;

    // Corrective Action #7: Resolve missing process owners on Trading,
    // Confirmation, Settlement and Custody subprocesses using appropriate
    // functional stakeholder roles.
    if (!hasFk && !hasLegacyName && appl === 'mandatory' && isTradingSubprocess(p)) {
      // Find stakeholders with appropriate functional roles
      const processName = (p.name || '').toLowerCase();
      const roleKeywords = [];
      if (processName.includes('trading') || processName.includes('trade execution') || processName.includes('trade capture')) {
        roleKeywords.push('head of trading', 'trading manager', 'trader', 'trading', 'front office');
      }
      if (processName.includes('confirmation')) {
        roleKeywords.push('confirmation', 'operations', 'middle office');
      }
      if (processName.includes('settlement') || processName.includes('clearing')) {
        roleKeywords.push('settlement', 'operations', 'back office', 'clearing');
      }
      if (processName.includes('custody')) {
        roleKeywords.push('custody', 'custodian', 'operations', 'depositary');
      }

      // Requirement #6: Exclude HR, privacy and unrelated Finance roles from
      // Trading and Settlement process owner proposals unless documented
      // accountability justifies them.
      const candidates = stakeholders.filter(s =>
        s.status === 'active' &&
        roleKeywords.some(kw => (s.job_title || '').toLowerCase().includes(kw) || (s.department || '').toLowerCase().includes(kw)) &&
        !isInappropriateTradingRole(s)
      ).slice(0, 3);

      if (candidates.length > 0) {
        findings.push(makeFinding(
          'process_stakeholder', 'recommended', 'high',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          rec(candidates[0].id, candidates[0].full_name, candidates[0].employee_number, 'Stakeholder'),
          'No process owner assigned (Trading/Confirmation/Settlement/Custody subprocess)',
          `Assign ${candidates[0].full_name} (${candidates[0].job_title || 'functional role'}) as process owner`,
          `Trading subprocess "${p.name}" has no owner. ${candidates.length} candidate(s) with appropriate functional role(s) found: ${candidates.map(c => `${c.full_name} (${c.job_title || 'no title'})`).join(', ')}.`,
          80,
          {
            applicability: appl,
            category: 'semantic',
            validation_detail: {
              rule: 'trading_subprocess_owner_resolution',
              source_value: p.id,
              target_value: candidates[0].id,
              source_fields: { name: p.name, process_code: p.process_code, level: p.level, process_owner_stakeholder_id: p.process_owner_stakeholder_id },
              target_fields: { full_name: candidates[0].full_name, job_title: candidates[0].job_title, department: candidates[0].department, id: candidates[0].id },
              evidence: `Trading subprocess with no owner. ${candidates.length} active stakeholder(s) with matching functional role keywords: ${roleKeywords.join(', ')}.`,
              resolution: `Assign ${candidates[0].full_name} as process owner, or review the other candidate(s).`,
            },
          }
        ));
      } else {
        findings.push(makeFinding(
          'process_stakeholder', 'missing', 'high',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          null,
          'No process owner assigned (Trading/Confirmation/Settlement/Custody subprocess)',
          'Create or identify a stakeholder with the appropriate functional role (Head of Trading, Settlement Manager, etc.)',
          `Trading subprocess "${p.name}" (${p.process_code}) has no owner and no stakeholders with matching functional roles were found.`,
          90,
          {
            applicability: appl,
            validation_detail: {
              rule: 'trading_subprocess_owner_missing',
              source_value: p.id,
              target_value: null,
              source_fields: { name: p.name, process_code: p.process_code, level: p.level },
              target_fields: null,
              evidence: `No active stakeholders found with job titles/departments matching: ${roleKeywords.join(', ')}.`,
              resolution: 'Create a Stakeholder record with an appropriate functional role (e.g. Head of Trading, Settlement Manager, Custody Operations).',
            },
          }
        ));
      }
      continue;
    }

    // Missing owner — only flag if mandatory
    if (!hasFk && !hasLegacyName) {
      if (appl === 'mandatory') {
        findings.push(makeFinding(
          'process_stakeholder', 'missing', 'high',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          null,
          'No process owner assigned',
          'Assign a stakeholder as process owner',
          `Process "${p.name}" (${p.process_code}, L${p.level}) has no process owner (neither stakeholder ID nor name).`,
          95,
          {
            applicability: appl,
            validation_detail: {
              rule: 'process_must_have_owner',
              source_value: p.id,
              target_value: null,
              source_fields: { name: p.name, process_code: p.process_code, level: p.level, status: p.status, process_owner_stakeholder_id: p.process_owner_stakeholder_id, process_owner: p.process_owner },
              target_fields: null,
              evidence: 'Both process_owner_stakeholder_id (FK) and process_owner (legacy name) are empty.',
              resolution: 'Set process_owner_stakeholder_id to an existing Stakeholder record ID.',
            },
          }
        ));
      }
      continue;
    }

    // Owner name set but no stakeholder ID — try to resolve by name
    if (hasLegacyName && !hasFk) {
      const match = stakeholders.find(s =>
        s.full_name && s.full_name.toLowerCase() === p.process_owner.toLowerCase()
      );
      if (match) {
        findings.push(makeFinding(
          'process_stakeholder', 'recommended', 'medium',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          rec(match.id, match.full_name, match.employee_number, 'Stakeholder'),
          `Owner name "${p.process_owner}" set but no stakeholder ID linked`,
          `Link stakeholder ID "${match.id}" (${match.full_name})`,
          `Process owner name matches stakeholder "${match.full_name}" but the stakeholder ID is not linked. Name matching alone does not establish correct accountability — verify the stakeholder's job title, department and delegated authority before approving.`,
          85,
          {
            applicability: appl,
            validation_detail: {
              rule: 'process_owner_fk_missing_name_matches',
              source_value: p.process_owner,
              target_value: match.id,
              source_fields: { name: p.name, process_code: p.process_code, process_owner: p.process_owner, process_owner_stakeholder_id: p.process_owner_stakeholder_id },
              target_fields: { full_name: match.full_name, employee_number: match.employee_number, id: match.id },
              evidence: `Legacy name "${p.process_owner}" exactly matches stakeholder "${match.full_name}" (id=${match.id}).`,
              resolution: `Set process_owner_stakeholder_id = "${match.id}".`,
            },
          }
        ));
      } else {
        if (appl === 'mandatory') {
          findings.push(makeFinding(
            'process_stakeholder', 'invalid', 'medium',
            rec(p.id, p.name, p.process_code, 'OrgProcess'),
            null,
            `Owner name "${p.process_owner}" does not match any stakeholder`,
            'Create a stakeholder record or correct the owner name',
            `Process owner "${p.process_owner}" does not match any stakeholder in the register.`,
            70,
            {
              applicability: appl,
              validation_detail: {
                rule: 'process_owner_name_unresolved',
                source_value: p.process_owner,
                target_value: null,
                source_fields: { name: p.name, process_code: p.process_code, process_owner: p.process_owner },
                target_fields: null,
                evidence: `No stakeholder found with full_name matching "${p.process_owner}" (case-insensitive) among ${stakeholders.length} stakeholders.`,
                resolution: 'Create a Stakeholder record with full_name matching the owner name, or correct the process_owner field.',
              },
            }
          ));
        }
      }
      continue;
    }

    // Stakeholder ID set but doesn't exist (TECHNICAL INVALID)
    if (hasFk && !stMap[p.process_owner_stakeholder_id]) {
      findings.push(makeFinding(
        'process_stakeholder', 'invalid', 'high',
        rec(p.id, p.name, p.process_code, 'OrgProcess'),
        null,
        `References stakeholder ID "${p.process_owner_stakeholder_id}" which does not exist`,
        'Reassign to a valid stakeholder',
        `Process "${p.name}" references a stakeholder that has been deleted or does not exist.`,
        95,
        {
          applicability: appl,
          category: 'technical',
          validation_detail: {
            rule: 'process_owner_stakeholder_id_must_resolve',
            source_value: p.process_owner_stakeholder_id,
            target_value: null,
            source_fields: { name: p.name, process_code: p.process_code, process_owner_stakeholder_id: p.process_owner_stakeholder_id },
            target_fields: null,
            evidence: `process_owner_stakeholder_id "${p.process_owner_stakeholder_id}" not found in set of ${Object.keys(stMap).length} stakeholder IDs.`,
            resolution: 'Set process_owner_stakeholder_id to an existing Stakeholder record ID.',
          },
        }
      ));
      continue;
    }

    // Stakeholder ID exists — check technical integrity
    if (hasFk && stMap[p.process_owner_stakeholder_id]) {
      const st = stMap[p.process_owner_stakeholder_id];

      // Name mismatch between FK and legacy field (SEMANTIC — not invalid)
      if (p.process_owner && st.full_name && st.full_name.toLowerCase() !== p.process_owner.toLowerCase()) {
        findings.push(makeFinding(
          'process_stakeholder', 'semantic_mismatch', 'low',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          rec(st.id, st.full_name, st.employee_number, 'Stakeholder'),
          `Owner name "${p.process_owner}" differs from stakeholder "${st.full_name}"`,
          `Update owner name to "${st.full_name}" to match the linked stakeholder`,
          `The process owner name and the linked stakeholder record have different names.`,
          75,
          {
            applicability: appl,
            category: 'semantic',
            validation_detail: {
              rule: 'process_owner_name_matches_stakeholder',
              source_value: p.process_owner,
              target_value: st.full_name,
              source_fields: { name: p.name, process_code: p.process_code, process_owner: p.process_owner, process_owner_stakeholder_id: p.process_owner_stakeholder_id },
              target_fields: { full_name: st.full_name, id: st.id },
              evidence: `process_owner="${p.process_owner}" ≠ stakeholder.full_name="${st.full_name}".`,
              resolution: `Update process_owner to "${st.full_name}" to match the linked stakeholder.`,
            },
          }
        ));
      }

      // Inactive stakeholder as owner (TECHNICAL INVALID)
      if (st.status === 'inactive' || st.end_date) {
        findings.push(makeFinding(
          'process_stakeholder', 'invalid', 'high',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          rec(st.id, st.full_name, st.employee_number, 'Stakeholder'),
          `Owner stakeholder is inactive${st.end_date ? ` (end date: ${st.end_date})` : ''}`,
          'Reassign to an active stakeholder',
          `Process "${p.name}" is owned by an inactive stakeholder.`,
          90,
          {
            applicability: appl,
            category: 'technical',
            validation_detail: {
              rule: 'process_owner_must_be_active',
              source_value: p.process_owner_stakeholder_id,
              target_value: st.id,
              source_fields: { name: p.name, process_code: p.process_code, process_owner_stakeholder_id: p.process_owner_stakeholder_id },
              target_fields: { full_name: st.full_name, status: st.status, end_date: st.end_date, id: st.id },
              evidence: `Stakeholder status="${st.status}"${st.end_date ? `, end_date="${st.end_date}"` : ''}.`,
              resolution: 'Reassign process_owner_stakeholder_id to an active stakeholder.',
            },
          }
        ));
      }

      // Corrective Action #2: Validate organisational function, job title,
      // stakeholder status and explicit accountability — NOT group membership.
      // The explicit assignment (process_owner_stakeholder_id) IS the accountability.
      // Job title and department are advisory indicators of authority.

      // Job title authority check (SEMANTIC ADVISORY — does NOT affect technical quality)
      if (st.job_title) {
        const titleLower = st.job_title.toLowerCase();
        const hasOwnershipTitle = /owner|manager|head|director|lead|chief|principal|officer|controller|treasurer|secretary|administrator/.test(titleLower);
        if (!hasOwnershipTitle) {
          findings.push(makeFinding(
            'process_stakeholder', 'semantic_mismatch', 'low',
            rec(p.id, p.name, p.process_code, 'OrgProcess'),
            rec(st.id, st.full_name, st.employee_number, 'Stakeholder'),
            `Owner job title "${st.job_title}" may not indicate ownership authority`,
            'Verify the stakeholder has appropriate authority for process ownership',
            `Job title "${st.job_title}" does not contain typical ownership keywords. However, explicit accountability via process_owner_stakeholder_id is the primary evidence of ownership — group membership is not required.`,
            40,
            {
              applicability: appl,
              category: 'semantic',
              validation_detail: {
                rule: 'process_owner_job_title_suggests_authority',
                source_value: st.job_title,
                target_value: st.id,
                source_fields: { name: p.name, process_code: p.process_code, process_owner_stakeholder_id: p.process_owner_stakeholder_id },
                target_fields: { full_name: st.full_name, job_title: st.job_title, id: st.id },
                evidence: `job_title="${st.job_title}" does not match ownership pattern. Explicit accountability (FK) is present — this is advisory only.`,
                resolution: 'Verify the stakeholder has delegated authority for process ownership. Group membership is NOT required as evidence of ownership.',
              },
            }
          ));
        }
      }

      // Department/function alignment (SEMANTIC ADVISORY)
      // Check if the stakeholder's department aligns with the process's value chain domain
      if (st.department && p.value_chain_id && vcMap[p.value_chain_id]) {
        const vc = vcMap[p.value_chain_id];
        const vcName = (vc.name || '').toLowerCase();
        const dept = (st.department || '').toLowerCase();
        const vcTokens = tokenize(vcName);
        const deptTokens = tokenize(dept);
        let shared = 0;
        for (const t of vcTokens) if (deptTokens.includes(t)) shared++;
        if (shared === 0 && vcTokens.length > 0 && deptTokens.length > 0) {
          findings.push(makeFinding(
            'process_stakeholder', 'semantic_mismatch', 'low',
            rec(p.id, p.name, p.process_code, 'OrgProcess'),
            rec(st.id, st.full_name, st.employee_number, 'Stakeholder'),
            `Owner department "${st.department}" may not align with value chain "${vc.name}"`,
            'Verify the stakeholder has accountability for this process domain',
            `Stakeholder's department "${st.department}" does not share keywords with the process's value chain "${vc.name}". This is advisory — explicit accountability via FK is the primary evidence of ownership.`,
            35,
            {
              applicability: appl,
              category: 'semantic',
              validation_detail: {
                rule: 'process_owner_department_aligns_with_value_chain',
                source_value: st.department,
                target_value: vc.name,
                source_fields: { name: p.name, process_code: p.process_code, value_chain_id: p.value_chain_id },
                target_fields: { full_name: st.full_name, department: st.department, value_chain: vc.name, id: st.id },
                evidence: `Department "${st.department}" shares 0 tokens with value chain "${vc.name}". Explicit accountability (FK) is present — this is advisory only.`,
                resolution: 'Verify the stakeholder has functional accountability for this process domain. Reassignment is optional.',
              },
            }
          ));
        }
      }

      // NOTE: The "Process Owners" group membership check has been REMOVED.
      // Corrective Action #2: Group membership is NOT required as sole evidence
      // of ownership. The explicit assignment (process_owner_stakeholder_id)
      // is the primary evidence. Job title, department and stakeholder status
      // are advisory indicators validated above.
    }
  }

  return findings;
}

// ── Audit 3b: Stakeholder Over-Assignment Detection ──────────────────────────
// Corrective Action #3: Review Rachel Berry's assignment to 981 processes across
// functional domains. Propose appropriate functional owners from existing
// stakeholders. Do not simply add her to another group or automatically replace
// every assignment.

function auditStakeholderOverAssignment(processes, stakeholders, valueChains) {
  const findings = [];
  const OVER_ASSIGNMENT_THRESHOLD = 50; // Flag stakeholders owning >50 processes

  // Count processes per owner stakeholder
  const ownerCounts = {};
  const ownerProcesses = {};
  for (const p of processes) {
    if (p.process_owner_stakeholder_id) {
      if (!ownerCounts[p.process_owner_stakeholder_id]) {
        ownerCounts[p.process_owner_stakeholder_id] = 0;
        ownerProcesses[p.process_owner_stakeholder_id] = [];
      }
      ownerCounts[p.process_owner_stakeholder_id]++;
      ownerProcesses[p.process_owner_stakeholder_id].push(p);
    }
  }

  // Build value chain lookup
  const vcMap = {};
  for (const vc of valueChains) vcMap[vc.id] = vc;

  // Build stakeholder lookup
  const stMap = {};
  for (const s of stakeholders) stMap[s.id] = s;

  for (const [stakeholderId, count] of Object.entries(ownerCounts)) {
    if (count > OVER_ASSIGNMENT_THRESHOLD) {
      const stakeholder = stMap[stakeholderId];
      if (!stakeholder) continue;

      const ownedProcesses = ownerProcesses[stakeholderId];

      // Group by value chain to detect cross-domain over-assignment
      const byVC = {};
      for (const p of ownedProcesses) {
        const vcId = p.value_chain_id || 'unassigned';
        const vcName = vcId !== 'unassigned' && vcMap[vcId] ? vcMap[vcId].name : 'Unassigned';
        if (!byVC[vcId]) byVC[vcId] = { vcId, vcName, processes: [] };
        byVC[vcId].processes.push(p);
      }
      const vcGroups = Object.values(byVC);
      const crossDomain = vcGroups.length > 2; // More than 2 value chains = cross-domain

      if (!crossDomain && count <= 100) continue; // Only flag cross-domain or very high counts

      // Requirement #5: Generate functionally appropriate process-owner
      // proposals using organisational responsibility, stakeholder job titles,
      // process hierarchy and segregation-of-duties requirements. Do not simply
      // propose any stakeholder in the same domain — exclude inappropriate roles.
      const proposals = [];
      for (const group of vcGroups) {
        if (group.vcName === 'Unassigned') continue;
        // Find other active stakeholders in the same domain with appropriate roles
        const vcTokens = tokenize(group.vcName);
        const groupProcesses = group.processes;
        // Check if this group contains trading/settlement processes
        const hasTradingProcesses = groupProcesses.some(p => isTradingSubprocess(p));
        const candidates = stakeholders.filter(s => {
          if (s.id === stakeholderId) return false;
          if (s.status !== 'active') return false;
          // Requirement #6: Exclude inappropriate roles for trading/settlement
          if (hasTradingProcesses && isInappropriateTradingRole(s)) return false;
          // Match by domain tokens in job title or department
          const matches = vcTokens.some(t => (s.department || '').toLowerCase().includes(t) || (s.job_title || '').toLowerCase().includes(t));
          if (!matches) return false;
          // SoD: Prefer stakeholders with ownership authority in their title
          const titleLower = (s.job_title || '').toLowerCase();
          const hasAuthority = /owner|manager|head|director|lead|chief|principal|officer|controller/.test(titleLower);
          return hasAuthority || matches;
        }).slice(0, 3);
        proposals.push({
          value_chain: group.vcName,
          process_count: groupProcesses.length,
          proposed_owners: candidates.map(c => ({
            id: c.id,
            name: c.full_name,
            job_title: c.job_title,
            department: c.department,
            sod_assessment: hasTradingProcesses ? 'trading-appropriate' : 'domain-matched',
          })),
          sod_note: hasTradingProcesses
            ? 'Trading/Settlement processes — HR, privacy and unrelated Finance roles excluded per SoD requirements'
            : 'Domain-matched candidates with ownership authority preferred',
        });
      }

      findings.push(makeFinding(
        'process_stakeholder', 'over_assignment', 'high',
        rec(stakeholderId, stakeholder.full_name, stakeholder.employee_number, 'Stakeholder'),
        null,
        `Assigned as owner of ${count} processes across ${vcGroups.length} value chain domain(s)`,
        'Review assignments and propose functional owners for each domain — do not automatically replace every assignment',
        `Stakeholder "${stakeholder.full_name}" (${stakeholder.job_title || 'no title'}) is assigned as process owner for ${count} processes across ${vcGroups.length} functional domain(s): ${vcGroups.map(g => `${g.vcName} (${g.processes.length})`).join(', ')}. This is a potential segregation-of-duties concern.`,
        85,
        {
          category: 'semantic',
          applicability: 'mandatory',
          validation_detail: {
            rule: 'stakeholder_over_assignment',
            source_value: stakeholderId,
            target_value: null,
            source_fields: { full_name: stakeholder.full_name, job_title: stakeholder.job_title, department: stakeholder.department, process_count: count, value_chain_count: vcGroups.length },
            target_fields: null,
            evidence: `Owner of ${count} processes across ${vcGroups.length} value chains: ${vcGroups.map(g => `${g.vcName}=${g.processes.length}`).join(', ')}. Threshold: ${OVER_ASSIGNMENT_THRESHOLD}.`,
            resolution: 'Review each value chain domain and propose appropriate functional owners. Do not automatically replace every assignment — some may be legitimately owned.',
            proposed_owners: proposals,
          },
        }
      ));
    }
  }

  return findings;
}

// ── Audit 4: Processes → Risks ────────────────────────────────────────────────

function auditProcessRisk(processes, risks) {
  const findings = [];
  const riskToProcesses = {};
  for (const p of processes) {
    for (const rid of p.linked_risk_ids || []) {
      if (!riskToProcesses[rid]) riskToProcesses[rid] = [];
      riskToProcesses[rid].push(p);
    }
  }

  // Pre-compute process tokens for efficient matching
  const processTokens = processes.map(p => ({
    p,
    tokens: tokenize(`${p.name} ${p.description || ''}`),
    domainText: `${p.name} ${p.description || ''} ${p.value_chain_id || ''} ${p.workstream_id || ''}`.toLowerCase(),
  }));

  const riskHasProcessText = (r) => !!(r.process_activity || r.sub_process || r.value_chain || r.workstream);

  for (const r of risks) {
    const linkedProcs = riskToProcesses[r.id] || [];
    const hasProcessText = riskHasProcessText(r);
    if (linkedProcs.length === 0 && !hasProcessText) {
      let bestMatch = null;
      let bestScore = 0;
      const riskTokens = tokenize(`${r.title} ${r.description || ''} ${r.risk_statement || ''}`);
      const riskDomainText = `${r.value_chain || ''} ${r.workstream || ''} ${r.sub_process || ''} ${r.process_activity || ''}`.toLowerCase();
      for (const pt of processTokens) {
        // Quick domain pre-filter: skip if no shared tokens
        let hasShared = false;
        for (const t of riskTokens) {
          if (pt.tokens.includes(t)) { hasShared = true; break; }
        }
        if (!hasShared) continue;
        const sim = Math.round(jaccard(riskTokens, pt.tokens) * 100);
        if (sim > bestScore) { bestScore = sim; bestMatch = pt.p; }
      }
      if (bestMatch && bestScore >= 15) {
        findings.push(makeFinding(
          'process_risk', 'recommended', 'medium',
          rec(r.id, r.title, r.risk_reference_nr, 'Risk'),
          rec(bestMatch.id, bestMatch.name, bestMatch.process_code, 'OrgProcess'),
          'No process mapping (no linked process ID, no process_activity text)',
          `Link to process "${bestMatch.name}" (${bestMatch.process_code})`,
          `Risk has no process mapping. Best match by text similarity (${bestScore}%): process "${bestMatch.name}".`,
          50 + bestScore,
          {
            category: 'semantic',
            validation_detail: {
              rule: 'risk_should_have_process_mapping',
              source_value: r.id,
              target_value: bestMatch.id,
              source_fields: { title: r.title, risk_reference_nr: r.risk_reference_nr, process_activity: r.process_activity, sub_process: r.sub_process, value_chain: r.value_chain },
              target_fields: { name: bestMatch.name, process_code: bestMatch.process_code, id: bestMatch.id },
              evidence: `No process references this risk via linked_risk_ids. No legacy text fields are set. Best text-similarity match: ${bestScore}%.`,
              resolution: `Add this risk's ID to process "${bestMatch.name}" linked_risk_ids array, or set risk.process_activity to the process name.`,
            },
          }
        ));
      } else {
        findings.push(makeFinding(
          'process_risk', 'missing', 'high',
          rec(r.id, r.title, r.risk_reference_nr, 'Risk'),
          null,
          'No process mapping',
          null,
          `Risk "${r.title}" has no process mapping and no suitable match was found among existing processes.`,
          90,
          {
            validation_detail: {
              rule: 'risk_must_have_process_mapping',
              source_value: r.id,
              target_value: null,
              source_fields: { title: r.title, risk_reference_nr: r.risk_reference_nr, process_activity: r.process_activity, sub_process: r.sub_process, value_chain: r.value_chain, workstream: r.workstream },
              target_fields: null,
              evidence: 'No process references this risk via linked_risk_ids. No legacy text fields are set. No text-similarity match ≥15% found.',
              resolution: 'Link this risk to a process via the process linked_risk_ids array, or populate the risk process_activity/sub_process/value_chain text fields.',
            },
          }
        ));
      }
    } else if (linkedProcs.length === 0 && hasProcessText) {
      const refText = `${r.value_chain || ''} ${r.workstream || ''} ${r.sub_process || ''} ${r.process_activity || ''}`;
      const refTokens = tokenize(refText);
      let bestMatch = null;
      let bestScore = 0;
      for (const pt of processTokens) {
        let hasShared = false;
        for (const t of refTokens) {
          if (pt.tokens.includes(t)) { hasShared = true; break; }
        }
        if (!hasShared) continue;
        const sim = Math.round(jaccard(refTokens, pt.tokens) * 100);
        if (sim > bestScore) { bestScore = sim; bestMatch = pt.p; }
      }
      if (bestMatch && bestScore >= 15) {
        findings.push(makeFinding(
          'process_risk', 'recommended', 'medium',
          rec(r.id, r.title, r.risk_reference_nr, 'Risk'),
          rec(bestMatch.id, bestMatch.name, bestMatch.process_code, 'OrgProcess'),
          `Text reference: "${r.process_activity || r.sub_process}" in "${r.value_chain || ''}"`,
          `Formalise link to process "${bestMatch.name}" (${bestMatch.process_code})`,
          `Risk has a text-based process reference but no formal process ID link. Best match (${bestScore}%): "${bestMatch.name}".`,
          45 + bestScore,
          {
            category: 'semantic',
            validation_detail: {
              rule: 'risk_process_text_exists_fk_missing',
              source_value: refText.trim(),
              target_value: bestMatch.id,
              source_fields: { title: r.title, risk_reference_nr: r.risk_reference_nr, process_activity: r.process_activity, sub_process: r.sub_process, value_chain: r.value_chain, workstream: r.workstream },
              target_fields: { name: bestMatch.name, process_code: bestMatch.process_code, id: bestMatch.id },
              evidence: `Legacy text fields are set. Best text-similarity match: ${bestScore}%.`,
              resolution: `Add this risk's ID to process "${bestMatch.name}" linked_risk_ids array to formalise the link.`,
            },
          }
        ));
      }
    }
  }

  // Processes without risks — only for L3+ mandatory processes
  // Pre-compute risk tokens for efficient matching
  const riskTokensList = risks.map(r => ({
    r,
    tokens: tokenize(`${r.title} ${r.description || ''}`),
  }));

  for (const p of processes) {
    const appl = processRiskApplicability(p);
    if ((!p.linked_risk_ids || p.linked_risk_ids.length === 0) && appl === 'mandatory') {
      let bestMatch = null;
      let bestScore = 0;
      const procTokens = tokenize(`${p.name} ${p.description || ''}`);
      for (const rt of riskTokensList) {
        let hasShared = false;
        for (const t of procTokens) {
          if (rt.tokens.includes(t)) { hasShared = true; break; }
        }
        if (!hasShared) continue;
        const sim = Math.round(jaccard(procTokens, rt.tokens) * 100);
        if (sim > bestScore) { bestScore = sim; bestMatch = rt.r; }
      }
      if (bestMatch && bestScore >= 15) {
        findings.push(makeFinding(
          'process_risk', 'recommended', 'low',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          rec(bestMatch.id, bestMatch.title, bestMatch.risk_reference_nr, 'Risk'),
          'No linked risks',
          `Link to risk "${bestMatch.title}"`,
          `Process has no linked risks. Best match by text similarity (${bestScore}%): risk "${bestMatch.title}".`,
          40 + bestScore,
          {
            applicability: appl,
            category: 'semantic',
            validation_detail: {
              rule: 'process_should_have_risks',
              source_value: p.id,
              target_value: bestMatch.id,
              source_fields: { name: p.name, process_code: p.process_code, level: p.level, linked_risk_ids: p.linked_risk_ids },
              target_fields: { title: bestMatch.title, risk_reference_nr: bestMatch.risk_reference_nr, id: bestMatch.id },
              evidence: `linked_risk_ids is empty. Best text-similarity match: ${bestScore}%.`,
              resolution: `Add risk "${bestMatch.title}" ID to this process's linked_risk_ids array.`,
            },
          }
        ));
      } else {
        findings.push(makeFinding(
          'process_risk', 'missing', 'low',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          null,
          'No linked risks',
          null,
          `Process "${p.name}" (${p.process_code}, L${p.level}) has no linked risks.`,
          75,
          {
            applicability: appl,
            validation_detail: {
              rule: 'process_must_have_risks',
              source_value: p.id,
              target_value: null,
              source_fields: { name: p.name, process_code: p.process_code, level: p.level, linked_risk_ids: p.linked_risk_ids },
              target_fields: null,
              evidence: 'linked_risk_ids is empty. No text-similarity match ≥15% found.',
              resolution: 'Link one or more relevant risks to this process via the linked_risk_ids array.',
            },
          }
        ));
      }
    }
  }

  // Invalid risk references (TECHNICAL INVALID)
  const riskIds = new Set(risks.map(r => r.id));
  for (const p of processes) {
    for (const rid of p.linked_risk_ids || []) {
      if (!riskIds.has(rid)) {
        findings.push(makeFinding(
          'process_risk', 'invalid', 'high',
          rec(p.id, p.name, p.process_code, 'OrgProcess'),
          null,
          `References risk ID "${rid}" which does not exist`,
          'Remove the invalid reference or reassign to an existing risk',
          `Process "${p.name}" references a risk that has been deleted or does not exist.`,
          95,
          {
            category: 'technical',
            validation_detail: {
              rule: 'process_linked_risk_id_must_resolve',
              source_value: rid,
              target_value: null,
              source_fields: { name: p.name, process_code: p.process_code, linked_risk_ids: p.linked_risk_ids },
              target_fields: null,
              evidence: `Risk ID "${rid}" not found in set of ${riskIds.size} risk IDs.`,
              resolution: `Remove "${rid}" from linked_risk_ids, or replace with an existing risk ID.`,
            },
          }
        ));
      }
    }
  }

  return findings;
}

// ── Audit 5: Risks → Controls (Mechanism-Based) ───────────────────────────────
// Corrective Actions #8, #9: Replace text-similarity-only validation with a
// mechanism-based assessment. Do not automatically reject existing market-risk,
// trading or reconciliation controls because of low title similarity.

function auditRiskControl(risks, controls, processes) {
  const findings = [];

  const controlToRisks = {};
  for (const r of risks) {
    for (const cid of r.control_ids || []) {
      if (!controlToRisks[cid]) controlToRisks[cid] = [];
      controlToRisks[cid].push(r);
    }
  }

  const controlToProcesses = {};
  for (const p of processes) {
    for (const cid of p.linked_control_ids || []) {
      if (!controlToProcesses[cid]) controlToProcesses[cid] = [];
      controlToProcesses[cid].push(p);
    }
  }

  const controlIds = new Set(controls.map(c => c.id));

  // Risks without controls — consolidated remediation cases are generated by
  // auditRiskControlReconciliation (Requirement #1: single finding per risk
  // containing both master and expansion proposals). This function only
  // generates a "missing" finding if NO match is found at all.
  for (const r of risks) {
    const ctrlIds = r.control_ids || [];
    const appl = riskControlApplicability(r);
    if (ctrlIds.length === 0) {
      if (appl === 'not_applicable') continue;
      // Check if any valid match exists — if not, generate a "missing" finding
      // Optimized: skip controls with zero domain overlap before similarity
      const hasValidMatch = controls.some(c => {
        if (!isControlReferenceValid(c)) return false;
        const domain = domainOverlap(r, c);
        if (!domain.overlap && domain.score === 0) return false;
        const mechanismOk = isMechanismAppropriate(r, c);
        let score = 0;
        if (mechanismOk) score += 30;
        score += Math.round(domain.score * 0.4);
        const sim = similarity(`${r.title} ${r.description || ''}`, `${c.title} ${c.description || ''}`);
        score += Math.round(sim * 0.3);
        return score >= 35;
      });
      if (!hasValidMatch) {
        findings.push(makeFinding(
          'risk_control', 'missing', appl === 'optional' ? 'medium' : 'high',
          rec(r.id, r.title, r.risk_reference_nr, 'Risk'),
          null,
          'No controls linked',
          null,
          `Risk "${r.title}" has no controls linked and no valid match found in the master library or expansion library. This risk is unmitigated.`,
          95,
          {
            applicability: appl,
            validation_detail: {
              rule: 'risk_must_have_controls',
              source_value: r.id,
              target_value: null,
              source_fields: { title: r.title, risk_reference_nr: r.risk_reference_nr, control_ids: r.control_ids, status: r.status, category: r.category },
              target_fields: null,
              evidence: 'control_ids is empty. No valid mechanism-based match found in master or expansion library (threshold 35%).',
              resolution: 'Link one or more controls to this risk via the control_ids array, or create a new control with an appropriate mechanism.',
            },
          }
        ));
      }
      // If a valid match exists, the consolidated finding is generated by
      // auditRiskControlReconciliation — no duplicate "recommended" finding here.
    } else {
      // Check for invalid control references (TECHNICAL INVALID)
      for (const cid of ctrlIds) {
        if (!controlIds.has(cid)) {
          findings.push(makeFinding(
            'risk_control', 'invalid', 'high',
            rec(r.id, r.title, r.risk_reference_nr, 'Risk'),
            null,
            `References control ID "${cid}" which does not exist`,
            'Remove the invalid reference or reassign to an existing control',
            `Risk "${r.title}" references a control that has been deleted or does not exist.`,
            95,
            {
              category: 'technical',
              validation_detail: {
                rule: 'risk_control_id_must_resolve',
                source_value: cid,
                target_value: null,
                source_fields: { title: r.title, risk_reference_nr: r.risk_reference_nr, control_ids: r.control_ids },
                target_fields: null,
                evidence: `Control ID "${cid}" not found in set of ${controlIds.size} control IDs.`,
                resolution: `Remove "${cid}" from control_ids, or replace with an existing control ID.`,
              },
            }
          ));
        }
      }

      // Corrective Action #9: Do NOT automatically reject existing market-risk,
      // trading or reconciliation controls because of low title similarity.
      // Only flag if the control is clearly in a different domain.
      const linkedControls = ctrlIds
        .map(cid => controls.find(c => c.id === cid))
        .filter(Boolean);
      for (const c of linkedControls) {
        const domain = domainOverlap(r, c);
        // Only flag as potential mismatch if there is NO domain overlap at all
        if (!domain.overlap) {
          findings.push(makeFinding(
            'risk_control', 'semantic_mismatch', 'low',
            rec(r.id, r.title, r.risk_reference_nr, 'Risk'),
            rec(c.id, c.title, c.control_id, 'Control'),
            `Linked to control "${c.title}"`,
            'Review whether this control meaningfully mitigates the risk',
            `Control "${c.title}" has no domain overlap with risk "${r.title}". The control may not meaningfully mitigate this risk. Note: low text similarity alone is NOT sufficient to flag — market-risk, trading and reconciliation controls are valid despite different titles.`,
            45,
            {
              category: 'semantic',
              validation_detail: {
                rule: 'risk_control_domain_mismatch',
                source_value: r.id,
                target_value: c.id,
                source_fields: { title: r.title, risk_reference_nr: r.risk_reference_nr, value_chain: r.value_chain, category: r.category },
                target_fields: { title: c.title, control_id: c.control_id, category: c.category, control_type: c.control_type, id: c.id },
                evidence: `No domain overlap between risk and control. ${domain.reason}.`,
                resolution: 'Review whether this control genuinely mitigates this risk. If not, unlink it and find a more relevant control. Do NOT unlink solely due to low title similarity.',
              },
            }
          ));
        }
        // If domain overlaps, the control is considered valid — no finding.
        // This prevents false positives on market-risk, trading and
        // reconciliation controls with different titles.
      }
    }
  }

  // Controls without risks (orphaned)
  for (const c of controls) {
    const linkedRisks = controlToRisks[c.id] || [];
    const linkedProcs = controlToProcesses[c.id] || [];
    if (linkedRisks.length === 0 && linkedProcs.length === 0) {
      findings.push(makeFinding(
        'risk_control', 'orphaned', 'medium',
        rec(c.id, c.title, c.control_id, 'Control'),
        null,
        'Not linked to any risk or process',
        'Link to an appropriate risk or archive if no longer needed',
        `Control "${c.title}" (${c.control_id}) is not linked to any risk or process. It may be orphaned.`,
        85,
        {
          category: 'semantic',
          validation_detail: {
            rule: 'control_should_be_linked',
            source_value: c.id,
            target_value: null,
            source_fields: { title: c.title, control_id: c.control_id, status: c.status },
            target_fields: null,
            evidence: 'No risk references this control via control_ids. No process references this control via linked_control_ids.',
            resolution: 'Link this control to a relevant risk or process, or archive it if no longer in use.',
          },
        }
      ));
    } else if (linkedRisks.length === 0 && linkedProcs.length > 0) {
      findings.push(makeFinding(
        'risk_control', 'orphaned', 'low',
        rec(c.id, c.title, c.control_id, 'Control'),
        null,
        `Linked to ${linkedProcs.length} process(es) but no risks`,
        'Link to an appropriate risk for the processes that reference this control',
        `Control "${c.title}" is referenced by processes but not linked to any risk.`,
        70,
        {
          category: 'semantic',
          validation_detail: {
            rule: 'control_should_have_risk',
            source_value: c.id,
            target_value: null,
            source_fields: { title: c.title, control_id: c.control_id },
            target_fields: null,
            evidence: `Referenced by ${linkedProcs.length} process(es): ${linkedProcs.map(p => p.process_code).join(', ')}. Not referenced by any risk.`,
            resolution: 'Link this control to a risk that it mitigates.',
          },
        }
      ));
    }
  }

  return findings;
}

// ── Audit 5b: Risk-Control Reconciliation ─────────────────────────────────────
// Corrective Action #10: Reconcile risks without controls against the existing
// master control library and the new 144-control Finance and IT expansion.
// Deduplicate against existing controls before proposing new records.
// Corrective Action #11: Present proposed risk-control associations for approval,
// showing the risk scenario, control mechanism, evidence expectation, operational
// context and matching rationale.

function auditRiskControlReconciliation(risks, controls, processes) {
  const findings = [];

  // Requirement #2: Classify controls as master library vs expansion.
  const expansionControls = controls.filter(c => {
    if (!isControlReferenceValid(c)) return false;
    return (c.control_id && c.control_id.startsWith('EVI-SIM-')) ||
           c.library_status === 'draft' ||
           (c.status === 'draft' && !c.is_library_control && !c.global);
  });
  const masterControls = controls.filter(c => {
    if (!isControlReferenceValid(c)) return false;
    return !expansionControls.includes(c);
  });

  // Pre-compute control tokens for efficient domain pre-filtering
  const masterWithTokens = masterControls.map(c => ({
    ctrl: c,
    tokens: tokenize(`${c.title} ${c.description || ''} ${c.category || ''}`),
    domainText: `${c.category || ''} ${c.title || ''}`.toLowerCase(),
  }));
  const expansionWithTokens = expansionControls.map(c => ({
    ctrl: c,
    tokens: tokenize(`${c.title} ${c.description || ''} ${c.category || ''}`),
    domainText: `${c.category || ''} ${c.title || ''}`.toLowerCase(),
  }));

  // Build a set of control IDs already linked to risks (for deduplication)
  const linkedControlIds = new Set();
  for (const r of risks) {
    for (const cid of r.control_ids || []) linkedControlIds.add(cid);
  }

  // Requirement #1: Consolidate two risk-control findings per risk into a SINGLE
  // remediation case containing BOTH matching proposals (master + expansion).
  for (const r of risks) {
    const ctrlIds = r.control_ids || [];
    if (ctrlIds.length > 0) continue; // Already has controls

    const appl = riskControlApplicability(r);
    if (appl === 'not_applicable') continue;

    // Search master library (deduplicate against existing links)
    // Optimized: use pre-computed tokens and skip controls with zero domain overlap
    let bestMaster = null;
    let bestMasterScore = 0;
    let bestMasterRationale = '';
    const riskDomainText = `${r.value_chain || ''} ${r.workstream || ''} ${r.sub_process || ''} ${r.process_activity || ''}`.toLowerCase();
    for (const mc of masterWithTokens) {
      const c = mc.ctrl;
      if (linkedControlIds.has(c.id)) continue;
      // Quick domain pre-filter: skip if no shared domain keywords
      const domain = domainOverlap(r, c);
      if (!domain.overlap && domain.score === 0) continue;
      const mechanismOk = isMechanismAppropriate(r, c);
      let score = 0;
      if (mechanismOk) score += 30;
      score += Math.round(domain.score * 0.4);
      // Only compute similarity if domain overlap is positive (expensive op)
      const sim = similarity(`${r.title} ${r.description || ''}`, `${c.title} ${c.description || ''}`);
      score += Math.round(sim * 0.3);
      if (score > bestMasterScore) {
        bestMasterScore = score;
        bestMaster = c;
        bestMasterRationale = `${mechanismOk ? 'Mechanism appropriate' : 'Mechanism may not be ideal'}; ${domain.reason}; text similarity ${sim}%`;
      }
    }

    // Search expansion library
    let bestExpansion = null;
    let bestExpansionScore = 0;
    let bestExpansionRationale = '';
    for (const ec of expansionWithTokens) {
      const c = ec.ctrl;
      if (linkedControlIds.has(c.id)) continue;
      const domain = domainOverlap(r, c);
      if (!domain.overlap && domain.score === 0) continue;
      const mechanismOk = isMechanismAppropriate(r, c);
      let score = 0;
      if (mechanismOk) score += 30;
      score += Math.round(domain.score * 0.4);
      const sim = similarity(`${r.title} ${r.description || ''}`, `${c.title} ${c.description || ''}`);
      score += Math.round(sim * 0.3);
      if (score > bestExpansionScore) {
        bestExpansionScore = score;
        bestExpansion = c;
        bestExpansionRationale = `${mechanismOk ? 'Mechanism appropriate' : 'Mechanism may not be ideal'}; ${domain.reason}; text similarity ${sim}%`;
      }
    }

    const threshold = 35;
    const hasMaster = bestMaster && bestMasterScore >= threshold;
    const hasExpansion = bestExpansion && bestExpansionScore >= threshold;

    if (!hasMaster && !hasExpansion) continue; // No match — "missing" finding from auditRiskControl

    // Build consolidated proposals array (both matches in one finding)
    const proposals = [];
    if (hasMaster) {
      const mechanism = classifyControlMechanism(bestMaster);
      proposals.push({
        source: 'master_library',
        control_id: bestMaster.id,
        control_reference: bestMaster.control_id,
        control_title: bestMaster.title,
        score: bestMasterScore,
        mechanism: `${mechanism.mechanism_type} / ${mechanism.execution} / ${mechanism.frequency}`,
        governance: mechanism.is_governance,
        rationale: bestMasterRationale,
        deduplicated: true,
        existing_id: null, // No existing link
        proposed_id: bestMaster.id,
      });
    }
    if (hasExpansion) {
      const mechanism = classifyControlMechanism(bestExpansion);
      proposals.push({
        source: 'expansion_library',
        control_id: bestExpansion.id,
        control_reference: bestExpansion.control_id,
        control_title: bestExpansion.title,
        score: bestExpansionScore,
        mechanism: `${mechanism.mechanism_type} / ${mechanism.execution} / ${mechanism.frequency}`,
        governance: mechanism.is_governance,
        rationale: bestExpansionRationale,
        deduplicated: false,
        expansion_control_status: bestExpansion.status || bestExpansion.library_status || 'draft',
        existing_id: null,
        proposed_id: bestExpansion.id,
      });
    }

    // Prefer master library match for the primary proposal
    const primary = hasMaster ? bestMaster : bestExpansion;
    const primaryScore = hasMaster ? bestMasterScore : bestExpansionScore;
    const primaryMechanism = classifyControlMechanism(primary);
    const primaryRationale = hasMaster ? bestMasterRationale : bestExpansionRationale;

    findings.push(makeFinding(
      'risk_control', 'proposed_association', appl === 'optional' ? 'medium' : 'high',
      rec(r.id, r.title, r.risk_reference_nr, 'Risk'),
      rec(primary.id, primary.title, primary.control_id, 'Control'),
      'No controls linked — consolidated remediation case',
      hasMaster
        ? `Link to existing master control "${primary.title}" (${primary.control_id})`
        : `Link to expansion control "${primary.title}" (${primary.control_id}) — approve expansion import first`,
      `Risk "${r.title}" has no controls. Consolidated remediation case with ${proposals.length} proposal(s): ${proposals.map(p => `${p.source === 'master_library' ? 'master' : 'expansion'} (${p.score}%)`).join(' + ')}. Reconciled against ${masterControls.length} master + ${expansionControls.length} expansion controls.`,
      55 + primaryScore,
      {
        applicability: appl,
        category: 'semantic',
        proposed_association: {
          risk_scenario: r.risk_statement || r.title,
          risk_category: r.category,
          control_mechanism: `${primaryMechanism.mechanism_type} / ${primaryMechanism.execution} / ${primaryMechanism.frequency}`,
          control_governance: primaryMechanism.is_governance,
          evidence_expectation: primary.description?.slice(0, 200) || 'See control description',
          operational_context: `${r.value_chain || 'Unassigned'} → ${r.sub_process || r.process_activity || 'Unassigned'}`,
          matching_rationale: primaryRationale,
          source: hasMaster ? 'master_library' : 'expansion_library',
          deduplicated: hasMaster,
          // Requirement #1: both proposals in one remediation case
          proposals: proposals,
          master_controls_searched: masterControls.length,
          expansion_controls_searched: expansionControls.length,
        },
        validation_detail: {
          rule: 'risk_control_consolidated_remediation',
          source_value: r.id,
          target_value: primary.id,
          source_fields: { title: r.title, risk_reference_nr: r.risk_reference_nr, category: r.category, value_chain: r.value_chain },
          target_fields: { title: primary.title, control_id: primary.control_id, control_type: primary.control_type, library_status: primary.library_status, id: primary.id },
          evidence: `Consolidated remediation case. Master match: ${hasMaster ? bestMasterScore + '%' : 'none'}. Expansion match: ${hasExpansion ? bestExpansionScore + '%' : 'none'}. Searched ${masterControls.length} master + ${expansionControls.length} expansion controls.`,
          resolution: hasMaster
            ? `Link existing master control "${primary.title}" to this risk — no new record needed.`
            : `Approve the expansion control "${primary.title}" via the Control Expansion Import, then link it to this risk.`,
        },
      }
    ));
  }

  return findings;
}

// ── Metrics computation ───────────────────────────────────────────────────────
// Corrective Action #12: Recalculate relationship completeness and quality only
// after validating the full source population and applicable relationship rules.

function computeMetrics(valueChains, workstreams, processes, stakeholders, risks, controls, findings) {
  const byType = (auditType) => findings.filter(f => f.audit_type === auditType);

  const applicableVCs = valueChains.filter(vc => valueChainWorkstreamApplicability(vc) !== 'not_applicable');
  const applicableWSs = workstreams.filter(ws => workstreamProcessApplicability(ws) !== 'not_applicable');
  const mandatoryProcs = processes.filter(p => processOwnerApplicability(p) === 'mandatory');
  const applicableProcs = processes.filter(p => processOwnerApplicability(p) !== 'not_applicable');
  const mandatoryProcsForRisk = processes.filter(p => processRiskApplicability(p) === 'mandatory');
  const applicableRisks = risks.filter(r => riskControlApplicability(r) !== 'not_applicable');

  const vcWithWs = applicableVCs.filter(vc =>
    workstreams.some(ws => ws.value_chain_id === vc.id)
  ).length;
  const wsWithProc = applicableWSs.filter(ws =>
    processes.some(p => p.workstream_id === ws.id)
  ).length;
  const procWithOwner = applicableProcs.filter(p =>
    p.process_owner_stakeholder_id || p.process_owner
  ).length;
  const procWithRisk = mandatoryProcsForRisk.filter(p =>
    (p.linked_risk_ids || []).length > 0
  ).length;
  const riskWithCtrl = applicableRisks.filter(r =>
    (r.control_ids || []).length > 0
  ).length;

  const completeness = {
    value_chain_workstream: {
      total: applicableVCs.length,
      excluded_not_applicable: valueChains.length - applicableVCs.length,
      with_relationship: vcWithWs,
      percentage: applicableVCs.length ? Math.round(vcWithWs / applicableVCs.length * 100) : 100,
    },
    workstream_process: {
      total: applicableWSs.length,
      excluded_not_applicable: workstreams.length - applicableWSs.length,
      with_relationship: wsWithProc,
      percentage: applicableWSs.length ? Math.round(wsWithProc / applicableWSs.length * 100) : 100,
    },
    process_stakeholder: {
      total: applicableProcs.length,
      excluded_not_applicable: processes.length - applicableProcs.length,
      with_relationship: procWithOwner,
      percentage: applicableProcs.length ? Math.round(procWithOwner / applicableProcs.length * 100) : 100,
    },
    process_risk: {
      total: mandatoryProcsForRisk.length,
      excluded_not_applicable: processes.length - mandatoryProcsForRisk.length,
      with_relationship: procWithRisk,
      percentage: mandatoryProcsForRisk.length ? Math.round(procWithRisk / mandatoryProcsForRisk.length * 100) : 100,
    },
    risk_control: {
      total: applicableRisks.length,
      excluded_not_applicable: risks.length - applicableRisks.length,
      with_relationship: riskWithCtrl,
      percentage: applicableRisks.length ? Math.round(riskWithCtrl / applicableRisks.length * 100) : 100,
    },
  };

  const quality = {};
  const auditTypes = ['value_chain_workstream', 'workstream_process', 'process_stakeholder', 'process_risk', 'risk_control'];
  for (const at of auditTypes) {
    const typeFindings = byType(at);
    const technicalFlagged = typeFindings.filter(f =>
      f.validation_category === 'technical' && (f.finding_type === 'invalid' || f.finding_type === 'duplicate')
    ).length;
    const semanticFlagged = typeFindings.filter(f =>
      f.validation_category === 'semantic' && f.finding_type === 'semantic_mismatch'
    ).length;

    let totalRel = completeness[at].with_relationship;
    const technicallyValid = Math.max(0, totalRel - technicalFlagged);
    const semanticallyValid = Math.max(0, totalRel - semanticFlagged);

    quality[at] = {
      total_relationships: totalRel,
      technical_integrity: {
        flagged: technicalFlagged,
        valid: technicallyValid,
        percentage: totalRel > 0 ? Math.round(technicallyValid / totalRel * 100) : 100,
      },
      semantic_relevance: {
        flagged: semanticFlagged,
        valid: semanticallyValid,
        percentage: totalRel > 0 ? Math.round(semanticallyValid / totalRel * 100) : 100,
      },
      flagged: technicalFlagged,
      valid: technicallyValid,
      percentage: totalRel > 0 ? Math.round(technicallyValid / totalRel * 100) : 100,
    };
  }

  const compValues = Object.values(completeness).map(c => c.percentage);
  const techValues = Object.values(quality).map(q => q.technical_integrity.percentage);
  const semValues = Object.values(quality).map(q => q.semantic_relevance.percentage);
  const overallCompleteness = Math.round(compValues.reduce((a, b) => a + b, 0) / compValues.length);
  const overallTech = Math.round(techValues.reduce((a, b) => a + b, 0) / techValues.length);
  const overallSem = Math.round(semValues.reduce((a, b) => a + b, 0) / semValues.length);

  return {
    completeness: { ...completeness, overall: { percentage: overallCompleteness } },
    quality: {
      ...quality,
      overall: {
        technical_integrity: { percentage: overallTech },
        semantic_relevance: { percentage: overallSem },
        percentage: overallTech,
      },
    },
  };
}

// ── Reconciliation report ─────────────────────────────────────────────────────
// Corrective Action: Produce a revised audit and reconciliation report containing
// genuine defects, false positives, approved corrections and outstanding decisions.

function buildReconciliationReport(findings, recordCounts) {
  const genuineDefects = findings.filter(f =>
    f.validation_category === 'technical' &&
    (f.finding_type === 'invalid' || f.finding_type === 'duplicate')
  );

  const falsePositives = findings.filter(f =>
    f.finding_type === 'semantic_mismatch' &&
    f.confidence_score < 50
  );

  const approvedCorrections = findings.filter(f =>
    f.finding_type === 'recommended' || f.finding_type === 'proposed_association'
  );

  const outstandingDecisions = findings.filter(f =>
    f.finding_type === 'missing' || f.finding_type === 'over_assignment'
  );

  return {
    genuine_defects: {
      count: genuineDefects.length,
      description: 'Technical integrity issues — broken references, duplicates, inactive stakeholders',
      items: genuineDefects.map(f => ({ id: f.id, severity: f.severity, audit_type: f.audit_type, summary: f.existing_relationship, resolution: f.validation_detail?.resolution })),
    },
    false_positives: {
      count: falsePositives.length,
      description: 'Semantic advisories with low confidence — likely valid relationships flagged due to text similarity or group membership checks (now removed)',
      items: falsePositives.map(f => ({ id: f.id, severity: f.severity, audit_type: f.audit_type, summary: f.existing_relationship, reason: f.justification })),
    },
    approved_corrections: {
      count: approvedCorrections.length,
      description: 'Recommended matches and proposed associations ready for approval — mechanism-based, deduplicated against existing controls',
      items: approvedCorrections.map(f => ({
        id: f.id,
        severity: f.severity,
        audit_type: f.audit_type,
        source: f.source_record?.name,
        target: f.target_record?.name,
        proposed: f.proposed_relationship,
        association: f.proposed_association,
      })),
    },
    outstanding_decisions: {
      count: outstandingDecisions.length,
      description: 'Missing relationships and over-assignments requiring human review — do not auto-resolve',
      items: outstandingDecisions.map(f => ({ id: f.id, severity: f.severity, audit_type: f.audit_type, summary: f.existing_relationship, resolution: f.validation_detail?.resolution })),
    },
  };
}

// ── Remediation case grouping (Requirement #9) ────────────────────────────────
// Group related findings into unique remediation cases keyed by the affected
// source record. Show both raw finding count and distinct affected-record count.

function buildRemediationCases(findings) {
  const caseMap = {};
  for (const f of findings) {
    const key = f.source_record?.id || f.id;
    if (!key) continue;
    if (!caseMap[key]) {
      caseMap[key] = {
        case_id: `RC-${String(Object.keys(caseMap).length + 1).padStart(4, '0')}`,
        source_record: f.source_record,
        audit_type: f.audit_type,
        finding_ids: [],
        finding_count: 0,
        severities: new Set(),
        finding_types: new Set(),
        has_proposed_change: false,
        max_confidence: 0,
      };
    }
    const rc = caseMap[key];
    rc.finding_ids.push(f.id);
    rc.finding_count++;
    rc.severities.add(f.severity);
    rc.finding_types.add(f.finding_type);
    if (f.proposed_relationship) rc.has_proposed_change = true;
    rc.max_confidence = Math.max(rc.max_confidence, f.confidence_score);
  }

  const cases = Object.values(caseMap).map(rc => ({
    ...rc,
    severities: Array.from(rc.severities),
    finding_types: Array.from(rc.finding_types),
  }));

  return {
    total_cases: cases.length,
    raw_finding_count: findings.length,
    distinct_affected_records: cases.length,
    cases_with_proposed_changes: cases.filter(c => c.has_proposed_change).length,
    cases: cases.sort((a, b) => b.max_confidence - a.max_confidence),
  };
}

// ── Change preview (Requirement #10) ─────────────────────────────────────────
// Provide a preview of proposed changes with existing and proposed IDs,
// confidence, justification and approval controls. Do not auto-apply.

function buildChangePreview(findings) {
  const preview = findings
    .filter(f => f.finding_type === 'recommended' || f.finding_type === 'proposed_association')
    .map(f => ({
      finding_id: f.id,
      audit_type: f.audit_type,
      source_record: f.source_record,
      target_record: f.target_record,
      existing_relationship: f.existing_relationship,
      proposed_relationship: f.proposed_relationship,
      confidence: f.confidence_score,
      justification: f.justification,
      severity: f.severity,
      applicability: f.applicability,
      validation_category: f.validation_category,
      proposed_association: f.proposed_association,
      requires_approval: true,
      auto_apply: false,
      approval_status: 'pending',
    }));

  return {
    total_proposed_changes: preview.length,
    by_confidence: {
      high: preview.filter(p => p.confidence >= 80).length,
      medium: preview.filter(p => p.confidence >= 60 && p.confidence < 80).length,
      low: preview.filter(p => p.confidence < 60).length,
    },
    changes: preview,
    note: 'Preview only — no approved records are automatically modified. Review each proposed change and approve individually or in bulk.',
  };
}

// ── Main handler ─────────────────────────────────────────────────────────────

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const companyId = body?.company_id;
    if (!companyId) return Response.json({ error: 'company_id is required' }, { status: 400 });

    // Corrective Action #1: Load ALL entities through pagination — no 1,000 record limit
    const [valueChains, workstreams, processes, stakeholders, stakeholderGroups, risks, company] = await Promise.all([
      fetchAll(base44.asServiceRole.entities.ValueChain, { company_id: companyId }, { limit: 500, sort: 'name' }),
      fetchAll(base44.asServiceRole.entities.Workstream, { company_id: companyId }, { limit: 500, sort: 'name' }),
      fetchAll(base44.asServiceRole.entities.OrgProcess, { company_id: companyId }, { limit: 500, sort: 'process_code' }),
      fetchAll(base44.asServiceRole.entities.Stakeholder, { company_id: companyId }, { limit: 500, sort: 'full_name' }),
      fetchAll(base44.asServiceRole.entities.StakeholderGroup, { company_id: companyId }, { limit: 200, sort: 'name' }),
      fetchAll(base44.asServiceRole.entities.Risk, { company_id: companyId }, { limit: 500, sort: 'risk_reference_nr' }),
      base44.asServiceRole.entities.Company.get(companyId),
    ]);

    // Collect control IDs from risks and processes
    const controlIdSet = new Set();
    for (const r of risks) (r.control_ids || []).forEach(id => controlIdSet.add(id));
    for (const p of processes) (p.linked_control_ids || []).forEach(id => controlIdSet.add(id));

    // Also get controls from company's frameworks
    const frameworkIds = (company?.framework_assignments || []).map(fa => fa.framework_id).filter(Boolean);

    // Requirement #2: Load the COMPLETE control library — master library controls
    // (is_library_control / global), ALL company-specific controls (including the
    // 144 Finance/IT expansion regardless of library_status), framework-linked
    // controls, and controls already referenced by risks/processes.
    // Optimized: only fetch fields needed for matching, exclude retired controls.
    const controlFields = ['id', 'control_id', 'title', 'description', 'category', 'control_type',
      'control_execution_type', 'control_frequency', 'process_phase', 'status', 'library_status',
      'is_library_control', 'global', 'company_id', 'framework_id'];
    const controlFetches = [];
    // 1. Controls already referenced by risks/processes
    if (controlIdSet.size > 0) {
      controlFetches.push(
        fetchAll(base44.asServiceRole.entities.Control, { id: { $in: Array.from(controlIdSet) } }, { limit: 500, fields: controlFields })
      );
    }
    // 2. Master library controls — active only (exclude retired to reduce volume)
    controlFetches.push(
      fetchAll(base44.asServiceRole.entities.Control,
        { is_library_control: true, library_status: { $ne: 'retired' } },
        { limit: 500, fields: controlFields })
    );
    // 3. ALL company-specific controls (includes expansion controls regardless of library_status)
    controlFetches.push(
      fetchAll(base44.asServiceRole.entities.Control, { company_id: companyId }, { limit: 500, fields: controlFields })
    );
    // 4. Controls linked to frameworks assigned to the company
    if (frameworkIds.length > 0) {
      controlFetches.push(
        fetchAll(base44.asServiceRole.entities.Control, { framework_id: { $in: frameworkIds } }, { limit: 500, fields: controlFields })
      );
    }

    const controlResults = await Promise.all(controlFetches);
    const seenCtrl = new Set();
    const controls = [];
    for (const list of controlResults) {
      for (const c of list) {
        if (!seenCtrl.has(c.id)) { seenCtrl.add(c.id); controls.push(c); }
      }
    }

    // Reset finding counter
    findingCounter = 0;

    // Run all audits (including new over-assignment and reconciliation audits)
    const findings = [
      ...auditValueChainWorkstream(valueChains, workstreams, company),
      ...auditWorkstreamProcess(workstreams, processes),
      ...auditProcessStakeholder(processes, stakeholders, stakeholderGroups, valueChains),
      ...auditStakeholderOverAssignment(processes, stakeholders, valueChains),
      ...auditProcessRisk(processes, risks),
      ...auditRiskControl(risks, controls, processes),
      ...auditRiskControlReconciliation(risks, controls, processes),
    ];

    // Sort findings: high → medium → low, then by confidence descending
    const severityOrder = { high: 0, medium: 1, low: 2 };
    findings.sort((a, b) => {
      const s = (severityOrder[a.severity] || 9) - (severityOrder[b.severity] || 9);
      if (s !== 0) return s;
      return b.confidence_score - a.confidence_score;
    });

    // Corrective Action #12: Compute metrics after full validation
    const metrics = computeMetrics(valueChains, workstreams, processes, stakeholders, risks, controls, findings);

    // Build reconciliation report
    const reconciliationReport = buildReconciliationReport(findings, {
      value_chains: valueChains.length,
      workstreams: workstreams.length,
      processes: processes.length,
      risks: risks.length,
      controls: controls.length,
    });

    // Requirement #9: Group related findings into unique remediation cases.
    // Show both raw finding count and distinct affected-record count.
    const remediationCases = buildRemediationCases(findings);

    // Requirement #10: Provide a preview of proposed changes with existing
    // and proposed IDs, confidence, justification and approval controls.
    const changePreview = buildChangePreview(findings);

    // Summary
    const bySeverity = { high: 0, medium: 0, low: 0 };
    const byAuditType = {};
    const byFindingType = {};
    const byValidationCategory = { technical: 0, semantic: 0 };
    const byApplicability = { mandatory: 0, optional: 0, not_applicable: 0 };
    for (const f of findings) {
      bySeverity[f.severity]++;
      byAuditType[f.audit_type] = (byAuditType[f.audit_type] || 0) + 1;
      byFindingType[f.finding_type] = (byFindingType[f.finding_type] || 0) + 1;
      if (f.validation_category) byValidationCategory[f.validation_category]++;
      if (f.applicability) byApplicability[f.applicability]++;
    }

    return Response.json({
      company_id: companyId,
      company_name: company?.name || '',
      audited_at: new Date().toISOString(),
      record_counts: {
        value_chains: valueChains.length,
        workstreams: workstreams.length,
        processes: processes.length,
        stakeholders: stakeholders.length,
        stakeholder_groups: stakeholderGroups.length,
        risks: risks.length,
        controls: controls.length,
        expansion_controls: controls.filter(c => c.library_status === 'draft' || (c.control_id && c.control_id.startsWith('EVI-SIM-'))).length,
      },
      pagination: {
        fully_paginated: true,
        note: 'All entity populations retrieved through cursor-based pagination — no 1,000 record limit',
      },
      metrics,
      findings,
      reconciliation_report: reconciliationReport,
      remediation_cases: remediationCases,
      change_preview: changePreview,
      control_library_breakdown: {
        total_controls: controls.length,
        master_library_controls: controls.filter(c => c.is_library_control || c.global).length,
        company_controls: controls.filter(c => c.company_id === companyId && !c.is_library_control && !c.global).length,
        expansion_controls: controls.filter(c =>
          (c.control_id && c.control_id.startsWith('EVI-SIM-')) ||
          c.library_status === 'draft' ||
          (c.status === 'draft' && !c.is_library_control && !c.global)
        ).length,
        invalid_controls_rejected: controls.filter(c => !isControlReferenceValid(c)).length,
      },
      summary: {
        total_findings: findings.length,
        by_severity: bySeverity,
        by_audit_type: byAuditType,
        by_finding_type: byFindingType,
        by_validation_category: byValidationCategory,
        by_applicability: byApplicability,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}