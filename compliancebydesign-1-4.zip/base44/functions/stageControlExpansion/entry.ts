import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import {
  normalizeText, jaccardSimilarity, bestMatch,
  validateEnum, parseCSV, resolveOwnerRole,
} from "../../shared/controlExpansionUtils.ts";

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { file_url, company_id } = await req.json();
    if (!file_url || !company_id) {
      return Response.json({ error: 'file_url and company_id required' }, { status: 400 });
    }

    // 1. Fetch and parse CSV
    const fileRes = await fetch(file_url, { signal: AbortSignal.timeout(15000) });
    if (!fileRes.ok) return Response.json({ error: 'Failed to fetch CSV file' }, { status: 400 });
    const csvText = await fileRes.text();
    const rows = parseCSV(csvText);
    console.log(`Parsed ${rows.length} CSV rows`);

    if (rows.length === 0) {
      return Response.json({ error: 'No rows found in CSV' }, { status: 400 });
    }

    // 2. Load reference data
    const [frameworks, stakeholders, stakeholderGroups, controlObjectives, processes, valueChains, risks] = await Promise.all([
      base44.asServiceRole.entities.Framework.filter({ is_master: true }, { limit: 100, fields: ['id', 'name', 'framework_code'] }),
      base44.asServiceRole.entities.Stakeholder.filter({ company_id, status: 'active' }, { limit: 500, fields: ['id', 'full_name', 'job_title', 'department'] }),
      base44.asServiceRole.entities.StakeholderGroup.filter({ company_id, status: 'active' }, { limit: 100, fields: ['id', 'name'] }),
      base44.asServiceRole.entities.ControlObjective.filter({}, { limit: 500, fields: ['id', 'reference_number', 'title', 'control_statement', 'category'] }),
      base44.asServiceRole.entities.OrgProcess.filter({ company_id, level: { $in: [3, 4] } }, { limit: 500, fields: ['id', 'process_code', 'name', 'value_chain_id', 'value_chain', 'workstream'] }),
      base44.asServiceRole.entities.ValueChain.filter({ company_id }, { limit: 200, fields: ['id', 'value_chain_code', 'name', 'management_chain'] }),
      base44.asServiceRole.entities.Risk.filter({ company_id }, { limit: 200, fields: ['id', 'risk_reference_nr', 'title', 'risk_statement', 'category', 'value_chain'] }),
    ]);

    const frameworkList = frameworks.items || [];
    const stakeholderList = stakeholders.items || [];
    const groupList = stakeholderGroups.items || [];
    const objectiveList = controlObjectives.items || [];
    const processList = processes.items || [];
    const vcList = valueChains.items || [];
    const riskList = risks.items || [];

    // 3. Load existing library controls (paginated)
    let allLibraryControls = [];
    let cursor = undefined;
    let page = null;
    do {
      page = await base44.asServiceRole.entities.Control.filter(
        { is_library_control: true },
        { limit: 500, fields: ['id', 'control_id', 'title', 'description', 'category', 'control_owner', 'framework_id'], cursor }
      );
      allLibraryControls = allLibraryControls.concat(page.items || []);
      cursor = page.next_cursor;
    } while (cursor && page.has_more);
    console.log(`Loaded ${allLibraryControls.length} library controls`);

    // Also load any existing company controls
    const companyControlsRes = await base44.asServiceRole.entities.Control.filter(
      { company_id },
      { limit: 500, fields: ['id', 'control_id', 'title', 'description', 'category', 'control_owner', 'framework_id'] }
    );
    const companyControls = companyControlsRes.items || [];

    // 4. Build framework map (by code, lowercased)
    const frameworkByCode = new Map();
    for (const fw of frameworkList) {
      if (fw.framework_code) frameworkByCode.set(fw.framework_code.toLowerCase().trim(), fw);
      if (fw.name) frameworkByCode.set(fw.name.toLowerCase().trim(), fw);
    }
    // Add common aliases
    const ifrs = frameworkList.find(f => (f.framework_code || '').toLowerCase().includes('ifrs'));
    if (ifrs) frameworkByCode.set('ifrs', ifrs);
    const soxItgc = frameworkList.find(f => (f.framework_code || '').toLowerCase().includes('sox itgc'));
    if (soxItgc) frameworkByCode.set('sox itgc', soxItgc);
    const soxFin = frameworkList.find(f => (f.framework_code || '').toLowerCase().includes('sox finance'));
    if (soxFin) frameworkByCode.set('sox finance', soxFin);

    // 5. Build value chain candidates for matching
    const vcCandidates = vcList.map(vc => ({
      id: vc.id,
      code: vc.value_chain_code,
      name: vc.name,
      chain: vc.management_chain,
      text: `${vc.name} ${vc.management_chain || ''} ${vc.value_chain_code || ''}`,
    }));

    // 6. Build process candidates
    const processCandidates = processList.map(p => ({
      id: p.id,
      code: p.process_code,
      name: p.name,
      vc: p.value_chain,
      text: `${p.name} ${p.process_code || ''}`,
    }));

    // 7. Build risk candidates
    const riskCandidates = riskList.map(r => ({
      id: r.id,
      ref: r.risk_reference_nr,
      title: r.title,
      statement: r.risk_statement,
      text: `${r.title} ${r.risk_statement || ''}`,
    }));

    // 8. Build objective candidates
    const objectiveCandidates = objectiveList.map(o => ({
      id: o.id,
      ref: o.reference_number,
      title: o.title,
      statement: o.control_statement,
      text: `${o.title} ${o.control_statement || ''}`,
    }));

    // 9. Process each CSV row
    const items = [];
    for (const row of rows) {
      const control_id = (row.control_id || '').trim();
      const title = (row.title || '').trim();
      const description = (row.description || '').trim();
      const fn = (row.function || '').trim();
      const domain = (row.domain || '').trim();
      const category = (row.category || '').trim();
      const controlOwner = (row.control_owner || '').trim();
      const proposedOwnerRole = (row.proposed_owner_role || '').trim();
      const proposedObjective = (row.proposed_control_objective || '').trim();
      const proposedRisk = (row.proposed_risk_statement || '').trim();
      const expectedEvidence = (row.expected_evidence || '').trim();
      const changeType = (row.change_type || '').trim();
      const simulationFlag = (row.simulation_flag || '').trim().toLowerCase() === 'true';
      const reviewRequired = (row.review_required || '').trim().toLowerCase() === 'yes';
      const possibleSimilar = (row.possible_existing_similar_title || '').trim();

      // --- Framework resolution ---
      let framework_id = '';
      let framework_name = '';
      if (row.framework_id && frameworkByCode.has(row.framework_id.toLowerCase().trim())) {
        const fw = frameworkByCode.get(row.framework_id.toLowerCase().trim());
        framework_id = fw.id;
        framework_name = fw.name;
      } else {
        // Infer from function
        const fnLower = fn.toLowerCase();
        if (fnLower.includes('finance')) {
          const fw = frameworkByCode.get('ifrs') || frameworkByCode.get('sox finance');
          if (fw) { framework_id = fw.id; framework_name = fw.name; }
        } else if (fnLower.includes('it') || fnLower.includes('technology')) {
          const fw = frameworkByCode.get('sox itgc') || frameworkByCode.get('cobit5');
          if (fw) { framework_id = fw.id; framework_name = fw.name; }
        }
      }

      // --- Enum validation ---
      const validationIssues = [];
      const execResult = validateEnum('control_execution_type', row.control_execution_type);
      if (!execResult.valid) validationIssues.push({ field: 'control_execution_type', csv_value: row.control_execution_type, suggested: execResult.suggestedValue });
      const freqResult = validateEnum('control_frequency', row.control_frequency);
      if (!freqResult.valid) validationIssues.push({ field: 'control_frequency', csv_value: row.control_frequency, suggested: freqResult.suggestedValue });
      const phaseResult = validateEnum('process_phase', row.process_phase);
      if (!phaseResult.valid) validationIssues.push({ field: 'process_phase', csv_value: row.process_phase, suggested: phaseResult.suggestedValue });
      const typeResult = validateEnum('control_type', row.control_type);
      if (!typeResult.valid) validationIssues.push({ field: 'control_type', csv_value: row.control_type, suggested: typeResult.suggestedValue });
      const critResult = validateEnum('control_criticality', row.control_criticality);
      if (!critResult.valid) validationIssues.push({ field: 'control_criticality', csv_value: row.control_criticality, suggested: critResult.suggestedValue });
      if (!framework_id) validationIssues.push({ field: 'framework_id', csv_value: row.framework_id, suggested: framework_name || 'Unresolved' });

      // --- Duplicate detection (semantic match against library + company controls) ---
      let duplicateMatch = null;
      const allExisting = [...allLibraryControls, ...companyControls];
      // If CSV has a possible_existing_similar_title hint, boost that
      let bestDupScore = 0;
      let bestDup = null;
      for (const ec of allExisting) {
        const titleSim = jaccardSimilarity(title, ec.title);
        let score = titleSim;
        // Boost if possible_existing_similar_title matches
        if (possibleSimilar && normalizeText(ec.title).includes(normalizeText(possibleSimilar))) {
          score += 0.2;
        }
        if (score > bestDupScore) {
          bestDupScore = score;
          bestDup = { existing_id: ec.id, existing_control_id: ec.control_id, existing_title: ec.title, existing_category: ec.category, existing_owner: ec.control_owner, similarity: Math.round(score * 100) };
        }
      }
      if (bestDup && bestDupScore >= 0.35) {
        const recommendation = bestDupScore >= 0.6 ? 'high_confidence_duplicate' : bestDupScore >= 0.45 ? 'likely_duplicate' : 'possible_duplicate';
        duplicateMatch = { ...bestDup, recommendation };
      }

      // --- Owner role resolution ---
      const ownerText = controlOwner || proposedOwnerRole;
      const ownerResolution = resolveOwnerRole(ownerText, stakeholderList, groupList);

      // --- Control objective link proposal ---
      let objectiveLink = { proposed_text: proposedObjective, match: null, status: 'unmatched' };
      if (proposedObjective) {
        const match = bestMatch(proposedObjective, objectiveCandidates, 0.3);
        if (match) {
          objectiveLink = { proposed_text: proposedObjective, match: { id: match.id, ref: match.ref, title: match.title }, status: 'matched', score: Math.round(match.score * 100) };
        }
      }

      // --- Value chain link proposal ---
      let vcLink = { proposed_function: fn, proposed_domain: domain, match: null, status: 'unmatched' };
      const vcQuery = `${fn} ${domain} ${category}`;
      const vcMatch = bestMatch(vcQuery, vcCandidates, 0.25);
      if (vcMatch) {
        vcLink = { proposed_function: fn, proposed_domain: domain, match: { id: vcMatch.id, code: vcMatch.code, name: vcMatch.name, chain: vcMatch.chain }, status: 'matched', score: Math.round(vcMatch.score * 100) };
      }

      // --- Process link proposal ---
      let processLink = { proposed_category: category, proposed_domain: domain, match: null, status: 'unmatched' };
      const procQuery = `${category} ${domain} ${fn}`;
      const procMatch = bestMatch(procQuery, processCandidates, 0.2);
      if (procMatch) {
        processLink = { proposed_category: category, proposed_domain: domain, match: { id: procMatch.id, code: procMatch.code, name: procMatch.name, vc: procMatch.vc }, status: 'matched', score: Math.round(procMatch.score * 100) };
      }

      // --- Risk-control match candidate (advisory only, no auto-link) ---
      let riskMatch = { proposed_statement: proposedRisk, candidates: [], status: 'none' };
      if (proposedRisk) {
        const matches = [];
        for (const r of riskCandidates) {
          const score = jaccardSimilarity(proposedRisk, r.text);
          if (score >= 0.15) {
            matches.push({ id: r.id, ref: r.ref, title: r.title, score: Math.round(score * 100) });
          }
        }
        matches.sort((a, b) => b.score - a.score);
        if (matches.length > 0) {
          riskMatch = { proposed_statement: proposedRisk, candidates: matches.slice(0, 3), status: 'candidate' };
        }
      }

      // --- Determine action ---
      let action = 'create';
      if (duplicateMatch && (duplicateMatch.recommendation === 'high_confidence_duplicate' || duplicateMatch.recommendation === 'likely_duplicate')) {
        action = 'update_existing';
      }
      if (reviewRequired && validationIssues.length > 2) {
        action = 'skip'; // needs manual review before creating
      }

      // --- Build raw fields (ready for creation) ---
      const rawFields = {
        framework_id,
        control_id,
        title,
        description: description + (expectedEvidence ? `\n\nExpected evidence: ${expectedEvidence}` : '') + (simulationFlag ? '\n\n[SYNTHETIC CONTROL — simulated proposal, not from production evidence]' : ''),
        category: category || domain,
        priority: (row.priority || 'medium').toLowerCase(),
        status: 'draft',
        control_criticality: critResult.valid ? critResult.value : 'Should Have',
        control_owner: controlOwner || proposedOwnerRole,
        key_control: row.key_control === 'true' || row.key_control === true,
        control_execution_type: execResult.valid ? execResult.value : 'Manual',
        control_type: typeResult.valid ? typeResult.value : 'Preventive',
        control_frequency: freqResult.valid ? freqResult.value : 'Monthly',
        process_phase: phaseResult.valid ? phaseResult.value : 'Process - Input',
        is_library_control: false,
        library_status: 'draft',
        control_objective_id: objectiveLink.match?.id || '',
      };

      items.push({
        row_index: items.length,
        control_id,
        title,
        function: fn,
        domain,
        category,
        change_type: changeType,
        simulation_flag: simulationFlag,
        review_required: reviewRequired,
        action,
        validation_issues: validationIssues,
        duplicate_match: duplicateMatch,
        owner_resolution: {
          role_text: ownerText,
          type: ownerResolution.type,
          matches: ownerResolution.matches.slice(0, 3),
        },
        objective_link: objectiveLink,
        process_link: processLink,
        value_chain_link: vcLink,
        risk_match: riskMatch,
        raw_fields: rawFields,
        framework_name,
      });
    }

    // 10. Build summary
    const summary = {
      total: items.length,
      by_action: {
        create: items.filter(i => i.action === 'create').length,
        update_existing: items.filter(i => i.action === 'update_existing').length,
        skip: items.filter(i => i.action === 'skip').length,
      },
      validation_issues: items.filter(i => i.validation_issues.length > 0).length,
      duplicates_found: items.filter(i => i.duplicate_match !== null).length,
      owners_resolved: items.filter(i => i.owner_resolution.type === 'stakeholder' || i.owner_resolution.type === 'group').length,
      owners_ambiguous: items.filter(i => i.owner_resolution.type === 'ambiguous').length,
      owners_unmatched: items.filter(i => i.owner_resolution.type === 'none').length,
      objectives_matched: items.filter(i => i.objective_link.status === 'matched').length,
      processes_matched: items.filter(i => i.process_link.status === 'matched').length,
      value_chains_matched: items.filter(i => i.value_chain_link.status === 'matched').length,
      risk_candidates: items.filter(i => i.risk_match.status === 'candidate').length,
      by_function: {},
    };
    for (const item of items) {
      const fn = item.function || 'Unspecified';
      summary.by_function[fn] = (summary.by_function[fn] || 0) + 1;
    }

    return Response.json({
      company_id,
      staged_at: new Date().toISOString(),
      total_rows: rows.length,
      items,
      summary,
      reference_counts: {
        frameworks: frameworkList.length,
        stakeholders: stakeholderList.length,
        stakeholder_groups: groupList.length,
        control_objectives: objectiveList.length,
        processes: processList.length,
        value_chains: vcList.length,
        risks: riskList.length,
        library_controls: allLibraryControls.length,
        company_controls: companyControls.length,
      },
    });
  } catch (error) {
    console.error('Stage error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}